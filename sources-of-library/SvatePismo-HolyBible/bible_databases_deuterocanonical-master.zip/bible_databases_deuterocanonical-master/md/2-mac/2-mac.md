# 2 Maccabees



**[1:1]** The brethren, the Jews that be at Jerusalem and in the land of Judea, wish unto the brethren, the Jews that are throughout Egypt health and peace:

**[1:2]** God be gracious unto you, and remember his covenant that he made with Abraham, Isaac, and Jacob, his faithful servants;

**[1:3]** And give you all an heart to serve him, and to do his will, with a good courage and a willing mind;

**[1:4]** And open your hearts in his law and commandments, and send you peace,

**[1:5]** And hear your prayers, and be at one with you, and never forsake you in time of trouble.

**[1:6]** And now we be here praying for you.

**[1:7]** What time as Demetrius reigned, in the hundred threescore and ninth year, we the Jews wrote unto you in the extremity of trouble that came upon us in those years, from the time that Jason and his company revolted from the holy land and kingdom,

**[1:8]** And burned the porch, and shed innocent blood: then we prayed unto the Lord, and were heard; we offered also sacrifices and fine flour, and lighted the lamps, and set forth the loaves.

**[1:9]** And now see that ye keep the feast of tabernacles in the month Casleu.

**[1:10]** In the hundred fourscore and eighth year, the people that were at Jerusalem and in Judea, and the council, and Judas, sent greeting and health unto Aristobulus, king Ptolemeus’ master, who was of the stock of the anointed priests, and to the Jews that were in Egypt:

**[1:11]** Insomuch as God hath delivered us from great perils, we thank him highly, as having been in battle against a king.

**[1:12]** For he cast them out that fought within the holy city.

**[1:13]** For when the leader was come into Persia, and the army with him that seemed invincible, they were slain in the temple of Nanea by the deceit of Nanea’s priests.

**[1:14]** For Antiochus, as though he would marry her, came into the place, and his friends that were with him, to receive money in name of a dowry.

**[1:15]** Which when the priests of Nanea had set forth, and he was entered with a small company into the compass of the temple, they shut the temple as soon as Antiochus was come in:

**[1:16]** And opening a privy door of the roof, they threw stones like thunderbolts, and struck down the captain, hewed them in pieces, smote off their heads and cast them to those that were without.

**[1:17]** Blessed be our God in all things, who hath delivered up the ungodly.

**[1:18]** Therefore whereas we are now purposed to keep the purification of the temple upon the five and twentieth day of the month Casleu, we thought it necessary to certify you thereof, that ye also might keep it, as the feast of the tabernacles, and of the fire, which was given us when Neemias offered sacrifice, after that he had builded the temple and the altar.

**[1:19]** For when our fathers were led into Persia, the priests that were then devout took the fire of the altar privily, and hid it in an hollow place of a pit without water, where they kept it sure, so that the place was unknown to all men.

**[1:20]** Now after many years, when it pleased God, Neemias, being sent from the king of Persia, did send of the posterity of those priests that had hid it to the fire: but when they told us they found no fire, but thick water;

**[1:21]** Then commanded he them to draw it up, and to bring it; and when the sacrifices were laid on, Neemias commanded the priests to sprinkle the wood and the things laid thereupon with the water.

**[1:22]** When this was done, and the time came that the sun shone, which afore was hid in the cloud, there was a great fire kindled, so that every man marvelled.

**[1:23]** And the priests made a prayer whilst the sacrifice was consuming, I say, both the priests, and all the rest, Jonathan beginning, and the rest answering thereunto, as Neemias did.

**[1:24]** And the prayer was after this manner; O Lord, Lord God, Creator of all things, who art fearful and strong, and righteous, and merciful, and the only and gracious King,

**[1:25]** The only giver of all things, the only just, almighty, and everlasting, thou that deliverest Israel from all trouble, and didst choose the fathers, and sanctify them:

**[1:26]** Receive the sacrifice for thy whole people Israel, and preserve thine own portion, and sanctify it.

**[1:27]** Gather those together that are scattered from us, deliver them that serve among the heathen, look upon them that are despised and abhorred, and let the heathen know that thou art our God.

**[1:28]** Punish them that oppress us, and with pride do us wrong.

**[1:29]** Plant thy people again in thy holy place, as Moses hath spoken.

**[1:30]** And the priests sung psalms of thanksgiving.

**[1:31]** Now when the sacrifice was consumed, Neemias commanded the water that was left to be poured on the great stones.

**[1:32]** When this was done, there was kindled a flame: but it was consumed by the light that shined from the altar.

**[1:33]** So when this matter was known, it was told the king of Persia, that in the place, where the priests that were led away had hid the fire, there appeared water, and that Neemias had purified the sacrifices therewith.

**[1:34]** Then the king, inclosing the place, made it holy, after he had tried the matter.

**[1:35]** And the king took many gifts, and bestowed thereof on those whom he would gratify.

**[1:36]** And Neemias called this thing Naphthar, which is as much as to say, a cleansing: but many men call it Nephi.

**[2:1]** It is also found in the records, that Jeremy the prophet commanded them that were carried away to take of the fire, as it hath been signified:

**[2:2]** And how that the prophet, having given them the law, charged them not to forget the commandments of the Lord, and that they should not err in their minds, when they see images of silver and gold, with their ornaments.

**[2:3]** And with other such speeches exhorted he them, that the law should not depart from their hearts.

**[2:4]** It was also contained in the same writing, that the prophet, being warned of God, commanded the tabernacle and the ark to go with him, as he went forth into the mountain, where Moses climbed up, and saw the heritage of God.

**[2:5]** And when Jeremy came thither, he found an hollow cave, wherein he laid the tabernacle, and the ark, and the altar of incense, and so stopped the door.

**[2:6]** And some of those that followed him came to mark the way, but they could not find it.

**[2:7]** Which when Jeremy perceived, he blamed them, saying, As for that place, it shall be unknown until the time that God gather his people again together, and receive them unto mercy.

**[2:8]** Then shall the Lord shew them these things, and the glory of the Lord shall appear, and the cloud also, as it was shewed under Moses, and as when Solomon desired that the place might be honourably sanctified.

**[2:9]** It was also declared, that he being wise offered the sacrifice of dedication, and of the finishing of the temple.

**[2:10]** And as when Moses prayed unto the Lord, the fire came down from heaven, and consumed the sacrifices: even so prayed Solomon also, and the fire came down from heaven, and consumed the burnt offerings.

**[2:11]** And Moses said, Because the sin offering was not to be eaten, it was consumed.

**[2:12]** So Solomon kept those eight days.

**[2:13]** The same things also were reported in the writings and commentaries of Neemias; and how he founding a library gathered together the acts of the kings, and the prophets, and of David, and the epistles of the kings concerning the holy gifts.

**[2:14]** In like manner also Judas gathered together all those things that were lost by reason of the war we had, and they remain with us,

**[2:15]** Wherefore if ye have need thereof, send some to fetch them unto you.

**[2:16]** Whereas we then are about to celebrate the purification, we have written unto you, and ye shall do well, if ye keep the same days.

**[2:17]** We hope also, that the God, that delivered all his people, and gave them all an heritage, and the kingdom, and the priesthood, and the sanctuary,

**[2:18]** As he promised in the law, will shortly have mercy upon us, and gather us together out of every land under heaven into the holy place: for he hath delivered us out of great troubles, and hath purified the place.

**[2:19]** Now as concerning Judas Maccabeus, and his brethren, and the purification of the great temple, and the dedication of the altar,

**[2:20]** And the wars against Antiochus Epiphanes, and Eupator his son,

**[2:21]** And the manifest signs that came from heaven unto those that behaved themselves manfully to their honour for Judaism: so that, being but a few, they overcame the whole country, and chased barbarous multitudes,

**[2:22]** And recovered again the temple renowned all the world over, and freed the city, and upheld the laws which were going down, the Lord being gracious unto them with all favour:

**[2:23]** All these things, I say, being declared by Jason of Cyrene in five books, we will assay to abridge in one volume.

**[2:24]** For considering the infinite number, and the difficulty which they find that desire to look into the narrations of the story, for the variety of the matter,

**[2:25]** We have been careful, that they that will read may have delight, and that they that are desirous to commit to memory might have ease, and that all into whose hands it comes might have profit.

**[2:26]** Therefore to us, that have taken upon us this painful labour of abridging, it was not easy, but a matter of sweat and watching;

**[2:27]** Even as it is no ease unto him that prepareth a banquet, and seeketh the benefit of others: yet for the pleasuring of many we will undertake gladly this great pains;

**[2:28]** Leaving to the author the exact handling of every particular, and labouring to follow the rules of an abridgement.

**[2:29]** For as the master builder of a new house must care for the whole building; but he that undertaketh to set it out, and paint it, must seek out fit things for the adorning thereof: even so I think it is with us.

**[2:30]** To stand upon every point, and go over things at large, and to be curious in particulars, belongeth to the first author of the story:

**[2:31]** But to use brevity, and avoid much labouring of the work, is to be granted to him that will make an abridgment.

**[2:32]** Here then will we begin the story: only adding thus much to that which hath been said, that it is a foolish thing to make a long prologue, and to be short in the story itself.

**[3:1]** Now when the holy city was inhabited with all peace, and the laws were kept very well, because of the godliness of Onias the high priest, and his hatred of wickedness,

**[3:2]** It came to pass that even the kings themselves did honour the place, and magnify the temple with their best gifts;

**[3:3]** Insomuch that Seleucus of Asia of his own revenues bare all the costs belonging to the service of the sacrifices.

**[3:4]** But one Simon of the tribe of Benjamin, who was made governor of the temple, fell out with the high priest about disorder in the city.

**[3:5]** And when he could not overcome Onias, he gat him to Apollonius the son of Thraseas, who then was governor of Celosyria and Phenice,

**[3:6]** And told him that the treasury in Jerusalem was full of infinite sums of money, so that the multitude of their riches, which did not pertain to the account of the sacrifices, was innumerable, and that it was possible to bring all into the king’s hand.

**[3:7]** Now when Apollonius came to the king, and had shewed him of the money whereof he was told, the king chose out Heliodorus his treasurer, and sent him with a commandment to bring him the foresaid money.

**[3:8]** So forthwith Heliodorus took his journey; under a colour of visiting the cities of Celosyria and Phenice, but indeed to fulfil the king’s purpose.

**[3:9]** And when he was come to Jerusalem, and had been courteously received of the high priest of the city, he told him what intelligence was given of the money, and declared wherefore he came, and asked if these things were so indeed.

**[3:10]** Then the high priest told him that there was such money laid up for the relief of widows and fatherless children:

**[3:11]** And that some of it belonged to Hircanus son of Tobias, a man of great dignity, and not as that wicked Simon had misinformed: the sum whereof in all was four hundred talents of silver, and two hundred of gold:

**[3:12]** And that it was altogether impossible that such wrongs should be done unto them, that had committed it to the holiness of the place, and to the majesty and inviolable sanctity of the temple, honoured over all the world.

**[3:13]** But Heliodorus, because of the king’s commandment given him, said, That in any wise it must be brought into the king’s treasury.

**[3:14]** So at the day which he appointed he entered in to order this matter: wherefore there was no small agony throughout the whole city.

**[3:15]** But the priests, prostrating themselves before the altar in their priests’ vestments, called unto heaven upon him that made a law concerning things given to he kept, that they should safely be preserved for such as had committed them to be kept.

**[3:16]** Then whoso had looked the high priest in the face, it would have wounded his heart: for his countenance and the changing of his colour declared the inward agony of his mind.

**[3:17]** For the man was so compassed with fear and horror of the body, that it was manifest to them that looked upon him, what sorrow he had now in his heart.

**[3:18]** Others ran flocking out of their houses to the general supplication, because the place was like to come into contempt.

**[3:19]** And the women, girt with sackcloth under their breasts, abounded in the streets, and the virgins that were kept in ran, some to the gates, and some to the walls, and others looked out of the windows.

**[3:20]** And all, holding their hands toward heaven, made supplication.

**[3:21]** Then it would have pitied a man to see the falling down of the multitude of all sorts, and the fear of the high priest being in such an agony.

**[3:22]** They then called upon the Almighty Lord to keep the things committed of trust safe and sure for those that had committed them.

**[3:23]** Nevertheless Heliodorus executed that which was decreed.

**[3:24]** Now as he was there present himself with his guard about the treasury, the Lord of spirits, and the Prince of all power, caused a great apparition, so that all that presumed to come in with him were astonished at the power of God, and fainted, and were sore afraid.

**[3:25]** For there appeared unto them an horse with a terrible rider upon him, and adorned with a very fair covering, and he ran fiercely, and smote at Heliodorus with his forefeet, and it seemed that he that sat upon the horse had complete harness of gold.

**[3:26]** Moreover two other young men appeared before him, notable in strength, excellent in beauty, and comely in apparel, who stood by him on either side; and scourged him continually, and gave him many sore stripes.

**[3:27]** And Heliodorus fell suddenly unto the ground, and was compassed with great darkness: but they that were with him took him up, and put him into a litter.

**[3:28]** Thus him, that lately came with a great train and with all his guard into the said treasury, they carried out, being unable to help himself with his weapons: and manifestly they acknowledged the power of God.

**[3:29]** For he by the hand of God was cast down, and lay speechless without all hope of life.

**[3:30]** But they praised the Lord, that had miraculously honoured his own place: for the temple; which a little afore was full of fear and trouble, when the Almighty Lord appeared, was filled with joy and gladness.

**[3:31]** Then straightways certain of Heliodorus’ friends prayed Onias, that he would call upon the most High to grant him his life, who lay ready to give up the ghost.

**[3:32]** So the high priest, suspecting lest the king should misconceive that some treachery had been done to Heliodorus by the Jews, offered a sacrifice for the health of the man.

**[3:33]** Now as the high priest was making an atonement, the same young men in the same clothing appeared and stood beside Heliodorus, saying, Give Onias the high priest great thanks, insomuch as for his sake the Lord hath granted thee life:

**[3:34]** And seeing that thou hast been scourged from heaven, declare unto all men the mighty power of God. And when they had spoken these words, they appeared no more.

**[3:35]** So Heliodorus, after he had offered sacrifice unto the Lord, and made great vows unto him that had saved his life, and saluted Onias, returned with his host to the king.

**[3:36]** Then testified he to all men the works of the great God, which he had seen with his eyes.

**[3:37]** And when the king Heliodorus, who might be a fit man to be sent yet once again to Jerusalem, he said,

**[3:38]** If thou hast any enemy or traitor, send him thither, and thou shalt receive him well scourged, if he escape with his life: for in that place, no doubt; there is an especial power of God.

**[3:39]** For he that dwelleth in heaven hath his eye on that place, and defendeth it; and he beateth and destroyeth them that come to hurt it.

**[3:40]** And the things concerning Heliodorus, and the keeping of the treasury, fell out on this sort.

**[4:1]** This Simon now, of whom we spake afore, having been a betrayer of the money, and of his country, slandered Onias, as if he ha terrified Heliodorus, and been the worker of these evils.

**[4:2]** Thus was he bold to call him a traitor, that had deserved well of the city, and tendered his own nation, and was so zealous of the laws.

**[4:3]** But when their hatred went so far, that by one of Simon’s faction murders were committed,

**[4:4]** Onias seeing the danger of this contention, and that Apollonius, as being the governor of Celosyria and Phenice, did rage, and increase Simon’s malice,

**[4:5]** He went to the king, not to be an accuser of his countrymen, but seeking the good of all, both publick and private:

**[4:6]** For he saw that it was impossible that the state should continue quiet, and Simon leave his folly, unless the king did look thereunto.

**[4:7]** But after the death of Seleucus, when Antiochus, called Epiphanes, took the kingdom, Jason the brother of Onias laboured underhand to be high priest,

**[4:8]** Promising unto the king by intercession three hundred and threescore talents of silver, and of another revenue eighty talents:

**[4:9]** Beside this, he promised to assign an hundred and fifty more, if he might have licence to set him up a place for exercise, and for the training up of youth in the fashions of the heathen, and to write them of Jerusalem by the name of Antiochians.

**[4:10]** Which when the king had granted, and he had gotten into his hand the rule he forthwith brought his own nation to Greekish fashion.

**[4:11]** And the royal privileges granted of special favour to the Jews by the means of John the father of Eupolemus, who went ambassador to Rome for amity and aid, he took away; and putting down the governments which were according to the law, he brought up new customs against the law:

**[4:12]** For he built gladly a place of exercise under the tower itself, and brought the chief young men under his subjection, and made them wear a hat.

**[4:13]** Now such was the height of Greek fashions, and increase of heathenish manners, through the exceeding profaneness of Jason, that ungodly wretch, and no high priest;

**[4:14]** That the priests had no courage to serve any more at the altar, but despising the temple, and neglecting the sacrifices, hastened to be partakers of the unlawful allowance in the place of exercise, after the game of Discus called them forth;

**[4:15]** Not setting by the honours of their fathers, but liking the glory of the Grecians best of all.

**[4:16]** By reason whereof sore calamity came upon them: for they had them to be their enemies and avengers, whose custom they followed so earnestly, and unto whom they desired to be like in all things.

**[4:17]** For it is not a light thing to do wickedly against the laws of God: but the time following shall declare these things.

**[4:18]** Now when the game that was used every faith year was kept at Tyrus, the king being present,

**[4:19]** This ungracious Jason sent special messengers from Jerusalem, who were Antiochians, to carry three hundred drachms of silver to the sacrifice of Hercules, which even the bearers thereof thought fit not to bestow upon the sacrifice, because it was not convenient, but to be reserved for other charges.

**[4:20]** This money then, in regard of the sender, was appointed to Hercules’ sacrifice; but because of the bearers thereof, it was employed to the making of gallies.

**[4:21]** Now when Apollonius the son of Menestheus was sent into Egypt for the coronation of king Ptolemeus Philometor, Antiochus, understanding him not to be well affected to his affairs, provided for his own safety: whereupon he came to Joppa, and from thence to Jerusalem:

**[4:22]** Where he was honourably received of Jason, and of the city, and was brought in with torch alight, and with great shoutings: and so afterward went with his host unto Phenice.

**[4:23]** Three years afterward Jason sent Menelaus, the aforesaid Simon’s brother, to bear the money unto the king, and to put him in mind of certain necessary matters.

**[4:24]** But he being brought to the presence of the king, when he had magnified him for the glorious appearance of his power, got the priesthood to himself, offering more than Jason by three hundred talents of silver.

**[4:25]** So he came with the king’s mandate, bringing nothing worthy the high priesthood, but having the fury of a cruel tyrant, and the rage of a savage beast.

**[4:26]** Then Jason, who had undermined his own brother, being undermined by another, was compelled to flee into the country of the Ammonites.

**[4:27]** So Menelaus got the principality: but as for the money that he had promised unto the king, he took no good order for it, albeit Sostratis the ruler of the castle required it:

**[4:28]** For unto him appertained the gathering of the customs. Wherefore they were both called before the king.

**[4:29]** Now Menelaus left his brother Lysimachus in his stead in the priesthood; and Sostratus left Crates, who was governor of the Cyprians.

**[4:30]** While those things were in doing, they of Tarsus and Mallos made insurrection, because they were given to the king’s concubine, called Antiochus.

**[4:31]** Then came the king in all haste to appease matters, leaving Andronicus, a man in authority, for his deputy.

**[4:32]** Now Menelaus, supposing that he had gotten a convenient time, stole certain vessels of gold out of the temple, and gave some of them to Andronicus, and some he sold into Tyrus and the cities round about.

**[4:33]** Which when Onias knew of a surety, he reproved him, and withdrew himself into a sanctuary at Daphne, that lieth by Antiochia.

**[4:34]** Wherefore Menelaus, taking Andronicus apart, prayed, him to get Onias into his hands; who being persuaded thereunto, and coming to Onias in deceit, gave him his right hand with oaths; and though he were suspected by him, yet persuaded he him to come forth of the sanctuary: whom forthwith he shut up without regard of justice.

**[4:35]** For the which cause not only the Jews, but many also of other nations, took great indignation, and were much grieved for the unjust murder of the man.

**[4:36]** And when the king was come again from the places about Cilicia, the Jews that were in the city, and certain of the Greeks that abhorred the fact also, complained because Onias was slain without cause.

**[4:37]** Therefore Antiochus was heartily sorry, and moved to pity, and wept, because of the sober and modest behaviour of him that was dead.

**[4:38]** And being kindled with anger, forthwith he took away Andronicus his purple, and rent off his clothes, and leading him through the whole city unto that very place, where he had committed impiety against Onias, there slew he the cursed murderer. Thus the Lord rewarded him his punishment, as he had deserved.

**[4:39]** Now when many sacrileges had been committed in the city by Lysimachus with the consent of Menelaus, and the fruit thereof was spread abroad, the multitude gathered themselves together against Lysimachus, many vessels of gold being already carried away.

**[4:40]** Whereupon the common people rising, and being filled with rage, Lysimachus armed about three thousand men, and began first to offer violence; one Auranus being the leader, a man far gone in years, and no less in folly.

**[4:41]** They then seeing the attempt of Lysimachus, some of them caught stones, some clubs, others taking handfuls of dust, that was next at hand, cast them all together upon Lysimachus, and those that set upon them.

**[4:42]** Thus many of them they wounded, and some they struck to the ground, and all of them they forced to flee: but as for the churchrobber himself, him they killed beside the treasury.

**[4:43]** Of these matters therefore there was an accusation laid against Menelaus.

**[4:44]** Now when the king came to Tyrus, three men that were sent from the senate pleaded the cause before him:

**[4:45]** But Menelaus, being now convicted, promised Ptolemee the son of Dorymenes to give him much money, if he would pacify the king toward him.

**[4:46]** Whereupon Ptolemee taking the king aside into a certain gallery, as it were to take the air, brought him to be of another mind:

**[4:47]** Insomuch that he discharged Menelaus from the accusations, who notwithstanding was cause of all the mischief: and those poor men, who, if they had told their cause, yea, before the Scythians, should have been judged innocent, them he condemned to death.

**[4:48]** Thus they that followed the matter for the city, and for the people, and for the holy vessels, did soon suffer unjust punishment.

**[4:49]** Wherefore even they of Tyrus, moved with hatred of that wicked deed, caused them to be honourably buried.

**[4:50]** And so through the covetousness of them that were of power Menelaus remained still in authority, increasing in malice, and being a great traitor to the citizens.

**[5:1]** About the same time Antiochus prepared his second voyage into Egypt:

**[5:2]** And then it happened, that through all the city, for the space almost of forty days, there were seen horsemen running in the air, in cloth of gold, and armed with lances, like a band of soldiers,

**[5:3]** And troops of horsemen in array, encountering and running one against another, with shaking of shields, and multitude of pikes, and drawing of swords, and casting of darts, and glittering of golden ornaments, and harness of all sorts.

**[5:4]** Wherefore every man prayed that that apparition might turn to good.

**[5:5]** Now when there was gone forth a false rumour, as though Antiochus had been dead, Jason took at the least a thousand men, and suddenly made an assault upon the city; and they that were upon the walls being put back, and the city at length taken, Menelaus fled into the castle:

**[5:6]** But Jason slew his own citizens without mercy, not considering that to get the day of them of his own nation would be a most unhappy day for him; but thinking they had been his enemies, and not his countrymen, whom he conquered.

**[5:7]** Howbeit for all this he obtained not the principality, but at the last received shame for the reward of his treason, and fled again into the country of the Ammonites.

**[5:8]** In the end therefore he had an unhappy return, being accused before Aretas the king of the Arabians, fleeing from city to city, pursued of all men, hated as a forsaker of the laws, and being had in abomination as an open enemy of his country and countrymen, he was cast out into Egypt.

**[5:9]** Thus he that had driven many out of their country perished in a strange land, retiring to the Lacedemonians, and thinking there to find succour by reason of his kindred:

**[5:10]** And he that had cast out many unburied had none to mourn for him, nor any solemn funerals at all, nor sepulchre with his fathers.

**[5:11]** Now when this that was done came to the king’s car, he thought that Judea had revolted: whereupon removing out of Egypt in a furious mind, he took the city by force of arms,

**[5:12]** And commanded his men of war not to spare such as they met, and to slay such as went up upon the houses.

**[5:13]** Thus there was killing of young and old, making away of men, women, and children, slaying of virgins and infants.

**[5:14]** And there were destroyed within the space of three whole days fourscore thousand, whereof forty thousand were slain in the conflict; and no fewer sold than slain.

**[5:15]** Yet was he not content with this, but presumed to go into the most holy temple of all the world; Menelaus, that traitor to the laws, and to his own country, being his guide:

**[5:16]** And taking the holy vessels with polluted hands, and with profane hands pulling down the things that were dedicated by other kings to the augmentation and glory and honour of the place, he gave them away.

**[5:17]** And so haughty was Antiochus in mind, that he considered not that the Lord was angry for a while for the sins of them that dwelt in the city, and therefore his eye was not upon the place.

**[5:18]** For had they not been formerly wrapped in many sins, this man, as soon as he had come, had forthwith been scourged, and put back from his presumption, as Heliodorus was, whom Seleucus the king sent to view the treasury.

**[5:19]** Nevertheless God did not choose the people for the place’s sake, but the place far the people’s sake.

**[5:20]** And therefore the place itself, that was partaker with them of the adversity that happened to the nation, did afterward communicate in the benefits sent from the Lord: and as it was forsaken in the wrath of the Almighty, so again, the great Lord being reconciled, it was set up with all glory.

**[5:21]** So when Antiochus had carried out of the temple a thousand and eight hundred talents, he departed in all haste unto Antiochia, weening in his pride to make the land navigable, and the sea passable by foot: such was the haughtiness of his mind.

**[5:22]** And he left governors to vex the nation: at Jerusalem, Philip, for his country a Phrygian, and for manners more barbarous than he that set him there;

**[5:23]** And at Garizim, Andronicus; and besides, Menelaus, who worse than all the rest bare an heavy hand over the citizens, having a malicious mind against his countrymen the Jews.

**[5:24]** He sent also that detestable ringleader Apollonius with an army of two and twenty thousand, commanding him to slay all those that were in their best age, and to sell the women and the younger sort:

**[5:25]** Who coming to Jerusalem, and pretending peace, did forbear till the holy day of the sabbath, when taking the Jews keeping holy day, he commanded his men to arm themselves.

**[5:26]** And so he slew all them that were gone to the celebrating of the sabbath, and running through the city with weapons slew great multitudes.

**[5:27]** But Judas Maccabeus with nine others, or thereabout, withdrew himself into the wilderness, and lived in the mountains after the manner of beasts, with his company, who fed on herbs continually, lest they should be partakers of the pollution.

**[6:1]** Not long after this the king sent an old man of Athens to compel the Jews to depart from the laws of their fathers, and not to live after the laws of God:

**[6:2]** And to pollute also the temple in Jerusalem, and to call it the temple of Jupiter Olympius; and that in Garizim, of Jupiter the Defender of strangers, as they did desire that dwelt in the place.

**[6:3]** The coming in of this mischief was sore and grievous to the people:

**[6:4]** For the temple was filled with riot and revelling by the Gentiles, who dallied with harlots, and had to do with women within the circuit of the holy places, and besides that brought in things that were not lawful.

**[6:5]** The altar also was filled with profane things, which the law forbiddeth.

**[6:6]** Neither was it lawful for a man to keep sabbath days or ancient fasts, or to profess himself at all to be a Jew.

**[6:7]** And in the day of the king’s birth every month they were brought by bitter constraint to eat of the sacrifices; and when the fast of Bacchus was kept, the Jews were compelled to go in procession to Bacchus, carrying ivy.

**[6:8]** Moreover there went out a decree to the neighbour cities of the heathen, by the suggestion of Ptolemee, against the Jews, that they should observe the same fashions, and be partakers of their sacrifices:

**[6:9]** And whoso would not conform themselves to the manners of the Gentiles should be put to death. Then might a man have seen the present misery.

**[6:10]** For there were two women brought, who had circumcised their children; whom when they had openly led round about the city, the babes handing at their breasts, they cast them down headlong from the wall.

**[6:11]** And others, that had run together into caves near by, to keep the sabbath day secretly, being discovered by Philip, were all burnt together, because they made a conscience to help themselves for the honour of the most sacred day.

**[6:12]** Now I beseech those that read this book, that they be not discouraged for these calamities, but that they judge those punishments not to be for destruction, but for a chastening of our nation.

**[6:13]** For it is a token of his great goodness, when wicked doers are not suffered any long time, but forthwith punished.

**[6:14]** For not as with other nations, whom the Lord patiently forbeareth to punish, till they be come to the fulness of their sins, so dealeth he with us,

**[6:15]** Lest that, being come to the height of sin, afterwards he should take vengeance of us.

**[6:16]** And therefore he never withdraweth his mercy from us: and though he punish with adversity, yet doth he never forsake his people.

**[6:17]** But let this that we at spoken be for a warning unto us. And now will we come to the declaring of the matter in a few words.

**[6:18]** Eleazar, one of the principal scribes, an aged man, and of a well favoured countenance, was constrained to open his mouth, and to eat swine’s flesh.

**[6:19]** But he, choosing rather to die gloriously, than to live stained with such an abomination, spit it forth, and came of his own accord to the torment,

**[6:20]** As it behoved them to come, that are resolute to stand out against such things, as are not lawful for love of life to be tasted.

**[6:21]** But they that had the charge of that wicked feast, for the old acquaintance they had with the man, taking him aside, besought him to bring flesh of his own provision, such as was lawful for him to use, and make as if he did eat of the flesh taken from the sacrifice commanded by the king;

**[6:22]** That in so doing he might be delivered from death, and for the old friendship with them find favour.

**[6:23]** But he began to consider discreetly, and as became his age, and the excellency of his ancient years, and the honour of his gray head, whereon was come, and his most honest education from a child, or rather the holy law made and given by God: therefore he answered accordingly, and willed them straightways to send him to the grave.

**[6:24]** For it becometh not our age, said he, in any wise to dissemble, whereby many young persons might think that Eleazar, being fourscore years old and ten, were now gone to a strange religion;

**[6:25]** And so they through mine hypocrisy, and desire to live a little time and a moment longer, should be deceived by me, and I get a stain to mine old age, and make it abominable.

**[6:26]** For though for the present time I should be delivered from the punishment of men: yet should I not escape the hand of the Almighty, neither alive, nor dead.

**[6:27]** Wherefore now, manfully changing this life, I will shew myself such an one as mine age requireth,

**[6:28]** And leave a notable example to such as be young to die willingly and courageously for the honourable and holy laws. And when he had said these words, immediately he went to the torment:

**[6:29]** They that led him changing the good will they bare him a little before into hatred, because the foresaid speeches proceeded, as they thought, from a desperate mind.

**[6:30]** But when he was ready to die with stripes, he groaned, and said, It is manifest unto the Lord, that hath the holy knowledge, that whereas I might have been delivered from death, I now endure sore pains in body by being beaten: but in soul am well content to suffer these things, because I fear him.

**[6:31]** And thus this man died, leaving his death for an example of a noble courage, and a memorial of virtue, not only unto young men, but unto all his nation.

**[7:1]** It came to pass also, that seven brethren with their mother were taken, and compelled by the king against the law to taste swine’s flesh, and were tormented with scourges and whips.

**[7:2]** But one of them that spake first said thus, What wouldest thou ask or learn of us? we are ready to die, rather than to transgress the laws of our fathers.

**[7:3]** Then the king, being in a rage, commanded pans and caldrons to be made hot:

**[7:4]** Which forthwith being heated, he commanded to cut out the tongue of him that spake first, and to cut off the utmost parts of his body, the rest of his brethren and his mother looking on.

**[7:5]** Now when he was thus maimed in all his members, he commanded him being yet alive to be brought to the fire, and to be fried in the pan: and as the vapour of the pan was for a good space dispersed, they exhorted one another with the mother to die manfully, saying thus,

**[7:6]** The Lord God looketh upon us, and in truth hath comfort in us, as Moses in his song, which witnessed to their faces, declared, saying, And he shall be comforted in his servants.

**[7:7]** So when the first was dead after this number, they brought the second to make him a mocking stock: and when they had pulled off the skin of his head with the hair, they asked him, Wilt thou eat, before thou be punished throughout every member of thy body?

**[7:8]** But he answered in his own language, and said, No. Wherefore he also received the next torment in order, as the former did.

**[7:9]** And when he was at the last gasp, he said, Thou like a fury takest us out of this present life, but the King of the world shall raise us up, who have died for his laws, unto everlasting life.

**[7:10]** After him was the third made a mocking stock: and when he was required, he put out his tongue, and that right soon, holding forth his hands manfully.

**[7:11]** And said courageously, These I had from heaven; and for his laws I despise them; and from him I hope to receive them again.

**[7:12]** Insomuch that the king, and they that were with him, marvelled at the young man’s courage, for that he nothing regarded the pains.

**[7:13]** Now when this man was dead also, they tormented and mangled the fourth in like manner.

**[7:14]** So when he was ready to die he said thus, It is good, being put to death by men, to look for hope from God to be raised up again by him: as for thee, thou shalt have no resurrection to life.

**[7:15]** Afterward they brought the fifth also, and mangled him.

**[7:16]** Then looked he unto the king, and said, Thou hast power over men, thou art corruptible, thou doest what thou wilt; yet think not that our nation is forsaken of God;

**[7:17]** But abide a while, and behold his great power, how he will torment thee and thy seed.

**[7:18]** After him also they brought the sixth, who being ready to die said, Be not deceived without cause: for we suffer these things for ourselves, having sinned against our God: therefore marvellous things are done unto us.

**[7:19]** But think not thou, that takest in hand to strive against God, that thou shalt escape unpunished.

**[7:20]** But the mother was marvellous above all, and worthy of honourable memory: for when she saw her seven sons slain within the space of one day, she bare it with a good courage, because of the hope that she had in the Lord.

**[7:21]** Yea, she exhorted every one of them in her own language, filled with courageous spirits; and stirring up her womanish thoughts with a manly stomach, she said unto them,

**[7:22]** I cannot tell how ye came into my womb: for I neither gave you breath nor life, neither was it I that formed the members of every one of you;

**[7:23]** But doubtless the Creator of the world, who formed the generation of man, and found out the beginning of all things, will also of his own mercy give you breath and life again, as ye now regard not your own selves for his laws’ sake.

**[7:24]** Now Antiochus, thinking himself despised, and suspecting it to be a reproachful speech, whilst the youngest was yet alive, did not only exhort him by words, but also assured him with oaths, that he would make him both a rich and a happy man, if he would turn from the laws of his fathers; and that also he would take him for his friend, and trust him with affairs.

**[7:25]** But when the young man would in no case hearken unto him, the king called his mother, and exhorted her that she would counsel the young man to save his life.

**[7:26]** And when he had exhorted her with many words, she promised him that she would counsel her son.

**[7:27]** But she bowing herself toward him, laughing the cruel tyrant to scorn, spake in her country language on this manner; O my son, have pity upon me that bare thee nine months in my womb, and gave thee such three years, and nourished thee, and brought thee up unto this age, and endured the troubles of education.

**[7:28]** I beseech thee, my son, look upon the heaven and the earth, and all that is therein, and consider that God made them of things that were not; and so was mankind made likewise.

**[7:29]** Fear not this tormentor, but, being worthy of thy brethren, take thy death that I may receive thee again in mercy with thy brethren.

**[7:30]** Whiles she was yet speaking these words, the young man said, Whom wait ye for? I will not obey the king’s commandment: but I will obey the commandment of the law that was given unto our fathers by Moses.

**[7:31]** And thou, that hast been the author of all mischief against the Hebrews, shalt not escape the hands of God.

**[7:32]** For we suffer because of our sins.

**[7:33]** And though the living Lord be angry with us a little while for our chastening and correction, yet shall he be at one again with his servants.

**[7:34]** But thou, O godless man, and of all other most wicked, be not lifted up without a cause, nor puffed up with uncertain hopes, lifting up thy hand against the servants of God:

**[7:35]** For thou hast not yet escaped the judgment of Almighty God, who seeth all things.

**[7:36]** For our brethren, who now have suffered a short pain, are dead under God’s covenant of everlasting life: but thou, through the judgment of God, shalt receive just punishment for thy pride.

**[7:37]** But I, as my brethren, offer up my body and life for the laws of our fathers, beseeching God that he would speedily be merciful unto our nation; and that thou by torments and plagues mayest confess, that he alone is God;

**[7:38]** And that in me and my brethren the wrath of the Almighty, which is justly brought upon our nation, may cease.

**[7:39]** Than the king’ being in a rage, handed him worse than all the rest, and took it grievously that he was mocked.

**[7:40]** So this man died undefiled, and put his whole trust in the Lord.

**[7:41]** Last of all after the sons the mother died.

**[7:42]** Let this be enough now to have spoken concerning the idolatrous feasts, and the extreme tortures.

**[8:1]** Then Judas Maccabeus, and they that were with him, went privily into the towns, and called their kinsfolks together, and took unto them all such as continued in the Jews’ religion, and assembled about six thousand men.

**[8:2]** And they called upon the Lord, that he would look upon the people that was trodden down of all; and also pity the temple profaned of ungodly men;

**[8:3]** And that he would have compassion upon the city, sore defaced, and ready to be made even with the ground; and hear the blood that cried unto him,

**[8:4]** And remember the wicked slaughter of harmless infants, and the blasphemies committed against his name; and that he would shew his hatred against the wicked.

**[8:5]** Now when Maccabeus had his company about him, he could not be withstood by the heathen: for the wrath of the Lord was turned into mercy.

**[8:6]** Therefore he came at unawares, and burnt up towns and cities, and got into his hands the most commodious places, and overcame and put to flight no small number of his enemies.

**[8:7]** But specially took he advantage of the night for such privy attempts, insomuch that the fruit of his holiness was spread every where.

**[8:8]** So when Philip saw that this man increased by little and little, and that things prospered with him still more and more, he wrote unto Ptolemeus, the governor of Celosyria and Phenice, to yield more aid to the king’s affairs.

**[8:9]** Then forthwith choosing Nicanor the son of Patroclus, one of his special friends, he sent him with no fewer than twenty thousand of all nations under him, to root out the whole generation of the Jews; and with him he joined also Gorgias a captain, who in matters of war had great experience.

**[8:10]** So Nicanor undertook to make so much money of the captive Jews, as should defray the tribute of two thousand talents, which the king was to pay to the Romans.

**[8:11]** Wherefore immediately he sent to the cities upon the sea coast, proclaiming a sale of the captive Jews, and promising that they should have fourscore and ten bodies for one talent, not expecting the vengeance that was to follow upon him from the Almighty God.

**[8:12]** Now when word was brought unto Judas of Nicanor’s coming, and he had imparted unto those that were with him that the army was at hand,

**[8:13]** They that were fearful, and distrusted the justice of God, fled, and conveyed themselves away.

**[8:14]** Others sold all that they had left, and withal besought the Lord to deliver them, sold by the wicked Nicanor before they met together:

**[8:15]** And if not for their own sakes, yet for the covenants he had made with their fathers, and for his holy and glorious name’s sake, by which they were called.

**[8:16]** So Maccabeus called his men together unto the number of six thousand, and exhorted them not to be stricken with terror of the enemy, nor to fear the great multitude of the heathen, who came wrongly against them; but to fight manfully,

**[8:17]** And to set before their eyes the injury that they had unjustly done to the holy place, and the cruel handling of the city, whereof they made a mockery, and also the taking away of the government of their forefathers:

**[8:18]** For they, said he, trust in their weapons and boldness; but our confidence is in the Almighty who at a beck can cast down both them that come against us, and also all the world.

**[8:19]** Moreover, he recounted unto them what helps their forefathers had found, and how they were delivered, when under Sennacherib an hundred fourscore and five thousand perished.

**[8:20]** And he told them of the battle that they had in Babylon with the Galatians, how they came but eight thousand in all to the business, with four thousand Macedonians, and that the Macedonians being perplexed, the eight thousand destroyed an hundred and twenty thousand because of the help that they had from heaven, and so received a great booty.

**[8:21]** Thus when he had made them bold with these words, and ready to die for the law and the country, he divided his army into four parts;

**[8:22]** And joined with himself his own brethren, leaders of each band, to wit Simon, and Joseph, and Jonathan, giving each one fifteen hundred men.

**[8:23]** Also he appointed Eleazar to read the holy book: and when he had given them this watchword, The help of God; himself leading the first band,

**[8:24]** And by the help of the Almighty they slew above nine thousand of their enemies, and wounded and maimed the most part of Nicanor’s host, and so put all to flight;

**[8:25]** And took their money that came to buy them, and pursued them far: but lacking time they returned:

**[8:26]** For it was the day before the sabbath, and therefore they would no longer pursue them.

**[8:27]** So when they had gathered their armour together, and spoiled their enemies, they occupied themselves about the sabbath, yielding exceeding praise and thanks to the Lord, who had preserved them unto that day, which was the beginning of mercy distilling upon them.

**[8:28]** And after the sabbath, when they had given part of the spoils to the maimed, and the widows, and orphans, the residue they divided among themselves and their servants.

**[8:29]** When this was done, and they had made a common supplication, they besought the merciful Lord to be reconciled with his servants for ever.

**[8:30]** Moreover of those that were with Timotheus and Bacchides, who fought against them, they slew above twenty thousand, and very easily got high and strong holds, and divided among themselves many spoils more, and made the maimed, orphans, widows, yea, and the aged also, equal in spoils with themselves.

**[8:31]** And when they had gathered their armour together, they laid them up all carefully in convenient places, and the remnant of the spoils they brought to Jerusalem.

**[8:32]** They slew also Philarches, that wicked person, who was with Timotheus, and had annoyed the Jews many ways.

**[8:33]** Furthermore at such time as they kept the feast for the victory in their country they burnt Callisthenes, that had set fire upon the holy gates, who had fled into a little house; and so he received a reward meet for his wickedness.

**[8:34]** As for that most ungracious Nicanor, who had brought a thousand merchants to buy the Jews,

**[8:35]** He was through the help of the Lord brought down by them, of whom he made least account; and putting off his glorious apparel, and discharging his company, he came like a fugitive servant through the midland unto Antioch having very great dishonour, for that his host was destroyed.

**[8:36]** Thus he, that took upon him to make good to the Romans their tribute by means of captives in Jerusalem, told abroad, that the Jews had God to fight for them, and therefore they could not be hurt, because they followed the laws that he gave them.

**[9:1]** About that time came Antiochus with dishonour out of the country of Persia

**[9:2]** For he had entered the city called Persepolis, and went about to rob the temple, and to hold the city; whereupon the multitude running to defend themselves with their weapons put them to flight; and so it happened, that Antiochus being put to flight of the inhabitants returned with shame.

**[9:3]** Now when he came to Ecbatane, news was brought him what had happened unto Nicanor and Timotheus.

**[9:4]** Then swelling with anger. he thought to avenge upon the Jews the disgrace done unto him by those that made him flee. Therefore commanded he his chariotman to drive without ceasing, and to dispatch the journey, the judgment of God now following him. For he had spoken proudly in this sort, That he would come to Jerusalem and make it a common burying place of the Jews.

**[9:5]** But the Lord Almighty, the God of Isreal, smote him with an incurable and invisible plague: or as soon as he had spoken these words, a pain of the bowels that was remediless came upon him, and sore torments of the inner parts;

**[9:6]** And that most justly: for he had tormented other men’s bowels with many and strange torments.

**[9:7]** Howbeit he nothing at all ceased from his bragging, but still was filled with pride, breathing out fire in his rage against the Jews, and commanding to haste the journey: but it came to pass that he fell down from his chariot, carried violently; so that having a sore fall, all the members of his body were much pained.

**[9:8]** And thus he that a little afore thought he might command the waves of the sea, (so proud was he beyond the condition of man) and weigh the high mountains in a balance, was now cast on the ground, and carried in an horselitter, shewing forth unto all the manifest power of God.

**[9:9]** So that the worms rose up out of the body of this wicked man, and whiles he lived in sorrow and pain, his flesh fell away, and the filthiness of his smell was noisome to all his army.

**[9:10]** And the man, that thought a little afore he could reach to the stars of heaven, no man could endure to carry for his intolerable stink.

**[9:11]** Here therefore, being plagued, he began to leave off his great pride, and to come to the knowledge of himself by the scourge of God, his pain increasing every moment.

**[9:12]** And when he himself could not abide his own smell, he said these words, It is meet to be subject unto God, and that a man that is mortal should not proudly think of himself if he were God.

**[9:13]** This wicked person vowed also unto the Lord, who now no more would have mercy upon him, saying thus,

**[9:14]** That the holy city (to the which he was going in haste to lay it even with the ground, and to make it a common buryingplace,) he would set at liberty:

**[9:15]** And as touching the Jews, whom he had judged not worthy so much as to be buried, but to be cast out with their children to be devoured of the fowls and wild beasts, he would make them all equals to the citizens of Athens:

**[9:16]** And the holy temple, which before he had spoiled, he would garnish with goodly gifts, and restore all the holy vessels with many more, and out of his own revenue defray the charges belonging to the sacrifices:

**[9:17]** Yea, and that also he would become a Jew himself, and go through all the world that was inhabited, and declare the power of God.

**[9:18]** But for all this his pains would not cease: for the just judgment of God was come upon him: therefore despairing of his health, he wrote unto the Jews the letter underwritten, containing the form of a supplication, after this manner:

**[9:19]** Antiochus, king and governor, to the good Jews his citizens wisheth much joy, health, and prosperity:

**[9:20]** If ye and your children fare well, and your affairs be to your contentment, I give very great thanks to God, having my hope in heaven.

**[9:21]** As for me, I was weak, or else I would have remembered kindly your honour and good will returning out of Persia, and being taken with a grievous disease, I thought it necessary to care for the common safety of all:

**[9:22]** Not distrusting mine health, but having great hope to escape this sickness.

**[9:23]** But considering that even my father, at what time he led an army into the high countries. appointed a successor,

**[9:24]** To the end that, if any thing fell out contrary to expectation, or if any tidings were brought that were grievous, they of the land, knowing to whom the state was left, might not be troubled:

**[9:25]** Again, considering how that the princes that are borderers and neighbours unto my kingdom wait for opportunities, and expect what shall be the event. I have appointed my son Antiochus king, whom I often committed and commended unto many of you, when I went up into the high provinces; to whom I have written as followeth:

**[9:26]** Therefore I pray and request you to remember the benefits that I have done unto you generally, and in special, and that every man will be still faithful to me and my son.

**[9:27]** For I am persuaded that he understanding my mind will favourably and graciously yield to your desires.

**[9:28]** Thus the murderer and blasphemer having suffered most grievously, as he entreated other men, so died he a miserable death in a strange country in the mountains.

**[9:29]** And Philip, that was brought up with him, carried away his body, who also fearing the son of Antiochus went into Egypt to Ptolemeus Philometor.

**[10:1]** Now Maccabeus and his company, the Lord guiding them, recovered the temple and the city:

**[10:2]** But the altars which the heathen had built in the open street, and also the chapels, they pulled down.

**[10:3]** And having cleansed the temple they made another altar, and striking stones they took fire out of them, and offered a sacrifice after two years, and set forth incense, and lights, and shewbread.

**[10:4]** When that was done, they fell flat down, and besought the Lord that they might come no more into such troubles; but if they sinned any more against him, that he himself would chasten them with mercy, and that they might not be delivered unto the blasphemous and barbarous nations.

**[10:5]** Now upon the same day that the strangers profaned the temple, on the very same day it was cleansed again, even the five and twentieth day of the same month, which is Casleu.

**[10:6]** And they kept the eight days with gladness, as in the feast of the tabernacles, remembering that not long afore they had held the feast of the tabernacles, when as they wandered in the mountains and dens like beasts.

**[10:7]** Therefore they bare branches, and fair boughs, and palms also, and sang psalms unto him that had given them good success in cleansing his place.

**[10:8]** They ordained also by a common statute and decree, That every year those days should be kept of the whole nation of the Jews.

**[10:9]** And this was the end of Antiochus, called Epiphanes.

**[10:10]** Now will we declare the acts of Antiochus Eupator, who was the son of this wicked man, gathering briefly the calamities of the wars.

**[10:11]** So when he was come to the crown, he set one Lysias over the affairs of his realm, and appointed him his chief governor of Celosyria and Phenice.

**[10:12]** For Ptolemeus, that was called Macron, choosing rather to do justice unto the Jews for the wrong that had been done unto them, endeavoured to continue peace with them.

**[10:13]** Whereupon being accused of the king’s friends before Eupator, and called traitor at every word because he had left Cyprus, that Philometor had committed unto him, and departed to Antiochus Epiphanes, and seeing that he was in no honourable place, he was so discouraged, that he poisoned himself and died.

**[10:14]** But when Gorgias was governor of the holds, he hired soldiers, and nourished war continually with the Jews:

**[10:15]** And therewithall the Idumeans, having gotten into their hands the most commodious holds, kept the Jews occupied, and receiving those that were banished from Jerusalem, they went about to nourish war.

**[10:16]** Then they that were with Maccabeus made supplication, and besought God that he would be their helper; and so they ran with violence upon the strong holds of the Idumeans,

**[10:17]** And assaulting them strongly, they won the holds, and kept off all that fought upon the wall, and slew all that fell into their hands, and killed no fewer than twenty thousand.

**[10:18]** And because certain, who were no less than nine thousand, were fled together into two very strong castles, having all manner of things convenient to sustain the siege,

**[10:19]** Maccabeus left Simon and Joseph, and Zaccheus also, and them that were with him, who were enough to besiege them, and departed himself unto those places which more needed his help.

**[10:20]** Now they that were with Simon, being led with covetousness, were persuaded for money through certain of those that were in the castle, and took seventy thousand drachms, and let some of them escape.

**[10:21]** But when it was told Maccabeus what was done, he called the governors of the people together, and accused those men, that they had sold their brethren for money, and set their enemies free to fight against them.

**[10:22]** So he slew those that were found traitors, and immediately took the two castles.

**[10:23]** And having good success with his weapons in all things he took in hand, he slew in the two holds more than twenty thousand.

**[10:24]** Now Timotheus, whom the Jews had overcome before, when he had gathered a great multitude of foreign forces, and horses out of Asia not a few, came as though he would take Jewry by force of arms.

**[10:25]** But when he drew near, they that were with Maccabeus turned themselves to pray unto God, and sprinkled earth upon their heads, and girded their loins with sackcloth,

**[10:26]** And fell down at the foot of the altar, and besought him to be merciful to them, and to be an enemy to their enemies, and an adversary to their adversaries, as the law declareth.

**[10:27]** So after the prayer they took their weapons, and went on further from the city: and when they drew near to their enemies, they kept by themselves.

**[10:28]** Now the sun being newly risen, they joined both together; the one part having together with their virtue their refuge also unto the Lord for a pledge of their success and victory: the other side making their rage leader of their battle

**[10:29]** But when the battle waxed strong, there appeared unto the enemies from heaven five comely men upon horses, with bridles of gold, and two of them led the Jews,

**[10:30]** And took Maccabeus betwixt them, and covered him on every side weapons, and kept him safe, but shot arrows and lightnings against the enemies: so that being confounded with blindness, and full of trouble, they were killed.

**[10:31]** And there were slain of footmen twenty thousand and five hundred, and six hundred horsemen.

**[10:32]** As for Timotheus himself, he fled into a very strong hold, called Gawra, where Chereas was governor.

**[10:33]** But they that were with Maccabeus laid siege against the fortress courageously four days.

**[10:34]** And they that were within, trusting to the strength of the place, blasphemed exceedingly, and uttered wicked words.

**[10:35]** Nevertheless upon the fifth day early twenty young men of Maccabeus’ company, inflamed with anger because of the blasphemies, assaulted the wall manly, and with a fierce courage killed all that they met withal.

**[10:36]** Others likewise ascending after them, whiles they were busied with them that were within, burnt the towers, and kindling fires burnt the blasphemers alive; and others broke open the gates, and, having received in the rest of the army, took the city,

**[10:37]** And killed Timotheus, that was hid in a certain pit, and Chereas his brother, with Apollophanes.

**[10:38]** When this was done, they praised the Lord with psalms and thanksgiving, who had done so great things for Israel, and given them the victory.

**[11:1]** Not long after the, Lysias the king’s protector and cousin, who also managed the affairs, took sore displeasure for the things that were done.

**[11:2]** And when he had gathered about fourscore thousand with all the horsemen, he came against the Jews, thinking to make the city an habitation of the Gentiles,

**[11:3]** And to make a gain of the temple, as of the other chapels of the heathen, and to set the high priesthood to sale every year:

**[11:4]** Not at all considering the power of God but puffed up with his ten thousands of footmen, and his thousands of horsemen, and his fourscore elephants.

**[11:5]** So he came to Judea, and drew near to Bethsura, which was a strong town, but distant from Jerusalem about five furlongs, and he laid sore siege unto it.

**[11:6]** Now when they that were with Maccabeus heard that he besieged the holds, they and all the people with lamentation and tears besought the Lord that he would send a good angel to deliver Israel.

**[11:7]** Then Maccabeus himself first of all took weapons, exhorting the other that they would jeopard themselves together with him to help their brethren: so they went forth together with a willing mind.

**[11:8]** And as they were at Jerusalem, there appeared before them on horseback one in white clothing, shaking his armour of gold.

**[11:9]** Then they praised the merciful God all together, and took heart, insomuch that they were ready not only to fight with men, but with most cruel beasts, and to pierce through walls of iron.

**[11:10]** Thus they marched forward in their armour, having an helper from heaven: for the Lord was merciful unto them

**[11:11]** And giving a charge upon their enemies like lions, they slew eleven thousand footmen, and sixteen hundred horsemen, and put all the other to flight.

**[11:12]** Many of them also being wounded escaped naked; and Lysias himself fled away shamefully, and so escaped.

**[11:13]** Who, as he was a man of understanding, casting with himself what loss he had had, and considering that the Hebrews could not be overcome, because the Almighty God helped them, he sent unto them,

**[11:14]** And persuaded them to agree to all reasonable conditions, and promised that he would persuade the king that he must needs be a friend unto them.

**[11:15]** Then Maccabeus consented to all that Lysias desired, being careful of the common good; and whatsoever Maccabeus wrote unto Lysias concerning the Jews, the king granted it.

**[11:16]** For there were letters written unto the Jews from Lysias to this effect: Lysias unto the people of the Jews sendeth greeting:

**[11:17]** John and Absolom, who were sent from you, delivered me the petition subscribed, and made request for the performance of the contents thereof.

**[11:18]** Therefore what things soever were meet to be reported to the king, I have declared them, and he hath granted as much as might be.

**[11:19]** And if then ye will keep yourselves loyal to the state, hereafter also will I endeavour to be a means of your good.

**[11:20]** But of the particulars I have given order both to these and the other that came from me, to commune with you.

**[11:21]** Fare ye well. The hundred and eight and fortieth year, the four and twentieth day of the month Dioscorinthius.

**[11:22]** Now the king’s letter contained these words: King Antiochus unto his brother Lysias sendeth greeting:

**[11:23]** Since our father is translated unto the gods, our will is, that they that are in our realm live quietly, that every one may attend upon his own affairs.

**[11:24]** We understand also that the Jews would not consent to our father, for to be brought unto the custom of the Gentiles, but had rather keep their own manner of living: for the which cause they require of us, that we should suffer them to live after their own laws.

**[11:25]** Wherefore our mind is, that this nation shall be in rest, and we have determined to restore them their temple, that they may live according to the customs of their forefathers.

**[11:26]** Thou shalt do well therefore to send unto them, and grant them peace, that when they are certified of our mind, they may be of good comfort, and ever go cheerfully about their own affairs.

**[11:27]** And the letter of the king unto the nation of the Jews was after this manner: King Antiochus sendeth greeting unto the council, and the rest of the Jews:

**[11:28]** If ye fare well, we have our desire; we are also in good health.

**[11:29]** Menelaus declared unto us, that your desire was to return home, and to follow your own business:

**[11:30]** Wherefore they that will depart shall have safe conduct till the thirtieth day of Xanthicus with security.

**[11:31]** And the Jews shall use their own kind of meats and laws, as before; and none of them any manner of ways shall be molested for things ignorantly done.

**[11:32]** I have sent also Menelaus, that he may comfort you.

**[11:33]** Fare ye well. In the hundred forty and eighth year, and the fifteenth day of the month Xanthicus.

**[11:34]** The Romans also sent unto them a letter containing these words: Quintus Memmius and Titus Manlius, ambassadors of the Romans, send greeting unto the people of the Jews.

**[11:35]** Whatsoever Lysias the king’s cousin hath granted, therewith we also are well pleased.

**[11:36]** But touching such things as he judged to be referred to the king, after ye have advised thereof, send one forthwith, that we may declare as it is convenient for you: for we are now going to Antioch.

**[11:37]** Therefore send some with speed, that we may know what is your mind.

**[11:38]** Farewell. This hundred and eight and fortieth year, the fifteenth day of the month Xanthicus.

**[12:1]** When these covenants were made, Lysias went unto the king, and the Jews were about their husbandry.

**[12:2]** But of the governours of several places, Timotheus, and Apollonius the son of Genneus, also Hieronymus, and Demophon, and beside them Nicanor the governor of Cyprus, would not suffer them to be quiet and live in peace.

**[12:3]** The men of Joppa also did such an ungodly deed: they prayed the Jews that dwelt among them to go with their wives and children into the boats which they had prepared, as though they had meant them no hurt.

**[12:4]** Who accepted of it according to the common decree of the city, as being desirous to live in peace, and suspecting nothing: but when they were gone forth into the deep, they drowned no less than two hundred of them.

**[12:5]** When Judas heard of this cruelty done unto his countrymen, he commanded those that were with him to make them ready.

**[12:6]** And calling upon God the righteous Judge, he came against those murderers of his brethren, and burnt the haven by night, and set the boats on fire, and those that fled thither he slew.

**[12:7]** And when the town was shut up, he went backward, as if he would return to root out all them of the city of Joppa.

**[12:8]** But when he heard that the Jamnites were minded to do in like manner unto the Jews that dwelt among them,

**[12:9]** He came upon the Jamnites also by night, and set fire on the haven and the navy, so that the light of the fire was seen at Jerusalem two hundred and forty furlongs off.

**[12:10]** Now when they were gone from thence nine furlongs in their journey toward Timotheus, no fewer than five thousand men on foot and five hundred horsemen of the Arabians set upon him.

**[12:11]** Whereupon there was a very sore battle; but Judas’ side by the help of God got the victory; so that the Nomades of Arabia, being overcome, besought Judas for peace, promising both to give him cattle, and to pleasure him otherwise.

**[12:12]** Then Judas, thinking indeed that they would be profitable in many things, granted them peace: whereupon they shook hands, and so they departed to their tents.

**[12:13]** He went also about to make a bridge to a certain strong city, which was fenced about with walls, and inhabited by people of divers countries; and the name of it was Caspis.

**[12:14]** But they that were within it put such trust in the strength of the walls and provision of victuals, that they behaved themselves rudely toward them that were with Judas, railing and blaspheming, and uttering such words as were not to be spoken.

**[12:15]** Wherefore Judas with his company, calling upon the great Lord of the world, who without rams or engines of war did cast down Jericho in the time of Joshua, gave a fierce assault against the walls,

**[12:16]** And took the city by the will of God, and made unspeakable slaughters, insomuch that a lake two furlongs broad near adjoining thereunto, being filled full, was seen running with blood.

**[12:17]** Then departed they from thence seven hundred and fifty furlongs, and came to Characa unto the Jews that are called Tubieni.

**[12:18]** But as for Timotheus, they found him not in the places: for before he had dispatched any thing, he departed from thence, having left a very strong garrison in a certain hold.

**[12:19]** Howbeit Dositheus and Sosipater, who were of Maccabeus’ captains, went forth, and slew those that Timotheus had left in the fortress, above ten thousand men.

**[12:20]** And Maccabeus ranged his army by bands, and set them over the bands, and went against Timotheus, who had about him an hundred and twenty thousand men of foot, and two thousand and five hundred horsemen.

**[12:21]** Now when Timotheus had knowledge of Judas’ coming, he sent the women and children and the other baggage unto a fortress called Carnion: for the town was hard to besiege, and uneasy to come unto, by reason of the straitness of all the places.

**[12:22]** But when Judas his first band came in sight, the enemies, being smitten with fear and terror through the appearing of him who seeth all things, fled amain, one running into this way, another that way, so as that they were often hurt of their own men, and wounded with the points of their own swords.

**[12:23]** Judas also was very earnest in pursuing them, killing those wicked wretches, of whom he slew about thirty thousand men.

**[12:24]** Moreover Timotheus himself fell into the hands of Dositheus and Sosipater, whom he besought with much craft to let him go with his life, because he had many of the Jews’ parents, and the brethren of some of them, who, if they put him to death, should not be regarded.

**[12:25]** So when he had assured them with many words that he would restore them without hurt, according to the agreement, they let him go for the saving of their brethren.

**[12:26]** Then Maccabeus marched forth to Carnion, and to the temple of Atargatis, and there he slew five and twenty thousand persons.

**[12:27]** And after he had put to flight and destroyed them, Judas removed the host toward Ephron, a strong city, wherein Lysias abode, and a great multitude of divers nations, and the strong young men kept the walls, and defended them mightily: wherein also was great provision of engines and darts.

**[12:28]** But when Judas and his company had called upon Almighty God, who with his power breaketh the strength of his enemies, they won the city, and slew twenty and five thousand of them that were within,

**[12:29]** From thence they departed to Scythopolis, which lieth six hundred furlongs from Jerusalem,

**[12:30]** But when the Jews that dwelt there had testified that the Scythopolitans dealt lovingly with them, and entreated them kindly in the time of their adversity;

**[12:31]** They gave them thanks, desiring them to be friendly still unto them: and so they came to Jerusalem, the feast of the weeks approaching.

**[12:32]** And after the feast, called Pentecost, they went forth against Gorgias the governor of Idumea,

**[12:33]** Who came out with three thousand men of foot and four hundred horsemen.

**[12:34]** And it happened that in their fighting together a few of the Jews were slain.

**[12:35]** At which time Dositheus, one of Bacenor’s company, who was on horseback, and a strong man, was still upon Gorgias, and taking hold of his coat drew him by force; and when he would have taken that cursed man alive, a horseman of Thracia coming upon him smote off his shoulder, so that Gorgias fled unto Marisa.

**[12:36]** Now when they that were with Gorgias had fought long, and were weary, Judas called upon the Lord, that he would shew himself to be their helper and leader of the battle.

**[12:37]** And with that he began in his own language, and sung psalms with a loud voice, and rushing unawares upon Gorgias’ men, he put them to flight.

**[12:38]** So Judas gathered his host, and came into the city of Odollam, And when the seventh day came, they purified themselves, as the custom was, and kept the sabbath in the same place.

**[12:39]** And upon the day following, as the use had been, Judas and his company came to take up the bodies of them that were slain, and to bury them with their kinsmen in their fathers’ graves.

**[12:40]** Now under the coats of every one that was slain they found things consecrated to the idols of the Jamnites, which is forbidden the Jews by the law. Then every man saw that this was the cause wherefore they were slain.

**[12:41]** All men therefore praising the Lord, the righteous Judge, who had opened the things that were hid,

**[12:42]** Betook themselves unto prayer, and besought him that the sin committed might wholly be put out of remembrance. Besides, that noble Judas exhorted the people to keep themselves from sin, forsomuch as they saw before their eyes the things that came to pass for the sins of those that were slain.

**[12:43]** And when he had made a gathering throughout the company to the sum of two thousand drachms of silver, he sent it to Jerusalem to offer a sin offering, doing therein very well and honestly, in that he was mindful of the resurrection:

**[12:44]** For if he had not hoped that they that were slain should have risen again, it had been superfluous and vain to pray for the dead.

**[12:45]** And also in that he perceived that there was great favour laid up for those that died godly, it was an holy and good thought. Whereupon he made a reconciliation for the dead, that they might be delivered from sin.

**[13:1]** In the hundred forty and ninth year it was told Judas, that Antiochus Eupator was coming with a great power into Judea,

**[13:2]** And with him Lysias his protector, and ruler of his affairs, having either of them a Grecian power of footmen, an hundred and ten thousand, and horsemen five thousand and three hundred, and elephants two and twenty, and three hundred chariots armed with hooks.

**[13:3]** Menelaus also joined himself with them, and with great dissimulation encouraged Antiochus, not for the safeguard of the country, but because he thought to have been made governor.

**[13:4]** But the King of kings moved Antiochus’ mind against this wicked wretch, and Lysias informed the king that this man was the cause of all mischief, so that the king commanded to bring him unto Berea, and to put him to death, as the manner is in that place.

**[13:5]** Now there was in that place a tower of fifty cubits high, full of ashes, and it had a round instrument which on every side hanged down into the ashes.

**[13:6]** And whosoever was condemned of sacrilege, or had committed any other grievous crime, there did all men thrust him unto death.

**[13:7]** Such a death it happened that wicked man to die, not having so much as burial in the earth; and that most justly:

**[13:8]** For inasmuch as he had committed many sins about the altar, whose fire and ashes were holy, he received his death in ashes.

**[13:9]** Now the king came with a barbarous and haughty mind to do far worse to the Jews, than had been done in his father’s time.

**[13:10]** Which things when Judas perceived, he commanded the multitude to call upon the Lord night and day, that if ever at any other time, he would now also help them, being at the point to be put from their law, from their country, and from the holy temple:

**[13:11]** And that he would not suffer the people, that had even now been but a little refreshed, to be in subjection to the blasphemous nations.

**[13:12]** So when they had all done this together, and besought the merciful Lord with weeping and fasting, and lying flat upon the ground three days long, Judas, having exhorted them, commanded they should be in a readiness.

**[13:13]** And Judas, being apart with the elders, determined, before the king’s host should enter into Judea, and get the city, to go forth and try the matter in fight by the help of the Lord.

**[13:14]** So when he had committed all to the Creator of the world, and exhorted his soldiers to fight manfully, even unto death, for the laws, the temple, the city, the country, and the commonwealth, he camped by Modin:

**[13:15]** And having given the watchword to them that were about him, Victory is of God; with the most valiant and choice young men he went in into the king’s tent by night, and slew in the camp about four thousand men, and the chiefest of the elephants, with all that were upon him.

**[13:16]** And at last they filled the camp with fear and tumult, and departed with good success.

**[13:17]** This was done in the break of the day, because the protection of the Lord did help him.

**[13:18]** Now when the king had taken a taste of the manliness of the Jews, he went about to take the holds by policy,

**[13:19]** And marched toward Bethsura, which was a strong hold of the Jews: but he was put to flight, failed, and lost of his men:

**[13:20]** For Judas had conveyed unto them that were in it such things as were necessary.

**[13:21]** But Rhodocus, who was in the Jews’ host, disclosed the secrets to the enemies; therefore he was sought out, and when they had gotten him, they put him in prison.

**[13:22]** The king treated with them in Bethsum the second time, gave his hand, took their’s, departed, fought with Judas, was overcome;

**[13:23]** Heard that Philip, who was left over the affairs in Antioch, was desperately bent, confounded, intreated the Jews, submitted himself, and sware to all equal conditions, agreed with them, and offered sacrifice, honoured the temple, and dealt kindly with the place,

**[13:24]** And accepted well of Maccabeus, made him principal governor from Ptolemais unto the Gerrhenians;

**[13:25]** Came to Ptolemais: the people there were grieved for the covenants; for they stormed, because they would make their covenants void:

**[13:26]** Lysias went up to the judgment seat, said as much as could be in defence of the cause, persuaded, pacified, made them well affected, returned to Antioch. Thus it went touching the king’s coming and departing.

**[14:1]** After three years was Judas informed, that Demetrius the son of Seleucus, having entered by the haven of Tripolis with a great power and navy,

**[14:2]** Had taken the country, and killed Antiochus, and Lysias his protector.

**[14:3]** Now one Alcimus, who had been high priest, and had defiled himself wilfully in the times of their mingling with the Gentiles, seeing that by no means he could save himself, nor have any more access to the holy altar,

**[14:4]** Came to king Demetrius in the hundred and one and fiftieth year, presenting unto him a crown of gold, and a palm, and also of the boughs which were used solemnly in the temple: and so that day he held his peace.

**[14:5]** Howbeit having gotten opportunity to further his foolish enterprize, and being called into counsel by Demetrius, and asked how the Jews stood affected, and what they intended, he answered thereunto:

**[14:6]** Those of the Jews that he called Assideans, whose captain is Judas Maccabeus, nourish war and are seditious, and will not let the rest be in peace.

**[14:7]** Therefore I, being deprived of mine ancestors’ honour, I mean the high priesthood, am now come hither:

**[14:8]** First, verily for the unfeigned care I have of things pertaining to the king; and secondly, even for that I intend the good of mine own countrymen: for all our nation is in no small misery through the unadvised dealing of them aforersaid.

**[14:9]** Wherefore, O king, seeing knowest all these things, be careful for the country, and our nation, which is pressed on every side, according to the clemency that thou readily shewest unto all.

**[14:10]** For as long as Judas liveth, it is not possible that the state should be quiet.

**[14:11]** This was no sooner spoken of him, but others of the king’s friends, being maliciously set against Judas, did more incense Demetrius.

**[14:12]** And forthwith calling Nicanor, who had been master of the elephants, and making him governor over Judea, he sent him forth,

**[14:13]** Commanding him to slay Judas, and to scatter them that were with him, and to make Alcimus high priest of the great temple.

**[14:14]** Then the heathen, that had fled out of Judea from Judas, came to Nicanor by flocks, thinking the harm and calamities ot the Jews to be their welfare.

**[14:15]** Now when the Jews heard of Nicanor’s coming, and that the heathen were up against them, they cast earth upon their heads, and made supplication to him that had established his people for ever, and who always helpeth his portion with manifestation of his presence.

**[14:16]** So at the commandment of the captain they removed straightways from thence, and came near unto them at the town of Dessau.

**[14:17]** Now Simon, Judas’ brother, had joined battle with Nicanor, but was somewhat discomfited through the sudden silence of his enemies.

**[14:18]** Nevertheless Nicanor, hearing of the manliness of them that were with Judas, and the courageousness that they had to fight for their country, durst not try the matter by the sword.

**[14:19]** Wherefore he sent Posidonius, and Theodotus, and Mattathias, to make peace.

**[14:20]** So when they had taken long advisement thereupon, and the captain had made the multitude acquainted therewith, and it appeared that they were all of one mind, they consented to the covenants,

**[14:21]** And appointed a day to meet in together by themselves: and when the day came, and stools were set for either of them,

**[14:22]** Ludas placed armed men ready in convenient places, lest some treachery should be suddenly practised by the enemies: so they made a peaceable conference.

**[14:23]** Now Nicanor abode in Jerusalem, and did no hurt, but sent away the people that came flocking unto him.

**[14:24]** And he would not willingly have Judas out of his sight: for he love the man from his heart

**[14:25]** He prayed him also to take a wife, and to beget children: so he married, was quiet, and took part of this life.

**[14:26]** But Alcimus, perceiving the love that was betwixt them, and considering the covenants that were made, came to Demetrius, and told him that Nicanor was not well affected toward the state; for that he had ordained Judas, a traitor to his realm, to be the king’s successor.

**[14:27]** Then the king being in a rage, and provoked with the accusations of the most wicked man, wrote to Nicanor, signifying that he was much displeased with the covenants, and commanding him that he should send Maccabeus prisoner in all haste unto Antioch.

**[14:28]** When this came to Nicanor’s hearing, he was much confounded in himself, and took it grievously that he should make void the articles which were agreed upon, the man being in no fault.

**[14:29]** But because there was no dealing against the king, he watched his time to accomplish this thing by policy.

**[14:30]** Notwithstanding, when Maccabeus saw that Nicanor began to be churlish unto him, and that he entreated him more roughly than he was wont, perceiving that such sour behaviour came not of good, he gathered together not a few of his men, and withdrew himself from Nicanor.

**[14:31]** But the other, knowing that he was notably prevented by Judas’ policy, came into the great and holy temple, and commanded the priests, that were offering their usual sacrifices, to deliver him the man.

**[14:32]** And when they sware that they could not tell where the man was whom he sought,

**[14:33]** He stretched out his right hand toward the temple, and made an oath in this manner: If ye will not deliver me Judas as a prisoner, I will lay this temple of God even with the ground, and I will break down the altar, and erect a notable temple unto Bacchus.

**[14:34]** After these words he departed. Then the priests lifted up their hands toward heaven, and besought him that was ever a defender of their nation, saying in this manner;

**[14:35]** Thou, O Lord of all things, who hast need of nothing, wast pleased that the temple of thine habitation should be among us:

**[14:36]** Therefore now, O holy Lord of all holiness, keep this house ever undefiled, which lately was cleansed, and stop every unrighteous mouth.

**[14:37]** Now was there accused unto Nicanor one Razis, one of the elders of Jerusalem, a lover of his countrymen, and a man of very good report, who for his kindness was called a father of the Jews.

**[14:38]** For in the former times, when they mingled not themselves with the Gentiles, he had been accused of Judaism, and did boldly jeopard his body and life with all vehemency for the religion of the Jews.

**[14:39]** So Nicanor, willing to declare the hate that he bare unto the Jews, sent above five hundred men of war to take him:

**[14:40]** For he thought by taking him to do the Jews much hurt.

**[14:41]** Now when the multitude would have taken the tower, and violently broken into the outer door, and bade that fire should be brought to burn it, he being ready to be taken on every side fell upon his sword;

**[14:42]** Choosing rather to die manfully, than to come into the hands of the wicked, to be abused otherwise than beseemed his noble birth:

**[14:43]** But missing his stroke through haste, the multitude also rushing within the doors, he ran boldly up to the wall, and cast himself down manfully among the thickest of them.

**[14:44]** But they quickly giving back, and a space being made, he fell down into the midst of the void place.

**[14:45]** Nevertheless, while there was yet breath within him, being inflamed with anger, he rose up; and though his blood gushed out like spouts of water, and his wounds were grievous, yet he ran through the midst of the throng; and standing upon a steep rock,

**[14:46]** When as his blood was now quite gone, he plucked out his bowels, and taking them in both his hands, he cast them upon the throng, and calling upon the Lord of life and spirit to restore him those again, he thus died.

**[15:1]** But Nicanor, hearing that Judas and his company were in the strong places about Samaria, resolved without any danger to set upon them on the sabbath day.

**[15:2]** Nevertheless the Jews that were compelled to go with him said, O destroy not so cruelly and barbarously, but give honour to that day, which he, that seeth all things, hath honoured with holiness above all other days.

**[15:3]** Then the most ungracious wretch demanded, if there were a Mighty one in heaven, that had commanded the sabbath day to be kept.

**[15:4]** And when they said, There is in heaven a living Lord, and mighty, who commanded the seventh day to be kept:

**[15:5]** Then said the other, And I also am mighty upon earth, and I command to take arms, and to do the king’s business. Yet he obtained not to have his wicked will done.

**[15:6]** So Nicanor in exceeding pride and haughtiness determined to set up a publick monument of his victory over Judas and them that were with him.

**[15:7]** But Maccabeus had ever sure confidence that the Lord would help him:

**[15:8]** Wherefore he exhorted his people not to fear the coming of the heathen against them, but to remember the help which in former times they had received from heaven, and now to expect the victory and aid, which should come unto them from the Almighty.

**[15:9]** And so comforting them out of the law and the prophets, and withal putting them in mind of the battles that they won afore, he made them more cheerful.

**[15:10]** And when he had stirred up their minds, he gave them their charge, shewing them therewithall the falsehood of the heathen, and the breach of oaths.

**[15:11]** Thus he armed every one of them, not so much with defence of shields and spears, as with comfortable and good words: and beside that, he told them a dream worthy to be believed, as if it had been so indeed, which did not a little rejoice them.

**[15:12]** And this was his vision: That Onias, who had been high priest, a virtuous and a good man, reverend in conversation, gentle in condition, well spoken also, and exercised from a child in all points of virtue, holding up his hands prayed for the whole body of the Jews.

**[15:13]** This done, in like manner there appeared a man with gray hairs, and exceeding glorious, who was of a wonderful and excellent majesty.

**[15:14]** Then Onias answered, saying, This is a lover of the brethren, who prayeth much for the people, and for the holy city, to wit, Jeremias the prophet of God.

**[15:15]** Whereupon Jeremias holding forth his right hand gave to Judas a sword of gold, and in giving it spake thus,

**[15:16]** Take this holy sword, a gift from God, with the which thou shalt wound the adversaries.

**[15:17]** Thus being well comforted by the words of Judas, which were very good, and able to stir them up to valour, and to encourage the hearts of the young men, they determined not to pitch camp, but courageously to set upon them, and manfully to try the matter by conflict, because the city and the sanctuary and the temple were in danger.

**[15:18]** For the care that they took for their wives, and their children, their brethren, and folks, was in least account with them: but the greatest and principal fear was for the holy temple.

**[15:19]** Also they that were in the city took not the least care, being troubled for the conflict abroad.

**[15:20]** And now, when as all looked what should be the trial, and the enemies were already come near, and the army was set in array, and the beasts conveniently placed, and the horsemen set in wings,

**[15:21]** Maccabeus seeing the coming of the multitude, and the divers preparations of armour, and the fierceness of the beasts, stretched out his hands toward heaven, and called upon the Lord that worketh wonders, knowing that victory cometh not by arms, but even as it seemeth good to him, he giveth it to such as are worthy:

**[15:22]** Therefore in his prayer he said after this manner; O Lord, thou didst send thine angel in the time of Ezekias king of Judea, and didst slay in the host of Sennacherib an hundred fourscore and five thousand:

**[15:23]** Wherefore now also, O Lord of heaven, send a good angel before us for a fear and dread unto them;

**[15:24]** And through the might of thine arm let those be stricken with terror, that come against thy holy people to blaspheme. And he ended thus.

**[15:25]** Then Nicanor and they that were with him came forward with trumpets and songs.

**[15:26]** But Judas and his company encountered the enemies with invocation and prayer.

**[15:27]** So that fighting with their hands, and praying unto God with their hearts, they slew no less than thirty and five thousand men: for through the appearance of God they were greatly cheered.

**[15:28]** Now when the battle was done, returning again with joy, they knew that Nicanor lay dead in his harness.

**[15:29]** Then they made a great shout and a noise, praising the Almighty in their own language.

**[15:30]** And Judas, who was ever the chief defender of the citizens both in body and mind, and who continued his love toward his countrymen all his life, commanded to strike off Nicanor’s head, and his hand with his shoulder, and bring them to Jerusalem.

**[15:31]** So when he was there, and called them of his nation together, and set the priests before the altar, he sent for them that were of the tower,

**[15:32]** And shewed them vile Nicanor’s head, and the hand of that blasphemer, which with proud brags he had stretched out against the holy temple of the Almighty.

**[15:33]** And when he had cut out the tongue of that ungodly Nicanor, he commanded that they should give it by pieces unto the fowls, and hang up the reward of his madness before the temple.

**[15:34]** So every man praised toward the heaven the glorious Lord, saying, Blessed be he that hath kept his own place undefiled.

**[15:35]** He hanged also Nicanor’s head upon the tower, an evident and manifest sign unto all of the help of the Lord.

**[15:36]** And they ordained all with a common decree in no case to let that day pass without solemnity, but to celebrate the thirtieth day of the twelfth month, which in the Syrian tongue is called Adar, the day before Mardocheus’ day.

**[15:37]** Thus went it with Nicanor: and from that time forth the Hebrews had the city in their power. And here will I make an end.

**[15:38]** And if I have done well, and as is fitting the story, it is that which I desired: but if slenderly and meanly, it is that which I could attain unto.

**[15:39]** For as it is hurtful to drink wine or water alone; and as wine mingled with water is pleasant, and delighteth the taste: even so speech finely framed delighteth the ears of them that read the story. And here shall be an end.

