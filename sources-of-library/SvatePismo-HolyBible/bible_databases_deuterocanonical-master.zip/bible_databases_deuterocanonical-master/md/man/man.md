# Prayer of Manasseh



**[1:1]** O Lord, Almighty God of our fathers, Abraham, Isaac, and Jacob, and of their righteous seed; 

**[1:2]** who hast made heaven and earth, with all the ornament thereof; 

**[1:3]** who hast bound the sea by the word of thy commandment; who hast shut up the deep, and sealed it by thy terrible and glorious name;

**[1:4]** whom all men fear, and tremble before thy power; for the majesty of thy glory cannot be borne, and thine angry threatening toward sinners is importable: 

**[1:5]** but thy merciful promise is unmeasurable and unsearchable; 

**[1:6]** for thou art the most high Lord, of great compassion, longsuffering, very merciful, and repentest of the evils of men. Thou, O Lord, according to thy great goodness hast promised repentance and forgiveness to them that have sinned against thee: and of thine infinite mercies hast appointed repentance unto sinners, that they may be saved. 

**[1:7]** Thou therefore, O Lord, that art the God of the just, hast not appointed repentance to the just, as to Abraham, and Isaac, and Jacob, which have not sinned against thee; but thou hast appointed repentance unto me that am a sinner: cb**[1:8]** for I have sinned above the number of the sands of the sea. My transgressions, O Lord, are multiplied: my transgressions are multiplied, and I am not worthy to behold and see the height of heaven for the multitude of mine iniquities. 

**[1:9]** I am bowed down with many iron bands, that I cannot lift up mine head, neither have any release: for I have provoked thy wrath, and done evil before thee: I did not thy will, neither kept I thy commandments: I have set up abominations, and have multiplied offences. 

**[1:10]** Now therefore I bow the knee of mine heart, beseeching thee of grace. 

**[1:11]** I have sinned, O Lord, I have sinned, and I acknowledge mine iniquities: 

**[1:12]** wherefore, I humbly beseech thee, forgive me, O Lord, forgive me, and destroy me not with mine iniquites. Be not angry with me for ever, by reserving evil for me; neither condemn me to the lower parts of the earth. For thou art the God, even the God of them that repent; 

**[1:13]** and in me thou wilt shew all thy goodness: for thou wilt save me, that am unworthy, according to thy great mercy. 

**[1:14]** Therefore I will praise thee for ever all the days of my life: for all the powers of the heavens do praise thee, and thine is the glory for ever and ever. Amen.

