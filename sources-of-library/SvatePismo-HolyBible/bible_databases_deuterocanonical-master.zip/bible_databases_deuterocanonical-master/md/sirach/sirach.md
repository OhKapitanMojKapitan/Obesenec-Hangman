# Sirach



**[1:1]** All wisdom cometh from the Lord, and is with him for ever.

**[1:2]** Who can number the sand of the sea, and the drops of rain, and the days of eternity?

**[1:3]** Who can find out the height of heaven, and the breadth of the earth, and the deep, and wisdom?

**[1:4]** Wisdom hath been created before all things, and the understanding of prudence from everlasting.

**[1:5]** The word of God most high is the fountain of wisdom; and her ways are everlasting commandments.

**[1:6]** To whom hath the root of wisdom been revealed? or who hath known her wise counsels?

**[1:7]** Unto whom hath the knowledge of wisdom been made manifest? and who hath understood her great experience?

**[1:8]** There is one wise and greatly to be feared, the Lord sitting upon his throne.

**[1:9]** He created her, and saw her, and numbered her, and poured her out upon all his works.

**[1:10]** She is with all flesh according to his gift, and he hath given her to them that love him.

**[1:11]** The fear of the Lord is honour, and glory, and gladness, and a crown of rejoicing.

**[1:12]** The fear of the Lord maketh a merry heart, and giveth joy, and gladness, and a long life.

**[1:13]** Whoso feareth the Lord, it shall go well with him at the last, and he shall find favour in the day of his death.

**[1:14]** To fear the Lord is the beginning of wisdom: and it was created with the faithful in the womb.

**[1:15]** She hath built an everlasting foundation with men, and she shall continue with their seed.

**[1:16]** To fear the Lord is fulness of wisdom, and filleth men with her fruits.

**[1:17]** She filleth all their house with things desirable, and the garners with her increase.

**[1:18]** The fear of the Lord is a crown of wisdom, making peace and perfect health to flourish; both which are the gifts of God: and it enlargeth their rejoicing that love him.

**[1:19]** Wisdom raineth down skill and knowledge of understanding standing, and exalteth them to honour that hold her fast.

**[1:20]** The root of wisdom is to fear the Lord, and the branches thereof are long life.

**[1:21]** The fear of the Lord driveth away sins: and where it is present, it turneth away wrath.

**[1:22]** A furious man cannot be justified; for the sway of his fury shall be his destruction.

**[1:23]** A patient man will tear for a time, and afterward joy shall spring up unto him.

**[1:24]** He will hide his words for a time, and the lips of many shall declare his wisdom.

**[1:25]** The parables of knowledge are in the treasures of wisdom: but godliness is an abomination to a sinner.

**[1:26]** If thou desire wisdom, keep the commandments, and the Lord shall give her unto thee.

**[1:27]** For the fear of the Lord is wisdom and instruction: and faith and meekness are his delight.

**[1:28]** Distrust not the fear of the Lord when thou art poor: and come not unto him with a double heart.

**[1:29]** Be not an hypocrite in the sight of men, and take good heed what thou speakest.

**[1:30]** Exalt not thyself, lest thou fall, and bring dishonour upon thy soul, and so God discover thy secrets, and cast thee down in the midst of the congregation, because thou camest not in truth to the fear of the Lord, but thy heart is full of deceit.

**[2:1]** My son, if thou come to serve the Lord, prepare thy soul for temptation.

**[2:2]** Set thy heart aright, and constantly endure, and make not haste in time of trouble.

**[2:3]** Cleave unto him, and depart not away, that thou mayest be increased at thy last end.

**[2:4]** Whatsoever is brought upon thee take cheerfully, and be patient when thou art changed to a low estate.

**[2:5]** For gold is tried in the fire, and acceptable men in the furnace of adversity.

**[2:6]** Believe in him, and he will help thee; order thy way aright, and trust in him.

**[2:7]** Ye that fear the Lord, wait for his mercy; and go not aside, lest ye fall.

**[2:8]** Ye that fear the Lord, believe him; and your reward shall not fail.

**[2:9]** Ye that fear the Lord, hope for good, and for everlasting joy and mercy.

**[2:10]** Look at the generations of old, and see; did ever any trust in the Lord, and was confounded? or did any abide in his fear, and was forsaken? or whom did he ever despise, that called upon him?

**[2:11]** For the Lord is full of compassion and mercy, longsuffering, and very pitiful, and forgiveth sins, and saveth in time of affliction.

**[2:12]** Woe be to fearful hearts, and faint hands, and the sinner that goeth two ways!

**[2:13]** Woe unto him that is fainthearted! for he believeth not; therefore shall he not be defended.

**[2:14]** Woe unto you that have lost patience! and what will ye do when the Lord shall visit you?

**[2:15]** They that fear the Lord will not disobey his Word; and they that love him will keep his ways.

**[2:16]** They that fear the Lord will seek that which is well, pleasing unto him; and they that love him shall be filled with the law.

**[2:17]** They that fear the Lord will prepare their hearts, and humble their souls in his sight,

**[2:18]** Saying, We will fall into the hands of the Lord, and not into the hands of men: for as his majesty is, so is his mercy.

**[3:1]** Hear me your father, O children, and do thereafter, that ye may be safe.

**[3:2]** For the Lord hath given the father honour over the children, and hath confirmed the authority of the mother over the sons.

**[3:3]** Whoso honoureth his father maketh an atonement for his sins:

**[3:4]** And he that honoureth his mother is as one that layeth up treasure.

**[3:5]** Whoso honoureth his father shall have joy of his own children; and when he maketh his prayer, he shall be heard.

**[3:6]** He that honoureth his father shall have a long life; and he that is obedient unto the Lord shall be a comfort to his mother.

**[3:7]** He that feareth the Lord will honour his father, and will do service unto his parents, as to his masters.

**[3:8]** Honour thy father and mother both in word and deed, that a blessing may come upon thee from them.

**[3:9]** For the blessing of the father establisheth the houses of children; but the curse of the mother rooteth out foundations.

**[3:10]** Glory not in the dishonour of thy father; for thy father’s dishonour is no glory unto thee.

**[3:11]** For the glory of a man is from the honour of his father; and a mother in dishonour is a reproach to the children.

**[3:12]** My son, help thy father in his age, and grieve him not as long as he liveth.

**[3:13]** And if his understanding fail, have patience with him; and despise him not when thou art in thy full strength.

**[3:14]** For the relieving of thy father shall not be forgotten: and instead of sins it shall be added to build thee up.

**[3:15]** In the day of thine affliction it shall be remembered; thy sins also shall melt away, as the ice in the fair warm weather.

**[3:16]** He that forsaketh his father is as a blasphemer; and he that angereth his mother is cursed: of God.

**[3:17]** My son, go on with thy business in meekness; so shalt thou be beloved of him that is approved.

**[3:18]** The greater thou art, the more humble thyself, and thou shalt find favour before the Lord.

**[3:19]** Many are in high place, and of renown: but mysteries are revealed unto the meek.

**[3:20]** For the power of the Lord is great, and he is honoured of the lowly.

**[3:21]** Seek not out things that are too hard for thee, neither search the things that are above thy strength.

**[3:22]** But what is commanded thee, think thereupon with reverence, for it is not needful for thee to see with thine eyes the things that are in secret.

**[3:23]** Be not curious in unnecessary matters: for more things are shewed unto thee than men understand.

**[3:24]** For many are deceived by their own vain opinion; and an evil suspicion hath overthrown their judgment.

**[3:25]** Without eyes thou shalt want light: profess not the knowledge therefore that thou hast not.

**[3:26]** A stubborn heart shall fare evil at the last; and he that loveth danger shall perish therein.

**[3:27]** An obstinate heart shall be laden with sorrows; and the wicked man shall heap sin upon sin.

**[3:28]** In the punishment of the proud there is no remedy; for the plant of wickedness hath taken root in him.

**[3:29]** The heart of the prudent will understand a parable; and an attentive ear is the desire of a wise man.

**[3:30]** Water will quench a flaming fire; and alms maketh an atonement for sins.

**[3:31]** And he that requiteth good turns is mindful of that which may come hereafter; and when he falleth, he shall find a stay.

**[4:1]** My son, defraud not the poor of his living, and make not the needy eyes to wait long.

**[4:2]** Make not an hungry soul sorrowful; neither provoke a man in his distress.

**[4:3]** Add not more trouble to an heart that is vexed; and defer not to give to him that is in need.

**[4:4]** Reject not the supplication of the afflicted; neither turn away thy face from a poor man.

**[4:5]** Turn not away thine eye from the needy, and give him none occasion to curse thee:

**[4:6]** For if he curse thee in the bitterness of his soul, his prayer shall be heard of him that made him.

**[4:7]** Get thyself the love of the congregation, and bow thy head to a great man.

**[4:8]** Let it not grieve thee to bow down thine ear to the poor, and give him a friendly answer with meekness.

**[4:9]** Deliver him that suffereth wrong from the hand of the oppressor; and be not fainthearted when thou sittest in judgment.

**[4:10]** Be as a father unto the fatherless, and instead of an husband unto their mother: so shalt thou be as the son of the most High, and he shall love thee more than thy mother doth.

**[4:11]** Wisdom exalteth her children, and layeth hold of them that seek her.

**[4:12]** He that loveth her loveth life; and they that seek to her early shall be filled with joy.

**[4:13]** He that holdeth her fast shall inherit glory; and wheresoever she entereth, the Lord will bless.

**[4:14]** They that serve her shall minister to the Holy One: and them that love her the Lord doth love.

**[4:15]** Whoso giveth ear unto her shall judge the nations: and he that attendeth unto her shall dwell securely.

**[4:16]** If a man commit himself unto her, he shall inherit her; and his generation shall hold her in possession.

**[4:17]** For at the first she will walk with him by crooked ways, and bring fear and dread upon him, and torment him with her discipline, until she may trust his soul, and try him by her laws.

**[4:18]** Then will she return the straight way unto him, and comfort him, and shew him her secrets.

**[4:19]** But if he go wrong, she will forsake him, and give him over to his own ruin.

**[4:20]** Observe the opportunity, and beware of evil; and be not ashamed when it concerneth thy soul.

**[4:21]** For there is a shame that bringeth sin; and there is a shame which is glory and grace.

**[4:22]** Accept no person against thy soul, and let not the reverence of any man cause thee to fall.

**[4:23]** And refrain not to speak, when there is occasion to do good, and hide not thy wisdom in her beauty.

**[4:24]** For by speech wisdom shall be known: and learning by the word of the tongue.

**[4:25]** In no wise speak against the truth; but be abashed of the error of thine ignorance.

**[4:26]** Be not ashamed to confess thy sins; and force not the course of the river.

**[4:27]** Make not thyself an underling to a foolish man; neither accept the person of the mighty.

**[4:28]** Strive for the truth unto death, and the Lord shall fight for thee.

**[4:29]** Be not hasty in thy tongue, and in thy deeds slack and remiss.

**[4:30]** Be not as a lion in thy house, nor frantick among thy servants.

**[4:31]** Let not thine hand be stretched out to receive, and shut when thou shouldest repay.

**[5:1]** Set thy heart upon thy goods; and say not, I have enough for my life.

**[5:2]** Follow not thine own mind and thy strength, to walk in the ways of thy heart:

**[5:3]** And say not, Who shall controul me for my works? for the Lord will surely revenge thy pride.

**[5:4]** Say not, I have sinned, and what harm hath happened unto me? for the Lord is longsuffering, he will in no wise let thee go.

**[5:5]** Concerning propitiation, be not without fear to add sin unto sin:

**[5:6]** And say not His mercy is great; he will be pacified for the multitude of my sins: for mercy and wrath come from him, and his indignation resteth upon sinners.

**[5:7]** Make no tarrying to turn to the Lord, and put not off from day to day: for suddenly shall the wrath of the Lord come forth, and in thy security thou shalt be destroyed, and perish in the day of vengeance.

**[5:8]** Set not thine heart upon goods unjustly gotten, for they shall not profit thee in the day of calamity.

**[5:9]** Winnow not with every wind, and go not into every way: for so doth the sinner that hath a double tongue.

**[5:10]** Be stedfast in thy understanding; and let thy word be the same.

**[5:11]** Be swift to hear; and let thy life be sincere; and with patience give answer.

**[5:12]** If thou hast understanding, answer thy neighbour; if not, lay thy hand upon thy mouth.

**[5:13]** Honour and shame is in talk: and the tongue of man is his fall.

**[5:14]** Be not called a whisperer, and lie not in wait with thy tongue: for a foul shame is upon the thief, and an evil condemnation upon the double tongue.

**[5:15]** Be not ignorant of any thing in a great matter or a small.

**[6:1]** Instead of a friend become not an enemy; for thereby thou shalt inherit an ill name, shame, and reproach: even so shall a sinner that hath a double tongue.

**[6:2]** Extol not thyself in the counsel of thine own heart; that thy soul be not torn in pieces as a bull straying alone.

**[6:3]** Thou shalt eat up thy leaves, and lose thy fruit, and leave thyself as a dry tree.

**[6:4]** A wicked soul shall destroy him that hath it, and shall make him to be laughed to scorn of his enemies.

**[6:5]** Sweet language will multiply friends: and a fairspeaking tongue will increase kind greetings.

**[6:6]** Be in peace with many: nevertheless have but one counsellor of a thousand.

**[6:7]** If thou wouldest get a friend, prove him first and be not hasty to credit him.

**[6:8]** For some man is a friend for his own occasion, and will not abide in the day of thy trouble.

**[6:9]** And there is a friend, who being turned to enmity, and strife will discover thy reproach.

**[6:10]** Again, some friend is a companion at the table, and will not continue in the day of thy affliction.

**[6:11]** But in thy prosperity he will be as thyself, and will be bold over thy servants.

**[6:12]** If thou be brought low, he will be against thee, and will hide himself from thy face.

**[6:13]** Separate thyself from thine enemies, and take heed of thy friends.

**[6:14]** A faithfull friend is a strong defence: and he that hath found such an one hath found a treasure.

**[6:15]** Nothing doth countervail a faithful friend, and his excellency is invaluable.

**[6:16]** A faithful friend is the medicine of life; and they that fear the Lord shall find him.

**[6:17]** Whoso feareth the Lord shall direct his friendship aright: for as he is, so shall his neighbour be also.

**[6:18]** My son, gather instruction from thy youth up: so shalt thou find wisdom till thine old age.

**[6:19]** Come unto her as one that ploweth and soweth, and wait for her good fruits: for thou shalt not toil much in labouring about her, but thou shalt eat of her fruits right soon.

**[6:20]** She is very unpleasant to the unlearned: he that is without understanding will not remain with her.

**[6:21]** She will lie upon him as a mighty stone of trial; and he will cast her from him ere it be long.

**[6:22]** For wisdom is according to her name, and she is not manifest unto many.

**[6:23]** Give ear, my son, receive my advice, and refuse not my counsel,

**[6:24]** And put thy feet into her fetters, and thy neck into her chain.

**[6:25]** Bow down thy shoulder, and bear her, and be not grieved with her bonds.

**[6:26]** Come unto her with thy whole heart, and keep her ways with all thy power.

**[6:27]** Search, and seek, and she shall be made known unto thee: and when thou hast got hold of her, let her not go.

**[6:28]** For at the last thou shalt find her rest, and that shall be turned to thy joy.

**[6:29]** Then shall her fetters be a strong defence for thee, and her chains a robe of glory.

**[6:30]** For there is a golden ornament upon her, and her bands are purple lace.

**[6:31]** Thou shalt put her on as a robe of honour, and shalt put her about thee as a crown of joy.

**[6:32]** My son, if thou wilt, thou shalt be taught: and if thou wilt apply thy mind, thou shalt be prudent.

**[6:33]** If thou love to hear, thou shalt receive understanding: and if thou bow thine ear, thou shalt be wise,

**[6:34]** Stand in the multitude of the elders; and cleave unto him that is wise.

**[6:35]** Be willing to hear every godly discourse; and let not the parables of understanding escape thee.

**[6:36]** And if thou seest a man of understanding, get thee betimes unto him, and let thy foot wear the steps of his door.

**[6:37]** Let thy mind be upon the ordinances of the Lord and meditate continually in his commandments: he shall establish thine heart, and give thee wisdom at thine owns desire.

**[7:1]** Do no evil, so shall no harm come unto thee.

**[7:2]** Depart from the unjust, and iniquity shall turn away from thee.

**[7:3]** My son, sow not upon the furrows of unrighteousness, and thou shalt not reap them sevenfold.

**[7:4]** Seek not of the Lord preeminence, neither of the king the seat of honour.

**[7:5]** justify not thyself before the Lord; and boast not of thy wisdom before the king.

**[7:6]** Seek not to be judge, being not able to take away iniquity; lest at any time thou fear the person of the mighty, an stumblingblock in the way of thy uprightness.

**[7:7]** Offend not against the multitude of a city, and then thou shalt not cast thyself down among the people.

**[7:8]** Bind not one sin upon another; for in one thou shalt not be unpunished.

**[7:9]** Say not, God will look upon the multitude of my oblations, and when I offer to the most high God, he will accept it.

**[7:10]** Be not fainthearted when thou makest thy prayer, and neglect not to give alms.

**[7:11]** Laugh no man to scorn in the bitterness of his soul: for there is one which humbleth and exalteth.

**[7:12]** Devise not a lie against thy brother; neither do the like to thy friend.

**[7:13]** Use not to make any manner of lie: for the custom thereof is not good.

**[7:14]** Use not many words in a multitude of elders, and make not much babbling when thou prayest.

**[7:15]** Hate not laborious work, neither husbandry, which the most High hath ordained.

**[7:16]** Number not thyself among the multitude of sinners, but remember that wrath will not tarry long.

**[7:17]** Humble thyself greatly: for the vengeance of the ungodly is fire and worms.

**[7:18]** Change not a friend for any good by no means; neither a faithful brother for the gold of Ophir.

**[7:19]** Forego not a wise and good woman: for her grace is above gold.

**[7:20]** Whereas thy servant worketh truly, entreat him not evil. nor the hireling that bestoweth himself wholly for thee.

**[7:21]** Let thy soul love a good servant, and defraud him not of liberty.

**[7:22]** Hast thou cattle? have an eye to them: and if they be for thy profit, keep them with thee.

**[7:23]** Hast thou children? instruct them, and bow down their neck from their youth.

**[7:24]** Hast thou daughters? have a care of their body, and shew not thyself cheerful toward them.

**[7:25]** Marry thy daughter, and so shalt thou have performed a weighty matter: but give her to a man of understanding.

**[7:26]** Hast thou a wife after thy mind? forsake her not: but give not thyself over to a light woman.

**[7:27]** Honour thy father with thy whole heart, and forget not the sorrows of thy mother.

**[7:28]** Remember that thou wast begotten of them; and how canst thou recompense them the things that they have done for thee?

**[7:29]** Fear the Lord with all thy soul, and reverence his priests.

**[7:30]** Love him that made thee with all thy strength, and forsake not his ministers.

**[7:31]** Fear the Lord, and honor the priest; and give him his portion, as it is commanded thee; the firstfruits, and the trespass offering, and the gift of the shoulders, and the sacrifice of sanctification, and the firstfruits of the holy things.

**[7:32]** And stretch thine hand unto the poor, that thy blessing may be perfected.

**[7:33]** A gift hath grace in the sight of every man living; and for the dead detain it not.

**[7:34]** Fail not to be with them that weep, and mourn with them that mourn.

**[7:35]** Be not slow to visit the sick: for that shall make thee to be beloved.

**[7:36]** Whatsoever thou takest in hand, remember the end, and thou shalt never do amiss.

**[8:1]** Strive not with a mighty man’ lest thou fall into his hands.

**[8:2]** Be not at variance with a rich man, lest he overweigh thee: for gold hath destroyed many, and perverted the hearts of kings.

**[8:3]** Strive not with a man that is full of tongue, and heap not wood upon his fire.

**[8:4]** Jest not with a rude man, lest thy ancestors be disgraced.

**[8:5]** Reproach not a man that turneth from sin, but remember that we are all worthy of punishment.

**[8:6]** Dishonour not a man in his old age: for even some of us wax old.

**[8:7]** Rejoice not over thy greatest enemy being dead, but remember that we die all.

**[8:8]** Despise not the discourse of the wise, but acquaint thyself with their proverbs: for of them thou shalt learn instruction, and how to serve great men with ease.

**[8:9]** Miss not the discourse of the elders: for they also learned of their fathers, and of them thou shalt learn understanding, and to give answer as need requireth.

**[8:10]** Kindle not the coals of a sinner, lest thou be burnt with the flame of his fire.

**[8:11]** Rise not up in anger at the presence of an injurious person, lest he lie in wait to entrap thee in thy words

**[8:12]** Lend not unto him that is mightier than thyself; for if thou lendest him, count it but lost.

**[8:13]** Be not surety above thy power: for if thou be surety, take care to pay it.

**[8:14]** Go not to law with a judge; for they will judge for him according to his honour.

**[8:15]** Travel not by the way with a bold fellow, lest he become grievous unto thee: for he will do according to his own will, and thou shalt perish with him through his folly.

**[8:16]** Strive not with an angry man, and go not with him into a solitary place: for blood is as nothing in his sight, and where there is no help, he will overthrow thee.

**[8:17]** Consult not with a fool; for he cannot keep counsel.

**[8:18]** Do no secret thing before a stranger; for thou knowest not what he will bring forth.

**[8:19]** Open not thine heart to every man, lest he requite thee with a shrewd turn.

**[9:1]** Be not jealous over the wife of thy bosom, and teach her not an evil lesson against thyself.

**[9:2]** Give not thy soul unto a woman to set her foot upon thy substance.

**[9:3]** Meet not with an harlot, lest thou fall into her snares.

**[9:4]** Use not much the company of a woman that is a singer, lest thou be taken with her attempts.

**[9:5]** Gaze not on a maid, that thou fall not by those things that are precious in her.

**[9:6]** Give not thy soul unto harlots, that thou lose not thine inheritance.

**[9:7]** Look not round about thee in the streets of the city, neither wander thou in the solitary place thereof.

**[9:8]** Turn away thine eye from a beautiful woman, and look not upon another’s beauty; for many have been deceived by the beauty of a woman; for herewith love is kindled as a fire.

**[9:9]** Sit not at all with another man’s wife, nor sit down with her in thine arms, and spend not thy money with her at the wine; lest thine heart incline unto her, and so through thy desire thou fall into destruction.

**[9:10]** Forsake not an old friend; for the new is not comparable to him: a new friend is as new wine; when it is old, thou shalt drink it with pleasure.

**[9:11]** Envy not the glory of a sinner: for thou knowest not what shall be his end.

**[9:12]** Delight not in the thing that the ungodly have pleasure in; but remember they shall not go unpunished unto their grave.

**[9:13]** Keep thee far from the man that hath power to kill; so shalt thou not doubt the fear of death: and if thou come unto him, make no fault, lest he take away thy life presently: remember that thou goest in the midst of snares, and that thou walkest upon the battlements of the city.

**[9:14]** As near as thou canst, guess at thy neighbour, and consult with the wise.

**[9:15]** Let thy talk be with the wise, and all thy communication in the law of the most High.

**[9:16]** And let just men eat and drink with thee; and let thy glorying be in the fear of the Lord.

**[9:17]** For the hand of the artificer the work shall be commended: and the wise ruler of the people for his speech.

**[9:18]** A man of an ill tongue is dangerous in his city; and he that is rash in his talk shall be hated.

**[10:1]** A wise judge will instruct his people; and the government of a prudent man is well ordered.

**[10:2]** As the judge of the people is himself, so are his officers; and what manner of man the ruler of the city is, such are all they that dwell therein.

**[10:3]** An unwise king destroyeth his people; but through the prudence of them which are in authority the city shall be inhabited.

**[10:4]** The power of the earth is in the hand of the Lord, and in due time he will set over it one that is profitable.

**[10:5]** In the hand of God is the prosperity of man: and upon the person of the scribe shall he lay his honour.

**[10:6]** Bear not hatred to thy neighbour for every wrong; and do nothing at all by injurious practices.

**[10:7]** Pride is hateful before God and man: and by both doth one commit iniquity.

**[10:8]** Because of unrighteous dealings, injuries, and riches got by deceit, the kingdom is translated from one people to another.

**[10:9]** Why is earth and ashes proud? There is not a more wicked thing than a covetous man: for such an one setteth his own soul to sale; because while he liveth he casteth away his bowels.

**[10:10]** The physician cutteth off a long disease; and he that is to day a king to morrow shall die.

**[10:11]** For when a man is dead, he shall inherit creeping things, beasts, and worms.

**[10:12]** The beginning of pride is when one departeth from God, and his heart is turned away from his Maker.

**[10:13]** For pride is the beginning of sin, and he that hath it shall pour out abomination: and therefore the Lord brought upon them strange calamities, and overthrew them utterly.

**[10:14]** The Lord hath cast down the thrones of proud princes, and set up the meek in their stead.

**[10:15]** The Lord hath plucked up the roots of the proud nations, and planted the lowly in their place.

**[10:16]** The Lord overthrew countries of the heathen, and destroyed them to the foundations of the earth.

**[10:17]** He took some of them away, and destroyed them, and hath made their memorial to cease from the earth.

**[10:18]** Pride was not made for men, nor furious anger for them that are born of a woman.

**[10:19]** They that fear the Lord are a sure seed, and they that love him an honourable plant: they that regard not the law are a dishonourable seed; they that transgress the commandments are a deceivable seed.

**[10:20]** Among brethren he that is chief is honorable; so are they that fear the Lord in his eyes.

**[10:21]** The fear of the Lord goeth before the obtaining of authority: but roughness and pride is the losing thereof.

**[10:22]** Whether he be rich, noble, or poor, their glory is the fear of the Lord.

**[10:23]** It is not meet to despise the poor man that hath understanding; neither is it convenient to magnify a sinful man.

**[10:24]** Great men, and judges, and potentates, shall be honoured; yet is there none of them greater than he that feareth the Lord.

**[10:25]** Unto the servant that is wise shall they that are free do service: and he that hath knowledge will not grudge when he is reformed.

**[10:26]** Be not overwise in doing thy business; and boast not thyself in the time of thy distress.

**[10:27]** Better is he that laboureth, and aboundeth in all things, than he that boasteth himself, and wanteth bread.

**[10:28]** My son, glorify thy soul in meekness, and give it honour according to the dignity thereof.

**[10:29]** Who will justify him that sinneth against his own soul? and who will honour him that dishonoureth his own life?

**[10:30]** The poor man is honoured for his skill, and the rich man is honoured for his riches.

**[10:31]** He that is honoured in poverty, how much more in riches? and he that is dishonourable in riches, how much more in poverty?

**[11:1]** Wisdom lifteth up the head of him that is of low degree, and maketh him to sit among great men.

**[11:2]** Commend not a man for his beauty; neither abhor a man for his outward appearance.

**[11:3]** The bee is little among such as fly; but her fruit is the chief of sweet things.

**[11:4]** Boast not of thy clothing and raiment, and exalt not thyself in the day of honour: for the works of the Lord are wonderful, and his works among men are hidden.

**[11:5]** Many kings have sat down upon the ground; and one that was never thought of hath worn the crown.

**[11:6]** Many mighty men have been greatly disgraced; and the honourable delivered into other men’s hands.

**[11:7]** Blame not before thou hast examined the truth: understand first, and then rebuke.

**[11:8]** Answer not before thou hast heard the cause: neither interrupt men in the midst of their talk.

**[11:9]** Strive not in a matter that concerneth thee not; and sit not in judgment with sinners.

**[11:10]** My son, meddle not with many matters: for if thou meddle much, thou shalt not be innocent; and if thou follow after, thou shalt not obtain, neither shalt thou escape by fleeing.

**[11:11]** There is one that laboureth, and taketh pains, and maketh haste, and is so much the more behind.

**[11:12]** Again, there is another that is slow, and hath need of help, wanting ability, and full of poverty; yet the eye of the Lord looked upon him for good, and set him up from his low estate,

**[11:13]** And lifted up his head from misery; so that many that saw from him is peace over all the

**[11:14]** Prosperity and adversity, life and death, poverty and riches, come of the Lord.

**[11:15]** Wisdom, knowledge, and understanding of the law, are of the Lord: love, and the way of good works, are from him.

**[11:16]** Error and darkness had their beginning together with sinners: and evil shall wax old with them that glory therein.

**[11:17]** The gift of the Lord remaineth with the ungodly, and his favour bringeth prosperity for ever.

**[11:18]** There is that waxeth rich by his wariness and pinching, and this his the portion of his reward:

**[11:19]** Whereas he saith, I have found rest, and now will eat continually of my goods; and yet he knoweth not what time shall come upon him, and that he must leave those things to others, and die.

**[11:20]** Be stedfast in thy covenant, and be conversant therein, and wax old in thy work.

**[11:21]** Marvel not at the works of sinners; but trust in the Lord, and abide in thy labour: for it is an easy thing in the sight of the Lord on the sudden to make a poor man rich.

**[11:22]** The blessing of the Lord is in the reward of the godly, and suddenly he maketh his blessing flourish.

**[11:23]** Say not, What profit is there of my service? and what good things shall I have hereafter?

**[11:24]** Again, say not, I have enough, and possess many things, and what evil shall I have hereafter?

**[11:25]** In the day of prosperity there is a forgetfulness of affliction: and in the day of affliction there is no more remembrance of prosperity.

**[11:26]** For it is an easy thing unto the Lord in the day of death to reward a man according to his ways.

**[11:27]** The affliction of an hour maketh a man forget pleasure: and in his end his deeds shall be discovered.

**[11:28]** Judge none blessed before his death: for a man shall be known in his children.

**[11:29]** Bring not every man into thine house: for the deceitful man hath many trains.

**[11:30]** Like as a partridge taken and kept in a cage, so is the heart of the proud; and like as a spy, watcheth he for thy fall:

**[11:31]** For he lieth in wait, and turneth good into evil, and in things worthy praise will lay blame upon thee.

**[11:32]** Of a spark of fire a heap of coals is kindled: and a sinful man layeth wait for blood.

**[11:33]** Take heed of a mischievous man, for he worketh wickedness; lest he bring upon thee a perpetual blot.

**[11:34]** Receive a stranger into thine house, and he will disturb thee, and turn thee out of thine own.

**[12:1]** When thou wilt do good know to whom thou doest it; so shalt thou be thanked for thy benefits.

**[12:2]** Do good to the godly man, and thou shalt find a recompence; and if not from him, yet from the most High.

**[12:3]** There can no good come to him that is always occupied in evil, nor to him that giveth no alms.

**[12:4]** Give to the godly man, and help not a sinner.

**[12:5]** Do well unto him that is lowly, but give not to the ungodly: hold back thy bread, and give it not unto him, lest he overmaster thee thereby: for else thou shalt receive twice as much evil for all the good thou shalt have done unto him.

**[12:6]** For the most High hateth sinners, and will repay vengeance unto the ungodly, and keepeth them against the mighty day of their punishment.

**[12:7]** Give unto the good, and help not the sinner.

**[12:8]** A friend cannot be known in prosperity: and an enemy cannot be hidden in adversity.

**[12:9]** In the prosperity of a man enemies will be grieved: but in his adversity even a friend will depart.

**[12:10]** Never trust thine enemy: for like as iron rusteth, so is his wickedness.

**[12:11]** Though he humble himself, and go crouching, yet take good heed and beware of him, and thou shalt be unto him as if thou hadst wiped a lookingglass, and thou shalt know that his rust hath not been altogether wiped away.

**[12:12]** Set him not by thee, lest, when he hath overthrown thee, he stand up in thy place; neither let him sit at thy right hand, lest he seek to take thy seat, and thou at the last remember my words, and be pricked therewith.

**[12:13]** Who will pity a charmer that is bitten with a serpent, or any such as come nigh wild beasts?

**[12:14]** So one that goeth to a sinner, and is defiled with him in his sins, who will pity?

**[12:15]** For a while he will abide with thee, but if thou begin to fall, he will not tarry.

**[12:16]** An enemy speaketh sweetly with his lips, but in his heart he imagineth how to throw thee into a pit: he will weep with his eyes, but if he find opportunity, he will not be satisfied with blood.

**[12:17]** If adversity come upon thee, thou shalt find him there first; and though he pretend to help thee, yet shall he undermine thee.

**[12:18]** He will shake his head, and clap his hands, and whisper much, and change his countenance.

**[13:1]** He that toucheth pitch shall be defiled therewith; and he that hath fellowship with a proud man shall be like unto him.

**[13:2]** Burden not thyself above thy power while thou livest; and have no fellowship with one that is mightier and richer than thyself: for how agree the kettle and the earthen pot together? for if the one be smitten against the other, it shall be broken.

**[13:3]** The rich man hath done wrong, and yet he threateneth withal: the poor is wronged, and he must intreat also.

**[13:4]** If thou be for his profit, he will use thee: but if thou have nothing, he will forsake thee.

**[13:5]** If thou have any thing, he will live with thee: yea, he will make thee bare, and will not be sorry for it.

**[13:6]** If he have need of thee, he will deceive thee, and smile upon thee, and put thee in hope; he will speak thee fair, and say, What wantest thou?

**[13:7]** And he will shame thee by his meats, until he have drawn thee dry twice or thrice, and at the last he will laugh thee to scorn afterward, when he seeth thee, he will forsake thee, and shake his head at thee.

**[13:8]** Beware that thou be not deceived and brought down in thy jollity.

**[13:9]** If thou be invited of a mighty man, withdraw thyself, and so much the more will he invite thee.

**[13:10]** Press thou not upon him, lest thou be put back; stand not far off, lest thou be forgotten.

**[13:11]** Affect not to be made equal unto him in talk, and believe not his many words: for with much communication will he tempt thee, and smiling upon thee will get out thy secrets:

**[13:12]** But cruelly he will lay up thy words, and will not spare to do thee hurt, and to put thee in prison.

**[13:13]** Observe, and take good heed, for thou walkest in peril of thy overthrowing: when thou hearest these things, awake in thy sleep.

**[13:14]** Love the Lord all thy life, and call upon him for thy salvation.

**[13:15]** Every beast loveth his like, and every man loveth his neighbor.

**[13:16]** All flesh consorteth according to kind, and a man will cleave to his like.

**[13:17]** What fellowship hath the wolf with the lamb? so the sinner with the godly.

**[13:18]** What agreement is there between the hyena and a dog? and what peace between the rich and the poor?

**[13:19]** As the wild ass is the lion’s prey in the wilderness: so the rich eat up the poor.

**[13:20]** As the proud hate humility: so doth the rich abhor the poor.

**[13:21]** A rich man beginning to fall is held up of his friends: but a poor man being down is thrust away by his friends.

**[13:22]** When a rich man is fallen, he hath many helpers: he speaketh things not to be spoken, and yet men justify him: the poor man slipped, and yet they rebuked him too; he spake wisely, and could have no place.

**[13:23]** When a rich man speaketh, every man holdeth his tongue, and, look, what he saith, they extol it to the clouds: but if the poor man speak, they say, What fellow is this? and if he stumble, they will help to overthrow him.

**[13:24]** Riches are good unto him that hath no sin, and poverty is evil in the mouth of the ungodly.

**[13:25]** The heart of a man changeth his countenance, whether it be for good or evil: and a merry heart maketh a cheerful countenance.

**[13:26]** A cheerful countenance is a token of a heart that is in prosperity; and the finding out of parables is a wearisome labour of the mind.

**[14:1]** Blessed is the man that hath not slipped with his mouth, and is not pricked with the multitude of sins.

**[14:2]** Blessed is he whose conscience hath not condemned him, and who is not fallen from his hope in the Lord.

**[14:3]** Riches are not comely for a niggard: and what should an envious man do with money?

**[14:4]** He that gathereth by defrauding his own soul gathereth for others, that shall spend his goods riotously.

**[14:5]** He that is evil to himself, to whom will he be good? he shall not take pleasure in his goods.

**[14:6]** There is none worse than he that envieth himself; and this is a recompence of his wickedness.

**[14:7]** And if he doeth good, he doeth it unwillingly; and at the last he will declare his wickedness.

**[14:8]** The envious man hath a wicked eye; he turneth away his face, and despiseth men.

**[14:9]** A covetous man’s eye is not satisfied with his portion; and the iniquity of the wicked drieth up his soul.

**[14:10]** A wicked eye envieth his bread, and he is a niggard at his table.

**[14:11]** My son, according to thy ability do good to thyself, and give the Lord his due offering.

**[14:12]** Remember that death will not be long in coming, and that the covenant of the grave is not shewed unto thee.

**[14:13]** Do good unto thy friend before thou die, and according to thy ability stretch out thy hand and give to him.

**[14:14]** Defraud not thyself of the good day, and let not the part of a good desire overpass thee.

**[14:15]** Shalt thou not leave thy travails unto another? and thy labours to be divided by lot?

**[14:16]** Give, and take, and sanctify thy soul; for there is no seeking of dainties in the grave.

**[14:17]** All flesh waxeth old as a garment: for the covenant from the beginning is, Thou shalt die the death.

**[14:18]** As of the green leaves on a thick tree, some fall, and some grow; so is the generation of flesh and blood, one cometh to an end, and another is born.

**[14:19]** Every work rotteth and consumeth away, and the worker thereof shall go withal.

**[14:20]** Blessed is the man that doth meditate good things in wisdom, and that reasoneth of holy things by his understanding. ing.

**[14:21]** He that considereth her ways in his heart shall also have understanding in her secrets.

**[14:22]** Go after her as one that traceth, and lie in wait in her ways.

**[14:23]** He that prieth in at her windows shall also hearken at her doors.

**[14:24]** He that doth lodge near her house shall also fasten a pin in her walls.

**[14:25]** He shall pitch his tent nigh unto her, and shall lodge in a lodging where good things are.

**[14:26]** He shall set his children under her shelter, and shall lodge under her branches.

**[14:27]** By her he shall be covered from heat, and in her glory shall he dwell.

**[15:1]** He that feareth the Lord will do good, and he that hath the knowledge of the law shall obtain her.

**[15:2]** And as a mother shall she meet him, and receive him as a wife married of a virgin.

**[15:3]** With the bread of understanding shall she feed him, and give him the water of wisdom to drink.

**[15:4]** He shall be stayed upon her, and shall not be moved; and shall rely upon her, and shall not be confounded.

**[15:5]** She shall exalt him above his neighbours, and in the midst of the congregation shall she open his mouth.

**[15:6]** He shall find joy and a crown of gladness, and she shall cause him to inherit an everlasting name.

**[15:7]** But foolish men shall not attain unto her, and sinners shall not see her.

**[15:8]** For she is far from pride, and men that are liars cannot remember her.

**[15:9]** Praise is not seemly in the mouth of a sinner, for it was not sent him of the Lord.

**[15:10]** For praise shall be uttered in wisdom, and the Lord will prosper it.

**[15:11]** Say not thou, It is through the Lord that I fell away: for thou oughtest not to do the things that he hateth.

**[15:12]** Say not thou, He hath caused me to err: for he hath no need of the sinful man.

**[15:13]** The Lord hateth all abomination; and they that fear God love it not.

**[15:14]** He himself made man from the beginning, and left him in the hand of his counsel;

**[15:15]** If thou wilt, to keep the commandments, and to perform acceptable faithfulness.

**[15:16]** He hath set fire and water before thee: stretch forth thy hand unto whether thou wilt.

**[15:17]** Before man is life and death; and whether him liketh shall be given him.

**[15:18]** For the wisdom of the Lord is great, and he is mighty in power, and beholdeth all things:

**[15:19]** And his eyes are upon them that fear him, and he knoweth every work of man.

**[15:20]** He hath commanded no man to do wickedly, neither hath he given any man licence to sin.

**[16:1]** Desire not a multitude of unprofitable children, neither delight in ungodly sons.

**[16:2]** Though they multiply, rejoice not in them, except the fear of the Lord be with them.

**[16:3]** Trust not thou in their life, neither respect their multitude: for one that is just is better than a thousand; and better it is to die without children, than to have them that are ungodly.

**[16:4]** For by one that hath understanding shall the city be replenished: but the kindred of the wicked shall speedily become desolate.

**[16:5]** Many such things have I seen with mine eyes, and mine ear hath heard greater things than these.

**[16:6]** In the congregation of the ungodly shall a fire be kindled; and in a rebellious nation wrath is set on fire.

**[16:7]** He was not pacified toward the old giants, who fell away in the strength of their foolishness.

**[16:8]** Neither spared he the place where Lot sojourned, but abhorred them for their pride.

**[16:9]** He pitied not the people of perdition, who were taken away in their sins:

**[16:10]** Nor the six hundred thousand footmen, who were gathered together in the hardness of their hearts.

**[16:11]** And if there be one stiffnecked among the people, it is marvel if he escape unpunished: for mercy and wrath are with him; he is mighty to forgive, and to pour out displeasure.

**[16:12]** As his mercy is great, so is his correction also: he judgeth a man according to his works

**[16:13]** The sinner shall not escape with his spoils: and the patience of the godly shall not be frustrate.

**[16:14]** Make way for every work of mercy: for every man shall find according to his works.

**[16:15]** The Lord hardened Pharaoh, that he should not know him, that his powerful works might be known to the world.

**[16:16]** His mercy is manifest to every creature; and he hath separated his light from the darkness with an adamant.

**[16:17]** Say not thou, I will hide myself from the Lord: shall any remember me from above? I shall not be remembered among so many people: for what is my soul among such an infinite number of creatures?

**[16:18]** Behold, the heaven, and the heaven of heavens, the deep, and the earth, and all that therein is, shall be moved when he shall visit.

**[16:19]** The mountains also and foundations of the earth be shaken with trembling, when the Lord looketh upon them.

**[16:20]** No heart can think upon these things worthily: and who is able to conceive his ways?

**[16:21]** It is a tempest which no man can see: for the most part of his works are hid.

**[16:22]** Who can declare the works of his justice? or who can endure them? for his covenant is afar off, and the trial of all things is in the end.

**[16:23]** He that wanteth understanding will think upon vain things: and a foolish man erring imagineth follies.

**[16:24]** by son, hearken unto me, and learn knowledge, and mark my words with thy heart.

**[16:25]** I will shew forth doctrine in weight, and declare his knowledge exactly.

**[16:26]** The works of the Lord are done in judgment from the beginning: and from the time he made them he disposed the parts thereof.

**[16:27]** He garnished his works for ever, and in his hand are the chief of them unto all generations: they neither labour, nor are weary, nor cease from their works.

**[16:28]** None of them hindereth another, and they shall never disobey his word.

**[16:29]** After this the Lord looked upon the earth, and filled it with his blessings.

**[16:30]** With all manner of living things hath he covered the face thereof; and they shall return into it again.

**[17:1]** The Lord created man of the earth, and turned him into it again.

**[17:2]** He gave them few days, and a short time, and power also over the things therein.

**[17:3]** He endued them with strength by themselves, and made them according to his image,

**[17:4]** And put the fear of man upon all flesh, and gave him dominion over beasts and fowls.

**[17:5]** They received the use of the five operations of the Lord, and in the sixth place he imparted them understanding, and in the seventh speech, an interpreter of the cogitations thereof.

**[17:6]** Counsel, and a tongue, and eyes, ears, and a heart, gave he them to understand.

**[17:7]** Withal he filled them with the knowledge of understanding, and shewed them good and evil.

**[17:8]** He set his eye upon their hearts, that he might shew them the greatness of his works.

**[17:9]** He gave them to glory in his marvellous acts for ever, that they might declare his works with understanding.

**[17:10]** And the elect shall praise his holy name.

**[17:11]** Beside this he gave them knowledge, and the law of life for an heritage.

**[17:12]** He made an everlasting covenant with them, and shewed them his judgments.

**[17:13]** Their eyes saw the majesty of his glory, and their ears heard his glorious voice.

**[17:14]** And he said unto them, Beware of all unrighteousness; and he gave every man commandment concerning his neighbour.

**[17:15]** Their ways are ever before him, and shall not be hid from his eyes.

**[17:16]** Every man from his youth is given to evil; neither could they make to themselves fleshy hearts for stony.

**[17:17]** For in the division of the nations of the whole earth he set a ruler over every people; but Israel is the Lord’s portion:

**[17:18]** Whom, being his firstborn, he nourisheth with discipline, and giving him the light of his love doth not forsake him.

**[17:19]** Therefore all their works are as the sun before him, and his eyes are continually upon their ways.

**[17:20]** None of their unrighteous deeds are hid from him, but all their sins are before the Lord

**[17:21]** But the Lord being gracious and knowing his workmanship, neither left nor forsook them, but spared them.

**[17:22]** The alms of a man is as a signet with him, and he will keep the good deeds of man as the apple of the eye, and give repentance to his sons and daughters.

**[17:23]** Afterwards he will rise up and reward them, and render their recompence upon their heads.

**[17:24]** But unto them that repent, he granted them return, and comforted those that failed in patience.

**[17:25]** Return unto the Lord, and forsake thy sins, make thy prayer before his face, and offend less.

**[17:26]** Turn again to the most High, and turn away from iniquity: for he will lead thee out of darkness into the light of health, and hate thou abomination vehemently.

**[17:27]** Who shall praise the most High in the grave, instead of them which live and give thanks?

**[17:28]** Thanksgiving perisheth from the dead, as from one that is not: the living and sound in heart shall praise the Lord.

**[17:29]** How great is the lovingkindness of the Lord our God, and his compassion unto such as turn unto him in holiness!

**[17:30]** For all things cannot be in men, because the son of man is not immortal.

**[17:31]** What is brighter than the sun? yet the light thereof faileth; and flesh and blood will imagine evil.

**[17:32]** He vieweth the power of the height of heaven; and all men are but earth and ashes.

**[18:1]** He that liveth for ever Hath created all things in general.

**[18:2]** The Lord only is righteous, and there is none other but he,

**[18:3]** Who governeth the world with the palm of his hand, and all things obey his will: for he is the King of all, by his power dividing holy things among them from profane.

**[18:4]** To whom hath he given power to declare his works? and who shall find out his noble acts?

**[18:5]** Who shall number the strength of his majesty? and who shall also tell out his mercies?

**[18:6]** As for the wondrous works of the Lord, there may nothing be taken from them, neither may any thing be put unto them, neither can the ground of them be found out.

**[18:7]** When a man hath done, then he beginneth; and when he leaveth off, then he shall be doubtful.

**[18:8]** What is man, and whereto serveth he? what is his good, and what is his evil?

**[18:9]** The number of a man’s days at the most are an hundred years.

**[18:10]** As a drop of water unto the sea, and a gravelstone in comparison of the sand; so are a thousand years to the days of eternity.

**[18:11]** Therefore is God patient with them, and poureth forth his mercy upon them.

**[18:12]** He saw and perceived their end to be evil; therefore he multiplied his compassion.

**[18:13]** The mercy of man is toward his neighbour; but the mercy of the Lord is upon all flesh: he reproveth, and nurtureth, and teacheth and bringeth again, as a shepherd his flock.

**[18:14]** He hath mercy on them that receive discipline, and that diligently seek after his judgments.

**[18:15]** My son, blemish not thy good deeds, neither use uncomfortable words when thou givest any thing.

**[18:16]** Shall not the dew asswage the heat? so is a word better than a gift.

**[18:17]** Lo, is not a word better than a gift? but both are with a gracious man.

**[18:18]** A fool will upbraid churlishly, and a gift of the envious consumeth the eyes.

**[18:19]** Learn before thou speak, and use physick or ever thou be sick.

**[18:20]** Before judgment examine thyself, and in the day of visitation thou shalt find mercy.

**[18:21]** Humble thyself before thou be sick, and in the time of sins shew repentance.

**[18:22]** Let nothing hinder thee to pay thy vow in due time, and defer not until death to be justified.

**[18:23]** Before thou prayest, prepare thyself; and be not as one that tempteth the Lord.

**[18:24]** Think upon the wrath that shall be at the end, and the time of vengeance, when he shall turn away his face.

**[18:25]** When thou hast enough, remember the time of hunger: and when thou art rich, think upon poverty and need.

**[18:26]** From the morning until the evening the time is changed, and all things are soon done before the Lord.

**[18:27]** A wise man will fear in every thing, and in the day of sinning he will beware of offence: but a fool will not observe time.

**[18:28]** Every man of understanding knoweth wisdom, and will give praise unto him that found her.

**[18:29]** They that were of understanding in sayings became also wise themselves, and poured forth exquisite parables.

**[18:30]** Go not after thy lusts, but refrain thyself from thine appetites.

**[18:31]** If thou givest thy soul the desires that please her, she will make thee a laughingstock to thine enemies that malign thee.

**[18:32]** Take not pleasure in much good cheer, neither be tied to the expence thereof.

**[18:33]** Be not made a beggar by banqueting upon borrowing, when thou hast nothing in thy purse: for thou shalt lie in wait for thine own life, and be talked on.

**[19:1]** A labouring man that A is given to drunkenness shall not be rich: and he that contemneth small things shall fall by little and little.

**[19:2]** Wine and women will make men of understanding to fall away: and he that cleaveth to harlots will become impudent.

**[19:3]** Moths and worms shall have him to heritage, and a bold man shall be taken away.

**[19:4]** He that is hasty to give credit is lightminded; and he that sinneth shall offend against his own soul.

**[19:5]** Whoso taketh pleasure in wickedness shall be condemned: but he that resisteth pleasures crowneth his life.

**[19:6]** He that can rule his tongue shall live without strife; and he that hateth babbling shall have less evil.

**[19:7]** Rehearse not unto another that which is told unto thee, and thou shalt fare never the worse.

**[19:8]** Whether it be to friend or foe, talk not of other men’s lives; and if thou canst without offence, reveal them not.

**[19:9]** For he heard and observed thee, and when time cometh he will hate thee.

**[19:10]** If thou hast heard a word, let it die with thee; and be bold, it will not burst thee.

**[19:11]** A fool travaileth with a word, as a woman in labour of a child.

**[19:12]** As an arrow that sticketh in a man’s thigh, so is a word within a fool’s belly.

**[19:13]** Admonish a friend, it may be he hath not done it: and if he have done it, that he do it no more.

**[19:14]** Admonish thy friend, it may be he hath not said it: and if he have, that he speak it not again.

**[19:15]** Admonish a friend: for many times it is a slander, and believe not every tale.

**[19:16]** There is one that slippeth in his speech, but not from his heart; and who is he that hath not offended with his tongue?

**[19:17]** Admonish thy neighbour before thou threaten him; and not being angry, give place to the law of the most High.

**[19:18]** The fear of the Lord is the first step to be accepted of him, and wisdom obtaineth his love.

**[19:19]** The knowledge of the commandments of the Lord is the doctrine of life: and they that do things that please him shall receive the fruit of the tree of immortality.

**[19:20]** The fear of the Lord is all wisdom; and in all wisdom is the performance of the law, and the knowledge of his omnipotency.

**[19:21]** If a servant say to his master, I will not do as it pleaseth thee; though afterward he do it, he angereth him that nourisheth him.

**[19:22]** The knowledge of wickedness is not wisdom, neither at any time the counsel of sinners prudence.

**[19:23]** There is a wickedness, and the same an abomination; and there is a fool wanting in wisdom.

**[19:24]** He that hath small understanding, and feareth God, is better than one that hath much wisdom, and transgresseth the law of the most High.

**[19:25]** There is an exquisite subtilty, and the same is unjust; and there is one that turneth aside to make judgment appear; and there is a wise man that justifieth in judgment.

**[19:26]** There is a wicked man that hangeth down his head sadly; but inwardly he is full of deceit,

**[19:27]** Casting down his countenance, and making as if he heard not: where he is not known, he will do thee a mischief before thou be aware.

**[19:28]** And if for want of power he be hindered from sinning, yet when he findeth opportunity he will do evil.

**[19:29]** A man may be known by his look, and one that hath understanding by his countenance, when thou meetest him.

**[19:30]** A man’s attire, and excessive laughter, and gait, shew what he is.

**[20:1]** There is a reproof that is not comely: again, some man holdeth his tongue, and he is wise.

**[20:2]** It is much better to reprove, than to be angry secretly: and he that confesseth his fault shall be preserved from hurt.

**[20:3]** How good is it, when thou art reproved, to shew repentance! for so shalt thou escape wilful sin.

**[20:4]** As is the lust of an eunuch to deflower a virgin; so is he that executeth judgment with violence.

**[20:5]** There is one that keepeth silence, and is found wise: and another by much babbling becometh hateful.

**[20:6]** Some man holdeth his tongue, because he hath not to answer: and some keepeth silence, knowing his time.

**[20:7]** A wise man will hold his tongue till he see opportunity: but a babbler and a fool will regard no time.

**[20:8]** He that useth many words shall be abhorred; and he that taketh to himself authority therein shall be hated.

**[20:9]** There is a sinner that hath good success in evil things; and t,1);The Lord created man of the earth, and turned him into it again.

**[17:2]** He gave them few days, and a short time, and power also over the things therein.

**[17:3]** He endued them with strength by themselves, and made them according to his image,

**[17:4]** And put the fear of man upon all flesh, and gave him dominion over beasts and fowls.

**[17:5]** They received the use of the five operations of the Lord, and in the sixth place he imparted them understanding, and in the seventh speech, an interpreter of the cogitations thereof.

**[17:6]** Counsel, and a tongue, and eyes, ears, and a heart, gave he them to understand.

**[17:7]** Withal he filled them with the knowledge of understanding, and shewed them good and evil.

**[17:8]** He set his eye upon their hearts, that he might shew them the greatness of his works.

**[17:9]** He gave them to glory in his marvellous acts for ever, that they might declare his works with understanding.

**[17:10]** And the elect shall praise his holy name.

**[17:11]** Beside this he gave them knowledge, and the law of life for an heritage.

**[17:12]** He made an everlasting covenant with them, and shewed them his judgments.

**[17:13]** Their eyes saw the majesty of his glory, and their ears heard his glorious voice.

**[17:14]** And he said unto them, Beware of all unrighteousness; and he gave every man commandment concerning his neighbour.

**[17:15]** Their ways are ever before him, and shall not be hid from his eyes.

**[17:16]** Every man from his youth is given to evil; neither could they make to themselves fleshy hearts for stony.

**[17:17]** For in the division of the nations of the whole earth he set a ruler over every people; but Israel is the Lord’s portion:

**[17:18]** Whom, being his firstborn, he nourisheth with discipline, and giving him the light of his love doth not forsake him.

**[17:19]** Therefore all their works are as the sun before him, and his eyes are continually upon their ways.

**[17:20]** None of their unrighteous deeds are hid from him, but all their sins are before the Lord

**[17:21]** But the Lord being gracious and knowing his workmanship, neither left nor forsook them, but spared them.

**[17:22]** The alms of a man is as a signet with him, and he will keep the good deeds of man as the apple of the eye, and give repentance to his sons and daughters.

**[17:23]** Afterwards he will rise up and reward them, and render their recompence upon their heads.

**[17:24]** But unto them that repent, he granted them return, and comforted those that failed in patience.

**[17:25]** Return unto the Lord, and forsake thy sins, make thy prayer before his face, and offend less.

**[17:26]** Turn again to the most High, and turn away from iniquity: for he will lead thee out of darkness into the light of health, and hate thou abomination vehemently.

**[17:27]** Who shall praise the most High in the grave, instead of them which live and give thanks?

**[17:28]** Thanksgiving perisheth from the dead, as from one that is not: the living and sound in heart shall praise the Lord.

**[17:29]** How great is the lovingkindness of the Lord our God, and his compassion unto such as turn unto him in holiness!

**[17:30]** For all things cannot be in men, because the son of man is not immortal.

**[17:31]** What is brighter than the sun? yet the light thereof faileth; and flesh and blood will imagine evil.

**[17:32]** He vieweth the power of the height of heaven; and all men are but earth and ashes.

**[18:1]** He that liveth for ever Hath created all things in general.

**[18:2]** The Lord only is righteous, and there is none other but he,

**[18:3]** Who governeth the world with the palm of his hand, and all things obey his will: for he is the King of all, by his power dividing holy things among them from profane.

**[18:4]** To whom hath he given power to declare his works? and who shall find out his noble acts?

**[18:5]** Who shall number the strength of his majesty? and who shall also tell out his mercies?

**[18:6]** As for the wondrous works of the Lord, there may nothing be taken from them, neither may any thing be put unto them, neither can the ground of them be found out.

**[18:7]** When a man hath done, then he beginneth; and when he leaveth off, then he shall be doubtful.

**[18:8]** What is man, and whereto serveth he? what is his good, and what is his evil?

**[18:9]** The number of a man’s days at the most are an hundred years.

**[18:10]** As a drop of water unto the sea, and a gravelstone in comparison of the sand; so are a thousand years to the days of eternity.

**[18:11]** Therefore is God patient with them, and poureth forth his mercy upon them.

**[18:12]** He saw and perceived their end to be evil; therefore he multiplied his compassion.

**[18:13]** The mercy of man is toward his neighbour; but the mercy of the Lord is upon all flesh: he reproveth, and nurtureth, and teacheth and bringeth again, as a shepherd his flock.

**[18:14]** He hath mercy on them that receive discipline, and that diligently seek after his judgments.

**[18:15]** My son, blemish not thy good deeds, neither use uncomfortable words when thou givest any thing.

**[18:16]** Shall not the dew asswage the heat? so is a word better than a gift.

**[18:17]** Lo, is not a word better than a gift? but both are with a gracious man.

**[18:18]** A fool will upbraid churlishly, and a gift of the envious consumeth the eyes.

**[18:19]** Learn before thou speak, and use physick or ever thou be sick.

**[18:20]** Before judgment examine thyself, and in the day of visitation thou shalt find mercy.

**[18:21]** Humble thyself before thou be sick, and in the time of sins shew repentance.

**[18:22]** Let nothing hinder thee to pay thy vow in due time, and defer not until death to be justified.

**[18:23]** Before thou prayest, prepare thyself; and be not as one that tempteth the Lord.

**[18:24]** Think upon the wrath that shall be at the end, and the time of vengeance, when he shall turn away his face.

**[18:25]** When thou hast enough, remember the time of hunger: and when thou art rich, think upon poverty and need.

**[18:26]** From the morning until the evening the time is changed, and all things are soon done before the Lord.

**[18:27]** A wise man will fear in every thing, and in the day of sinning he will beware of offence: but a fool will not observe time.

**[18:28]** Every man of understanding knoweth wisdom, and will give praise unto him that found her.

**[18:29]** They that were of understanding in sayings became also wise themselves, and poured forth exquisite parables.

**[18:30]** Go not after thy lusts, but refrain thyself from thine appetites.

**[18:31]** If thou givest thy soul the desires that please her, she will make thee a laughingstock to thine enemies that malign thee.

**[18:32]** Take not pleasure in much good cheer, neither be tied to the expence thereof.

**[18:33]** Be not made a beggar by banqueting upon borrowing, when thou hast nothing in thy purse: for thou shalt lie in wait for thine own life, and be talked on.

**[19:1]** A labouring man that A is given to drunkenness shall not be rich: and he that contemneth small things shall fall by little and little.

**[19:2]** Wine and women will make men of understanding to fall away: and he that cleaveth to harlots will become impudent.

**[19:3]** Moths and worms shall have him to heritage, and a bold man shall be taken away.

**[19:4]** He that is hasty to give credit is lightminded; and he that sinneth shall offend against his own soul.

**[19:5]** Whoso taketh pleasure in wickedness shall be condemned: but he that resisteth pleasures crowneth his life.

**[19:6]** He that can rule his tongue shall live without strife; and he that hateth babbling shall have less evil.

**[19:7]** Rehearse not unto another that which is told unto thee, and thou shalt fare never the worse.

**[19:8]** Whether it be to friend or foe, talk not of other men’s lives; and if thou canst without offence, reveal them not.

**[19:9]** For he heard and observed thee, and when time cometh he will hate thee.

**[19:10]** If thou hast heard a word, let it die with thee; and be bold, it will not burst thee.

**[19:11]** A fool travaileth with a word, as a woman in labour of a child.

**[19:12]** As an arrow that sticketh in a man’s thigh, so is a word within a fool’s belly.

**[19:13]** Admonish a friend, it may be he hath not done it: and if he have done it, that he do it no more.

**[19:14]** Admonish thy friend, it may be he hath not said it: and if he have, that he speak it not again.

**[19:15]** Admonish a friend: for many times it is a slander, and believe not every tale.

**[19:16]** There is one that slippeth in his speech, but not from his heart; and who is he that hath not offended with his tongue?

**[19:17]** Admonish thy neighbour before thou threaten him; and not being angry, give place to the law of the most High.

**[19:18]** The fear of the Lord is the first step to be accepted of him, and wisdom obtaineth his love.

**[19:19]** The knowledge of the commandments of the Lord is the doctrine of life: and they that do things that please him shall receive the fruit of the tree of immortality.

**[19:20]** The fear of the Lord is all wisdom; and in all wisdom is the performance of the law, and the knowledge of his omnipotency.

**[19:21]** If a servant say to his master, I will not do as it pleaseth thee; though afterward he do it, he angereth him that nourisheth him.

**[19:22]** The knowledge of wickedness is not wisdom, neither at any time the counsel of sinners prudence.

**[19:23]** There is a wickedness, and the same an abomination; and there is a fool wanting in wisdom.

**[19:24]** He that hath small understanding, and feareth God, is better than one that hath much wisdom, and transgresseth the law of the most High.

**[19:25]** There is an exquisite subtilty, and the same is unjust; and there is one that turneth aside to make judgment appear; and there is a wise man that justifieth in judgment.

**[19:26]** There is a wicked man that hangeth down his head sadly; but inwardly he is full of deceit,

**[19:27]** Casting down his countenance, and making as if he heard not: where he is not known, he will do thee a mischief before thou be aware.

**[19:28]** And if for want of power he be hindered from sinning, yet when he findeth opportunity he will do evil.

**[19:29]** A man may be known by his look, and one that hath understanding by his countenance, when thou meetest him.

**[19:30]** A man’s attire, and excessive laughter, and gait, shew what he is.

**[20:1]** There is a reproof that is not comely: again, some man holdeth his tongue, and he is wise.

**[20:2]** It is much better to reprove, than to be angry secretly: and he that confesseth his fault shall be preserved from hurt.

**[20:3]** How good is it, when thou art reproved, to shew repentance! for so shalt thou escape wilful sin.

**[20:4]** As is the lust of an eunuch to deflower a virgin; so is he that executeth judgment with violence.

**[20:5]** There is one that keepeth silence, and is found wise: and another by much babbling becometh hateful.

**[20:6]** Some man holdeth his tongue, because he hath not to answer: and some keepeth silence, knowing his time.

**[20:7]** A wise man will hold his tongue till he see opportunity: but a babbler and a fool will regard no time.

**[20:8]** He that useth many words shall be abhorred; and he that taketh to himself authority therein shall be hated.

**[20:9]** There is a sinner that hath good success in evil things; and there is a gain that turneth to loss.

**[20:10]** There is a gift that shall not profit thee; and there is a gift whose recompence is double.

**[20:11]** There is an abasement because of glory; and there is that lifteth up his head from a low estate.

**[20:12]** There is that buyeth much for a little, and repayeth it sevenfold.

**[20:13]** A wise man by his words maketh him beloved: but the graces of fools shall be poured out.

**[20:14]** The gift of a fool shall do thee no good when thou hast it; neither yet of the envious for his necessity: for he looketh to receive many things for one.

**[20:15]** He giveth little, and upbraideth much; he openeth his mouth like a crier; to day he lendeth, and to morrow will he ask it again: such an one is to be hated of God and man.

**[20:16]** The fool saith, I have no friends, I have no thank for all my good deeds, and they that eat my bread speak evil of me.

**[20:17]** How oft, and of how many shall he be laughed to scorn! for he knoweth not aright what it is to have; and it is all one unto him as if he had it not.

**[20:18]** To slip upon a pavement is better than to slip with the tongue: so the fall of the wicked shall come speedily.

**[20:19]** An unseasonable tale will always be in the mouth of the unwise.

**[20:20]** A wise sentence shall be rejected when it cometh out of a fool’s mouth; for he will not speak it in due season.

**[20:21]** There is that is hindered from sinning through want: and when he taketh rest, he shall not be troubled.

**[20:22]** There is that destroyeth his own soul through bashfulness, and by accepting of persons overthroweth himself.

**[20:23]** There is that for bashfulness promiseth to his friend, and maketh him his enemy for nothing.

**[20:24]** A lie is a foul blot in a man, yet it is continually in the mouth of the untaught.

**[20:25]** A thief is better than a man that is accustomed to lie: but they both shall have destruction to heritage.

**[20:26]** The disposition of a liar is dishonourable, and his shame is ever with him.

**[20:27]** A wise man shall promote himself to honour with his words: and he that hath understanding will please great men.

**[20:28]** He that tilleth his land shall increase his heap: and he that pleaseth great men shall get pardon for iniquity.

**[20:29]** Presents and gifts blind the eyes of the wise, and stop up his mouth that he cannot reprove.

**[20:30]** Wisdom that is hid, and treasure that is hoarded up, what profit is in them both?

**[20:31]** Better is he that hideth his folly than a man that hideth his wisdom.

**[20:32]** Necessary patience in seeking ing the Lord is better than he that leadeth his life without a guide.

**[21:1]** My son, hast thou sinned? do so no more, but ask pardon for thy former sins.

**[21:2]** Flee from sin as from the face of a serpent: for if thou comest too near it, it will bite thee: the teeth thereof are as the teeth of a lion, slaying the souls of men.

**[21:3]** All iniquity is as a two edged sword, the wounds whereof cannot be healed.

**[21:4]** To terrify and do wrong will waste riches: thus the house of proud men shall be made desolate.

**[21:5]** A prayer out of a poor man’s mouth reacheth to the ears of God, and his judgment cometh speedily.

**[21:6]** He that hateth to be reproved is in the way of sinners: but he that feareth the Lord will repent from his heart.

**[21:7]** An eloquent man is known far and near; but a man of understanding knoweth when he slippeth.

**[21:8]** He that buildeth his house with other men’s money is like one that gathereth himself stones for the tomb of his burial.

**[21:9]** The congregation of the wicked is like tow wrapped together: and the end of them is a flame of fire to destroy them.

**[21:10]** The way of sinners is made plain with stones, but at the end thereof is the pit of hell.

**[21:11]** He that keepeth the law of the Lord getteth the understanding thereof: and the perfection of the fear of the Lord is wisdom.

**[21:12]** He that is not wise will not be taught: but there is a wisdom which multiplieth bitterness.

**[21:13]** The knowledge of a wise man shall abound like a flood: and his counsel is like a pure fountain of life.

**[21:14]** The inner parts of a fool are like a broken vessel, and he will hold no knowledge as long as he liveth.

**[21:15]** If a skilful man hear a wise word, he will commend it, and add unto it: but as soon as one of no understanding heareth it, it displeaseth him, and he casteth it behind his back.

**[21:16]** The talking of a fool is like a burden in the way: but grace shall be found in the lips of the wise.

**[21:17]** They enquire at the mouth of the wise man in the congregation, and they shall ponder his words in their heart.

**[21:18]** As is a house that is destroyed, so is wisdom to a fool: and the knowledge of the unwise is as talk without sense.

**[21:19]** Doctrine unto fools is as fetters on the feet, and like manacles on the right hand.

**[21:20]** A fool lifteth up his voice with laughter; but a wise man doth scarce smile a little.

**[21:21]** Learning is unto a wise man as an ornament of gold, and like a bracelet upon his right arm.

**[21:22]** A foolish man’s foot is soon in his neighbour’s house: but a man of experience is ashamed of him.

**[21:23]** A fool will peep in at the door into the house: but he that is well nurtured will stand without.

**[21:24]** It is the rudeness of a man to hearken at the door: but a wise man will be grieved with the disgrace.

**[21:25]** The lips of talkers will be telling such things as pertain not unto them: but the words of such as have understanding are weighed in the balance.

**[21:26]** The heart of fools is in their mouth: but the mouth of the wise is in their heart.

**[21:27]** When the ungodly curseth Satan, he curseth his own soul.

**[21:28]** A whisperer defileth his own soul, and is hated wheresoever he dwelleth.

**[22:1]** A slothful man is compared to a filthy stone, and every one will hiss him out to his disgrace.

**[22:2]** A slothful man is compared to the filth of a dunghill: every man that takes it up will shake his hand.

**[22:3]** An evilnurtured man is the dishonour of his father that begat him: and a foolish daughter is born to his loss.

**[22:4]** A wise daughter shall bring an inheritance to her husband: but she that liveth dishonestly is her father’s heaviness.

**[22:5]** She that is bold dishonoureth both her father and her husband, but they both shall despise her.

**[22:6]** A tale out of season is as musick in mourning: but stripes and correction of wisdom are never out of time.

**[22:7]** Whoso teacheth a fool is as one that glueth a potsherd together, and as he that waketh one from a sound sleep.

**[22:8]** He that telleth a tale to a fool speaketh to one in a slumber: when he hath told his tale, he will say, What is the matter?

**[22:9]** If children live honestly, and have wherewithal, they shall cover the baseness of their parents.

**[22:10]** But children, being haughty, through disdain and want of nurture do stain the nobility of their kindred.

**[22:11]** Weep for the dead, for he hath lost the light: and weep for the fool, for he wanteth understanding: make little weeping for the dead, for he is at rest: but the life of the fool is worse than death.

**[22:12]** Seven days do men mourn for him that is dead; but for a fool and an ungodly man all the days of his life.

**[22:13]** Talk not much with a fool, and go not to him that hath no understanding: beware of him, lest thou have trouble, and thou shalt never be defiled with his fooleries: depart from him, and thou shalt find rest, and never be disquieted with madness.

**[22:14]** What is heavier than lead? and what is the name thereof, but a fool?

**[22:15]** Sand, and salt, and a mass of iron, is easier to bear, than a man without understanding.

**[22:16]** As timber girt and bound together in a building cannot be loosed with shaking: so the heart that is stablished by advised counsel shall fear at no time.

**[22:17]** A heart settled upon a thought of understanding is as a fair plaistering on the wall of a gallery.

**[22:18]** Pales set on an high place will never stand against the wind: so a fearful heart in the imagination of a fool cannot stand against any fear.

**[22:19]** He that pricketh the eye will make tears to fall: and he that pricketh the heart maketh it to shew her knowledge.

**[22:20]** Whoso casteth a stone at the birds frayeth them away: and he that upbraideth his friend breaketh friendship.

**[22:21]** Though thou drewest a sword at thy friend, yet despair not: for there may be a returning to favour.

**[22:22]** If thou hast opened thy mouth against thy friend, fear not; for there may be a reconciliation: except for upbraiding, or pride, or disclosing of secrets, or a treacherous wound: for for these things every friend will depart.

**[22:23]** Be faithful to thy neighbour in his poverty, that thou mayest rejoice in his prosperity: abide stedfast unto him in the time of his trouble, that thou mayest be heir with him in his heritage: for a mean estate is not always to be contemned: nor the rich that is foolish to be had in admiration.

**[22:24]** As the vapour and smoke of a furnace goeth before the fire; so reviling before blood.

**[22:25]** I will not be ashamed to defend a friend; neither will I hide myself from him.

**[22:26]** And if any evil happen unto me by him, every one that heareth it will beware of him.

**[22:27]** Who shall set a watch before my mouth, and a seal of wisdom upon my lips, that I fall not suddenly by them, and that my tongue destroy me not?

**[23:1]** O Lord, Father and Governor of all my whole life, leave me not to their counsels, and let me not fall by them.

**[23:2]** Who will set scourges over my thoughts, and the discipline of wisdom over mine heart? that they spare me not for mine ignorances, and it pass not by my sins:

**[23:3]** Lest mine ignorances increase, and my sins abound to my destruction, and I fall before mine adversaries, and mine enemy rejoice over me, whose hope is far from thy mercy.

**[23:4]** O Lord, Father and God of my life, give me not a proud look, but turn away from thy servants always a haughty mind.

**[23:5]** Turn away from me vain hopes and concupiscence, and thou shalt hold him up that is desirous always to serve thee.

**[23:6]** Let not the greediness of the belly nor lust of the flesh take hold of me; and give not over me thy servant into an impudent mind.

**[23:7]** Hear, O ye children, the discipline of the mouth: he that keepeth it shall never be taken in his lips.

**[23:8]** The sinner shall be left in his foolishness: both the evil speaker and the proud shall fall thereby.

**[23:9]** Accustom not thy mouth to swearing; neither use thyself to the naming of the Holy One.

**[23:10]** For as a servant that is continually beaten shall not be without a blue mark: so he that sweareth and nameth God continually shall not be faultless.

**[23:11]** A man that useth much swearing shall be filled with iniquity, and the plague shall never depart from his house: if he shall offend, his sin shall be upon him: and if he acknowledge not his sin, he maketh a double offence: and if he swear in vain, he shall not be innocent, but his house shall be full of calamities.

**[23:12]** There is a word that is clothed about with death: God grant that it be not found in the heritage of Jacob; for all such things shall be far from the godly, and they shall not wallow in their sins.

**[23:13]** Use not thy mouth to intemperate swearing, for therein is the word of sin.

**[23:14]** Remember thy father and thy mother, when thou sittest among great men. Be not forgetful before them, and so thou by thy custom become a fool, and wish that thou hadst not been born, and curse they day of thy nativity.

**[23:15]** The man that is accustomed to opprobrious words will never be reformed all the days of his life.

**[23:16]** Two sorts of men multiply sin, and the third will bring wrath: a hot mind is as a burning fire, it will never be quenched till it be consumed: a fornicator in the body of his flesh will never cease till he hath kindled a fire.

**[23:17]** All bread is sweet to a whoremonger, he will not leave off till he die.

**[23:18]** A man that breaketh wedlock, saying thus in his heart, Who seeth me? I am compassed about with darkness, the walls cover me, and no body seeth me; what need I to fear? the most High will not remember my sins:

**[23:19]** Such a man only feareth the eyes of men, and knoweth not that the eyes of the Lord are ten thousand times brighter than the sun, beholding all the ways of men, and considering the most secret parts.

**[23:20]** He knew all things ere ever they were created; so also after they were perfected he looked upon them all.

**[23:21]** This man shall be punished in the streets of the city, and where he suspecteth not he shall be taken.

**[23:22]** Thus shall it go also with the wife that leaveth her husband, and bringeth in an heir by another.

**[23:23]** For first, she hath disobeyed the law of the most High; and secondly, she hath trespassed against her own husband; and thirdly, she hath played the whore in adultery, and brought children by another man.

**[23:24]** She shall be brought out into the congregation, and inquisition shall be made of her children.

**[23:25]** Her children shall not take root, and her branches shall bring forth no fruit.

**[23:26]** She shall leave her memory to be cursed, and her reproach shall not be blotted out.

**[23:27]** And they that remain shall know that there is nothing better than the fear of the Lord, and that there is nothing sweeter than to take heed unto the commandments of the Lord.

**[23:28]** It is great glory to follow the Lord, and to be received of him is long life.

**[24:1]** Wisdom shall praise herself, and shall glory in the midst of her people.

**[24:2]** In the congregation of the most High shall she open her mouth, and triumph before his power.

**[24:3]** I came out of the mouth of the most High, and covered the earth as a cloud.

**[24:4]** I dwelt in high places, and my throne is in a cloudy pillar.

**[24:5]** I alone compassed the circuit of heaven, and walked in the bottom of the deep.

**[24:6]** In the waves of the sea and in all the earth, and in every people and nation, I got a possession.

**[24:7]** With all these I sought rest: and in whose inheritance shall I abide?

**[24:8]** So the Creator of all things gave me a commandment, and he that made me caused my tabernacle to rest, and said, Let thy dwelling be in Jacob, and thine inheritance in Israel.

**[24:9]** He created me from the beginning before the world, and I shall never fail.

**[24:10]** In the holy tabernacle I served before him; and so was I established in Sion.

**[24:11]** Likewise in the beloved city he gave me rest, and in Jerusalem was my power.

**[24:12]** And I took root in an honourable people, even in the portion of the Lord’s inheritance.

**[24:13]** I was exalted like a cedar in Libanus, and as a cypress tree upon the mountains of Hermon.

**[24:14]** I was exalted like a palm tree in En-gaddi, and as a rose plant in Jericho, as a fair olive tree in a pleasant field, and grew up as a plane tree by the water.

**[24:15]** I gave a sweet smell like cinnamon and aspalathus, and I yielded a pleasant odour like the best myrrh, as galbanum, and onyx, and sweet storax, and as the fume of frankincense in the tabernacle.

**[24:16]** As the turpentine tree I stretched out my branches, and my branches are the branches of honour and grace.

**[24:17]** As the vine brought I forth pleasant savour, and my flowers are the fruit of honour and riches.

**[24:18]** I am the mother of fair love, and fear, and knowledge, and holy hope: I therefore, being eternal, am given to all my children which are named of him.

**[24:19]** Come unto me, all ye that be desirous of me, and fill yourselves with my fruits.

**[24:20]** For my memorial is sweeter than honey, and mine inheritance than the honeycomb.

**[24:21]** They that eat me shall yet be hungry, and they that drink me shall yet be thirsty.

**[24:22]** He that obeyeth me shall never be confounded, and they that work by me shall not do amiss.

**[24:23]** All these things are the book of the covenant of the most high God, even the law which Moses commanded for an heritage unto the congregations of Jacob.

**[24:24]** Faint not to be strong in the Lord; that he may confirm you, cleave unto him: for the Lord Almighty is God alone, and beside him there is no other Saviour.

**[24:25]** He filleth all things with his wisdom, as Phison and as Tigris in the time of the new fruits.

**[24:26]** He maketh the understanding to abound like Euphrates, and as Jordan in the time of the harvest.

**[24:27]** He maketh the doctrine of knowledge appear as the light, and as Geon in the time of vintage.

**[24:28]** The first man knew her not perfectly: no more shall the last find her out.

**[24:29]** For her thoughts are more than the sea, and her counsels profounder than the great deep.

**[24:30]** I also came out as a brook from a river, and as a conduit into a garden.

**[24:31]** I said, I will water my best garden, and will water abundantly my garden bed: and, lo, my brook became a river, and my river became a sea.

**[24:32]** I will yet make doctrine to shine as the morning, and will send forth her light afar off.

**[24:33]** I will yet pour out doctrine as prophecy, and leave it to all ages for ever.

**[24:34]** Behold that I have not laboured for myself only, but for all them that seek wisdom.

**[25:1]** In three things I was beautified, and stood up beautiful both before God and men: the unity of brethren, the love of neighbours, a man and a wife that agree together.

**[25:2]** Three sorts of men my soul hateth, and I am greatly offended at their life: a poor man that is proud, a rich man that is a liar, and an old adulterer that doateth.

**[25:3]** If thou hast gathered nothing in thy youth, how canst thou find any thing in thine age?

**[25:4]** O how comely a thing is judgment for gray hairs, and for ancient men to know counsel!

**[25:5]** O how comely is the wisdom of old men, and understanding and counsel to men of honour.

**[25:6]** Much experience is the crown of old men, and the fear of God is their glory.

**[25:7]** There be nine things which I have judged in mine heart to be happy, and the tenth I will utter with my tongue: A man that hath joy of his children; and he that liveth to see the fall of his enemy:

**[25:8]** Well is him that dwelleth with a wife of understanding, and that hath not slipped with his tongue, and that hath not served a man more unworthy than himself:

**[25:9]** Well is him that hath found prudence, and he that speaketh in the ears of them that will hear:

**[25:10]** O how great is he that findeth wisdom! yet is there none above him that feareth the Lord.

**[25:11]** But the love of the Lord passeth all things for illumination: he that holdeth it, whereto shall he be likened?

**[25:12]** The fear of the Lord is the beginning of his love: and faith is the beginning of cleaving unto him.

**[25:13]** Give me any plague, but the plague of the heart: and any wickedness, but the wickedness of a woman:

**[25:14]** And any affliction, but the affliction from them that hate me: and any revenge, but the revenge of enemies.

**[25:15]** There is no head above the head of a serpent; and there is no wrath above the wrath of an enemy.

**[25:16]** I had rather dwell with a lion and a dragon, than to keep house with a wicked woman.

**[25:17]** The wickedness of a woman changeth her face, and darkeneth her countenance like sackcloth.

**[25:18]** Her husband shall sit among his neighbours; and when he heareth it shall sigh bitterly.

**[25:19]** All wickedness is but little to the wickedness of a woman: let the portion of a sinner fall upon her.

**[25:20]** As the climbing up a sandy way is to the feet of the aged, so is a wife full of words to a quiet man.

**[25:21]** Stumble not at the beauty of a woman, and desire her not for pleasure.

**[25:22]** A woman, if she maintain her husband, is full of anger, impudence, and much reproach.

**[25:23]** A wicked woman abateth the courage, maketh an heavy countenance and a wounded heart: a woman that will not comfort her husband in distress maketh weak hands and feeble knees.

**[25:24]** Of the woman came the beginning of sin, and through her we all die.

**[25:25]** Give the water no passage; neither a wicked woman liberty to gad abroad.

**[25:26]** If she go not as thou wouldest have her, cut her off from thy flesh, and give her a bill of divorce, and let her go.

**[26:1]** Blessed is the man that hath a virtuous wife, for the number of his days shall be double.

**[26:2]** A virtuous woman rejoiceth her husband, and he shall fulfil the years of his life in peace.

**[26:3]** A good wife is a good portion, which shall be given in the portion of them that fear the Lord.

**[26:4]** Whether a man be rich or poor, if he have a good heart toward the Lord, he shall at all times rejoice with a cheerful countenance.

**[26:5]** There be three things that mine heart feareth; and for the fourth I was sore afraid: the slander of a city, the gathering together of an unruly multitude, and a false accusation: all these are worse than death.

**[26:6]** But a grief of heart and sorrow is a woman that is jealous over another woman, and a scourge of the tongue which communicateth with all.

**[26:7]** An evil wife is a yoke shaken to and fro: he that hath hold of her is as though he held a scorpion.

**[26:8]** A drunken woman and a gadder abroad causeth great anger, and she will not cover her own shame.

**[26:9]** The whoredom of a woman may be known in her haughty looks and eyelids.

**[26:10]** If thy daughter be shameless, keep her in straitly, lest she abuse herself through overmuch liberty.

**[26:11]** Watch over an impudent eye: and marvel not if she trespass against thee.

**[26:12]** She will open her mouth, as a thirsty traveller when he hath found a fountain, and drink of every water near her: by every hedge will she sit down, and open her quiver against every arrow.

**[26:13]** The grace of a wife delighteth her husband, and her discretion will fatten his bones.

**[26:14]** A silent and loving woman is a gift of the Lord; and there is nothing so much worth as a mind well instructed.

**[26:15]** A shamefaced and faithful woman is a double grace, and her continent mind cannot be valued.

**[26:16]** As the sun when it ariseth in the high heaven; so is the beauty of a good wife in the ordering of her house.

**[26:17]** As the clear light is upon the holy candlestick; so is the beauty of the face in ripe age.

**[26:18]** As the golden pillars are upon the sockets of silver; so are the fair feet with a constant heart.

**[26:19]** My son, keep the flower of thine age sound; and give not thy strength to strangers.

**[26:20]** When thou hast gotten a fruitful possession through all the field, sow it with thine own seed, trusting in the goodness of thy stock.

**[26:21]** So thy race which thou leavest shall be magnified, having the confidence of their good descent.

**[26:22]** An harlot shall be accounted as spittle; but a married woman is a tower against death to her husband.

**[26:23]** A wicked woman is given as a portion to a wicked man: but a godly woman is given to him that feareth the Lord.

**[26:24]** A dishonest woman contemneth shame: but an honest woman will reverence her husband.

**[26:25]** A shameless woman shall be counted as a dog; but she that is shamefaced will fear the Lord.

**[26:26]** A woman that honoureth her husband shall be judged wise of all; but she that dishonoureth him in her pride shall be counted ungodly of all.

**[26:27]** A loud crying woman and a scold shall be sought out to drive away the enemies.

**[26:28]** There be two things that grieve my heart; and the third maketh me angry: a man of war that suffereth poverty; and men of understanding that are not set by; and one that returneth from righteousness to sin; the Lord prepareth such an one for the sword.

**[26:29]** A merchant shall hardly keep himself from doing wrong; and an huckster shall not be freed from sin.

**[27:1]** Many have sinned for a small matter; and he that seeketh for abundance will turn his eyes away.

**[27:2]** As a nail sticketh fast between the joinings of the stones; so doth sin stick close between buying and selling.

**[27:3]** Unless a man hold himself diligently in the fear of the Lord, his house shall soon be overthrown.

**[27:4]** As when one sifteth with a sieve, the refuse remaineth; so the filth of man in his talk.

**[27:5]** The furnace proveth the potter’s vessels; so the trial of man is in his reasoning.

**[27:6]** The fruit declareth if the tree have been dressed; so is the utterance of a conceit in the heart of man.

**[27:7]** Praise no man before thou hearest him speak; for this is the trial of men.

**[27:8]** If thou followest righteousness, thou shalt obtain her, and put her on, as a glorious long robe.

**[27:9]** The birds will resort unto their like; so will truth return unto them that practise in her.

**[27:10]** As the lion lieth in wait for the prey; so sin for them that work iniquity.

**[27:11]** The discourse of a godly man is always with wisdom; but a fool changeth as the moon.

**[27:12]** If thou be among the indiscreet, observe the time; but be continually among men of understanding.

**[27:13]** The discourse of fools is irksome, and their sport is the wantonness of sin.

**[27:14]** The talk of him that sweareth much maketh the hair stand upright; and their brawls make one stop his ears.

**[27:15]** The strife of the proud is bloodshedding, and their revilings are grievous to the ear.

**[27:16]** Whoso discovereth secrets loseth his credit; and shall never find friend to his mind.

**[27:17]** Love thy friend, and be faithful unto him: but if thou betrayest his secrets, follow no more after him.

**[27:18]** For as a man hath destroyed his enemy; so hast thou lost the love of thy neighbor.

**[27:19]** As one that letteth a bird go out of his hand, so hast thou let thy neighbour go, and shalt not get him again

**[27:20]** Follow after him no more, for he is too far off; he is as a roe escaped out of the snare.

**[27:21]** As for a wound, it may be bound up; and after reviling there may be reconcilement: but he that betrayeth secrets is without hope.

**[27:22]** He that winketh with the eyes worketh evil: and he that knoweth him will depart from him.

**[27:23]** When thou art present, he will speak sweetly, and will admire thy words: but at the last he will writhe his mouth, and slander thy sayings.

**[27:24]** I have hated many things, but nothing like him; for the Lord will hate him.

**[27:25]** Whoso casteth a stone on high casteth it on his own head; and a deceitful stroke shall make wounds.

**[27:26]** Whoso diggeth a pit shall fall therein: and he that setteth a trap shall be taken therein.

**[27:27]** He that worketh mischief, it shall fall upon him, and he shall not know whence it cometh.

**[27:28]** Mockery and reproach are from the proud; but vengeance, as a lion, shall lie in wait for them.

**[27:29]** They that rejoice at the fall of the righteous shall be taken in the snare; and anguish shall consume them before they die.

**[27:30]** Malice and wrath, even these are abominations; and the sinful man shall have them both.

**[28:1]** He that revengeth shall find vengeance from the Lord, and he will surely keep his sins in remembrance.

**[28:2]** Forgive thy neighbour the hurt that he hath done unto thee, so shall thy sins also be forgiven when thou prayest.

**[28:3]** One man beareth hatred against another, and doth he seek pardon from the Lord?

**[28:4]** He sheweth no mercy to a man, which is like himself: and doth he ask forgiveness of his own sins?

**[28:5]** If he that is but flesh nourish hatred, who will intreat for pardon of his sins?

**[28:6]** Remember thy end, and let enmity cease; remember corruption and death, and abide in the commandments.

**[28:7]** Remember the commandments, and bear no malice to thy neighbour: remember the covenant of the Highest, and wink at ignorance.

**[28:8]** Abstain from strife, and thou shalt diminish thy sins: for a furious man will kindle strife,

**[28:9]** A sinful man disquieteth friends, and maketh debate among them that be at peace.

**[28:10]** As the matter of the fire is, so it burneth: and as a man’s strength is, so is his wrath; and according to his riches his anger riseth; and the stronger they are which contend, the more they will be inflamed.

**[28:11]** An hasty contention kindleth a fire: and an hasty fighting sheddeth blood.

**[28:12]** If thou blow the spark, it shall burn: if thou spit upon it, it shall be quenched: and both these come out of thy mouth.

**[28:13]** Curse the whisperer and doubletongued: for such have destroyed many that were at peace.

**[28:14]** A backbiting tongue hath disquieted many, and driven them from nation to nation: strong cities hath it pulled down, and overthrown the houses of great men.

**[28:15]** A backbiting tongue hath cast out virtuous women, and deprived them of their labours.

**[28:16]** Whoso hearkeneth unto it shall never find rest, and never dwell quietly.

**[28:17]** The stroke of the whip maketh marks in the flesh: but the stroke of the tongue breaketh the bones.

**[28:18]** Many have fallen by the edge of the sword: but not so many as have fallen by the tongue.

**[28:19]** Well is he that is defended through the venom thereof; who hath not drawn the yoke thereof, nor hath been bound in her bands.

**[28:20]** For the yoke thereof is a yoke of iron, and the bands thereof are bands of brass.

**[28:21]** The death thereof is an evil death, the grave were better than it.

**[28:22]** It shall not have rule over them that fear God, neither shall they be burned with the flame thereof.

**[28:23]** Such as forsake the Lord shall fall into it; and it shall burn in them, and not be quenched; it shall be sent upon them as a lion, and devour them as a leopard.

**[28:24]** Look that thou hedge thy possession about with thorns, and bind up thy silver and gold,

**[28:25]** And weigh thy words in a balance, and make a door and bar for thy mouth.

**[28:26]** Beware thou slide not by it, lest thou fall before him that lieth in wait.

**[29:1]** He that is merciful will lend unto his neighbour; and he that strengtheneth his hand keepeth the commandments.

**[29:2]** Lend to thy neighbour in time of his need, and pay thou thy neighbour again in due season.

**[29:3]** Keep thy word, and deal faithfully with him, and thou shalt always find the thing that is necessary for thee.

**[29:4]** Many, when a thing was lent them, reckoned it to be found, and put them to trouble that helped them.

**[29:5]** Till he hath received, he will kiss a man’s hand; and for his neighbour’s money he will speak submissly: but when he should repay, he will prolong the time, and return words of grief, and complain of the time.

**[29:6]** If he prevail, he shall hardly receive the half, and he will count as if he had found it: if not, he hath deprived him of his money, and he hath gotten him an enemy without cause: he payeth him with cursings and railings; and for honour he will pay him disgrace.

**[29:7]** Many therefore have refused to lend for other men’s ill dealing, fearing to be defrauded.

**[29:8]** Yet have thou patience with a man in poor estate, and delay not to shew him mercy.

**[29:9]** Help the poor for the commandment’s sake, and turn him not away because of his poverty.

**[29:10]** Lose thy money for thy brother and thy friend, and let it not rust under a stone to be lost.

**[29:11]** Lay up thy treasure according to the commandments of the most High, and it shall bring thee more profit than gold.

**[29:12]** Shut up alms in thy storehouses: and it shall deliver thee from all affliction.

**[29:13]** It shall fight for thee against thine enemies better than a mighty shield and strong spear.

**[29:14]** An honest man is surety for his neighbour: but he that is impudent will forsake him.

**[29:15]** Forget not the friendship of thy surety, for he hath given his life for thee.

**[29:16]** A sinner will overthrow the good estate of his surety:

**[29:17]** And he that is of an unthankful mind will leave him in danger that delivered him.

**[29:18]** Suretiship hath undone many of good estate, and shaken them as a wave of the sea: mighty men hath it driven from their houses, so that they wandered among strange nations.

**[29:19]** A wicked man transgressing the commandments of the Lord shall fall into suretiship: and he that undertaketh and followeth other men’s business for gain shall fall into suits.

**[29:20]** Help thy neighbour according to thy power, and beware that thou thyself fall not into the same.

**[29:21]** The chief thing for life is water, and bread, and clothing, and an house to cover shame.

**[29:22]** Better is the life of a poor man in a mean cottage, than delicate fare in another man’s house.

**[29:23]** Be it little or much, hold thee contented, that thou hear not the reproach of thy house.

**[29:24]** For it is a miserable life to go from house to house: for where thou art a stranger, thou darest not open thy mouth.

**[29:25]** Thou shalt entertain, and feast, and have no thanks: moreover thou shalt hear bitter words:

**[29:26]** Come, thou stranger, and furnish a table, and feed me of that thou hast ready.

**[29:27]** Give place, thou stranger, to an honourable man; my brother cometh to be lodged, and I have need of mine house.

**[29:28]** These things are grievous to a man of understanding; the upbraiding of houseroom, and reproaching of the lender.

**[30:1]** He that loveth his son causeth him oft to feel the rod, that he may have joy of him in the end.

**[30:2]** He that chastiseth his son shall have joy in him, and shall rejoice of him among his acquaintance.

**[30:3]** He that teacheth his son grieveth the enemy: and before his friends he shall rejoice of him.

**[30:4]** Though his father die, yet he is as though he were not dead: for he hath left one behind him that is like himself.

**[30:5]** While he lived, he saw and rejoiced in him: and when he died, he was not sorrowful.

**[30:6]** He left behind him an avenger against his enemies, and one that shall requite kindness to his friends.

**[30:7]** He that maketh too much of his son shall bind up his wounds; and his bowels will be troubled at every cry.

**[30:8]** An horse not broken becometh headstrong: and a child left to himself will be wilful.

**[30:9]** Cocker thy child, and he shall make thee afraid: play with him, and he will bring thee to heaviness.

**[30:10]** Laugh not with him, lest thou have sorrow with him, and lest thou gnash thy teeth in the end.

**[30:11]** Give him no liberty in his youth, and wink not at his follies.

**[30:12]** Bow down his neck while he is young, and beat him on the sides while he is a child, lest he wax stubborn, and be disobedient unto thee, and so bring sorrow to thine heart.

**[30:13]** Chastise thy son, and hold him to labour, lest his lewd behaviour be an offence unto thee.

**[30:14]** Better is the poor, being sound and strong of constitution, than a rich man that is afflicted in his body.

**[30:15]** Health and good estate of body are above all gold, and a strong body above infinite wealth.

**[30:16]** There is no riches above a sound body, and no joy above the joy of the heart.

**[30:17]** Death is better than a bitter life or continual sickness.

**[30:18]** Delicates poured upon a mouth shut up are as messes of meat set upon a grave.

**[30:19]** What good doeth the offering unto an idol? for neither can it eat nor smell: so is he that is persecuted of the Lord.

**[30:20]** He seeth with his eyes and groaneth, as an eunuch that embraceth a virgin and sigheth.

**[30:21]** Give not over thy mind to heaviness, and afflict not thyself in thine own counsel.

**[30:22]** The gladness of the heart is the life of man, and the joyfulness of a man prolongeth his days.

**[30:23]** Love thine own soul, and comfort thy heart, remove sorrow far from thee: for sorrow hath killed many, and there is no profit therein.

**[30:24]** Envy and wrath shorten the life, and carefulness bringeth age before the time.

**[30:25]** A cheerful and good heart will have a care of his meat and diet.

**[31:1]** Watching for riches consumeth the flesh, and the care thereof driveth away sleep.

**[31:2]** Watching care will not let a man slumber, as a sore disease breaketh sleep,

**[31:3]** The rich hath great labour in gathering riches together; and when he resteth, he is filled with his delicates.

**[31:4]** The poor laboureth in his poor estate; and when he leaveth off, he is still needy.

**[31:5]** He that loveth gold shall not be justified, and he that followeth corruption shall have enough thereof.

**[31:6]** Gold hath been the ruin of many, and their destruction was present.

**[31:7]** It is a stumblingblock unto them that sacrifice unto it, and every fool shall be taken therewith.

**[31:8]** Blessed is the rich that is found without blemish, and hath not gone after gold.

**[31:9]** Who is he? and we will call him blessed: for wonderful things hath he done among his people.

**[31:10]** Who hath been tried thereby, and found perfect? then let him glory. Who might offend, and hath not offended? or done evil, and hath not done it?

**[31:11]** His goods shall be established, and the congregation shall declare his alms.

**[31:12]** If thou sit at a bountiful table, be not greedy upon it, and say not, There is much meat on it.

**[31:13]** Remember that a wicked eye is an evil thing: and what is created more wicked than an eye? therefore it weepeth upon every occasion.

**[31:14]** Stretch not thine hand whithersoever it looketh, and thrust it not with him into the dish.

**[31:15]** Judge not thy neighbour by thyself: and be discreet in every point.

**[31:16]** Eat as it becometh a man, those things which are set before thee; and devour note, lest thou be hated.

**[31:17]** Leave off first for manners’ sake; and be not unsatiable, lest thou offend.

**[31:18]** When thou sittest among many, reach not thine hand out first of all.

**[31:19]** A very little is sufficient for a man well nurtured, and he fetcheth not his wind short upon his bed.

**[31:20]** Sound sleep cometh of moderate eating: he riseth early, and his wits are with him: but the pain of watching, and choler, and pangs of the belly, are with an unsatiable man.

**[31:21]** And if thou hast been forced to eat, arise, go forth, vomit, and thou shalt have rest.

**[31:22]** My son, hear me, and despise me not, and at the last thou shalt find as I told thee: in all thy works be quick, so shall there no sickness come unto thee.

**[31:23]** Whoso is liberal of his meat, men shall speak well of him; and the report of his good housekeeping will be believed.

**[31:24]** But against him that is a niggard of his meat the whole city shall murmur; and the testimonies of his niggardness shall not be doubted of.

**[31:25]** Shew not thy valiantness in wine; for wine hath destroyed many.

**[31:26]** The furnace proveth the edge by dipping: so doth wine the hearts of the proud by drunkeness.

**[31:27]** Wine is as good as life to a man, if it be drunk moderately: what life is then to a man that is without wine? for it was made to make men glad.

**[31:28]** Wine measurably drunk and in season bringeth gladness of the heart, and cheerfulness of the mind:

**[31:29]** But wine drunken with excess maketh bitterness of the mind, with brawling and quarrelling.

**[31:30]** Drunkenness increaseth the rage of a fool till he offend: it diminisheth strength, and maketh wounds.

**[31:31]** Rebuke not thy neighbour at the wine, and despise him not in his mirth: give him no despiteful words, and press not upon him with urging him to drink.

**[32:1]** If thou be made the master of a feast, lift not thyself up, but be among them as one of the rest; take diligent care for them, and so sit down.

**[32:2]** And when thou hast done all thy office, take thy place, that thou mayest be merry with them, and receive a crown for thy well ordering of the feast.

**[32:3]** Speak, thou that art the elder, for it becometh thee, but with sound judgment; and hinder not musick.

**[32:4]** Pour not out words where there is a musician, and shew not forth wisdom out of time.

**[32:5]** A concert of musick in a banquet of wine is as a signet of carbuncle set in gold.

**[32:6]** As a signet of an emerald set in a work of gold, so is the melody of musick with pleasant wine.

**[32:7]** Speak, young man, if there be need of thee: and yet scarcely when thou art twice asked.

**[32:8]** Let thy speech be short, comprehending much in few words; be as one that knoweth and yet holdeth his tongue.

**[32:9]** If thou be among great men, make not thyself equal with them; and when ancient men are in place, use not many words.

**[32:10]** Before the thunder goeth lightning; and before a shamefaced man shall go favour.

**[32:11]** Rise up betimes, and be not the last; but get thee home without delay.

**[32:12]** There take thy pastime, and do what thou wilt: but sin not by proud speech.

**[32:13]** And for these things bless him that made thee, and hath replenished thee with his good things.

**[32:14]** Whoso feareth the Lord will receive his discipline; and they that seek him early shall find favour.

**[32:15]** He that seeketh the law shall be filled therewith: but the hypocrite will be offended thereat.

**[32:16]** They that fear the Lord shall find judgment, and shall kindle justice as a light.

**[32:17]** A sinful man will not be reproved, but findeth an excuse according to his will.

**[32:18]** A man of counsel will be considerate; but a strange and proud man is not daunted with fear, even when of himself he hath done without counsel.

**[32:19]** Do nothing without advice; and when thou hast once done, repent not.

**[32:20]** Go not in a way wherein thou mayest fall, and stumble not among the stones.

**[32:21]** Be not confident in a plain way.

**[32:22]** And beware of thine own children.

**[32:23]** In every good work trust thy own soul; for this is the keeping of the commandments.

**[32:24]** He that believeth in the Lord taketh heed to the commandment; and he that trusteth in him shall fare never the worse.

**[33:1]** There shall no evil happen unto him that feareth the Lord; but in temptation even again he will deliver him.

**[33:2]** A wise man hateth not the law; but he that is an hypocrite therein is as a ship in a storm.

**[33:3]** A man of understanding trusteth in the law; and the law is faithful unto him, as an oracle.

**[33:4]** Prepare what to say, and so thou shalt be heard: and bind up instruction, and then make answer.

**[33:5]** The heart of the foolish is like a cartwheel; and his thoughts are like a rolling axletree.

**[33:6]** A stallion horse is as a mocking friend, he neigheth under every one that sitteth upon him.

**[33:7]** Why doth one day excel another, when as all the light of every day in the year is of the sun?

**[33:8]** By the knowledge of the Lord they were distinguished: and he altered seasons and feasts.

**[33:9]** Some of them hath he made high days, and hallowed them, and some of them hath he made ordinary days.

**[33:10]** And all men are from the ground, and Adam was created of earth:

**[33:11]** In much knowledge the Lord hath divided them, and made their ways diverse.

**[33:12]** Some of them hath he blessed and exalted and some of them he sanctified, and set near himself: but some of them hath he cursed and brought low, and turned out of their places.

**[33:13]** As the clay is in the potter’s hand, to fashion it at his pleasure: so man is in the hand of him that made him, to render to them as liketh him best.

**[33:14]** Good is set against evil, and life against death: so is the godly against the sinner, and the sinner against the godly.

**[33:15]** So look upon all the works of the most High; and there are two and two, one against another.

**[33:16]** I awaked up last of all, as one that gathereth after the grapegatherers: by the blessing of the Lord I profited, and tred my winepress like a gatherer of grapes.

**[33:17]** Consider that I laboured not for myself only, but for all them that seek learning.

**[33:18]** Hear me, O ye great men of the people, and hearken with your ears, ye rulers of the congregation.

**[33:19]** Give not thy son and wife, thy brother and friend, power over thee while thou livest, and give not thy goods to another: lest it repent thee, and thou intreat for the same again.

**[33:20]** As long as thou livest and hast breath in thee, give not thyself over to any.

**[33:21]** For better it is that thy children should seek to thee, than that thou shouldest stand to their courtesy.

**[33:22]** In all thy works keep to thyself the preeminence; leave not a stain in thine honour.

**[33:23]** At the time when thou shalt end thy days, and finish thy life, distribute thine inheritance.

**[33:24]** Fodder, a wand, and burdens, are for the ass; and bread, correction, and work, for a servant. .

**[33:25]** If thou set thy servant to labour, thou shalt find rest: but if thou let him go idle, he shall seek liberty.

**[33:26]** A yoke and a collar do bow the neck: so are tortures and torments for an evil servant.

**[33:27]** Send him to labour, that he be not idle; for idleness teacheth much evil.

**[33:28]** Set him to work, as is fit for him: if he be not obedient, put on more heavy fetters.

**[33:29]** But be not excessive toward any; and without discretion do nothing.

**[33:30]** If thou have a servant, let him be unto thee as thyself, because thou hast bought him with a price.

**[33:31]** If thou have a servant, entreat him as a brother: for thou hast need of him, as of thine own soul: if thou entreat him evil, and he run from thee, which way wilt thou go to seek him?

**[34:1]** The hopes of a man void of understanding are vain and false: and dreams lift up fools.

**[34:2]** Whoso regardeth dreams is like him that catcheth at a shadow, and followeth after the wind.

**[34:3]** The vision of dreams is the resemblance of one thing to another, even as the likeness of a face to a face.

**[34:4]** Of an unclean thing what can be cleansed? and from that thing which is false what truth can come?

**[34:5]** Divinations, and soothsayings, and dreams, are vain: and the heart fancieth, as a woman’s heart in travail.

**[34:6]** If they be not sent from the most High in thy visitation, set not thy heart upon them.

**[34:7]** For dreams have deceived many, and they have failed that put their trust in them.

**[34:8]** The law shall be found perfect without lies: and wisdom is perfection to a faithful mouth.

**[34:9]** A man that hath travelled knoweth many things; and he that hath much experience will declare wisdom.

**[34:10]** He that hath no experience knoweth little: but he that hath travelled is full of prudence.

**[34:11]** When I travelled, I saw many things; and I understand more than I can express.

**[34:12]** I was ofttimes in danger of death: yet I was delivered because of these things.

**[34:13]** The spirit of those that fear the Lord shall live; for their hope is in him that saveth them.

**[34:14]** Whoso feareth the Lord shall not fear nor be afraid; for he is his hope.

**[34:15]** Blessed is the soul of him that feareth the Lord: to whom doth he look? and who is his strength?

**[34:16]** For the eyes of the Lord are upon them that love him, he is their mighty protection and strong stay, a defence from heat, and a cover from the sun at noon, a preservation from stumbling, and an help from falling.

**[34:17]** He raiseth up the soul, and lighteneth the eyes: he giveth health, life, and blessing.

**[34:18]** He that sacrificeth of a thing wrongfully gotten, his offering is ridiculous; and the gifts of unjust men are not accepted.

**[34:19]** The most High is not pleased with the offerings of the wicked; neither is he pacified for sin by the multitude of sacrifices.

**[34:20]** Whoso bringeth an offering of the goods of the poor doeth as one that killeth the son before his father’s eyes.

**[34:21]** The bread of the needy is their life: he that defraudeth him thereof is a man of blood.

**[34:22]** He that taketh away his neighbour’s living slayeth him; and he that defraudeth the labourer of his hire is a bloodshedder.

**[34:23]** When one buildeth, and another pulleth down, what profit have they then but labour?

**[34:24]** When one prayeth, and another curseth, whose voice will the Lord hear?

**[34:25]** He that washeth himself after the touching of a dead body, if he touch it again, what availeth his washing?

**[34:26]** So is it with a man that fasteth for his sins, and goeth again, and doeth the same: who will hear his prayer? or what doth his humbling profit him?

**[35:1]** He that keepeth the law bringeth offerings enough: he that taketh heed to the commandment offereth a peace offering.

**[35:2]** He that requiteth a goodturn offereth fine flour; and he that giveth alms sacrificeth praise.

**[35:3]** To depart from wickedness is a thing pleasing to the Lord; and to forsake unrighteousness is a propitiation.

**[35:4]** Thou shalt not appear empty before the Lord.

**[35:5]** For all these things are to be done because of the commandment.

**[35:6]** The offering of the righteous maketh the altar fat, and the sweet savour thereof is before the most High.

**[35:7]** The sacrifice of a just man is acceptable. and the memorial thereof shall never be forgotten.

**[35:8]** Give the Lord his honour with a good eye, and diminish not the firstfruits of thine hands.

**[35:9]** In all thy gifts shew a cheerful countenance, and dedicate thy tithes with gladness.

**[35:10]** Give unto the most High according as he hath enriched thee; and as thou hast gotten, give with a cheerful eye.

**[35:11]** For the Lord recompenseth, and will give thee seven times as much.

**[35:12]** Do not think to corrupt with gifts; for such he will not receive: and trust not to unrighteous sacrifices; for the Lord is judge, and with him is no respect of persons.

**[35:13]** He will not accept any person against a poor man, but will hear the prayer of the oppressed.

**[35:14]** He will not despise the supplication of the fatherless; nor the widow, when she poureth out her complaint.

**[35:15]** Do not the tears run down the widow’s cheeks? and is not her cry against him that causeth them to fall?

**[35:16]** He that serveth the Lord shall be accepted with favour, and his prayer shall reach unto the clouds.

**[35:17]** The prayer of the humble pierceth the clouds: and till it come nigh, he will not be comforted; and will not depart, till the most High shall behold to judge righteously, and execute judgment.

**[35:18]** For the Lord will not be slack, neither will the Mighty be patient toward them, till he have smitten in sunder the loins of the unmerciful, and repayed vengeance to the heathen; till he have taken away the multitude of the proud, and broken the sceptre of the unrighteous;

**[35:19]** Till he have rendered to every man according to his deeds, and to the works of men according to their devices; till he have judged the cause of his people, and made them to rejoice in his mercy.

**[35:20]** Mercy is seasonable in the time of affliction, as clouds of rain in the time of drought.

**[36:1]** Have mercy upon us, O Lord God of all, and behold us:

**[36:2]** And send thy fear upon all the nations that seek not after thee.

**[36:3]** Lift up thy hand against the strange nations, and let them see thy power.

**[36:4]** As thou wast sanctified in us before them: so be thou magnified among them before us.

**[36:5]** And let them know thee, as we have known thee, that there is no God but only thou, O God.

**[36:6]** Shew new signs, and make other strange wonders: glorify thy hand and thy right arm, that they may set forth thy wondrous works.

**[36:7]** Raise up indignation, and pour out wrath: take away the adversary, and destroy the enemy.

**[36:8]** Sake the time short, remember the covenant, and let them declare thy wonderful works.

**[36:9]** Let him that escapeth be consumed by the rage of the fire; and let them perish that oppress the people.

**[36:10]** Smite in sunder the heads of the rulers of the heathen, that say, There is none other but we.

**[36:11]** Gather all the tribes of Jacob together, and inherit thou them, as from the beginning.

**[36:12]** O Lord, have mercy upon the people that is called by thy name, and upon Israel, whom thou hast named thy firstborn.

**[36:13]** O be merciful unto Jerusalem, thy holy city, the place of thy rest.

**[36:14]** Fill Sion with thine unspeakable oracles, and thy people with thy glory:

**[36:15]** Give testimony unto those that thou hast possessed from the beginning, and raise up prophets that have been in thy name.

**[36:16]** Reward them that wait for thee, and let thy prophets be found faithful.

**[36:17]** O Lord, hear the prayer of thy servants, according to the blessing of Aaron over thy people, that all they which dwell upon the earth may know that thou art the Lord, the eternal God.

**[36:18]** The belly devoureth all meats, yet is one meat better than another.

**[36:19]** As the palate tasteth divers kinds of venison: so doth an heart of understanding false speeches.

**[36:20]** A froward heart causeth heaviness: but a man of experience will recompense him.

**[36:21]** A woman will receive every man, yet is one daughter better than another.

**[36:22]** The beauty of a woman cheereth the countenance, and a man loveth nothing better.

**[36:23]** If there be kindness, meekness, and comfort, in her tongue, then is not her husband like other men.

**[36:24]** He that getteth a wife beginneth a possession, a help like unto himself, and a pillar of rest.

**[36:25]** Where no hedge is, there the possession is spoiled: and he that hath no wife will wander up and down mourning.

**[36:26]** Who will trust a thief well appointed, that skippeth from city to city? so who will believe a man that hath no house, and lodgeth wheresoever the night taketh him?

**[37:1]** Every friend saith, I am his friend also: but there is a friend, which is only a friend in name.

**[37:2]** Is it not a grief unto death, when a companion and friend is turned to an enemy?

**[37:3]** O wicked imagination, whence camest thou in to cover the earth with deceit?

**[37:4]** There is a companion, which rejoiceth in the prosperity of a friend, but in the time of trouble will be against him.

**[37:5]** There is a companion, which helpeth his friend for the belly, and taketh up the buckler against the enemy.

**[37:6]** Forget not thy friend in thy mind, and be not unmindful of him in thy riches.

**[37:7]** Every counsellor extolleth counsel; but there is some that counselleth for himself.

**[37:8]** Beware of a counsellor, and know before what need he hath; for he will counsel for himself; lest he cast the lot upon thee,

**[37:9]** And say unto thee, Thy way is good: and afterward he stand on the other side, to see what shall befall thee.

**[37:10]** Consult not with one that suspecteth thee: and hide thy counsel from such as envy thee.

**[37:11]** Neither consult with a woman touching her of whom she is jealous; neither with a coward in matters of war; nor with a merchant concerning exchange; nor with a buyer of selling; nor with an envious man of thankfulness; nor with an unmerciful man touching kindness; nor with the slothful for any work; nor with an hireling for a year of finishing work; nor with an idle servant of much business: hearken not unto these in any matter of counsel.

**[37:12]** But be continually with a godly man, whom thou knowest to keep the commandments of the Lord, whose, mind is according to thy mind, and will sorrow with thee, if thou shalt miscarry.

**[37:13]** And let the counsel of thine own heart stand: for there is no man more faithful unto thee than it.

**[37:14]** For a man’s mind is sometime wont to tell him more than seven watchmen, that sit above in an high tower.

**[37:15]** And above all this pray to the most High, that he will direct thy way in truth.

**[37:16]** Let reason go before every enterprize, and counsel before every action.

**[37:17]** The countenance is a sign of changing of the heart.

**[37:18]** Four manner of things appear: good and evil, life and death: but the tongue ruleth over them continually.

**[37:19]** There is one that is wise and teacheth many, and yet is unprofitable to himself.

**[37:20]** There is one that sheweth wisdom in words, and is hated: he shall be destitute of all food.

**[37:21]** For grace is not given, him from the Lord, because he is deprived of all wisdom.

**[37:22]** Another is wise to himself; and the fruits of understanding are commendable in his mouth.

**[37:23]** A wise man instructeth his people; and the fruits of his understanding fail not.

**[37:24]** A wise man shall be filled with blessing; and all they that see him shall count him happy.

**[37:25]** The days of the life of man may be numbered: but the days of Israel are innumerable.

**[37:26]** A wise man shall inherit glory among his people, and his name shall be perpetual.

**[37:27]** My son, prove thy soul in thy life, and see what is evil for it, and give not that unto it.

**[37:28]** For all things are not profitable for all men, neither hath every soul pleasure in every thing.

**[37:29]** Be not unsatiable in any dainty thing, nor too greedy upon meats:

**[37:30]** For excess of meats bringeth sickness, and surfeiting will turn into choler.

**[37:31]** By surfeiting have many perished; but he that taketh heed prolongeth his life.

**[38:1]** Honour a physician with the honour due unto him for the uses which ye may have of him: for the Lord hath created him.

**[38:2]** For of the most High cometh healing, and he shall receive honour of the king.

**[38:3]** The skill of the physician shall lift up his head: and in the sight of great men he shall be in admiration.

**[38:4]** The Lord hath created medicines out of the earth; and he that is wise will not abhor them.

**[38:5]** Was not the water made sweet with wood, that the virtue thereof might be known?

**[38:6]** And he hath given men skill, that he might be honoured in his marvellous works.

**[38:7]** With such doth he heal men, and taketh away their pains.

**[38:8]** Of such doth the apothecary make a confection; and of his works there is no end; and from him is peace over all the earth,

**[38:9]** My son, in thy sickness be not negligent: but pray unto the Lord, and he will make thee whole.

**[38:10]** Leave off from sin, and order thine hands aright, and cleanse thy heart from all wickedness.

**[38:11]** Give a sweet savour, and a memorial of fine flour; and make a fat offering, as not being.

**[38:12]** Then give place to the physician, for the Lord hath created him: let him not go from thee, for thou hast need of him.

**[38:13]** There is a time when in their hands there is good success.

**[38:14]** For they shall also pray unto the Lord, that he would prosper that, which they give for ease and remedy to prolong life.

**[38:15]** He that sinneth before his Maker, let him fall into the hand of the physician.

**[38:16]** My son, let tears fall down over the dead, and begin to lament, as if thou hadst suffered great harm thyself; and then cover his body according to the custom, and neglect not his burial.

**[38:17]** Weep bitterly, and make great moan, and use lamentation, as he is worthy, and that a day or two, lest thou be evil spoken of: and then comfort thyself for thy heaviness.

**[38:18]** For of heaviness cometh death, and the heaviness of the heart breaketh strength.

**[38:19]** In affliction also sorrow remaineth: and the life of the poor is the curse of the heart.

**[38:20]** Take no heaviness to heart: drive it away, and member the last end.

**[38:21]** Forget it not, for there is no turning again: thou shalt not do him good, but hurt thyself.

**[38:22]** Remember my judgment: for thine also shall be so; yesterday for me, and to day for thee.

**[38:23]** When the dead is at rest, let his remembrance rest; and be comforted for him, when his Spirit is departed from him.

**[38:24]** The wisdom of a learned man cometh by opportunity of leisure: and he that hath little business shall become wise.

**[38:25]** How can he get wisdom that holdeth the plough, and that glorieth in the goad, that driveth oxen, and is occupied in their labours, and whose talk is of bullocks?

**[38:26]** He giveth his mind to make furrows; and is diligent to give the kine fodder.

**[38:27]** So every carpenter and workmaster, that laboureth night and day: and they that cut and grave seals, and are diligent to make great variety, and give themselves to counterfeit imagery, and watch to finish a work:

**[38:28]** The smith also sitting by the anvil, and considering the iron work, the vapour of the fire wasteth his flesh, and he fighteth with the heat of the furnace: the noise of the hammer and the anvil is ever in his ears, and his eyes look still upon the pattern of the thing that he maketh; he setteth his mind to finish his work, and watcheth to polish it perfectly:

**[38:29]** So doth the potter sitting at his work, and turning the wheel about with his feet, who is alway carefully set at his work, and maketh all his work by number;

**[38:30]** He fashioneth the clay with his arm, and boweth down his strength before his feet; he applieth himself to lead it over; and he is diligent to make clean the furnace:

**[38:31]** All these trust to their hands: and every one is wise in his work.

**[38:32]** Without these cannot a city be inhabited: and they shall not dwell where they will, nor go up and down:

**[38:33]** They shall not be sought for in publick counsel, nor sit high in the congregation: they shall not sit on the judges’ seat, nor understand the sentence of judgment: they cannot declare justice and judgment; and they shall not be found where parables are spoken.

**[38:34]** But they will maintain the state of the world, and all their desire is in the work of their craft.

**[39:1]** But he that giveth his mind to the law of the most High, and is occupied in the meditation thereof, will seek out the wisdom of all the ancient, and be occupied in prophecies.

**[39:2]** He will keep the sayings of the renowned men: and where subtil parables are, he will be there also.

**[39:3]** He will seek out the secrets of grave sentences, and be conversant in dark parables.

**[39:4]** He shall serve among great men, and appear before princes: he will travel through strange countries; for he hath tried the good and the evil among men.

**[39:5]** He will give his heart to resort early to the Lord that made him, and will pray before the most High, and will open his mouth in prayer, and make supplication for his sins.

**[39:6]** When the great Lord will, he shall be filled with the spirit of understanding: he shall pour out wise sentences, and give thanks unto the Lord in his prayer.

**[39:7]** He shall direct his counsel and knowledge, and in his secrets shall he meditate.

**[39:8]** He shall shew forth that which he hath learned, and shall glory in the law of the covenant of the Lord.

**[39:9]** Many shall commend his understanding; and so long as the world endureth, it shall not be blotted out; his memorial shall not depart away, and his name shall live from generation to generation.

**[39:10]** Nations shall shew forth his wisdom, and the congregation shall declare his praise.

**[39:11]** If he die, he shall leave a greater name than a thousand: and if he live, he shall increase it.

**[39:12]** Yet have I more to say, which I have thought upon; for I am filled as the moon at the full.

**[39:13]** Hearken unto me, ye holy children, and bud forth as a rose growing by the brook of the field:

**[39:14]** And give ye a sweet savour as frankincense, and flourish as a lily, send forth a smell, and sing a song of praise, bless the Lord in all his works.

**[39:15]** Magnify his name, and shew forth his praise with the songs of your lips, and with harps, and in praising him ye shall say after this manner:

**[39:16]** All the works of the Lord are exceeding good, and whatsoever he commandeth shall be accomplished in due season.

**[39:17]** And none may say, What is this? wherefore is that? for at time convenient they shall all be sought out: at his commandment the waters stood as an heap, and at the words of his mouth the receptacles of waters.

**[39:18]** At his commandment is done whatsoever pleaseth him; and none can hinder, when he will save.

**[39:19]** The works of all flesh are before him, and nothing can be hid from his eyes.

**[39:20]** He seeth from everlasting to everlasting; and there is nothing wonderful before him.

**[39:21]** A man need not to say, What is this? wherefore is that? for he hath made all things for their uses.

**[39:22]** His blessing covered the dry land as a river, and watered it as a flood.

**[39:23]** As he hath turned the waters into saltness: so shall the heathen inherit his wrath.

**[39:24]** As his ways are plain unto the holy; so are they stumblingblocks unto the wicked.

**[39:25]** For the good are good things created from the beginning: so evil things for sinners.

**[39:26]** The principal things for the whole use of man’s life are water, fire, iron, and salt, flour of wheat, honey, milk, and the blood of the grape, and oil, and clothing.

**[39:27]** All these things are for good to the godly: so to the sinners they are turned into evil.

**[39:28]** There be spirits that are created for vengeance, which in their fury lay on sore strokes; in the time of destruction they pour out their force, and appease the wrath of him that made them.

**[39:29]** Fire, and hail, and famine, and death, all these were created for vengeance;

**[39:30]** Teeth of wild beasts, and scorpions, serpents, and the sword punishing the wicked to destruction.

**[39:31]** They shall rejoice in his commandment, and they shall be ready upon earth, when need is; and when their time is come, they shall not transgress his word.

**[39:32]** Therefore from the beginning I was resolved, and thought upon these things, and have left them in writing.

**[39:33]** All the works of the Lord are good: and he will give every needful thing in due season.

**[39:34]** So that a man cannot say, This is worse than that: for in time they shall all be well approved.

**[39:35]** And therefore praise ye the Lord with the whole heart and mouth, and bless the name of the Lord.

**[40:1]** Great travail is created for every man, and an heavy yoke is upon the sons of Adam, from the day that they go out of their mother’s womb, till the day that they return to the mother of all things.

**[40:2]** Their imagination of things to come, and the day of death, trouble their thoughts, and cause fear of heart;

**[40:3]** From him that sitteth on a throne of glory, unto him that is humbled in earth and ashes;

**[40:4]** From him that weareth purple and a crown, unto him that is clothed with a linen frock.

**[40:5]** Wrath, and envy, trouble, and unquietness, fear of death, and anger, and strife, and in the time of rest upon his bed his night sleep, do change his knowledge.

**[40:6]** A little or nothing is his rest, and afterward he is in his sleep, as in a day of keeping watch, troubled in the vision of his heart, as if he were escaped out of a battle.

**[40:7]** When all is safe, he awaketh, and marvelleth that the fear was nothing.

**[40:8]** Such things happen unto all flesh, both man and beast, and that is sevenfold more upon sinners.

**[40:9]** Death, and bloodshed, strife, and sword, calamities, famine, tribulation, and the scourge;

**[40:10]** These things are created for the wicked, and for their sakes came the flood.

**[40:11]** All things that are of the earth shall turn to the earth again: and that which is of the waters doth return into the sea.

**[40:12]** All bribery and injustice shall be blotted out: but true dealing shall endure for ever.

**[40:13]** The goods of the unjust shall be dried up like a river, and shall vanish with noise, like a great thunder in rain.

**[40:14]** While he openeth his hand he shall rejoice: so shall transgressors come to nought.

**[40:15]** The children of the ungodly shall not bring forth many branches: but are as unclean roots upon a hard rock.

**[40:16]** The weed growing upon every water and bank of a river shall be pulled up before all grass.

**[40:17]** Bountifulness is as a most fruitful garden, and mercifulness endureth for ever.

**[40:18]** To labour, and to be content with that a man hath, is a sweet life: but he that findeth a treasure is above them both.

**[40:19]** Children and the building of a city continue a man’s name: but a blameless wife is counted above them both.

**[40:20]** Wine and musick rejoice the heart: but the love of wisdom is above them both.

**[40:21]** The pipe and the psaltery make sweet melody: but a pleasant tongue is above them both.

**[40:22]** Thine eye desireth favour and beauty: but more than both corn while it is green.

**[40:23]** A friend and companion never meet amiss: but above both is a wife with her husband.

**[40:24]** Brethren and help are against time of trouble: but alms shall deliver more than them both.

**[40:25]** Gold and silver make the foot stand sure: but counsel is esteemed above them both.

**[40:26]** Riches and strength lift up the heart: but the fear of the Lord is above them both: there is no want in the fear of the Lord, and it needeth not to seek help.

**[40:27]** The fear of the Lord is a fruitful garden, and covereth him above all glory.

**[40:28]** My son, lead not a beggar’s life; for better it is to die than to beg.

**[40:29]** The life of him that dependeth on another man’s table is not to be counted for a life; for he polluteth himself with other men’s meat: but a wise man well nurtured will beware thereof.

**[40:30]** Begging is sweet in the mouth of the shameless: but in his belly there shall burn a fire.

**[41:1]** O death, how bitter is the remembrance of thee to a man that liveth at rest in his possessions, unto the man that hath nothing to vex him, and that hath prosperity in all things: yea, unto him that is yet able to receive meat!

**[41:2]** O death, acceptable is thy sentence unto the needy, and unto him whose strength faileth, that is now in the last age, and is vexed with all things, and to him that despaireth, and hath lost patience!

**[41:3]** Fear not the sentence of death, remember them that have been before thee, and that come after; for this is the sentence of the Lord over all flesh.

**[41:4]** And why art thou against the pleasure of the most High? there is no inquisition in the grave, whether thou have lived ten, or an hundred, or a thousand years.

**[41:5]** The children of sinners are abominable children, and they that are conversant in the dwelling of the ungodly.

**[41:6]** The inheritance of sinners’ children shall perish, and their posterity shall have a perpetual reproach.

**[41:7]** The children will complain of an ungodly father, because they shall be reproached for his sake.

**[41:8]** Woe be unto you, ungodly men, which have forsaken the law of the most high God! for if ye increase, it shall be to your destruction:

**[41:9]** And if ye be born, ye shall be born to a curse: and if ye die, a curse shall be your portion.

**[41:10]** All that are of the earth shall turn to earth again: so the ungodly shall go from a curse to destruction.

**[41:11]** The mourning of men is about their bodies: but an ill name of sinners shall be blotted out.

**[41:12]** Have regard to thy name; for that shall continue with thee above a thousand great treasures of gold.

**[41:13]** A good life hath but few days: but a good name endureth for ever.

**[41:14]** My children, keep discipline in peace: for wisdom that is hid, and a treasure that is not seen, what profit is in them both?

**[41:15]** A man that hideth his foolishness is better than a man that hideth his wisdom.

**[41:16]** Therefore be shamefaced according to my word: for it is not good to retain all shamefacedness; neither is it altogether approved in every thing.

**[41:17]** Be ashamed of whoredom before father and mother: and of a lie before a prince and a mighty man;

**[41:18]** Of an offence before a judge and ruler; of iniquity before a congregation and people; of unjust dealing before thy partner and friend;

**[41:19]** And of theft in regard of the place where thou sojournest, and in regard of the truth of God and his covenant; and to lean with thine elbow upon the meat; and of scorning to give and take;

**[41:20]** And of silence before them that salute thee; and to look upon an harlot;

**[41:21]** And to turn away thy face from thy kinsman; or to take away a portion or a gift; or to gaze upon another man’s wife.

**[41:22]** Or to be overbusy with his maid, and come not near her bed; or of upbraiding speeches before friends; and after thou hast given, upbraid not;

**[41:23]** Or of iterating and speaking again that which thou hast heard; and of revealing of secrets.

**[41:24]** So shalt thou be truly shamefaced and find favour before all men.

**[42:1]** Of these things be not thou ashamed, and accept no person to sin thereby:

**[42:2]** Of the law of the most High, and his covenant; and of judgment to justify the ungodly;

**[42:3]** Of reckoning with thy partners and travellers; or of the gift of the heritage of friends;

**[42:4]** Of exactness of balance and weights; or of getting much or little;

**[42:5]** And of merchants’ indifferent selling; of much correction of children; and to make the side of an evil servant to bleed.

**[42:6]** Sure keeping is good, where an evil wife is; and shut up, where many hands are.

**[42:7]** Deliver all things in number and weight; and put all in writing that thou givest out, or receivest in.

**[42:8]** Be not ashamed to inform the unwise and foolish, and the extreme aged that contendeth with those that are young: thus shalt thou be truly learned, and approved of all men living.

**[42:9]** The father waketh for the daughter, when no man knoweth; and the care for her taketh away sleep: when she is young, lest she pass away the flower of her age; and being married, lest she should be hated:

**[42:10]** In her virginity, lest she should be defiled and gotten with child in her father’s house; and having an husband, lest she should misbehave herself; and when she is married, lest she should be barren.

**[42:11]** Keep a sure watch over a shameless daughter, lest she make thee a laughingstock to thine enemies, and a byword in the city, and a reproach among the people, and make thee ashamed before the multitude.

**[42:12]** Behold not every body’s beauty, and sit not in the midst of women.

**[42:13]** For from garments cometh a moth, and from women wickedness.

**[42:14]** Better is the churlishness of a man than a courteous woman, a woman, I say, which bringeth shame and reproach.

**[42:15]** I will now remember the works of the Lord, and declare the things that I have seen: In the words of the Lord are his works.

**[42:16]** The sun that giveth light looketh upon all things, and the work thereof is full of the glory of the Lord.

**[42:17]** The Lord hath not given power to the saints to declare all his marvellous works, which the Almighty Lord firmly settled, that whatsoever is might be established for his glory.

**[42:18]** He seeketh out the deep, and the heart, and considereth their crafty devices: for the Lord knoweth all that may be known, and he beholdeth the signs of the world.

**[42:19]** He declareth the things that are past, and for to come, and revealeth the steps of hidden things.

**[42:20]** No thought escapeth him, neither any word is hidden from him.

**[42:21]** He hath garnished the excellent works of his wisdom, and he is from everlasting to everlasting: unto him may nothing be added, neither can he be diminished, and he hath no need of any counsellor.

**[42:22]** Oh how desirable are all his works! and that a man may see even to a spark.

**[42:23]** All these things live and remain for ever for all uses, and they are all obedient.

**[42:24]** All things are double one against another: and he hath made nothing imperfect.

**[42:25]** One thing establisheth the good or another: and who shall be filled with beholding his glory?

**[43:1]** The pride of the height, the clear firmament, the beauty of heaven, with his glorious shew;

**[43:2]** The sun when it appeareth, declaring at his rising a marvellous instrument, the work of the most High:

**[43:3]** At noon it parcheth the country, and who can abide the burning heat thereof?

**[43:4]** A man blowing a furnace is in works of heat, but the sun burneth the mountains three times more; breathing out fiery vapours, and sending forth bright beams, it dimmeth the eyes.

**[43:5]** Great is the Lord that made it; and at his commandment runneth hastily.

**[43:6]** He made the moon also to serve in her season for a declaration of times, and a sign of the world.

**[43:7]** From the moon is the sign of feasts, a light that decreaseth in her perfection.

**[43:8]** The month is called after her name, increasing wonderfully in her changing, being an instrument of the armies above, shining in the firmament of heaven;

**[43:9]** The beauty of heaven, the glory of the stars, an ornament giving light in the highest places of the Lord.

**[43:10]** At the commandment of the Holy One they will stand in their order, and never faint in their watches.

**[43:11]** Look upon the rainbow, and praise him that made it; very beautiful it is in the brightness thereof.

**[43:12]** It compasseth the heaven about with a glorious circle, and the hands of the most High have bended it.

**[43:13]** By his commandment he maketh the snow to fall aplace, and sendeth swiftly the lightnings of his judgment.

**[43:14]** Through this the treasures are opened: and clouds fly forth as fowls.

**[43:15]** By his great power he maketh the clouds firm, and the hailstones are broken small.

**[43:16]** At his sight the mountains are shaken, and at his will the south wind bloweth.

**[43:17]** The noise of the thunder maketh the earth to tremble: so doth the northern storm and the whirlwind: as birds flying he scattereth the snow, and the falling down thereof is as the lighting of grasshoppers:

**[43:18]** The eye marvelleth at the beauty of the whiteness thereof, and the heart is astonished at the raining of it.

**[43:19]** The hoarfrost also as salt he poureth on the earth, and being congealed, it lieth on the top of sharp stakes.

**[43:20]** When the cold north wind bloweth, and the water is congealed into ice, it abideth upon every gathering together of water, and clotheth the water as with a breastplate.

**[43:21]** It devoureth the mountains, and burneth the wilderness, and consumeth the grass as fire.

**[43:22]** A present remedy of all is a mist coming speedily, a dew coming after heat refresheth.

**[43:23]** By his counsel he appeaseth the deep, and planteth islands therein.

**[43:24]** They that sail on the sea tell of the danger thereof; and when we hear it with our ears, we marvel thereat.

**[43:25]** For therein be strange and wondrous works, variety of all kinds of beasts and whales created.

**[43:26]** By him the end of them hath prosperous success, and by his word all things consist.

**[43:27]** We may speak much, and yet come short: wherefore in sum, he is all.

**[43:28]** How shall we be able to magnify him? for he is great above all his works.

**[43:29]** The Lord is terrible and very great, and marvellous is his power.

**[43:30]** When ye glorify the Lord, exalt him as much as ye can; for even yet will he far exceed: and when ye exalt him, put forth all your strength, and be not weary; for ye can never go far enough.

**[43:31]** Who hath seen him, that he might tell us? and who can magnify him as he is?

**[43:32]** There are yet hid greater things than these be, for we have seen but a few of his works.

**[43:33]** For the Lord hath made all things; and to the godly hath he given wisdom.

**[44:1]** Let us now praise famous men, and our fathers that begat us.

**[44:2]** The Lord hath wrought great glory by them through his great power from the beginning.

**[44:3]** Such as did bear rule in their kingdoms, men renowned for their power, giving counsel by their understanding, and declaring prophecies:

**[44:4]** Leaders of the people by their counsels, and by their knowledge of learning meet for the people, wise and eloquent are their instructions:

**[44:5]** Such as found out musical tunes, and recited verses in writing:

**[44:6]** Rich men furnished with ability, living peaceably in their habitations:

**[44:7]** All these were honoured in their generations, and were the glory of their times.

**[44:8]** There be of them, that have left a name behind them, that their praises might be reported.

**[44:9]** And some there be, which have no memorial; who are perished, as though they had never been; and are become as though they had never been born; and their children after them.

**[44:10]** But these were merciful men, whose righteousness hath not been forgotten.

**[44:11]** With their seed shall continually remain a good inheritance, and their children are within the covenant.

**[44:12]** Their seed standeth fast, and their children for their sakes.

**[44:13]** Their seed shall remain for ever, and their glory shall not be blotted out.

**[44:14]** Their bodies are buried in peace; but their name liveth for evermore.

**[44:15]** The people will tell of their wisdom, and the congregation will shew forth their praise.

**[44:16]** Enoch pleased the Lord, and was translated, being an example of repentance to all generations.

**[44:17]** Noah was found perfect and righteous; in the time of wrath he was taken in exchange for the world; therefore was he left as a remnant unto the earth, when the flood came.

**[44:18]** An everlasting covenant was made with him, that all flesh should perish no more by the flood.

**[44:19]** Abraham was a great father of many people: in glory was there none like unto him;

**[44:20]** Who kept the law of the most High, and was in covenant with him: he established the covenant in his flesh; and when he was proved, he was found faithful.

**[44:21]** Therefore he assured him by an oath, that he would bless the nations in his seed, and that he would multiply him as the dust of the earth, and exalt his seed as the stars, and cause them to inherit from sea to sea, and from the river unto the utmost part of the land.

**[44:22]** With Isaac did he establish likewise for Abraham his father’s sake the blessing of all men, and the covenant, And made it rest upon the head of Jacob. He acknowledged him in his blessing, and gave him an heritage, and divided his portions; among the twelve tribes did he part them.

**[45:1]** And he brought out of him a merciful man, which found favour in the sight of all flesh, even Moses, beloved of God and men, whose memorial is blessed.

**[45:2]** He made him like to the glorious saints, and magnified him, so that his enemies stood in fear of him.

**[45:3]** By his words he caused the wonders to cease, and he made him glorious in the sight of kings, and gave him a commandment for his people, and shewed him part of his glory.

**[45:4]** He sanctified him in his faithfuless and meekness, and chose him out of all men.

**[45:5]** He made him to hear his voice, and brought him into the dark cloud, and gave him commandments before his face, even the law of life and knowledge, that he might teach Jacob his covenants, and Israel his judgments.

**[45:6]** He exalted Aaron, an holy man like unto him, even his brother, of the tribe of Levi.

**[45:7]** An everlasting covenant he made with him and gave him the priesthood among the people; he beautified him with comely ornaments, and clothed him with a robe of glory.

**[45:8]** He put upon him perfect glory; and strengthened him with rich garments, with breeches, with a long robe, and the ephod.

**[45:9]** And he compassed him with pomegranates, and with many golden bells round about, that as he went there might be a sound, and a noise made that might be heard in the temple, for a memorial to the children of his people;

**[45:10]** With an holy garment, with gold, and blue silk, and purple, the work of the embroidere, with a breastplate of judgment, and with Urim and Thummim;

**[45:11]** With twisted scarlet, the work of the cunning workman, with precious stones graven like seals, and set in gold, the work of the jeweller, with a writing engraved for a memorial, after the number of the tribes of Israel.

**[45:12]** He set a crown of gold upon the mitre, wherein was engraved Holiness, an ornament of honour, a costly work, the desires of the eyes, goodly and beautiful.

**[45:13]** Before him there were none such, neither did ever any stranger put them on, but only his children and his children’s children perpetually.

**[45:14]** Their sacrifices shall be wholly consumed every day twice continually.

**[45:15]** Moses consecrated him, and anointed him with holy oil: this was appointed unto him by an everlasting covenant, and to his seed, so long as the heavens should remain, that they should minister unto him, and execute the office of the priesthood, and bless the people in his name.

**[45:16]** He chose him out of all men living to offer sacrifices to the Lord, incense, and a sweet savour, for a memorial, to make reconciliation for his people.

**[45:17]** He gave unto him his commandments, and authority in the statutes of judgments, that he should teach Jacob the testimonies, and inform Israel in his laws.

**[45:18]** Strangers conspired together against him, and maligned him in the wilderness, even the men that were of Dathan’s and Abiron’s side, and the congregation of Core, with fury and wrath.

**[45:19]** This the Lord saw, and it displeased him, and in his wrathful indignation were they consumed: he did wonders upon them, to consume them with the fiery flame.

**[45:20]** But he made Aaron more honourable, and gave him an heritage, and divided unto him the firstfruits of the increase; especially he prepared bread in abundance:

**[45:21]** For they eat of the sacrifices of the Lord, which he gave unto him and his seed.

**[45:22]** Howbeit in the land of the people he had no inheritance, neither had he any portion among the people: for the Lord himself is his portion and inheritance.

**[45:23]** The third in glory is Phinees the son of Eleazar, because he had zeal in the fear of the Lord, and stood up with good courage of heart: when the people were turned back, and made reconciliation for Israel.

**[45:24]** Therefore was there a covenant of peace made with him, that he should be the chief of the sanctuary and of his people, and that he and his posterity should have the dignity of the priesthood for ever:

**[45:25]** According to the covenant made with David son of Jesse, of the tribe of Juda, that the inheritance of the king should be to his posterity alone: so the inheritance of Aaron should also be unto his seed.

**[45:26]** God give you wisdom in your heart to judge his people in righteousness, that their good things be not abolished, and that their glory may endure for ever.

**[46:1]** Jesus the son a Nave was valiant in the wars, and was the successor of Moses in prophecies, who according to his name was made great for the saving of the elect of God, and taking vengeance of the enemies that rose up against them, that he might set Israel in their inheritance.

**[46:2]** How great glory gat he, when he did lift up his hands, and stretched out his sword against the cities!

**[46:3]** Who before him so stood to it? for the Lord himself brought his enemies unto him.

**[46:4]** Did not the sun go back by his means? and was not one day as long as two?

**[46:5]** He called upon the most high Lord, when the enemies pressed upon him on every side; and the great Lord heard him.

**[46:6]** And with hailstones of mighty power he made the battle to fall violently upon the nations, and in the descent of Beth-horon he destroyed them that resisted, that the nations might know all their strength, because he fought in the sight of the Lord, and he followed the Mighty One.

**[46:7]** In the time of Moses also he did a work of mercy, he and Caleb the son of Jephunne, in that they withstood the congregation, and withheld the people from sin, and appeased the wicked murmuring.

**[46:8]** And of six hundred thousand people on foot, they two were preserved to bring them in to the heritage, even unto the land that floweth with milk and honey.

**[46:9]** The Lord gave strength also unto Caleb, which remained with him unto his old age: so that he entered upon the high places of the land, and his seed obtained it for an heritage:

**[46:10]** That all the children of Israel might see that it is good to follow the Lord.

**[46:11]** And concerning the judges, every one by name, whose heart went not a whoring, nor departed from the Lord, let their memory be blessed.

**[46:12]** Let their bones flourish out of their place, and let the name of them that were honoured be continued upon their children.

**[46:13]** Samuel, the prophet of the Lord, beloved of his Lord, established a kingdom, and anointed princes over his people.

**[46:14]** By the law of the Lord he judged the congregation, and the Lord had respect unto Jacob.

**[46:15]** By his faithfulness he was found a true prophet, and by his word he was known to be faithful in vision.

**[46:16]** He called upon the mighty Lord, when his enemies pressed upon him on every side, when he offered the sucking lamb.

**[46:17]** And the Lord thundered from heaven, and with a great noise made his voice to be heard.

**[46:18]** And he destroyed the rulers of the Tyrians, and all the princes cf the Philistines.

**[46:19]** And before his long sleep he made protestations in the sight of the Lord and his anointed, I have not taken any man’s goods, so much as a shoe: and no man did accuse him.

**[46:20]** And after his death he prophesied, and shewed the king his end, and lifted up his voice from the earth in prophecy, to blot out the wickedness of the people.

**[47:1]** And after him rose up Nathan to prophesy in the time of David.

**[47:2]** As is the fat taken away from the peace offering, so was David chosen out of the children of Israel.

**[47:3]** He played with lions as with kids, and with bears as with lambs.

**[47:4]** Slew he not a giant, when he was yet but young? and did he not take away reproach from the people, when he lifted up his hand with the stone in the sling, and beat down the boasting of Goliath?

**[47:5]** For he called upon the most high Lord; and he gave him strength in his right hand to slay that mighty warrior, and set up the horn of his people.

**[47:6]** So the people honoured him with ten thousands, and praised him in the blessings of the Lord, in that he gave him a crown of glory.

**[47:7]** For he destroyed the enemies on every side, and brought to nought the Philistines his adversaries, and brake their horn in sunder unto this day.

**[47:8]** In all his works he praised the Holy One most high with words of glory; with his whole heart he sung songs, and loved him that made him.

**[47:9]** He set singers also before the altar, that by their voices they might make sweet melody, and daily sing praises in their songs.

**[47:10]** He beautified their feasts, and set in order the solemn times until the end, that they might praise his holy name, and that the temple might sound from morning.

**[47:11]** The Lord took away his sins, and exalted his horn for ever: he gave him a covenant of kings, and a throne of glory in Israel.

**[47:12]** After him rose up a wise son, and for his sake he dwelt at large.

**[47:13]** Solomon reigned in a peaceable time, and was honoured; for God made all quiet round about him, that he might build an house in his name, and prepare his sanctuary for ever.

**[47:14]** How wise wast thou in thy youth and, as a flood, filled with understanding!

**[47:15]** Thy soul covered the whole earth, and thou filledst it with dark parables.

**[47:16]** Thy name went far unto the islands; and for thy peace thou wast beloved.

**[47:17]** The countries marvelled at thee for thy songs, and proverbs, and parables, and interpretations.

**[47:18]** By the name of the Lord God, which is called the Lord God of Israel, thou didst gather gold as tin and didst multiply silver as lead.

**[47:19]** Thou didst bow thy loins unto women, and by thy body thou wast brought into subjection.

**[47:20]** Thou didst stain thy honour, and pollute thy seed: so that thou broughtest wrath upon thy children, and wast grieved for thy folly.

**[47:21]** So the kingdom was divided, and out of Ephraim ruled a rebellious kingdom.

**[47:22]** But the Lord will never leave off his mercy, neither shall any of his works perish, neither will he abolish the posterity of his elect, and the seed of him that loveth him he will not take away: wherefore he gave a remnant unto Jacob, and out of him a root unto David.

**[47:23]** Thus rested Solomon with his fathers, and of his seed he left behind him Roboam, even the foolishness of the people, and one that had no understanding, who turned away the people through his counsel. There was also Jeroboam the son of Nebat, who caused Israel to sin, and shewed Ephraim the way of sin:

**[47:24]** And their sins were multiplied exceedingly, that they were driven out of the land.

**[47:25]** For they sought out all wickedness, till the vengeance came upon them.

**[48:1]** Then stood up Elias the prophet as fire, and his word burned like a lamp.

**[48:2]** He brought a sore famine upon them, and by his zeal he diminished their number.

**[48:3]** By the word of the Lord he shut up the heaven, and also three times brought down fire.

**[48:4]** O Elias, how wast thou honoured in thy wondrous deeds! and who may glory like unto thee!

**[48:5]** Who didst raise up a dead man from death, and his soul from the place of the dead, by the word of the most High:

**[48:6]** Who broughtest kings to destruction, and honorable men from their bed:

**[48:7]** Who heardest the rebuke of the Lord in Sinai, and in Horeb the judgment of vengeance:

**[48:8]** Who annointedst kings to take revenge, and prophets to succeed after him:

**[48:9]** Who was taken up in a whirlwind of fire, and in a chariot of fiery horses:

**[48:10]** Who wast ordained for reproofs in their times, to pacify the wrath of the Lord’s judgment, before it brake forth into fury, and to turn the heart of the father unto the son, and to restore the tribes of Jacob.

**[48:11]** Blessed are they that saw thee, and slept in love; for we shall surely live.

**[48:12]** Elias it was, who was covered with a whirlwind: and Eliseus was filled with his spirit: whilst he lived, he was not moved with the presence of any prince, neither could any bring him into subjection.

**[48:13]** No word could overcome him; and after his death his body prophesied.

**[48:14]** He did wonders in his life, and at his death were his works marvellous.

**[48:15]** For all this the people repented not, neither departed they from their sins, till they were spoiled and carried out of their land, and were scattered through all the earth: yet there remained a small people, and a ruler in the house of David:

**[48:16]** Of whom some did that which was pleasing to God, and some multiplied sins.

**[48:17]** Ezekias fortified his city, and brought in water into the midst thereof: he digged the hard rock with iron, and made wells for waters.

**[48:18]** In his time Sennacherib came up, and sent Rabsaces, and lifted up his hand against Sion, and boasted proudly.

**[48:19]** Then trembled their hearts and hands, and they were in pain, as women in travail.

**[48:20]** But they called upon the Lord which is merciful, and stretched out their hands toward him: and immediately the Holy One heard them out of heaven, and delivered them by the ministry of Esay.

**[48:21]** He smote the host of the Assyrians, and his angel destroyed them.

**[48:22]** For Ezekias had done the thing that pleased the Lord, and was strong in the ways of David his father, as Esay the prophet, who was great and faithful in his vision, had commanded him.

**[48:23]** In his time the sun went backward, and he lengthened the king’s life.

**[48:24]** He saw by an excellent spirit what should come to pass at the last, and he comforted them that mourned in Sion.

**[48:25]** He shewed what should come to pass for ever, and secret things or ever they came.

**[49:1]** The remembrance of Josias is like the composition of the perfume that is made by the art of the apothecary: it is sweet as honey in all mouths, and as musick at a banquet of wine.

**[49:2]** He behaved himself uprightly in the conversion of the people, and took away the abominations of iniquity.

**[49:3]** He directed his heart unto the Lord, and in the time of the ungodly he established the worship of God.

**[49:4]** All, except David and Ezekias and Josias, were defective: for they forsook the law of the most High, even the kings of Juda failed.

**[49:5]** Therefore he gave their power unto others, and their glory to a strange nation.

**[49:6]** They burnt the chosen city of the sanctuary, and made the streets desolate, according to the prophecy of Jeremias.

**[49:7]** For they entreated him evil, who nevertheless was a prophet, sanctified in his mother’s womb, that he might root out, and afflict, and destroy; and that he might build up also, and plant.

**[49:8]** It was Ezekiel who saw the glorious vision, which was shewed him upon the chariot of the cherubims.

**[49:9]** For he made mention of the enemies under the figure of the rain, and directed them that went right.

**[49:10]** And of the twelve prophets let the memorial be blessed, and let their bones flourish again out of their place: for they comforted Jacob, and delivered them by assured hope.

**[49:11]** How shall we magnify Zorobabel? even he was as a signet on the right hand:

**[49:12]** So was Jesus the son of Josedec: who in their time builded the house, and set up an holy temple to the Lord, which was prepared for everlasting glory.

**[49:13]** And among the elect was Neemias, whose renown is great, who raised up for us the walls that were fallen, and set up the gates and the bars, and raised up our ruins again.

**[49:14]** But upon the earth was no man created like Enoch; for he was taken from the earth.

**[49:15]** Neither was there a young man born like Joseph, a governor of his brethren, a stay of the people, whose bones were regarded of the Lord.

**[49:16]** Sem and Seth were in great honour among men, and so was Adam above every living thing in creation.

**[50:1]** Simon the high priest, the son of Onias, who in his life repaired the house again, and in his days fortified the temple:

**[50:2]** And by him was built from the foundation the double height, the high fortress of the wall about the temple:

**[50:3]** In his days the cistern to receive water, being in compass as the sea, was covered with plates of brass:

**[50:4]** He took care of the temple that it should not fall, and fortified the city against besieging:

**[50:5]** How was he honoured in the midst of the people in his coming out of the sanctuary!

**[50:6]** He was as the morning star in the midst of a cloud, and as the moon at the full:

**[50:7]** As the sun shining upon the temple of the most High, and as the rainbow giving light in the bright clouds:

**[50:8]** And as the flower of roses in the spring of the year, as lilies by the rivers of waters, and as the branches of the frankincense tree in the time of summer:

**[50:9]** As fire and incense in the censer, and as a vessel of beaten gold set with all manner of precious stones:

**[50:10]** And as a fair olive tree budding forth fruit, and as a cypress tree which groweth up to the clouds.

**[50:11]** When he put on the robe of honour, and was clothed with the perfection of glory, when he went up to the holy altar, he made the garment of holiness honourable.

**[50:12]** When he took the portions out of the priests’ hands, he himself stood by the hearth of the altar, compassed about, as a young cedar in Libanus; and as palm trees compassed they him round about.

**[50:13]** So were all the sons of Aaron in their glory, and the oblations of the Lord in their hands, before all the congregation of Israel.

**[50:14]** And finishing the service at the altar, that he might adorn the offering of the most high Almighty,

**[50:15]** He stretched out his hand to the cup, and poured of the blood of the grape, he poured out at the foot of the altar a sweetsmelling savour unto the most high King of all.

**[50:16]** Then shouted the sons of Aaron, and sounded the silver trumpets, and made a great noise to be heard, for a remembrance before the most High.

**[50:17]** Then all the people together hasted, and fell down to the earth upon their faces to worship their Lord God Almighty, the most High.

**[50:18]** The singers also sang praises with their voices, with great variety of sounds was there made sweet melody.

**[50:19]** And the people besought the Lord, the most High, by prayer before him that is merciful, till the solemnity of the Lord was ended, and they had finished his service.

**[50:20]** Then he went down, and lifted up his hands over the whole congregation of the children of Israel, to give the blessing of the Lord with his lips, and to rejoice in his name.

**[50:21]** And they bowed themselves down to worship the second time, that they might receive a blessing from the most High.

**[50:22]** Now therefore bless ye the God of all, which only doeth wondrous things every where, which exalteth our days from the womb, and dealeth with us according to his mercy.

**[50:23]** He grant us joyfulness of heart, and that peace may be in our days in Israel for ever:

**[50:24]** That he would confirm his mercy with us, and deliver us at his time!

**[50:25]** There be two manner of nations which my heart abhorreth, and the third is no nation:

**[50:26]** They that sit upon the mountain of Samaria, and they that dwell among the Philistines, and that foolish people that dwell in Sichem.

**[50:27]** Jesus the son of Sirach of Jerusalem hath written in this book the instruction of understanding and knowledge, who out of his heart poured forth wisdom.

**[50:28]** Blessed is he that shall be exercised in these things; and he that layeth them up in his heart shall become wise.

**[50:29]** For if he do them, he shall be strong to all things: for the light of the Lord leadeth him, who giveth wisdom to the godly. Blessed be the name of the Lord for ever. Amen, Amen.

**[51:1]** I will thank thee, O Lord and King, and praise thee, O God my Saviour: I do give praise unto thy name:

**[51:2]** For thou art my defender and helper, and has preserved my body from destruction, and from the snare of the slanderous tongue, and from the lips that forge lies, and has been mine helper against mine adversaries:

**[51:3]** And hast delivered me, according to the multitude of they mercies and greatness of thy name, from the teeth of them that were ready to devour me, and out of the hands of such as sought after my life, and from the manifold afflictions which I had;

**[51:4]** From the choking of fire on every side, and from the midst of the fire which I kindled not;

**[51:5]** From the depth of the belly of hell, from an unclean tongue, and from lying words.

**[51:6]** By an accusation to the king from an unrighteous tongue my soul drew near even unto death, my life was near to the hell beneath.

**[51:7]** They compassed me on every side, and there was no man to help me: I looked for the succour of men, but there was none.

**[51:8]** Then thought I upon thy mercy, O Lord, and upon thy acts of old, how thou deliverest such as wait for thee, and savest them out of the hands of the enemies.

**[51:9]** Then lifted I up my supplications from the earth, and prayed for deliverance from death.

**[51:10]** I called upon the Lord, the Father of my Lord, that he would not leave me in the days of my trouble, and in the time of the proud, when there was no help.

**[51:11]** I will praise thy name continually, and will sing praises with thanksgiving; and so my prayer was heard:

**[51:12]** For thou savedst me from destruction, and deliveredst me from the evil time: therefore will I give thanks, and praise thee, and bless they name, O Lord.

**[51:13]** When I was yet young, or ever I went abroad, I desired wisdom openly in my prayer.

**[51:14]** I prayed for her before the temple, and will seek her out even to the end.

**[51:15]** Even from the flower till the grape was ripe hath my heart delighted in her: my foot went the right way, from my youth up sought I after her.

**[51:16]** I bowed down mine ear a little, and received her, and gat much learning.

**[51:17]** I profited therein, therefore will I ascribe glory unto him that giveth me wisdom.

**[51:18]** For I purposed to do after her, and earnestly I followed that which is good; so shall I not be confounded.

**[51:19]** My soul hath wrestled with her, and in my doings I was exact: I stretched forth my hands to the heaven above, and bewailed my ignorances of her.

**[51:20]** I directed my soul unto her, and I found her in pureness: I have had my heart joined with her from the beginning, therefore shall I not be foresaken.

**[51:21]** My heart was troubled in seeking her: therefore have I gotten a good possession.

**[51:22]** The Lord hath given me a tongue for my reward, and I will praise him therewith.

**[51:23]** Draw near unto me, ye unlearned, and dwell in the house of learning.

**[51:24]** Wherefore are ye slow, and what say ye to these things, seeing your souls are very thirsty?

**[51:25]** I opened my mouth, and said, Buy her for yourselves without money.

**[51:26]** Put your neck under the yoke, and let your soul receive instruction: she is hard at hand to find.

**[51:27]** Behold with your eyes, how that I have but little labour, and have gotten unto me much rest.

**[51:28]** Get learning with a great sum of money, and get much gold by her.

**[51:29]** Let your soul rejoice in his mercy, and be not ashamed of his praise.

**[51:30]** Work your work betimes, and in his time he will give you your reward.

