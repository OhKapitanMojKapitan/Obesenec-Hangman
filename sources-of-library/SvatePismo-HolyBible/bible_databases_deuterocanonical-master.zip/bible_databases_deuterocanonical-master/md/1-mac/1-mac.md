# 1 Maccabees



**[1:1]** And it happened, after that Alexander son of Philip, the Macedonian, who came out of the land of Chettiim, had smitten Darius king of the Persians and Medes, that he reigned in his stead, the first over Greece,

**[1:2]** And made many wars, and won many strong holds, and slew the kings of the earth,

**[1:3]** And went through to the ends of the earth, and took spoils of many nations, insomuch that the earth was quiet before him; whereupon he was exalted and his heart was lifted up.

**[1:4]** And he gathered a mighty strong host and ruled over countries, and nations, and kings, who became tributaries unto him.

**[1:5]** And after these things he fell sick, and perceived that he should die.

**[1:6]** Wherefore he called his servants, such as were honourable, and had been brought up with him from his youth, and parted his kingdom among them, while he was yet alive.

**[1:7]** So Alexander reigned twelves years, and then died.

**[1:8]** And his servants bare rule every one in his place.

**[1:9]** And after his death they all put crowns upon themselves; so did their sons after them many years: and evils were multiplied in the earth.

**[1:10]** And there came out of them a wicked root Antiochus surnamed Epiphanes, son of Antiochus the king, who had been an hostage at Rome, and he reigned in the hundred and thirty and seventh year of the kingdom of the Greeks.

**[1:11]** In those days went there out of Israel wicked men, who persuaded many, saying, Let us go and make a covenant with the heathen that are round about us: for since we departed from them we have had much sorrow.

**[1:12]** So this device pleased them well.

**[1:13]** Then certain of the people were so forward herein, that they went to the king, who gave them licence to do after the ordinances of the heathen:

**[1:14]** Whereupon they built a place of exercise at Jerusalem according to the customs of the heathen:

**[1:15]** And made themselves uncircumcised, and forsook the holy covenant, and joined themselves to the heathen, and were sold to do mischief.

**[1:16]** Now when the kingdom was established before Antiochus, he thought to reign over Egypt that he might have the dominion of two realms.

**[1:17]** Wherefore he entered into Egypt with a great multitude, with chariots, and elephants, and horsemen, and a great navy,

**[1:18]** And made war against Ptolemee king of Egypt: but Ptolemee was afraid of him, and fled; and many were wounded to death.

**[1:19]** Thus they got the strong cities in the land of Egypt and he took the spoils thereof.

**[1:20]** And after that Antiochus had smitten Egypt, he returned again in the hundred forty and third year, and went up against Israel and Jerusalem with a great multitude,

**[1:21]** And entered proudly into the sanctuary, and took away the golden altar, and the candlestick of light, and all the vessels thereof,

**[1:22]** And the table of the shewbread, and the pouring vessels, and the vials. and the censers of gold, and the veil, and the crown, and the golden ornaments that were before the temple, all which he pulled off.

**[1:23]** He took also the silver and the gold, and the precious vessels: also he took the hidden treasures which he found.

**[1:24]** And when he had taken all away, he went into his own land, having made a great massacre, and spoken very proudly.

**[1:25]** Therefore there was a great mourning in Israel, in every place where they were;

**[1:26]** So that the princes and elders mourned, the virgins and young men were made feeble, and the beauty of women was changed.

**[1:27]** Every bridegroom took up lamentation, and she that sat in the marriage chamber was in heaviness,

**[1:28]** The land also was moved for the inhabitants thereof, and all the house of Jacob was covered with confusion.

**[1:29]** And after two years fully expired the king sent his chief collector of tribute unto the cities of Juda, who came unto Jerusalem with a great multitude,

**[1:30]** And spake peaceable words unto them, but all was deceit: for when they had given him credence, he fell suddenly upon the city, and smote it very sore, and destroyed much people of Israel.

**[1:31]** And when he had taken the spoils of the city, he set it on fire, and pulled down the houses and walls thereof on every side.

**[1:32]** But the women and children took they captive, and possessed the cattle.

**[1:33]** Then builded they the city of David with a great and strong wall, and with mighty towers, and made it a strong hold for them.

**[1:34]** And they put therein a sinful nation, wicked men, and fortified themselves therein.

**[1:35]** They stored it also with armour and victuals, and when they had gathered together the spoils of Jerusalem, they laid them up there, and so they became a sore snare:

**[1:36]** For it was a place to lie in wait against the sanctuary, and an evil adversary to Israel.

**[1:37]** Thus they shed innocent blood on every side of the sanctuary, and defiled it:

**[1:38]** Insomuch that the inhabitants of Jerusalem fled because of them: whereupon the city was made an habitation of strangers, and became strange to those that were born in her; and her own children left her.

**[1:39]** Her sanctuary was laid waste like a wilderness, her feasts were turned into mourning, her sabbaths into reproach her honour into contempt.

**[1:40]** As had been her glory, so was her dishonour increased, and her excellency was turned into mourning.

**[1:41]** Moreover king Antiochus wrote to his whole kingdom, that all should be one people,

**[1:42]** And every one should leave his laws: so all the heathen agreed according to the commandment of the king.

**[1:43]** Yea, many also of the Israelites consented to his religion, and sacrificed unto idols, and profaned the sabbath.

**[1:44]** For the king had sent letters by messengers unto Jerusalem and the cities of Juda that they should follow the strange laws of the land,

**[1:45]** And forbid burnt offerings, and sacrifice, and drink offerings, in the temple; and that they should profane the sabbaths and festival days:

**[1:46]** And pollute the sanctuary and holy people:

**[1:47]** Set up altars, and groves, and chapels of idols, and sacrifice swine’s flesh, and unclean beasts:

**[1:48]** That they should also leave their children uncircumcised, and make their souls abominable with all manner of uncleanness and profanation:

**[1:49]** To the end they might forget the law, and change all the ordinances.

**[1:50]** And whosoever would not do according to the commandment of the king, he said, he should die.

**[1:51]** In the selfsame manner wrote he to his whole kingdom, and appointed overseers over all the people, commanding the cities of Juda to sacrifice, city by city.

**[1:52]** Then many of the people were gathered unto them, to wit every one that forsook the law; and so they committed evils in the land;

**[1:53]** And drove the Israelites into secret places, even wheresoever they could flee for succour.

**[1:54]** Now the fifteenth day of the month Casleu, in the hundred forty and fifth year, they set up the abomination of desolation upon the altar, and builded idol altars throughout the cities of Juda on every side;

**[1:55]** And burnt incense at the doors of their houses, and in the streets.

**[1:56]** And when they had rent in pieces the books of the law which they found, they burnt them with fire.

**[1:57]** And whosoever was found with any the book of the testament, or if any committed to the law, the king’s commandment was, that they should put him to death.

**[1:58]** Thus did they by their authority unto the Israelites every month, to as many as were found in the cities.

**[1:59]** Now the five and twentieth day of the month they did sacrifice upon the idol altar, which was upon the altar of God.

**[1:60]** At which time according to the commandment they put to death certain women, that had caused their children to be circumcised.

**[1:61]** And they hanged the infants about their necks, and rifled their houses, and slew them that had circumcised them.

**[1:62]** Howbeit many in Israel were fully resolved and confirmed in themselves not to eat any unclean thing.

**[1:63]** Wherefore the rather to die, that they might not be defiled with meats, and that they might not profane the holy covenant: so then they died.

**[1:64]** And there was very great wrath upon Israel.

**[2:1]** In those days arose Mattathias the son of John, the son of Simeon, a priest of the sons of Joarib, from Jerusalem, and dwelt in Modin.

**[2:2]** And he had five sons, Joannan, called Caddis:

**[2:3]** Simon; called Thassi:

**[2:4]** Judas, who was called Maccabeus:

**[2:5]** Eleazar, called Avaran: and Jonathan, whose surname was Apphus.

**[2:6]** And when he saw the blasphemies that were committed in Juda and Jerusalem,

**[2:7]** He said, Woe is me! wherefore was I born to see this misery of my people, and of the holy city, and to dwell there, when it was delivered into the hand of the enemy, and the sanctuary into the hand of strangers?

**[2:8]** Her temple is become as a man without glory.

**[2:9]** Her glorious vessels are carried away into captivity, her infants are slain in the streets, her young men with the sword of the enemy.

**[2:10]** What nation hath not had a part in her kingdom and gotten of her spoils?

**[2:11]** All her ornaments are taken away; of a free woman she is become a bondslave.

**[2:12]** And, behold, our sanctuary, even our beauty and our glory, is laid waste, and the Gentiles have profaned it.

**[2:13]** To what end therefore shall we live any longer?

**[2:14]** Then Mattathias and his sons rent their clothes, and put on sackcloth, and mourned very sore.

**[2:15]** In the mean while the king’s officers, such as compelled the people to revolt, came into the city Modin, to make them sacrifice.

**[2:16]** And when many of Israel came unto them, Mattathias also and his sons came together.

**[2:17]** Then answered the king’s officers, and said to Mattathias on this wise, Thou art a ruler, and an honourable and great man in this city, and strengthened with sons and brethren:

**[2:18]** Now therefore come thou first, and fulfil the king’s commandment, like as all the heathen have done, yea, and the men of Juda also, and such as remain at Jerusalem: so shalt thou and thy house be in the number of the king’s friends, and thou and thy children shall be honoured with silver and gold, and many rewards.

**[2:19]** Then Mattathias answered and spake with a loud voice, Though all the nations that are under the king’s dominion obey him, and fall away every one from the religion of their fathers, and give consent to his commandments:

**[2:20]** Yet will I and my sons and my brethren walk in the covenant of our fathers.

**[2:21]** God forbid that we should forsake the law and the ordinances.

**[2:22]** We will not hearken to the king’s words, to go from our religion, either on the right hand, or the left.

**[2:23]** Now when he had left speaking these words, there came one of the Jews in the sight of all to sacrifice on the altar which was at Modin, according to the king’s commandment.

**[2:24]** Which thing when Mattathias saw, he was inflamed with zeal, and his reins trembled, neither could he forbear to shew his anger according to judgment: wherefore he ran, and slew him upon the altar.

**[2:25]** Also the king’s commissioner, who compelled men to sacrifice, he killed at that time, and the altar he pulled down.

**[2:26]** Thus dealt he zealously for the law of God like as Phinees did unto Zambri the son of Salom.

**[2:27]** And Mattathias cried throughout the city with a loud voice, saying, Whosoever is zealous of the law, and maintaineth the covenant, let him follow me.

**[2:28]** So he and his sons fled into the mountains, and left all that ever they had in the city.

**[2:29]** Then many that sought after justice and judgment went down into the wilderness, to dwell there:

**[2:30]** Both they, and their children, and their wives; and their cattle; because afflictions increased sore upon them.

**[2:31]** Now when it was told the king’s servants, and the host that was at Jerusalem, in the city of David, that certain men, who had broken the king’s commandment, were gone down into the secret places in the wilderness,

**[2:32]** They pursued after them a great number, and having overtaken them, they camped against them, and made war against them on the sabbath day.

**[2:33]** And they said unto them, Let that which ye have done hitherto suffice; come forth, and do according to the commandment of the king, and ye shall live.

**[2:34]** But they said, We will not come forth, neither will we do the king’s commandment, to profane the sabbath day.

**[2:35]** So then they gave them the battle with all speed.

**[2:36]** Howbeit they answered them not, neither cast they a stone at them, nor stopped the places where they lay hid;

**[2:37]** But said, Let us die all in our innocency: heaven and earth will testify for us, that ye put us to death wrongfully.

**[2:38]** So they rose up against them in battle on the sabbath, and they slew them, with their wives and children and their cattle, to the number of a thousand people.

**[2:39]** Now when Mattathias and his friends understood hereof, they mourned for them right sore.

**[2:40]** And one of them said to another, If we all do as our brethren have done, and fight not for our lives and laws against the heathen, they will now quickly root us out of the earth.

**[2:41]** At that time therefore they decreed, saying, Whosoever shall come to make battle with us on the sabbath day, we will fight against him; neither will we die all, as our brethren that were murdered im the secret places.

**[2:42]** Then came there unto him a company of Assideans who were mighty men of Israel, even all such as were voluntarily devoted unto the law.

**[2:43]** Also all they that fled for persecution joined themselves unto them, and were a stay unto them.

**[2:44]** So they joined their forces, and smote sinful men in their anger, and wicked men in their wrath: but the rest fled to the heathen for succour.

**[2:45]** Then Mattathias and his friends went round about, and pulled down the altars:

**[2:46]** And what children soever they found within the coast of Israel uncircumcised, those they circumcised valiantly.

**[2:47]** They pursued also after the proud men, and the work prospered in their hand.

**[2:48]** So they recovered the law out of the hand of the Gentiles, and out of the hand of kings, neither suffered they the sinner to triumph.

**[2:49]** Now when the time drew near that Mattathias should die, he said unto his sons, Now hath pride and rebuke gotten strength, and the time of destruction, and the wrath of indignation:

**[2:50]** Now therefore, my sons, be ye zealous for the law, and give your lives for the covenant of your fathers.

**[2:51]** Call to remembrance what acts our fathers did in their time; so shall ye receive great honour and an everlasting name.

**[2:52]** Was not Abraham found faithful in temptation, and it was imputed unto him for righteousness?

**[2:53]** Joseph in the time of his distress kept the commandment and was made lord of Egypt.

**[2:54]** Phinees our father in being zealous and fervent obtained the covenant of an everlasting priesthood.

**[2:55]** Jesus for fulfilling the word was made a judge in Israel.

**[2:56]** Caleb for bearing witness before the congregation received the heritage of the land.

**[2:57]** David for being merciful possessed the throne of an everlasting kingdom.

**[2:58]** Elias for being zealous and fervent for the law was taken up into heaven.

**[2:59]** Ananias, Azarias, and Misael, by believing were saved out of the flame.

**[2:60]** Daniel for his innocency was delivered from the mouth of lions.

**[2:61]** And thus consider ye throughout all ages, that none that put their trust in him shall be overcome.

**[2:62]** Fear not then the words of a sinful man: for his glory shall be dung and worms.

**[2:63]** To day he shall be lifted up and to morrow he shall not be found, because he is returned into his dust, and his thought is come to nothing.

**[2:64]** Wherefore, ye my sons, be valiant and shew yourselves men in the behalf of the law; for by it shall ye obtain glory.

**[2:65]** And behold, I know that your brother Simon is a man of counsel, give ear unto him alway: he shall be a father unto you.

**[2:66]** As for Judas Maccabeus, he hath been mighty and strong, even from his youth up: let him be your captain, and fight the battle of the people.

**[2:67]** Take also unto you all those that observe the law, and avenge ye the wrong of your people.

**[2:68]** Recompense fully the heathen, and take heed to the commandments of the law.

**[2:69]** So he blessed them, and was gathered to his fathers.

**[2:70]** And he died in the hundred forty and sixth year, and his sons buried him in the sepulchres of his fathers at Modin, and all Israel made great lamentation for him.

**[3:1]** Then his son Judas, called Maccabeus, rose up in his stead.

**[3:2]** And all his brethren helped him, and so did all they that held with his father, and they fought with cheerfulness the battle of Israel.

**[3:3]** So he gat his people great honour, and put on a breastplate as a giant, and girt his warlike harness about him, and he made battles, protecting the host with his sword.

**[3:4]** In his acts he was like a lion, and like a lion’s whelp roaring for his prey.

**[3:5]** For He pursued the wicked, and sought them out, and burnt up those that vexed his people.

**[3:6]** Wherefore the wicked shrunk for fear of him, and all the workers of iniquity were troubled, because salvation prospered in his hand.

**[3:7]** He grieved also many kings, and made Jacob glad with his acts, and his memorial is blessed for ever.

**[3:8]** Moreover he went through the cities of Juda, destroying the ungodly out of them, and turning away wrath from Israel:

**[3:9]** So that he was renowned unto the utmost part of the earth, and he received unto him such as were ready to perish.

**[3:10]** Then Apollonius gathered the Gentiles together, and a great host out of Samaria, to fight against Israel.

**[3:11]** Which thing when Judas perceived, he went forth to meet him, and so he smote him, and slew him: many also fell down slain, but the rest fled.

**[3:12]** Wherefore Judas took their spoils, and Apollonius’ sword also, and therewith he fought all his life long.

**[3:13]** Now when Seron, a prince of the army of Syria, heard say that Judas had gathered unto him a multitude and company of the faithful to go out with him to war;

**[3:14]** He said, I will get me a name and honour in the kingdom; for I will go fight with Judas and them that are with him, who despise the king’s commandment.

**[3:15]** So he made him ready to go up, and there went with him a mighty host of the ungodly to help him, and to be avenged of the children of Israel.

**[3:16]** And when he came near to the going up of Bethhoron, Judas went forth to meet him with a small company:

**[3:17]** Who, when they saw the host coming to meet them, said unto Judas, How shall we be able, being so few, to fight against so great a multitude and so strong, seeing we are ready to faint with fasting all this day?

**[3:18]** Unto whom Judas answered, It is no hard matter for many to be shut up in the hands of a few; and with the God of heaven it is all one, to deliver with a great multitude, or a small company:

**[3:19]** For the victory of battle standeth not in the multitude of an host; but strength cometh from heaven.

**[3:20]** They come against us in much pride and iniquity to destroy us, and our wives and children, and to spoil us:

**[3:21]** But we fight for our lives and our laws.

**[3:22]** Wherefore the Lord himself will overthrow them before our face: and as for you, be ye not afraid of them.

**[3:23]** Now as soon as he had left off speaking, he leapt suddenly upon them, and so Seron and his host was overthrown before him.

**[3:24]** And they pursued them from the going down of Bethhoron unto the plain, where were slain about eight hundred men of them; and the residue fled into the land of the Philistines.

**[3:25]** Then began the fear of Judas and his brethren, and an exceeding great dread, to fall upon the nations round about them:

**[3:26]** Insomuch as his fame came unto the king, and all nations talked of the battles of Judas.

**[3:27]** Now when king Antiochus heard these things, he was full of indignation: wherefore he sent and gathered together all the forces of his realm, even a very strong army.

**[3:28]** He opened also his treasure, and gave his soldiers pay for a year, commanding them to be ready whensoever he should need them.

**[3:29]** Nevertheless, when he saw that the money of his treasures failed and that the tributes in the country were small, because of the dissension and plague, which he had brought upon the land in taking away the laws which had been of old time;

**[3:30]** He feared that he should not be able to bear the charges any longer, nor to have such gifts to give so liberally as he did before: for he had abounded above the kings that were before him.

**[3:31]** Wherefore, being greatly perplexed in his mind, he determined to go into Persia, there to take the tributes of the countries, and to gather much money.

**[3:32]** So he left Lysias, a nobleman, and one of the blood royal, to oversee the affairs of the king from the river Euphrates unto the borders of Egypt:

**[3:33]** And to bring up his son Antiochus, until he came again.

**[3:34]** Moreover he delivered unto him the half of his forces, and the elephants, and gave him charge of all things that he would have done, as also concerning them that dwelt in Juda and Jerusalem:

**[3:35]** To wit, that he should send an army against them, to destroy and root out the strength of Israel, and the remnant of Jerusalem, and to take away their memorial from that place;

**[3:36]** And that he should place strangers in all their quarters, and divide their land by lot.

**[3:37]** So the king took the half of the forces that remained, and departed from Antioch, his royal city, the hundred forty and seventh year; and having passed the river Euphrates, he went through the high countries.

**[3:38]** Then Lysias chose Ptolemee the son of Dorymenes, Nicanor, and Gorgias, mighty men of the king’s friends:

**[3:39]** And with them he sent forty thousand footmen, and seven thousand horsemen, to go into the land of Juda, and to destroy it, as the king commanded.

**[3:40]** So they went forth with all their power, and came and pitched by Emmaus in the plain country.

**[3:41]** And the merchants of the country, hearing the fame of them, took silver and gold very much, with servants, and came into the camp to buy the children of Israel for slaves: a power also of Syria and of the land of the Philistines joined themselves unto them.

**[3:42]** Now when Judas and his brethren saw that miseries were multiplied, and that the forces did encamp themselves in their borders: for they knew how the king had given commandment to destroy the people, and utterly abolish them;

**[3:43]** They said one to another, Let us restore the decayed fortune of our people, and let us fight for our people and the sanctuary.

**[3:44]** Then was the congregation gathered together, that they might be ready for battle, and that they might pray, and ask mercy and compassion.

**[3:45]** Now Jerusalem lay void as a wilderness, there was none of her children that went in or out: the sanctuary also was trodden down, and aliens kept the strong hold; the heathen had their habitation in that place; and joy was taken from Jacob, and the pipe with the harp ceased.

**[3:46]** Wherefore the Israelites assembled themselves together, and came to Maspha, over against Jerusalem; for in Maspha was the place where they prayed aforetime in Israel.

**[3:47]** Then they fasted that day, and put on sackcloth, and cast ashes upon their heads, and rent their clothes,

**[3:48]** And laid open the book of the law, wherein the heathen had sought to paint the likeness of their images.

**[3:49]** They brought also the priests’ garments, and the firstfruits, and the tithes: and the Nazarites they stirred up, who had accomplished their days.

**[3:50]** Then cried they with a loud voice toward heaven, saying, What shall we do with these, and whither shall we carry them away?

**[3:51]** For thy sanctuary is trodden down and profaned, and thy priests are in heaviness, and brought low.

**[3:52]** And lo, the heathen are assembled together against us to destroy us: what things they imagine against us, thou knowest.

**[3:53]** How shall we be able to stand against them, except thou, O God, be our help?

**[3:54]** Then sounded they with trumpets, and cried with a loud voice.

**[3:55]** And after this Judas ordained captains over the people, even captains over thousands, and over hundreds, and over fifties, and over tens.

**[3:56]** But as for such as were building houses, or had betrothed wives, or were planting vineyards, or were fearful, those he commanded that they should return, every man to his own house, according to the law.

**[3:57]** So the camp removed, and pitched upon the south side of Emmaus.

**[3:58]** And Judas said, arm yourselves, and be valiant men, and see that ye be in readiness against the morning, that ye may fight with these nations, that are assembled together against us to destroy us and our sanctuary:

**[3:59]** For it is better for us to die in battle, than to behold the calamities of our people and our sanctuary.

**[3:60]** Nevertheless, as the will of God is in heaven, so let him do.

**[4:1]** Then took Gorgias five thousand footmen, and a thousand of the best horsemen, and removed out of the camp by night;

**[4:2]** To the end he might rush in upon the camp of the Jews, and smite them suddenly. And the men of the fortress were his guides.

**[4:3]** Now when Judas heard thereof he himself removed, and the valiant men with him, that he might smite the king’s army which was at Emmaus,

**[4:4]** While as yet the forces were dispersed from the camp.

**[4:5]** In the mean season came Gorgias by night into the camp of Judas: and when he found no man there, he sought them in the mountains: for said he, These fellows flee from us

**[4:6]** But as soon as it was day, Judas shewed himself in the plain with three thousand men, who nevertheless had neither armour nor swords to their minds.

**[4:7]** And they saw the camp of the heathen, that it was strong and well harnessed, and compassed round about with horsemen; and these were expert of war.

**[4:8]** Then said Judas to the men that were with him, Fear ye not their multitude, neither be ye afraid of their assault.

**[4:9]** Remember how our fathers were delivered in the Red sea, when Pharaoh pursued them with an army.

**[4:10]** Now therefore let us cry unto heaven, if peradventure the Lord will have mercy upon us, and remember the covenant of our fathers, and destroy this host before our face this day:

**[4:11]** That so all the heathen may know that there is one who delivereth and saveth Israel.

**[4:12]** Then the strangers lifted up their eyes, and saw them coming over against them.

**[4:13]** Wherefore they went out of the camp to battle; but they that were with Judas sounded their trumpets.

**[4:14]** So they joined battle, and the heathen being discomfited fled into the plain.

**[4:15]** Howbeit all the hindmost of them were slain with the sword: for they pursued them unto Gazera, and unto the plains of Idumea, and Azotus, and Jamnia, so that there were slain of them upon a three thousand men.

**[4:16]** This done, Judas returned again with his host from pursuing them,

**[4:17]** And said to the people, Be not greedy of the spoil inasmuch as there is a battle before us,

**[4:18]** And Gorgias and his host are here by us in the mountain: but stand ye now against our enemies, and overcome them, and after this ye may boldly take the spoils.

**[4:19]** As Judas was yet speaking these words, there appeared a part of them looking out of the mountain:

**[4:20]** Who when they perceived that the Jews had put their host to flight and were burning the tents; for the smoke that was seen declared what was done:

**[4:21]** When therefore they perceived these things, they were sore afraid, and seeing also the host of Judas in the plain ready to fight,

**[4:22]** They fled every one into the land of strangers.

**[4:23]** Then Judas returned to spoil the tents, where they got much gold, and silver, and blue silk, and purple of the sea, and great riches.

**[4:24]** After this they went home, and sung a song of thanksgiving, and praised the Lord in heaven: because it is good, because his mercy endureth forever.

**[4:25]** Thus Israel had a great deliverance that day.

**[4:26]** Now all the strangers that had escaped came and told Lysias what had happened:

**[4:27]** Who, when he heard thereof, was confounded and discouraged, because neither such things as he would were done unto Israel, nor such things as the king commanded him were come to pass.

**[4:28]** The next year therefore following Lysias gathered together threescore thousand choice men of foot, and five thousand horsemen, that he might subdue them.

**[4:29]** So they came into Idumea, and pitched their tents at Bethsura, and Judas met them with ten thousand men.

**[4:30]** And when he saw that mighty army, he prayed and said, Blessed art thou, O Saviour of Israel, who didst quell the violence of the mighty man by the hand of thy servant David, and gavest the host of strangers into the hands of Jonathan the son of Saul, and his armourbearer;

**[4:31]** Shut up this army in the hand of thy people Israel, and let them be confounded in their power and horsemen:

**[4:32]** Make them to be of no courage, and cause the boldness of their strength to fall away, and let them quake at their destruction:

**[4:33]** Cast them down with the sword of them that love thee, and let all those that know thy name praise thee with thanksgiving.

**[4:34]** So they joined battle; and there were slain of the host of Lysias about five thousand men, even before them were they slain.

**[4:35]** Now when Lysias saw his army put to flight, and the manliness of Judas’ soldiers, and how they were ready either to live or die valiantly, he went into Antiochia, and gathered together a company of strangers, and having made his army greater than it was, he purposed to come again into Judea.

**[4:36]** Then said Judas and his brethren, Behold, our enemies are discomfited: let us go up to cleanse and dedicate the sanctuary.

**[4:37]** Upon this all the host assembled themselves together, and went up into mount Sion.

**[4:38]** And when they saw the sanctuary desolate, and the altar profaned, and the gates burned up, and shrubs growing in the courts as in a forest, or in one of the mountains, yea, and the priests’ chambers pulled down;

**[4:39]** They rent their clothes, and made great lamentation, and cast ashes upon their heads,

**[4:40]** And fell down flat to the ground upon their faces, and blew an alarm with the trumpets, and cried toward heaven.

**[4:41]** Then Judas appointed certain men to fight against those that were in the fortress, until he had cleansed the sanctuary.

**[4:42]** So he chose priests of blameless conversation, such as had pleasure in the law:

**[4:43]** Who cleansed the sanctuary, and bare out the defiled stones into an unclean place.

**[4:44]** And when as they consulted what to do with the altar of burnt offerings, which was profaned;

**[4:45]** They thought it best to pull it down, lest it should be a reproach to them, because the heathen had defiled it: wherefore they pulled it down,

**[4:46]** And laid up the stones in the mountain of the temple in a convenient place, until there should come a prophet to shew what should be done with them.

**[4:47]** Then they took whole stones according to the law, and built a new altar according to the former;

**[4:48]** And made up the sanctuary, and the things that were within the temple, and hallowed the courts.

**[4:49]** They made also new holy vessels, and into the temple they brought the candlestick, and the altar of burnt offerings, and of incense, and the table.

**[4:50]** And upon the altar they burned incense, and the lamps that were upon the candlestick they lighted, that they might give light in the temple.

**[4:51]** Furthermore they set the loaves upon the table, and spread out the veils, and finished all the works which they had begun to make.

**[4:52]** Now on the five and twentieth day of the ninth month, which is called the month Casleu, in the hundred forty and eighth year, they rose up betimes in the morning,

**[4:53]** And offered sacrifice according to the law upon the new altar of burnt offerings, which they had made.

**[4:54]** Look, at what time and what day the heathen had profaned it, even in that was it dedicated with songs, and citherns, and harps, and cymbals.

**[4:55]** Then all the people fell upon their faces, worshipping and praising the God of heaven, who had given them good success.

**[4:56]** And so they kept the dedication of the altar eight days and offered burnt offerings with gladness, and sacrificed the sacrifice of deliverance and praise.

**[4:57]** They decked also the forefront of the temple with crowns of gold, and with shields; and the gates and the chambers they renewed, and hanged doors upon them.

**[4:58]** Thus was there very great gladness among the people, for that the reproach of the heathen was put away.

**[4:59]** Moreover Judas and his brethren with the whole congregation of Israel ordained, that the days of the dedication of the altar should be kept in their season from year to year by the space of eight days, from the five and twentieth day of the month Casleu, with mirth and gladness.

**[4:60]** At that time also they builded up the mount Sion with high walls and strong towers round about, lest the Gentiles should come and tread it down as they had done before.

**[4:61]** And they set there a garrison to keep it, and fortified Bethsura to preserve it; that the people might have a defence against Idumea.

**[5:1]** Now when the nations round about heard that the altar was built and the sanctuary renewed as before, it displeased them very much.

**[5:2]** Wherefore they thought to destroy the generation of Jacob that was among them, and thereupon they began to slay and destroy the people.

**[5:3]** Then Judas fought against the children of Esau in Idumea at Arabattine, because they besieged Gael: and he gave them a great overthrow, and abated their courage, and took their spoils.

**[5:4]** Also he remembered the injury of the children of Bean, who had been a snare and an offence unto the people, in that they lay in wait for them in the ways.

**[5:5]** He shut them up therefore in the towers, and encamped against them, and destroyed them utterly, and burned the towers of that place with fire, and all that were therein.

**[5:6]** Afterward he passed over to the children of Ammon, where he found a mighty power, and much people, with Timotheus their captain.

**[5:7]** So he fought many battles with them, till at length they were discomfited before him; and he smote them.

**[5:8]** And when he had taken Jazar, with the towns belonging thereto, he returned into Judea.

**[5:9]** Then the heathen that were at Galaad assembled themselves together against the Israelites that were in their quarters, to destroy them; but they fled to the fortress of Dathema.

**[5:10]** And sent letters unto Judas and his brethren, The heathen that are round about us are assembled together against us to destroy us:

**[5:11]** And they are preparing to come and take the fortress whereunto we are fled, Timotheus being captain of their host.

**[5:12]** Come now therefore, and deliver us from their hands, for many of us are slain:

**[5:13]** Yea, all our brethren that were in the places of Tobie are put to death: their wives and their children also they have carried away captives, and borne away their stuff; and they have destroyed there about a thousand men.

**[5:14]** While these letters were yet reading, behold, there came other messengers from Galilee with their clothes rent, who reported on this wise,

**[5:15]** And said, They of Ptolemais, and of Tyrus, and Sidon, and all Galilee of the Gentiles, are assembled together against us to consume us.

**[5:16]** Now when Judas and the people heard these words, there assembled a great congregation together, to consult what they should do for their brethren, that were in trouble, and assaulted of them.

**[5:17]** Then said Judas unto Simon his brother, Choose thee out men, and go and deliver thy brethren that are in Galilee, for I and Jonathan my brother will go into the country of Galaad.

**[5:18]** So he left Joseph the son of Zacharias, and Azarias, captains of the people, with the remnant of the host in Judea to keep it.

**[5:19]** Unto whom he gave commandment, saying, Take ye the charge of this people, and see that ye make not war against the heathen until the time that we come again.

**[5:20]** Now unto Simon were given three thousand men to go into Galilee, and unto Judas eight thousand men for the country of Galaad.

**[5:21]** Then went Simon into Galilee, where he fought many battles with the heathen, so that the heathen were discomfited by him.

**[5:22]** And he pursued them unto the gate of Ptolemais; and there were slain of the heathen about three thousand men, whose spoils he took.

**[5:23]** And those that were in Galilee, and in Arbattis, with their wives and their children, and all that they had, took he away with him, and brought them into Judea with great joy.

**[5:24]** Judas Maccabeus also and his brother Jonathan went over Jordan, and travelled three days’ journey in the wilderness,

**[5:25]** Where they met with the Nabathites, who came unto them in a peaceable manner, and told them every thing that had happened to their brethren in the land of Galaad:

**[5:26]** And how that many of them were shut up in Bosora, and Bosor, and Alema, Casphor, Maked, and Carnaim; all these cities are strong and great:

**[5:27]** And that they were shut up in the rest of the cities of the country of Galaad, and that against to morrow they had appointed to bring their host against the forts, and to take them, and to destroy them all in one day.

**[5:28]** Hereupon Judas and his host turned suddenly by the way of the wilderness unto Bosora; and when he had won the city, he slew all the males with the edge of the sword, and took all their spoils, and burned the city with fire,

**[5:29]** From whence he removed by night, and went till he came to the fortress.

**[5:30]** And betimes in the morning they looked up, and, behold, there was an innumerable people bearing ladders and other engines of war, to take the fortress: for they assaulted them.

**[5:31]** When Judas therefore saw that the battle was begun, and that the cry of the city went up to heaven, with trumpets, and a great sound,

**[5:32]** He said unto his host, Fight this day for your brethren.

**[5:33]** So he went forth behind them in three companies, who sounded their trumpets, and cried with prayer.

**[5:34]** Then the host of Timotheus, knowing that it was Maccabeus, fled from him: wherefore he smote them with a great slaughter; so that there were killed of them that day about eight thousand men.

**[5:35]** This done, Judas turned aside to Maspha; and after he had assaulted it he took and slew all the males therein, and received the spoils thereof and and burnt it with fire.

**[5:36]** From thence went he, and took Casphon, Maged, Bosor, and the other cities of the country of Galaad.

**[5:37]** After these things gathered Timotheus another host and encamped against Raphon beyond the brook.

**[5:38]** So Judas sent men to espy the host, who brought him word, saying, All the heathen that be round about us are assembled unto them, even a very great host.

**[5:39]** He hath also hired the Arabians to help them and they have pitched their tents beyond the brook, ready to come and fight against thee. Upon this Judas went to meet them.

**[5:40]** Then Timotheus said unto the captains of his host, When Judas and his host come near the brook, if he pass over first unto us, we shall not be able to withstand him; for he will mightily prevail against us:

**[5:41]** But if he be afraid, and camp beyond the river, we shall go over unto him, and prevail against him.

**[5:42]** Now when Judas came near the brook, he caused the scribes of the people to remain by the brook: unto whom he gave commandment, saying, Suffer no man to remain in the camp, but let all come to the battle.

**[5:43]** So he went first over unto them, and all the people after him: then all the heathen, being discomfited before him, cast away their weapons, and fled unto the temple that was at Carnaim.

**[5:44]** But they took the city, and burned the temple with all that were therein. Thus was Carnaim subdued, neither could they stand any longer before Judas.

**[5:45]** Then Judas gathered together all the Israelites that were in the country of Galaad, from the least unto the greatest, even their wives, and their children, and their stuff, a very great host, to the end they might come into the land of Judea.

**[5:46]** Now when they came unto Ephron, (this was a great city in the way as they should go, very well fortified) they could not turn from it, either on the right hand or the left, but must needs pass through the midst of it.

**[5:47]** Then they of the city shut them out, and stopped up the gates with stones.

**[5:48]** Whereupon Judas sent unto them in peaceable manner, saying, Let us pass through your land to go into our own country, and none shall do you any hurt; we will only pass through on foot: howbeit they would not open unto him.

**[5:49]** Wherefore Judas commanded a proclamation to be made throughout the host, that every man should pitch his tent in the place where he was.

**[5:50]** So the soldiers pitched, and assaulted the city all that day and all that night, till at the length the city was delivered into his hands:

**[5:51]** Who then slew all the males with the edge of the sword, and rased the city, and took the spoils thereof, and passed through the city over them that were slain.

**[5:52]** After this went they over Jordan into the great plain before Bethsan.

**[5:53]** And Judas gathered together those that came behind, and exhorted the people all the way through, till they came into the land of Judea.

**[5:54]** So they went up to mount Sion with joy and gladness, where they offered burnt offerings, because not one of them were slain until they had returned in peace.

**[5:55]** Now what time as Judas and Jonathan were in the land of Galaad, and Simon his brother in Galilee before Ptolemais,

**[5:56]** Joseph the son of Zacharias, and Azarias, captains of the garrisons, heard of the valiant acts and warlike deeds which they had done.

**[5:57]** Wherefore they said, Let us also get us a name, and go fight against the heathen that are round about us.

**[5:58]** So when they had given charge unto the garrison that was with them, they went toward Jamnia.

**[5:59]** Then came Gorgias and his men out of the city to fight against them.

**[5:60]** And so it was, that Joseph and Azaras were put to flight, and pursued unto the borders of Judea: and there were slain that day of the people of Israel about two thousand men.

**[5:61]** Thus was there a great overthrow among the children of Israel, because they were not obedient unto Judas and his brethren, but thought to do some valiant act.

**[5:62]** Moreover these men came not of the seed of those, by whose hand deliverance was given unto Israel.

**[5:63]** Howbeit the man Judas and his brethren were greatly renowned in the sight of all Israel, and of all the heathen, wheresoever their name was heard of;

**[5:64]** Insomuch as the the people assembled unto them with joyful acclamations.

**[5:65]** Afterward went Judas forth with his brethren, and fought against the children of Esau in the land toward the south, where he smote Hebron, and the towns thereof, and pulled down the fortress of it, and burned the towers thereof round about.

**[5:66]** From thence he removed to go into the land of the Philistines, and passed through Samaria.

**[5:67]** At that time certain priests, desirous to shew their valour, were slain in battle, for that they went out to fight unadvisedly.

**[5:68]** So Judas turned to Azotus in the land of the Philistines, and when he had pulled down their altars, and burned their carved images with fire, and spoiled their cities, he returned into the land of Judea.

**[6:1]** About that time king Antiochus travelling through the high countries heard say, that Elymais in the country of Persia was a city greatly renowned for riches, silver, and gold;

**[6:2]** And that there was in it a very rich temple, wherein were coverings of gold, and breastplates, and shields, which Alexander, son of Philip, the Macedonian king, who reigned first among the Grecians, had left there.

**[6:3]** Wherefore he came and sought to take the city, and to spoil it; but he was not able, because they of the city, having had warning thereof,

**[6:4]** Rose up against him in battle: so he fled, and departed thence with great heaviness, and returned to Babylon.

**[6:5]** Moreover there came one who brought him tidings into Persia, that the armies, which went against the land of Judea, were put to flight:

**[6:6]** And that Lysias, who went forth first with a great power was driven away of the Jews; and that they were made strong by the armour, and power, and store of spoils, which they had gotten of the armies, whom they had destroyed:

**[6:7]** Also that they had pulled down the abomination, which he had set up upon the altar in Jerusalem, and that they had compassed about the sanctuary with high walls, as before, and his city Bethsura.

**[6:8]** Now when the king heard these words, he was astonished and sore moved: whereupon he laid him down upon his bed, and fell sick for grief, because it had not befallen him as he looked for.

**[6:9]** And there he continued many days: for his grief was ever more and more, and he made account that he should die.

**[6:10]** Wherefore he called for all his friends, and said unto them, The sleep is gone from mine eyes, and my heart faileth for very care.

**[6:11]** And I thought with myself, Into what tribulation am I come, and how great a flood of misery is it, wherein now I am! for I was bountiful and beloved in my power.

**[6:12]** But now I remember the evils that I did at Jerusalem, and that I took all the vessels of gold and silver that were therein, and sent to destroy the inhabitants of Judea without a cause.

**[6:13]** I perceive therefore that for this cause these troubles are come upon me, and, behold, I perish through great grief in a strange land.

**[6:14]** Then called he for Philip, one of his friends, who he made ruler over all his realm,

**[6:15]** And gave him the crown, and his robe, and his signet, to the end he should bring up his son Antiochus, and nourish him up for the kingdom.

**[6:16]** So king Antiochus died there in the hundred forty and ninth year.

**[6:17]** Now when Lysias knew that the king was dead, he set up Antiochus his son, whom he had brought up being young, to reign in his stead, and his name he called Eupator.

**[6:18]** About this time they that were in the tower shut up the Israelites round about the sanctuary, and sought always their hurt, and the strengthening of the heathen.

**[6:19]** Wherefore Judas, purposing to destroy them, called all the people together to besiege them.

**[6:20]** So they came together, and besieged them in the hundred and fiftieth year, and he made mounts for shot against them, and other engines.

**[6:21]** Howbeit certain of them that were besieged got forth, unto whom some ungodly men of Israel joined themselves:

**[6:22]** And they went unto the king, and said, How long will it be ere thou execute judgment, and avenge our brethren?

**[6:23]** We have been willing to serve thy father, and to do as he would have us, and to obey his commandments;

**[6:24]** For which cause they of our nation besiege the tower, and are alienated from us: moreover as many of us as they could light on they slew, and spoiled our inheritance.

**[6:25]** Neither have they stretched out their hand against us only, but also against their borders.

**[6:26]** And, behold, this day are they besieging the tower at Jerusalem, to take it: the sanctuary also and Bethsura have they fortified.

**[6:27]** Wherefore if thou dost not prevent them quickly, they will do the greater things than these, neither shalt thou be able to rule them.

**[6:28]** Now when the king heard this, he was angry, and gathered together all his friends, and the captains of his army, and those that had charge of the horse.

**[6:29]** There came also unto him from other kingdoms, and from isles of the sea, bands of hired soldiers.

**[6:30]** So that the number of his army was an hundred thousand footmen, and twenty thousand horsemen, and two and thirty elephants exercised in battle.

**[6:31]** These went through Idumea, and pitched against Bethsura, which they assaulted many days, making engines of war; but they of Bethsura came out, and burned them with fire, and fought valiantly.

**[6:32]** Upon this Judas removed from the tower, and pitched in Bathzacharias, over against the king’s camp.

**[6:33]** Then the king rising very early marched fiercely with his host toward Bathzacharias, where his armies made them ready to battle, and sounded the trumpets.

**[6:34]** And to the end they might provoke the elephants to fight, they shewed them the blood of grapes and mulberries.

**[6:35]** Moreover they divided the beasts among the armies, and for every elephant they appointed a thousand men, armed with coats of mail, and with helmets of brass on their heads; and beside this, for every beast were ordained five hundred horsemen of the best.

**[6:36]** These were ready at every occasion: wheresoever the beast was, and whithersoever the beast went, they went also, neither departed they from him.

**[6:37]** And upon the beasts were there strong towers of wood, which covered every one of them, and were girt fast unto them with devices: there were also upon every one two and thirty strong men, that fought upon them, beside the Indian that ruled him.

**[6:38]** As for the remnant of the horsemen, they set them on this side and that side at the two parts of the host giving them signs what to do, and being harnessed all over amidst the ranks.

**[6:39]** Now when the sun shone upon the shields of gold and brass, the mountains glistered therewith, and shined like lamps of fire.

**[6:40]** So part of the king’s army being spread upon the high mountains, and part on the valleys below, they marched on safely and in order.

**[6:41]** Wherefore all that heard the noise of their multitude, and the marching of the company, and the rattling of the harness, were moved: for the army was very great and mighty.

**[6:42]** Then Judas and his host drew near, and entered into battle, and there were slain of the king’s army six hundred men.

**[6:43]** Eleazar also, surnamed Savaran, perceiving that one of the beasts, armed with royal harness, was higher than all the rest, and supposing that the king was upon him,

**[6:44]** Put himself in jeopardy, to the end he might deliver his people, and get him a perpetual name:

**[6:45]** Wherefore he ran upon him courageously through the midst of the battle, slaying on the right hand and on the left, so that they were divided from him on both sides.

**[6:46]** Which done, he crept under the elephant, and thrust him under, and slew him: whereupon the elephant fell down upon him, and there he died.

**[6:47]** Howbeit the rest of the Jews seeing the strength of the king, and the violence of his forces, turned away from them.

**[6:48]** Then the king’s army went up to Jerusalem to meet them, and the king pitched his tents against Judea, and against mount Sion.

**[6:49]** But with them that were in Bethsura he made peace: for they came out of the city, because they had no victuals there to endure the siege, it being a year of rest to the land.

**[6:50]** So the king took Bethsura, and set a garrison there to keep it.

**[6:51]** As for the sanctuary, he besieged it many days: and set there artillery with engines and instruments to cast fire and stones, and pieces to cast darts and slings.

**[6:52]** Whereupon they also made engines against their engines, and held them battle a long season.

**[6:53]** Yet at the last, their vessels being without victuals, (for that it was the seventh year, and they in Judea that were delivered from the Gentiles, had eaten up the residue of the store;)

**[6:54]** There were but a few left in the sanctuary, because the famine did so prevail against them, that they were fain to disperse themselves, every man to his own place.

**[6:55]** At that time Lysias heard say, that Philip, whom Antiochus the king, whiles he lived, had appointed to bring up his son Antiochus, that he might be king,

**[6:56]** Was returned out of Persia and Media, and the king’s host also that went with him, and that he sought to take unto him the ruling of the affairs.

**[6:57]** Wherefore he went in all haste, and said to the king and the captains of the host and the company, We decay daily, and our victuals are but small, and the place we lay siege unto is strong, and the affairs of the kingdom lie upon us:

**[6:58]** Now therefore let us be friends with these men, and make peace with them, and with all their nation;

**[6:59]** And covenant with them, that they shall live after their laws, as they did before: for they are therefore displeased, and have done all these things, because we abolished their laws.

**[6:60]** So the king and the princes were content: wherefore he sent unto them to make peace; and they accepted thereof.

**[6:61]** Also the king and the princes made an oath unto them: whereupon they went out of the strong hold.

**[6:62]** Then the king entered into mount Sion; but when he saw the strength of the place, he broke his oath that he had made, and gave commandment to pull down the wall round about.

**[6:63]** Afterward departed he in all haste, and returned unto Antiochia, where he found Philip to be master of the city: so he fought against him, and took the city by force.

**[7:1]** In the hundred and one and fiftieth year Demetrius the son of Seleucus departed from Rome, and came up with a few men unto a city of the sea coast, and reigned there.

**[7:2]** And as he entered into the palace of his ancestors, so it was, that his forces had taken Antiochus and Lysias, to bring them unto him.

**[7:3]** Wherefore, when he knew it, he said, Let me not see their faces.

**[7:4]** So his host slew them. Now when Demetrius was set upon the throne of his kingdom,

**[7:5]** There came unto him all the wicked and ungodly men of Israel, having Alcimus, who was desirous to be high priest, for their captain:

**[7:6]** And they accused the people to the king, saying, Judas and his brethren have slain all thy friends, and driven us out of our own land.

**[7:7]** Now therefore send some man whom thou trustest, and let him go and see what havock he hath made among us, and in the king’s land, and let him punish them with all them that aid them.

**[7:8]** Then the king chose Bacchides, a friend of the king, who ruled beyond the flood, and was a great man in the kingdom, and faithful to the king,

**[7:9]** And him he sent with that wicked Alcimus, whom he made high priest, and commanded that he should take vengeance of the children of Israel.

**[7:10]** So they departed, and came with a great power into the land of Judea, where they sent messengers to Judas and his brethren with peaceable words deceitfully.

**[7:11]** But they gave no heed to their words; for they saw that they were come with a great power.

**[7:12]** Then did there assemble unto Alcimus and Bacchides a company of scribes, to require justice.

**[7:13]** Now the Assideans were the first among the children of Israel that sought peace of them:

**[7:14]** For said they, One that is a priest of the seed of Aaron is come with this army, and he will do us no wrong.

**[7:15]** So he spake unto them, peaceably, and sware unto them, saying, we will procure the harm neither of you nor your friends.

**[7:16]** Whereupon they believed him: howbeit he took of them threescore men, and slew them in one day, according to the words which he wrote,

**[7:17]** The flesh of thy saints have they cast out, and their blood have they shed round about Jerusalem, and there was none to bury them.

**[7:18]** Wherefore the fear and dread of them fell upon all the people, who said, There is neither truth nor righteousness in them; for they have broken the covenant and oath that they made.

**[7:19]** After this, removed Bacchides from Jerusalem, and pitched his tents in Bezeth, where he sent and took many of the men that had forsaken him, and certain of the people also, and when he had slain them, he cast them into the great pit.

**[7:20]** Then committed he the country to Alcimus, and left with him a power to aid him: so Bacchides went to the king.

**[7:21]** But Alcimus contended for the high priesthood.

**[7:22]** And unto him resorted all such as troubled the people, who, after they had gotten the land of Juda into their power, did much hurt in Israel.

**[7:23]** Now when Judas saw all the mischief that Alcimus and his company had done among the Israelites, even above the heathen,

**[7:24]** He went out into all the coasts of Judea round about, and took vengeance of them that had revolted from him, so that they durst no more go forth into the country.

**[7:25]** On the other side, when Alcimus saw that Judas and his company had gotten the upper hand, and knew that he was not able to abide their force, he went again to the king, and said all the worst of them that he could.

**[7:26]** Then the king sent Nicanor, one of his honourable princes, a man that bare deadly hate unto Israel, with commandment to destroy the people.

**[7:27]** So Nicanor came to Jerusalem with a great force; and sent unto Judas and his brethren deceitfully with friendly words, saying,

**[7:28]** Let there be no battle between me and you; I will come with a few men, that I may see you in peace.

**[7:29]** He came therefore to Judas, and they saluted one another peaceably. Howbeit the enemies were prepared to take away Judas by violence.

**[7:30]** Which thing after it was known to Judas, to wit, that he came unto him with deceit, he was sore afraid of him, and would see his face no more.

**[7:31]** Nicanor also, when he saw that his counsel was discovered, went out to fight against Judas beside Capharsalama:

**[7:32]** Where there were slain of Nicanor’s side about five thousand men, and the rest fled into the city of David.

**[7:33]** After this went Nicanor up to mount Sion, and there came out of the sanctuary certain of the priests and certain of the elders of the people, to salute him peaceably, and to shew him the burnt sacrifice that was offered for the king.

**[7:34]** But he mocked them, and laughed at them, and abused them shamefully, and spake proudly,

**[7:35]** And sware in his wrath, saying, Unless Judas and his host be now delivered into my hands, if ever I come again in safety, I will burn up this house: and with that he went out in a great rage.

**[7:36]** Then the priests entered in, and stood before the altar and the temple, weeping, and saying,

**[7:37]** Thou, O Lord, didst choose this house to be called by thy name, and to be a house of prayer and petition for thy people:

**[7:38]** Be avenged of this man and his host, and let them fall by the sword: remember their blasphemies, and suffer them not to continue any longer.

**[7:39]** So Nicanor went out of Jerusalem, and pitched his tents in Bethhoron, where an host out of Syria met him.

**[7:40]** But Judas pitched in Adasa with three thousand men, and there he prayed, saying,

**[7:41]** O Lord, when they that were sent from the king of the Assyrians blasphemed, thine angel went out, and smote an hundred fourscore and five thousand of them.

**[7:42]** Even so destroy thou this host before us this day, that the rest may know that he hath spoken blasphemously against thy sanctuary, and judge thou him according to his wickedness.

**[7:43]** So the thirteenth day of the month Adar the hosts joined battle: but Nicanor’s host was discomfited, and he himself was first slain in the battle.

**[7:44]** Now when Nicanor’s host saw that he was slain, they cast away their weapons, and fled.

**[7:45]** Then they pursued after them a day’s journey, from Adasa unto Gazera, sounding an alarm after them with their trumpets.

**[7:46]** Whereupon they came forth out of all the towns of Judea round about, and closed them in; so that they, turning back upon them that pursued them, were all slain with the sword, and not one of them was left.

**[7:47]** Afterwards they took the spoils, and the prey, and smote off Nicanors head, and his right hand, which he stretched out so proudly, and brought them away, and hanged them up toward Jerusalem.

**[7:48]** For this cause the people rejoiced greatly, and they kept that day a day of great gladness.

**[7:49]** Moreover they ordained to keep yearly this day, being the thirteenth of Adar.

**[7:50]** Thus the land of Juda was in rest a little while.

**[8:1]** Now Judas had heard of the the Romans, that they were mighty and valiant men, and such as would lovingly accept all that joined themselves unto them, and make a league of amity with all that came unto them;

**[8:2]** And that they were men of great valour. It was told him also of their wars and noble acts which they had done among the Galatians, and how they had conquered them, and brought them under tribute;

**[8:3]** And what they had done in the country of Spain, for the winning of the mines of the silver and gold which is there;

**[8:4]** And that by their policy and patience they had conquered all the place, though it were very far from them; and the kings also that came against them from the uttermost part of the earth, till they had discomfited them, and given them a great overthrow, so that the rest did give them tribute every year:

**[8:5]** Beside this, how they had discomfited in battle Philip, and Perseus, king of the Citims, with others that lifted up themselves against them, and had overcome them:

**[8:6]** How also Antiochus the great king of Asia, that came against them in battle, having an hundred and twenty elephants, with horsemen, and chariots, and a very great army, was discomfited by them;

**[8:7]** And how they took him alive, and covenanted that he and such as reigned after him should pay a great tribute, and give hostages, and that which was agreed upon,

**[8:8]** And the country of India, and Media and Lydia and of the goodliest countries, which they took of him, and gave to king Eumenes:

**[8:9]** Moreover how the Grecians had determined to come and destroy them;

**[8:10]** And that they, having knowledge thereof sent against them a certain captain, and fighting with them slew many of them, and carried away captives their wives and their children, and spoiled them, and took possession of their lands, and pulled down their strong holds, and brought them to be their servants unto this day:

**[8:11]** It was told him besides, how they destroyed and brought under their dominion all other kingdoms and isles that at any time resisted them;

**[8:12]** But with their friends and such as relied upon them they kept amity: and that they had conquered kingdoms both far and nigh, insomuch as all that heard of their name were afraid of them:

**[8:13]** Also that, whom they would help to a kingdom, those reign; and whom again they would, they displace: finally, that they were greatly exalted:

**[8:14]** Yet for all this none of them wore a crown or was clothed in purple, to be magnified thereby:

**[8:15]** Moreover how they had made for themselves a senate house, wherein three hundred and twenty men sat in council daily, consulting alway for the people, to the end they might be well ordered:

**[8:16]** And that they committed their government to one man every year, who ruled over all their country, and that all were obedient to that one, and that there was neither envy nor emmulation among them.

**[8:17]** In consideration of these things, Judas chose Eupolemus the son of John, the son of Accos, and Jason the son of Eleazar, and sent them to Rome, to make a league of amity and confederacy with them,

**[8:18]** And to intreat them that they would take the yoke from them; for they saw that the kingdom of the Grecians did oppress Israel with servitude.

**[8:19]** They went therefore to Rome, which was a very great journey, and came into the senate, where they spake and said.

**[8:20]** Judas Maccabeus with his brethren, and the people of the Jews, have sent us unto you, to make a confederacy and peace with you, and that we might be registered your confederates and friends.

**[8:21]** So that matter pleased the Romans well.

**[8:22]** And this is the copy of the epistle which the senate wrote back again in tables of brass, and sent to Jerusalem, that there they might have by them a memorial of peace and confederacy:

**[8:23]** Good success be to the Romans, and to the people of the Jews, by sea and by land for ever: the sword also and enemy be far from them,

**[8:24]** If there come first any war upon the Romans or any of their confederates throughout all their dominion,

**[8:25]** The people of the Jews shall help them, as the time shall be appointed, with all their heart:

**[8:26]** Neither shall they give any thing unto them that make war upon them, or aid them with victuals, weapons, money, or ships, as it hath seemed good unto the Romans; but they shall keep their covenants without taking any thing therefore.

**[8:27]** In the same manner also, if war come first upon the nation of the Jews, the Romans shall help them with all their heart, according as the time shall be appointed them:

**[8:28]** Neither shall victuals be given to them that take part against them, or weapons, or money, or ships, as it hath seemed good to the Romans; but they shall keep their covenants, and that without deceit.

**[8:29]** According to these articles did the Romans make a covenant with the people of the Jews.

**[8:30]** Howbeit if hereafter the one party or the other shall think to meet to add or diminish any thing, they may do it at their pleasures, and whatsoever they shall add or take away shall be ratified.

**[8:31]** And as touching the evils that Demetrius doeth to the Jews, we have written unto him, saying, Wherefore thou made thy yoke heavy upon our friends and confederates the Jews?

**[8:32]** If therefore they complain any more against thee, we will do them justice, and fight with thee by sea and by land.

**[9:1]** Furthermore, when Demetrius heard the Nicanor and his host were slain in battle, he sent Bacchides and Alcimus into the land of Judea the second time, and with them the chief strength of his host:

**[9:2]** Who went forth by the way that leadeth to Galgala, and pitched their tents before Masaloth, which is in Arbela, and after they had won it, they slew much people.

**[9:3]** Also the first month of the hundred fifty and second year they encamped before Jerusalem:

**[9:4]** From whence they removed, and went to Berea, with twenty thousand footmen and two thousand horsemen.

**[9:5]** Now Judas had pitched his tents at Eleasa, and three thousand chosen men with him:

**[9:6]** Who seeing the multitude of the other army to he so great were sore afraid; whereupon many conveyed themselves out of the host, insomuch as abode of them no more but eight hundred men.

**[9:7]** When Judas therefore saw that his host slipt away, and that the battle pressed upon him, he was sore troubled in mind, and much distressed, for that he had no time to gather them together.

**[9:8]** Nevertheless unto them that remained he said, Let us arise and go up against our enemies, if peradventure we may be able to fight with them.

**[9:9]** But they dehorted him, saying, We shall never be able: let us now rather save our lives, and hereafter we will return with our brethren, and fight against them: for we are but few.

**[9:10]** Then Judas said, God forbid that I should do this thing, and flee away from them: if our time be come, let us die manfully for our brethren, and let us not stain our honour.

**[9:11]** With that the host of Bacchides removed out of their tents, and stood over against them, their horsemen being divided into two troops, and their slingers and archers going before the host and they that marched in the foreward were all mighty men.

**[9:12]** As for Bacchides, he was in the right wing: so the host drew near on the two parts, and sounded their trumpets.

**[9:13]** They also of Judas’ side, even they sounded their trumpets also, so that the earth shook at the noise of the armies, and the battle continued from morning till night.

**[9:14]** Now when Judas perceived that Bacchides and the strength of his army were on the right side, he took with him all the hardy men,

**[9:15]** Who discomfited the right wing, and pursued them unto the mount Azotus.

**[9:16]** But when they of the left wing saw that they of the right wing were discomfited, they followed upon Judas and those that were with him hard at the heels from behind:

**[9:17]** Whereupon there was a sore battle, insomuch as many were slain on both parts.

**[9:18]** Judas also was killed, and the remnant fled.

**[9:19]** THen Jonathan and Simon took Judas their brother, and buried him in the sepulchre of his fathers in Modin.

**[9:20]** Moreover they bewailed him, and all Israel made great lamentation for him, and mourned many days, saying,

**[9:21]** How is the valiant man fallen, that delivered Israel!

**[9:22]** As for the other things concerning Judas and his wars, and the noble acts which he did, and his greatness, they are not written: for they were very many.

**[9:23]** Now after the death of Judas the wicked began to put forth their heads in all the coasts of Israel, and there arose up all such as wrought iniquity.

**[9:24]** In those days also was there a very great famine, by reason whereof the country revolted, and went with them.

**[9:25]** Then Bacchides chose the wicked men, and made them lords of the country.

**[9:26]** And they made enquiry and search for Judas’ friends, and brought them unto Bacchides, who took vengeance of them, and used them despitefully.

**[9:27]** So was there a great affliction in Israel, the like whereof was not since the time that a prophet was not seen among them.

**[9:28]** For this cause all Judas’ friends came together, and said unto Jonathan,

**[9:29]** Since thy brother Judas died, we have no man like him to go forth against our enemies, and Bacchides, and against them of our nation that are adversaries to us.

**[9:30]** Now therefore we have chosen thee this day to be our prince and captain in his stead, that thou mayest fight our battles.

**[9:31]** Upon this Jonathan took the governance upon him at that time, and rose up instead of his brother Judas.

**[9:32]** But when Bacchides gat knowledge thereof, he sought for to slay him

**[9:33]** Then Jonathan, and Simon his brother, and all that were with him, perceiving that, fled into the wilderness of Thecoe, and pitched their tents by the water of the pool Asphar.

**[9:34]** Which when Bacchides understood, he came near to Jordan with all his host upon the sabbath day.

**[9:35]** Now Jonathan had sent his brother John, a captain of the people, to pray his friends the Nabathites, that they might leave with them their carriage, which was much.

**[9:36]** But the children of Jambri came out of Medaba, and took John, and all that he had, and went their way with it.

**[9:37]** After this came word to Jonathan and Simon his brother, that the children of Jambri made a great marriage, and were bringing the bride from Nadabatha with a great train, as being the daughter of one of the great princes of Chanaan.

**[9:38]** Therefore they remembered John their brother, and went up, and hid themselves under the covert of the mountain:

**[9:39]** Where they lifted up their eyes, and looked, and, behold, there was much ado and great carriage: and the bridegroom came forth, and his friends and brethren, to meet them with drums, and instruments of musick, and many weapons.

**[9:40]** Then Jonathan and they that were with him rose up against them from the place where they lay in ambush, and made a slaughter of them in such sort, as many fell down dead, and the remnant fled into the mountain, and they took all their spoils.

**[9:41]** Thus was the marriage turned into mourning, and the noise of their melody into lamentation.

**[9:42]** So when they had avenged fully the blood of their brother, they turned again to the marsh of Jordan.

**[9:43]** Now when Bacchides heard hereof, he came on the sabbath day unto the banks of Jordan with a great power.

**[9:44]** Then Jonathan said to his company, Let us go up now and fight for our lives, for it standeth not with us to day, as in time past:

**[9:45]** For, behold, the battle is before us and behind us, and the water of Jordan on this side and that side, the marsh likewise and wood, neither is there place for us to turn aside.

**[9:46]** Wherefore cry ye now unto heaven, that ye may be delivered from the hand of your enemies.

**[9:47]** With that they joined battle, and Jonathan stretched forth his hand to smite Bacchides, but he turned back from him.

**[9:48]** Then Jonathan and they that were with him leapt into Jordan, and swam over unto the other bank: howbeit the other passed not over Jordan unto them.

**[9:49]** So there were slain of Bacchides’ side that day about a thousand men.

**[9:50]** Afterward returned Bacchides to Jerusalem and repaired the strong cites in Judea; the fort in Jericho, and Emmaus, and Bethhoron, and Bethel, and Thamnatha, Pharathoni, and Taphon, these did he strengthen with high walls, with gates and with bars.

**[9:51]** And in them he set a garrison, that they might work malice upon Israel.

**[9:52]** He fortified also the city Bethsura, and Gazera, and the tower, and put forces in them, and provision of victuals.

**[9:53]** Besides, he took the chief men’s sons in the country for hostages, and put them into the tower at Jerusalem to be kept.

**[9:54]** Moreover in the hundred fifty and third year, in the second month, Alcimus commanded that the wall of the inner court of the sanctuary should be pulled down; he pulled down also the works of the prophets

**[9:55]** And as he began to pull down, even at that time was Alcimus plagued, and his enterprizes hindered: for his mouth was stopped, and he was taken with a palsy, so that he could no more speak any thing, nor give order concerning his house.

**[9:56]** So Alcimus died at that time with great torment.

**[9:57]** Now when Bacchides saw that Alcimus was dead, he returned to the king: whereupon the land of Judea was in rest two years.

**[9:58]** Then all the ungodly men held a council, saying, Behold, Jonathan and his company are at ease, and dwell without care: now therefore we will bring Bacchides hither, who shall take them all in one night.

**[9:59]** So they went and consulted with him.

**[9:60]** Then removed he, and came with a great host, and sent letters privily to his adherents in Judea, that they should take Jonathan and those that were with him: howbeit they could not, because their counsel was known unto them.

**[9:61]** Wherefore they took of the men of the country, that were authors of that mischief, about fifty persons, and slew them.

**[9:62]** Afterward Jonathan, and Simon, and they that were with him, got them away to Bethbasi, which is in the wilderness, and they repaired the decays thereof, and made it strong.

**[9:63]** Which thing when Bacchides knew, he gathered together all his host, and sent word to them that were of Judea.

**[9:64]** Then went he and laid siege against Bethbasi; and they fought against it a long season and made engines of war.

**[9:65]** But Jonathan left his brother Simon in the city, and went forth himself into the country, and with a certain number went he forth.

**[9:66]** And he smote Odonarkes and his brethren, and the children of Phasiron in their tent.

**[9:67]** And when he began to smite them, and came up with his forces, Simon and his company went out of the city, and burned up the engines of war,

**[9:68]** And fought against Bacchides, who was discomfited by them, and they afflicted him sore: for his counsel and travail was in vain.

**[9:69]** Wherefore he was very wroth at the wicked men that gave him counsel to come into the country, inasmuch as he slew many of them, and purposed to return into his own country.

**[9:70]** Whereof when Jonathan had knowledge, he sent ambassadors unto him, to the end he should make peace with him, and deliver them the prisoners.

**[9:71]** Which thing he accepted, and did according to his demands, and sware unto him that he would never do him harm all the days of his life.

**[9:72]** When therefore he had restored unto him the prisoners that he had taken aforetime out of the land of Judea, he returned and went his way into his own land, neither came he any more into their borders.

**[9:73]** Thus the sword ceased from Israel: but Jonathan dwelt at Machmas, and began to govern the people; and he destroyed the ungodly men out of Israel.

**[10:1]** In the hundred and sixtieth year Alexander, the son of Antiochus surnamed Epiphanes, went up and took Ptolemais: for the people had received him, by means whereof he reigned there,

**[10:2]** Now when king Demetrius heard thereof, he gathered together an exceeding great host, and went forth against him to fight.

**[10:3]** Moreover Demetrius sent letters unto Jonathan with loving words, so as he magnified him.

**[10:4]** For said he, Let us first make peace with him, before he join with Alexander against us:

**[10:5]** Else he will remember all the evils that we have done against him, and against his brethren and his people.

**[10:6]** Wherefore he gave him authority to gather together an host, and to provide weapons, that he might aid him in battle: he commanded also that the hostages that were in the tower should be delivered him.

**[10:7]** Then came Jonathan to Jerusalem, and read the letters in the audience of all the people, and of them that were in the tower:

**[10:8]** Who were sore afraid, when they heard that the king had given him authority to gather together an host.

**[10:9]** Whereupon they of the tower delivered their hostages unto Jonathan, and he delivered them unto their parents.

**[10:10]** This done, Jonathan settled himself in Jerusalem, and began to build and repair the city.

**[10:11]** And he commanded the workmen to build the walls and the mount Sion and about with square stones for fortification; and they did so.

**[10:12]** Then the strangers, that were in the fortresses which Bacchides had built, fled away;

**[10:13]** Insomuch as every man left his place, and went into his own country.

**[10:14]** Only at Bethsura certain of those that had forsaken the law and the commandments remained still: for it was their place of refuge.

**[10:15]** Now when king Alexander had heard what promises Demetrius had sent unto Jonathan: when also it was told him of the battles and noble acts which he and his brethren had done, and of the pains that they had endured,

**[10:16]** He said, Shall we find such another man? now therefore we will make him our friend and confederate.

**[10:17]** Upon this he wrote a letter, and sent it unto him, according to these words, saying,

**[10:18]** King Alexander to his brother Jonathan sendeth greeting:

**[10:19]** We have heard of thee, that thou art a man of great power, and meet to be our friend.

**[10:20]** Wherefore now this day we ordain thee to be the high priest of thy nation, and to be called the king’s friend; (and therewithal he sent him a purple robe and a crown of gold:) and require thee to take our part, and keep friendship with us.

**[10:21]** So in the seventh month of the hundred and sixtieth year, at the feast of the tabernacles, Jonathan put on the holy robe, and gathered together forces, and provided much armour.

**[10:22]** Whereof when Demetrius heard, he was very sorry, and said,

**[10:23]** What have we done, that Alexander hath prevented us in making amity with the Jews to strengthen himself?

**[10:24]** I also will write unto them words of encouragement, and promise them dignities and gifts, that I may have their aid.

**[10:25]** He sent unto them therefore to this effect: King Demetrius unto the people of the Jews sendeth greeting:

**[10:26]** Whereas ye have kept covenants with us, and continued in our friendship, not joining yourselves with our enemies, we have heard hereof, and are glad.

**[10:27]** Wherefore now continue ye still to be faithful unto us, and we will well recompense you for the things ye do in our behalf,

**[10:28]** And will grant you many immunities, and give you rewards.

**[10:29]** And now do I free you, and for your sake I release all the Jews, from tributes, and from the customs of salt, and from crown taxes,

**[10:30]** And from that which appertaineth unto me to receive for the third part or the seed, and the half of the fruit of the trees, I release it from this day forth, so that they shall not be taken of the land of Judea, nor of the three governments which are added thereunto out of the country of Samaria and Galilee, from this day forth for evermore.

**[10:31]** Let Jerusalem also be holy and free, with the borders thereof, both from tenths and tributes.

**[10:32]** And as for the tower which is at Jerusalem, I yield up authority over it, and give the high priest, that he may set in it such men as he shall choose to keep it.

**[10:33]** Moreover I freely set at liberty every one of the Jews, that were carried captives out of the land of Judea into any part of my kingdom, and I will that all my officers remit the tributes even of their cattle.

**[10:34]** Furthermore I will that all the feasts, and sabbaths, and new moons, and solemn days, and the three days before the feast, and the three days after the feast shall be all of immunity and freedom for all the Jews in my realm.

**[10:35]** Also no man shall have authority to meddle with or to molest any of them in any matter.

**[10:36]** I will further, that there be enrolled among the king’s forces about thirty thousand men of the Jews, unto whom pay shall be given, as belongeth to all king’s forces.

**[10:37]** And of them some shall be placed in the king’s strong holds, of whom also some shall be set over the affairs of the kingdom, which are of trust: and I will that their overseers and governors be of themselves, and that they live after their own laws, even as the king hath commanded in the land of Judea.

**[10:38]** And concerning the three governments that are added to Judea from the country of Samaria, let them be joined with Judea, that they may be reckoned to be under one, nor bound to obey other authority than the high priest’s.

**[10:39]** As for Ptolemais, and the land pertaining thereto, I give it as a free gift to the sanctuary at Jerusalem for the necessary expences of the sanctuary.

**[10:40]** Moreover I give every year fifteen thousand shekels of silver out of the king’s accounts from the places appertaining.

**[10:41]** And all the overplus, which the officers payed not in as in former time, from henceforth shall be given toward the works of the temple.

**[10:42]** And beside this, the five thousand shekels of silver, which they took from the uses of the temple out of the accounts year by year, even those things shall be released, because they appertain to the priests that minister.

**[10:43]** And whosoever they be that flee unto the temple at Jerusalem, or be within the liberties hereof, being indebted unto the king, or for any other matter, let them be at liberty, and all that they have in my realm.

**[10:44]** For the building also and repairing of the works of the sanctuary expences shall be given of the king’s accounts.

**[10:45]** Yea, and for the building of the walls of Jerusalem, and the fortifying thereof round about, expences shall be given out of the king’s accounts, as also for the building of the walls in Judea.

**[10:46]** Now when Jonathan and the people heard these words, they gave no credit unto them, nor received them, because they remembered the great evil that he had done in Israel; for he had afflicted them very sore.

**[10:47]** But with Alexander they were well pleased, because he was the first that entreated of true peace with them, and they were confederate with him always.

**[10:48]** Then gathered king Alexander great forces, and camped over against Demetrius.

**[10:49]** And after the two kings had joined battle, Demetrius’ host fled: but Alexander followed after him, and prevailed against them.

**[10:50]** And he continued the battle very sore until the sun went down: and that day was Demetrius slain.

**[10:51]** Afterward Alexander sent ambassadors to Ptolemee king of Egypt with a message to this effect:

**[10:52]** Forasmuch as I am come again to my realm, and am set in the throne of my progenitors, and have gotten the dominion, and overthrown Demetrius, and recovered our country;

**[10:53]** For after I had joined battle with him, both he and his host was discomfited by us, so that we sit in the throne of his kingdom:

**[10:54]** Now therefore let us make a league of amity together, and give me now thy daughter to wife: and I will be thy son in law, and will give both thee and her as according to thy dignity.

**[10:55]** Then Ptolemee the king gave answer, saying, Happy be the day wherein thou didst return into the land of thy fathers, and satest in the throne of their kingdom.

**[10:56]** And now will I do to thee, as thou hast written: meet me therefore at Ptolemais, that we may see one another; for I will marry my daughter to thee according to thy desire.

**[10:57]** So Ptolemee went out of Egypt with his daughter Cleopatra, and they came unto Ptolemais in the hundred threescore and second year:

**[10:58]** Where king Alexander meeting him, he gave unto him his daughter Cleopatra, and celebrated her marriage at Ptolemais with great glory, as the manner of kings is.

**[10:59]** Now king Alexander had written unto Jonathan, that he should come and meet him.

**[10:60]** Who thereupon went honourably to Ptolemais, where he met the two kings, and gave them and their friends silver and gold, and many presents, and found favour in their sight.

**[10:61]** At that time certain pestilent fellows of Israel, men of a wicked life, assembled themselves against him, to accuse him: but the king would not hear them.

**[10:62]** Yea more than that, the king commanded to take off his garments, and clothe him in purple: and they did so.

**[10:63]** And he made him sit by himself, and said into his princes, Go with him into the midst of the city, and make proclamation, that no man complain against him of any matter, and that no man trouble him for any manner of cause.

**[10:64]** Now when his accusers saw that he was honored according to the proclamation, and clothed in purple, they fled all away.

**[10:65]** So the king honoured him, and wrote him among his chief friends, and made him a duke, and partaker of his dominion.

**[10:66]** Afterward Jonathan returned to Jerusalem with peace and gladness.

**[10:67]** Furthermore in the; hundred threescore and fifth year came Demetrius son of Demetrius out of Crete into the land of his fathers:

**[10:68]** Whereof when king Alexander heard tell, he was right sorry, and returned into Antioch.

**[10:69]** Then Demetrius made Apollonius the governor of Celosyria his general, who gathered together a great host, and camped in Jamnia, and sent unto Jonathan the high priest, saying,

**[10:70]** Thou alone liftest up thyself against us, and I am laughed to scorn for thy sake, and reproached: and why dost thou vaunt thy power against us in the mountains?

**[10:71]** Now therefore, if thou trustest in thine own strength, come down to us into the plain field, and there let us try the matter together: for with me is the power of the cities.

**[10:72]** Ask and learn who I am, and the rest that take our part, and they shall tell thee that thy foot is not able to to flight in their own land.

**[10:73]** Wherefore now thou shalt not be able to abide the horsemen and so great a power in the plain, where is neither stone nor flint, nor place to flee unto.

**[10:74]** So when Jonathan heard these words of Apollonius, he was moved in his mind, and choosing ten thousand men he went out of Jerusalem, where Simon his brother met him for to help him.

**[10:75]** And he pitched his tents against Joppa: but; they of Joppa shut him out of the city, because Apollonius had a garrison there.

**[10:76]** Then Jonathan laid siege unto it: whereupon they of the city let him in for fear: and so Jonathan won Joppa.

**[10:77]** Whereof when Apollonius heard, he took three thousand horsemen, with a great host of footmen, and went to Azotus as one that journeyed, and therewithal drew him forth into the plain. because he had a great number of horsemen, in whom he put his trust.

**[10:78]** Then Jonathan followed after him to Azotus, where the armies joined battle.

**[10:79]** Now Apollonius had left a thousand horsemen in ambush.

**[10:80]** And Jonathan knew that there was an ambushment behind him; for they had compassed in his host, and cast darts at the people, from morning till evening.

**[10:81]** But the people stood still, as Jonathan had commanded them: and so the enemies’ horses were tired.

**[10:82]** Then brought Simon forth his host, and set them against the footmen, (for the horsemen were spent) who were discomfited by him, and fled.

**[10:83]** The horsemen also, being scattered in the field, fled to Azotus, and went into Bethdagon, their idol’s temple, for safety.

**[10:84]** But Jonathan set fire on Azotus, and the cities round about it, and took their spoils; and the temple of Dagon, with them that were fled into it, he burned with fire.

**[10:85]** Thus there were burned and slain with the sword well nigh eight thousand men.

**[10:86]** And from thence Jonathan removed his host, and camped against Ascalon, where the men of the city came forth, and met him with great pomp.

**[10:87]** After this returned Jonathan and his host unto Jerusalem, having any spoils.

**[10:88]** Now when king ALexander heard these things, he honoured Jonathan yet more.

**[10:89]** And sent him a buckle of gold, as the use is to be given to such as are of the king’s blood: he gave him also Accaron with the borders thereof in possession.

**[11:1]** And the king of Egypt gathered together a great host, like the sand that lieth upon the sea shore, and many ships, and went about through deceit to get Alexander’s kingdom, and join it to his own.

**[11:2]** Whereupon he took his journey into Spain in peaceable manner, so as they of the cities opened unto him, and met him: for king Alexander had commanded them so to do, because he was his brother in law.

**[11:3]** Now as Ptolemee entered into the cities, he set in every one of them a garrison of soldiers to keep it.

**[11:4]** And when he came near to Azotus, they shewed him the temple of Dagon that was burnt, and Azotus and the suburbs thereof that were destroyed, and the bodies that were cast abroad and them that he had burnt in the battle; for they had made heaps of them by the way where he should pass.

**[11:5]** Also they told the king whatsoever Jonathan had done, to the intent he might blame him: but the king held his peace.

**[11:6]** Then Jonathan met the king with great pomp at Joppa, where they saluted one another, and lodged.

**[11:7]** Afterward Jonathan, when he had gone with the king to the river called Eleutherus, returned again to Jerusalem.

**[11:8]** King Ptolemee therefore, having gotten the dominion of the cities by the sea unto Seleucia upon the sea coast, imagined wicked counsels against Alexander.

**[11:9]** Whereupon he sent ambasadors unto king Demetrius, saying, Come, let us make a league betwixt us, and I will give thee my daughter whom Alexander hath, and thou shalt reign in thy father’s kingdom:

**[11:10]** For I repent that I gave my daughter unto him, for he sought to slay me.

**[11:11]** Thus did he slander him, because he was desirous of his kingdom.

**[11:12]** Wherefore he took his daughter from him, and gave her to Demetrius, and forsook Alexander, so that their hatred was openly known.

**[11:13]** Then Ptolemee entered into Antioch, where he set two crowns upon his head, the crown of Asia, and of Egypt.

**[11:14]** In the mean season was king Alexander in Cilicia, because those that dwelt in those parts had revolted from him.

**[11:15]** But when Alexander heard of this, he came to war against him: whereupon king Ptolemee brought forth his host, and met him with a mighty power, and put him to flight.

**[11:16]** So Alexander fled into Arabia there to be defended; but king Ptolemee was exalted:

**[11:17]** For Zabdiel the Arabian took off Alexander’s head, and sent it unto Ptolemee.

**[11:18]** King Ptolemee also died the third day after, and they that were in the strong holds were slain one of another.

**[11:19]** By this means Demetrius reigned in the hundred threescore and seventh year.

**[11:20]** At the same time Jonathan gathered together them that were in Judea to take the tower that was in Jerusalem: and he made many engines of war against it.

**[11:21]** Then came ungodly persons, who hated their own people, went unto the king, and told him that Jonathan besieged the tower,

**[11:22]** Whereof when he heard, he was angry, and immediately removing, he came to Ptolemais, and wrote unto Jonathan, that he should not lay siege to the tower, but come and speak with him at Ptolemais in great haste.

**[11:23]** Nevertheless Jonathan, when he heard this, commanded to besiege it still: and he chose certain of the elders of Israel and the priests, and put himself in peril;

**[11:24]** And took silver and gold, and raiment, and divers presents besides, and went to Ptolemais unto the king, where he found favour in his sight.

**[11:25]** And though certain ungodly men of the people had made complaints against him,

**[11:26]** Yet the king entreated him as his predecessors had done before, and promoted him in the sight of all his friends,

**[11:27]** And confirmed him in the high priesthood, and in all the honours that he had before, and gave him preeminence among his chief friends.

**[11:28]** Then Jonathan desired the king, that he would make Judea free from tribute, as also the three governments, with the country of Samaria; and he promised him three hundred talents.

**[11:29]** So the king consented, and wrote letters unto Jonathan of all these things after this manner:

**[11:30]** King Demetrius unto his brother Jonathan, and unto the nation of the Jews, sendeth greeting:

**[11:31]** We send you here a copy of the letter which we did write unto our cousin Lasthenes concerning you, that ye might see it.

**[11:32]** King Demetrius unto his father Lasthenes sendeth greeting:

**[11:33]** We are determined to do good to the people of the Jews, who are our friends, and keep covenants with us, because of their good will toward us.

**[11:34]** Wherefore we have ratified unto them the borders of Judea, with the three governments of Apherema and Lydda and Ramathem, that are added unto Judea from the country of Samaria, and all things appertaining unto them, for all such as do sacrifice in Jerusalem, instead of the payments which the king received of them yearly aforetime out of the fruits of the earth and of trees.

**[11:35]** And as for other things that belong unto us, of the tithes and customs pertaining unto us, as also the saltpits, and the crown taxes, which are due unto us, we discharge them of them all for their relief.

**[11:36]** And nothing hereof shall be revoked from this time forth for ever.

**[11:37]** Now therefore see that thou make a copy of these things, and let it be delivered unto Jonathan, and set upon the holy mount in a conspicuous place.

**[11:38]** After this, when king Demetrius saw that the land was quiet before him, and that no resistance was made against him, he sent away all his forces, every one to his own place, except certain bands of strangers, whom he had gathered from the isles of the heathen: wherefore all the forces of his fathers hated him.

**[11:39]** Moreover there was one Tryphon, that had been of Alexander’s part afore, who, seeing that all the host murmured against Demetrius, went to Simalcue the Arabian that brought up Antiochus the young son of Alexander,

**[11:40]** And lay sore upon him to deliver him this young Antiochus, that he might reign in his father’s stead: he told him therefore all that Demetrius had done, and how his men of war were at enmity with him, and there he remained a long season.

**[11:41]** In the mean time Jonathan sent unto king Demetrius, that he would cast those of the tower out of Jerusalem, and those also in the fortresses: for they fought against Israel.

**[11:42]** So Demetrius sent unto Jonathan, saying, I will not only do this for thee and thy people, but I will greatly honour thee and thy nation, if opportunity serve.

**[11:43]** Now therefore thou shalt do well, if thou send me men to help me; for all my forces are gone from me.

**[11:44]** Upon this Jonathan sent him three thousand strong men unto Antioch: and when they came to the king, the king was very glad of their coming.

**[11:45]** Howbeit they that were of the city gathered themselves together into the midst of the city, to the number of an hundred and twenty thousand men, and would have slain the king.

**[11:46]** Wherefore the king fled into the court, but they of the city kept the passages of the city, and began to fight.

**[11:47]** Then the king called to the Jews for help, who came unto him all at once, and dispersing themselves through the city slew that day in the city to the number of an hundred thousand.

**[11:48]** Also they set fire on the city, and gat many spoils that day, and delivered the king.

**[11:49]** So when they of the city saw that the Jews had got the city as they would, their courage was abated: wherefore they made supplication to the king, and cried, saying,

**[11:50]** Grant us peace, and let the Jews cease from assaulting us and the city.

**[11:51]** With that they cast away their weapons, and made peace; and the Jews were honoured in the sight of the king, and in the sight of all that were in his realm; and they returned to Jerusalem, having great spoils.

**[11:52]** So king Demetrius sat on the throne of his kingdom, and the land was quiet before him.

**[11:53]** Nevertheless he dissembled in all that ever he spake, and estranged himself from Jonathan, neither rewarded he him according to the benefits which he had received of him, but troubled him very sore.

**[11:54]** After this returned Tryphon, and with him the young child Antiochus, who reigned, and was crowned.

**[11:55]** Then there gathered unto him all the men of war, whom Demetrius had put away, and they fought against Demetrius, who turned his back and fled.

**[11:56]** Moreover Tryphon took the elephants, and won Antioch.

**[11:57]** At that time young Antiochus wrote unto Jonathan, saying, I confirm thee in the high priesthood, and appoint thee ruler over the four governments, and to be one of the king’s friends.

**[11:58]** Upon this he sent him golden vessels to be served in, and gave him leave to drink in gold, and to be clothed in purple, and to wear a golden buckle.

**[11:59]** His brother Simon also he made captain from the place called The ladder of Tyrus unto the borders of Egypt.

**[11:60]** Then Jonathan went forth, and passed through the cities beyond the water, and all the forces of Syria gathered themselves unto him for to help him: and when he came to Ascalon, they of the city met him honourably.

**[11:61]** From whence he went to Gaza, but they of Gaza shut him out; wherefore he laid siege unto it, and burned the suburbs thereof with fire, and spoiled them.

**[11:62]** Afterward, when they of Gaza made supplication unto Jonathan, he made peace with them, and took the sons of their chief men for hostages, and sent them to Jerusalem, and passed through the country unto Damascus.

**[11:63]** Now when Jonathan heard that Demetrius’ princes were come to Cades, which is in Galilee, with a great power, purposing to remove him out of the country,

**[11:64]** He went to meet them, and left Simon his brother in the country.

**[11:65]** Then Simon encamped against Bethsura and fought against it a long season, and shut it up:

**[11:66]** But they desired to have peace with him, which he granted them, and then put them out from thence, and took the city, and set a garrison in it.

**[11:67]** As for Jonathan and his host, they pitched at the water of Gennesar, from whence betimes in the morning they gat them to the plain of Nasor.

**[11:68]** And, behold, the host of strangers met them in the plain, who, having laid men in ambush for him in the mountains, came themselves over against him.

**[11:69]** So when they that lay in ambush rose out of their places and joined battle, all that were of Jonathan’s side fled;

**[11:70]** Insomuch as there was not one of them left, except Mattathias the son of Absalom, and Judas the son of Calphi, the captains of the host.

**[11:71]** Then Jonathan rent his clothes, and cast earth upon his head, and prayed.

**[11:72]** Afterwards turning again to battle, he put them to flight, and so they ran away.

**[11:73]** Now when his own men that were fled saw this, they turned again unto him, and with him pursued them to Cades, even unto their own tents, and there they camped.

**[11:74]** So there were slain of the heathen that day about three thousand men: but Jonathan returned to Jerusalem.

**[12:1]** Now when Jonathan saw that time served him, he chose certain men, and sent them to Rome, for to confirm and renew the friendship that they had with them.

**[12:2]** He sent letters also to the Lacedemonians, and to other places, for the same purpose.

**[12:3]** So they went unto Rome, and entered into the senate, and said, Jonathan the high priest, and the people of the Jews, sent us unto you, to the end ye should renew the friendship, which ye had with them, and league, as in former time.

**[12:4]** Upon this the Romans gave them letters unto the governors of every place that they should bring them into the land of Judea peaceably.

**[12:5]** And this is the copy of the letters which Jonathan wrote to the Lacedemonians:

**[12:6]** Jonathan the high priest, and the elders of the nation, and the priests, and the other of the Jews, unto the Lacedemonians their brethren send greeting:

**[12:7]** There were letters sent in times past unto Onias the high priest from Darius, who reigned then among you, to signify that ye are our brethren, as the copy here underwritten doth specify.

**[12:8]** At which time Onias entreated the ambassador that was sent honourably, and received the letters, wherein declaration was made of the league and friendship.

**[12:9]** Therefore we also, albeit we need none of these things, that we have the holy books of scripture in our hands to comfort us,

**[12:10]** Have nevertheless attempted to send unto you for the renewing of brotherhood and friendship, lest we should become strangers unto you altogether: for there is a long time passed since ye sent unto us.

**[12:11]** We therefore at all times without ceasing, both in our feasts, and other convenient days, do remember you in the sacrifices which we offer, and in our prayers, as reason is, and as it becometh us to think upon our brethren:

**[12:12]** And we are right glad of your honour.

**[12:13]** As for ourselves, we have had great troubles and wars on every side, forsomuch as the kings that are round about us have fought against us.

**[12:14]** Howbeit we would not be troublesome unto you, nor to others of our confederates and friends, in these wars:

**[12:15]** For we have help from heaven that succoureth us, so as we are delivered from our enemies, and our enemies are brought under foot.

**[12:16]** For this cause we chose Numenius the son of Antiochus, and Antipater he son of Jason, and sent them unto the Romans, to renew the amity that we had with them, and the former league.

**[12:17]** We commanded them also to go unto you, and to salute and to deliver you our letters concerning the renewing of our brotherhood.

**[12:18]** Wherefore now ye shall do well to give us an answer thereto.

**[12:19]** And this is the copy of the letters which Oniares sent.

**[12:20]** Areus king of the Lacedemonians to Onias the high priest, greeting:

**[12:21]** It is found in writing, that the Lacedemonians and Jews are brethren, and that they are of the stock of Abraham:

**[12:22]** Now therefore, since this is come to our knowledge, ye shall do well to write unto us of your prosperity.

**[12:23]** We do write back again to you, that your cattle and goods are our’s, and our’s are your’s We do command therefore our ambassadors to make report unto you on this wise.

**[12:24]** Now when Jonathan heard that Demebius’ princes were come to fight against him with a greater host than afore,

**[12:25]** He removed from Jerusalem, and met them in the land of Amathis: for he gave them no respite to enter his country.

**[12:26]** He sent spies also unto their tents, who came again, and told him that they were appointed to come upon them in the night season.

**[12:27]** Wherefore so soon as the sun was down, Jonathan commanded his men to watch, and to be in arms, that all the night long they might be ready to fight: also he sent forth centinels round about the host.

**[12:28]** But when the adversaries heard that Jonathan and his men were ready for battle, they feared, and trembled in their hearts, and they kindled fires in their camp.

**[12:29]** Howbeit Jonathan and his company knew it not till the morning: for they saw the lights burning.

**[12:30]** Then Jonathan pursued after them, but overtook them not: for they were gone over the river Eleutherus.

**[12:31]** Wherefore Jonathan turned to the Arabians, who were called Zabadeans, and smote them, and took their spoils.

**[12:32]** And removing thence, he came to Damascus, and so passed through all the country,

**[12:33]** Simon also went forth, and passed through the country unto Ascalon, and the holds there adjoining, from whence he turned aside to Joppa, and won it.

**[12:34]** For he had heard that they would deliver the hold unto them that took Demetrius’ part; wherefore he set a garrison there to keep it.

**[12:35]** After this came Jonathan home again, and calling the elders of the people together, he consulted with them about building strong holds in Judea,

**[12:36]** And making the walls of Jerusalem higher, and raising a great mount between the tower and the city, for to separate it from the city, that so it might be alone, that men might neither sell nor buy in it.

**[12:37]** Upon this they came together to build up the city, forasmuch as part of the wall toward the brook on the east side was fallen down, and they repaired that which was called Caphenatha.

**[12:38]** Simon also set up Adida in Sephela, and made it strong with gates and bars.

**[12:39]** Now Tryphon went about to get the kingdom of Asia, and to kill Antiochus the king, that he might set the crown upon his own head.

**[12:40]** Howbeit he was afraid that Jonathan would not suffer him, and that he would fight against him; wherefore he sought a way how to take Jonathan, that he might kill him. So he removed, and came to Bethsan.

**[12:41]** Then Jonathan went out to meet him with forty thousand men chosen for the battle, and came to Bethsan.

**[12:42]** Now when Tryphon saw Jonathan came with so great a force, he durst not stretch his hand against him;

**[12:43]** But received him honourably, and commended him unto all his friends, and gave him gifts, and commanded his men of war to be as obedient unto him, as to himself.

**[12:44]** Unto Jonathan also he said, Why hast thou brought all this people to so great trouble, seeing there is no war betwixt us?

**[12:45]** Therefore send them now home again, and choose a few men to wait on thee, and come thou with me to Ptolemais, for I will give it thee, and the rest of the strong holds and forces, and all that have any charge: as for me, I will return and depart: for this is the cause of my coming.

**[12:46]** So Jonathan believing him did as he bade him, and sent away his host, who went into the land of Judea.

**[12:47]** And with himself he retained but three thousand men, of whom he sent two thousand into Galilee, and one thousand went with him.

**[12:48]** Now as soon as Jonathan entered into Ptolemais, they of Ptolemais shut the gates and took him, and all them that came with him they slew with the sword.

**[12:49]** Then sent Tryphon an host of footmen and horsemen into Galilee, and into the great plain, to destroy all Jonathan’s company.

**[12:50]** But when they knew that Jonathan and they that were with him were taken and slain, they encouraged one another; and went close together, prepared to fight.

**[12:51]** They therefore that followed upon them, perceiving that they were ready to fight for their lives, turned back again.

**[12:52]** Whereupon they all came into the land of Judea peaceably, and there they bewailed Jonathan, and them that were with him, and they were sore afraid; wherefore all Israel made great lamentation.

**[12:53]** Then all the heathen that were round about then sought to destroy them: for said they, They have no captain, nor any to help them: now therefore let us make war upon them, and take away their memorial from among men.

**[13:1]** Now when Simon heard that Tryphon had gathered together a great host to invade the land of Judea, and destroy it,

**[13:2]** And saw that the people was in great trembling and fear, he went up to Jerusalem, and gathered the people together,

**[13:3]** And gave them exhortation, saying, Ye yourselves know what great things I, and my brethren, and my father’s house, have done for the laws and the sanctuary, the battles also and troubles which we have seen.

**[13:4]** By reason whereof all my brethren are slain for Israel’s sake, and I am left alone.

**[13:5]** Now therefore be it far from me, that I should spare mine own life in any time of trouble: for I am no better than my brethren.

**[13:6]** Doubtless I will avenge my nation, and the sanctuary, and our wives, and our children: for all the heathen are gathered to destroy us of very malice.

**[13:7]** Now as soon as the people heard these words, their spirit revived.

**[13:8]** And they answered with a loud voice, saying, Thou shalt be our leader instead of Judas and Jonathan thy brother.

**[13:9]** Fight thou our battles, and whatsoever, thou commandest us, that will we do.

**[13:10]** So then he gathered together all the men of war, and made haste to finish the walls of Jerusalem, and he fortified it round about.

**[13:11]** Also he sent Jonathan the son of Absolom, and with him a great power, to Joppa: who casting out them that were therein remained there in it.

**[13:12]** So Tryphon removed from Ptolemaus with a great power to invade the land of Judea, and Jonathan was with him in ward.

**[13:13]** But Simon pitched his tents at Adida, over against the plain.

**[13:14]** Now when Tryphon knew that Simon was risen up instead of his brother Jonathan, and meant to join battle with him, he sent messengers unto him, saying,

**[13:15]** Whereas we have Jonathan thy brother in hold, it is for money that he is owing unto the king’s treasure, concerning the business that was committed unto him.

**[13:16]** Wherefore now send an hundred talents of silver, and two of his sons for hostages, that when he is at liberty he may not revolt from us, and we will let him go.

**[13:17]** Hereupon Simon, albeit he perceived that they spake deceitfully unto him yet sent he the money and the children, lest peradventure he should procure to himself great hatred of the people:

**[13:18]** Who might have said, Because I sent him not the money and the children, therefore is Jonathan dead.

**[13:19]** So he sent them the children and the hundred talents: howbeit Tryphon dissembled neither would he let Jonathan go.

**[13:20]** And after this came Tryphon to invade the land, and destroy it, going round about by the way that leadeth unto Adora: but Simon and his host marched against him in every place, wheresoever he went.

**[13:21]** Now they that were in the tower sent messengers unto Tryphon, to the end that he should hasten his coming unto them by the wilderness, and send them victuals.

**[13:22]** Wherefore Tryphon made ready all his horsemen to come that night: but there fell a very great snow, by reason whereof he came not. So he departed, and came into the country of Galaad.

**[13:23]** And when he came near to Bascama he slew Jonathan, who was buried there.

**[13:24]** Afterward Tryphon returned and went into his own land.

**[13:25]** Then sent Simon, and took the bones of Jonathan his brother, and buried them in Modin, the city of his fathers.

**[13:26]** And all Israel made great lamentation for him, and bewailed him many days.

**[13:27]** Simon also built a monument upon the sepulchre of his father and his brethren, and raised it aloft to the sight, with hewn stone behind and before.

**[13:28]** Moreover he set up seven pyramids, one against another, for his father, and his mother, and his four brethren.

**[13:29]** And in these he made cunning devices, about the which he set great pillars, and upon the pillars he made all their armour for a perpetual memory, and by the armour ships carved, that they might be seen of all that sail on the sea.

**[13:30]** This is the sepulchre which he made at Modin, and it standeth yet unto this day.

**[13:31]** Now Tryphon dealt deceitfully with the young king Antiochus, and slew him.

**[13:32]** And he reigned in his stead, and crowned himself king of Asia, and brought a great calamity upon the land.

**[13:33]** Then Simon built up the strong holds in Judea, and fenced them about with high towers, and great walls, and gates, and bars, and laid up victuals therein.

**[13:34]** Moreover Simon chose men, and sent to king Demetrius, to the end he should give the land an immunity, because all that Tryphon did was to spoil.

**[13:35]** Unto whom king Demetrius answered and wrote after this manner:

**[13:36]** King Demetrius unto Simon the high priest, and friend of kings, as also unto the elders and nation of the Jews, sendeth greeting:

**[13:37]** The golden crown, and the scarlet robe, which ye sent unto us, we have received: and we are ready to make a stedfast peace with you, yea, and to write unto our officers, to confirm the immunities which we have granted.

**[13:38]** And whatsoever covenants we have made with you shall stand; and the strong holds, which ye have builded, shall be your own.

**[13:39]** As for any oversight or fault committed unto this day, we forgive it, and the crown tax also, which ye owe us: and if there were any other tribute paid in Jerusalem, it shall no more be paid.

**[13:40]** And look who are meet among you to be in our court, let then be enrolled, and let there be peace betwixt us.

**[13:41]** Thus the yoke of the heathen was taken away from Israel in the hundred and seventieth year.

**[13:42]** Then the people of Israel began to write in their instruments and contracts, In the first year of Simon the high priest, the governor and leader of the Jews.

**[13:43]** In those days Simon camped against Gaza and besieged it round about; he made also an engine of war, and set it by the city, and battered a certain tower, and took it.

**[13:44]** And they that were in the engine leaped into the city; whereupon there was a great uproar in the city:

**[13:45]** Insomuch as the people of the city rent their clothes, and climbed upon the walls with their wives and children, and cried with a loud voice, beseeching Simon to grant them peace.

**[13:46]** And they said, Deal not with us according to our wickedness, but according to thy mercy.

**[13:47]** So Simon was appeased toward them, and fought no more against them, but put them out of the city, and cleansed the houses wherein the idols were, and so entered into it with songs and thanksgiving.

**[13:48]** Yea, he put all uncleanness out of it, and placed such men there as would keep the law, and made it stronger than it was before, and built therein a dwellingplace for himself.

**[13:49]** They also of the tower in Jerusalem were kept so strait, that they could neither come forth, nor go into the country, nor buy, nor sell: wherefore they were in great distress for want of victuals, and a great number of them perished through famine.

**[13:50]** Then cried they to Simon, beseeching him to be at one with them: which thing he granted them; and when he had put them out from thence, he cleansed the tower from pollutions:

**[13:51]** And entered into it the three and twentieth day of the second month in the hundred seventy and first year, with thanksgiving, and branches of palm trees, and with harps, and cymbals, and with viols, and hymns, and songs: because there was destroyed a great enemy out of Israel.

**[13:52]** He ordained also that that day should be kept every year with gladness. Moreover the hill of the temple that was by the tower he made stronger than it was, and there he dwelt himself with his company.

**[13:53]** And when Simon saw that John his son was a valiant man, he made him captain of all the hosts; and he dwelt in Gazera.

**[14:1]** Now in the hundred threescore and twelfth year king Demetrius gathered his forces together, and went into Media to get him help to fight against Tryphone.

**[14:2]** But when Arsaces, the king of Persia and Media, heard that Demetrius was entered within his borders, he sent one of his princes to take him alive:

**[14:3]** Who went and smote the host of Demetrius, and took him, and brought him to Arsaces, by whom he was put in ward.

**[14:4]** As for the land of Judea, that was quiet all the days of Simon; for he sought the good of his nation in such wise, as that evermore his authority and honour pleased them well.

**[14:5]** And as he was honourable in all his acts, so in this, that he took Joppa for an haven, and made an entrance to the isles of the sea,

**[14:6]** And enlarged the bounds of his nation, and recovered the country,

**[14:7]** And gathered together a great number of captives, and had the dominion of Gazera, and Bethsura, and the tower, out of the which he took all uncleaness, neither was there any that resisted him.

**[14:8]** Then did they till their ground in peace, and the earth gave her increase, and the trees of the field their fruit.

**[14:9]** The ancient men sat all in the streets, communing together of good things, and the young men put on glorious and warlike apparel.

**[14:10]** He provided victuals for the cities, and set in them all manner of munition, so that his honourable name was renowned unto the end of the world.

**[14:11]** He made peace in the land, and Israel rejoiced with great joy:

**[14:12]** For every man sat under his vine and his fig tree, and there was none to fray them:

**[14:13]** Neither was there any left in the land to fight against them: yea, the kings themselves were overthrown in those days.

**[14:14]** Moreover he strengthened all those of his people that were brought low: the law he searched out; and every contemner of the law and wicked person he took away.

**[14:15]** He beautified the sanctuary, and multiplied vessels of the temple.

**[14:16]** Now when it was heard at Rome, and as far as Sparta, that Jonathan was dead, they were very sorry.

**[14:17]** But as soon as they heard that his brother Simon was made high priest in his stead, and ruled the country, and the cities therein:

**[14:18]** They wrote unto him in tables of brass, to renew the friendship and league which they had made with Judas and Jonathan his brethren:

**[14:19]** Which writings were read before the congregation at Jerusalem.

**[14:20]** And this is the copy of the letters that the Lacedemonians sent; The rulers of the Lacedemonians, with the city, unto Simon the high priest, and the elders, and priests, and residue of the people of the Jews, our brethren, send greeting:

**[14:21]** The ambassadors that were sent unto our people certified us of your glory and honour: wherefore we were glad of their coming,

**[14:22]** And did register the things that they spake in the council of the people in this manner; Numenius son of Antiochus, and Antipater son of Jason, the Jews’ ambassadors, came unto us to renew the friendship they had with us.

**[14:23]** And it pleased the people to entertain the men honourably, and to put the copy of their ambassage in publick records, to the end the people of the Lacedemonians might have a memorial thereof: furthermore we have written a copy thereof unto Simon the high priest.

**[14:24]** After this Simon sent Numenius to Rome with a great shield of gold of a thousand pound weight to confirm the league with them.

**[14:25]** Whereof when the people heard, they said, What thanks shall we give to Simon and his sons?

**[14:26]** For he and his brethren and the house of his father have established Israel, and chased away in fight their enemies from them, and confirmed their liberty.

**[14:27]** So then they wrote it in tables of brass, which they set upon pillars in mount Sion: and this is the copy of the writing; The eighteenth day of the month Elul, in the hundred threescore and twelfth year, being the third year of Simon the high priest,

**[14:28]** At Saramel in the great congregation of the priests, and people, and rulers of the nation, and elders of the country, were these things notified unto us.

**[14:29]** Forasmuch as oftentimes there have been wars in the country, wherein for the maintenance of their sanctuary, and the law, Simon the son of Mattathias, of the posterity of Jarib, together with his brethren, put themselves in jeopardy, and resisting the enemies of their nation did their nation great honour:

**[14:30]** (For after that Jonathan, having gathered his nation together, and been their high priest, was added to his people,

**[14:31]** Their enemies prepared to invade their country, that they might destroy it, and lay hands on the sanctuary:

**[14:32]** At which time Simon rose up, and fought for his nation, and spent much of his own substance, and armed the valiant men of his nation and gave them wages,

**[14:33]** And fortified the cities of Judea, together with Bethsura, that lieth upon the borders of Judea, where the armour of the enemies had been before; but he set a garrison of Jews there:

**[14:34]** Moreover he fortified Joppa, which lieth upon the sea, and Gazera, that bordereth upon Azotus, where the enemies had dwelt before: but he placed Jews there, and furnished them with all things convenient for the reparation thereof.)

**[14:35]** The people therefore sang the acts of Simon, and unto what glory he thought to bring his nation, made him their governor and chief priest, because he had done all these things, and for the justice and faith which he kept to his nation, and for that he sought by all means to exalt his people.

**[14:36]** For in his time things prospered in his hands, so that the heathen were taken out of their country, and they also that were in the city of David in Jerusalem, who had made themselves a tower, out of which they issued, and polluted all about the sanctuary, and did much hurt in the holy place:

**[14:37]** But he placed Jews therein. and fortified it for the safety of the country and the city, and raised up the walls of Jerusalem.

**[14:38]** King Demetrius also confirmed him in the high priesthood according to those things,

**[14:39]** And made him one of his friends, and honoured him with great honour.

**[14:40]** For he had heard say, that the Romans had called the Jews their friends and confederates and brethren; and that they had entertained the ambassadors of Simon honourably;

**[14:41]** Also that the Jews and priests were well pleased that Simon should be their governor and high priest for ever, until there should arise a faithful prophet;

**[14:42]** Moreover that he should be their captain, and should take charge of the sanctuary, to set them over their works, and over the country, and over the armour, and over the fortresses, that, I say, he should take charge of the sanctuary;

**[14:43]** Beside this, that he should be obeyed of every man, and that all the writings in the country should be made in his name, and that he should be clothed in purple, and wear gold:

**[14:44]** Also that it should be lawful for none of the people or priests to break any of these things, or to gainsay his words, or to gather an assembly in the country without him, or to be clothed in purple, or wear a buckle of gold;

**[14:45]** And whosoever should do otherwise, or break any of these things, he should be punished.

**[14:46]** Thus it liked all the people to deal with Simon, and to do as hath been said.

**[14:47]** Then Simon accepted hereof, and was well pleased to be high priest, and captain and governor of the Jews and priests, and to defend them all.

**[14:48]** So they commanded that this writing should be put in tables of brass, and that they should be set up within the compass of the sanctuary in a conspicuous place;

**[14:49]** Also that the copies thereof should be laid up in the treasury, to the end that Simon and his sons might have them.

**[15:1]** Moreover Antiochus son of Demetrius the king sent letters from the isles of the sea unto Simon the priest and prince of the Jews, and to all the people;

**[15:2]** The contents whereof were these: King Antiochus to Simon the high priest and prince of his nation, and to the people of the Jews, greeting:

**[15:3]** Forasmuch as certain pestilent men have usurped the kingdom of our fathers, and my purpose is to challenge it again, that I may restore it to the old estate, and to that end have gathered a multitude of foreign soldiers together, and prepared ships of war;

**[15:4]** My meaning also being to go through the country, that I may be avenged of them that have destroyed it, and made many cities in the kingdom desolate:

**[15:5]** Now therefore I confirm unto thee all the oblations which the kings before me granted thee, and whatsoever gifts besides they granted.

**[15:6]** I give thee leave also to coin money for thy country with thine own stamp.

**[15:7]** And as concerning Jerusalem and the sanctuary, let them be free; and all the armour that thou hast made, and fortresses that thou hast built, and keepest in thine hands, let them remain unto thee.

**[15:8]** And if anything be, or shall be, owing to the king, let it be forgiven thee from this time forth for evermore.

**[15:9]** Furthermore, when we have obtained our kingdom, we will honour thee, and thy nation, and thy temple, with great honour, so that your honour shall be known throughout the world.

**[15:10]** In the hundred threescore and fourteenth year went Antiochus into the land of his fathers: at which time all the forces came together unto him, so that few were left with Tryphon.

**[15:11]** Wherefore being pursued by king Antiochus, he fled unto Dora, which lieth by the sea side:

**[15:12]** For he saw that troubles came upon him all at once, and that his forces had forsaken him.

**[15:13]** Then camped Antiochus against Dora, having with him an hundred and twenty thousand men of war, and eight thousand horsemen.

**[15:14]** And when he had compassed the city round about, and joined ships close to the town on the sea side, he vexed the city by land and by sea, neither suffered he any to go out or in.

**[15:15]** In the mean season came Numenius and his company from Rome, having letters to the kings and countries; wherein were written these things:

**[15:16]** Lucius, consul of the Romans unto king Ptolemee, greeting:

**[15:17]** The Jews’ ambassadors, our friends and confederates, came unto us to renew the old friendship and league, being sent from Simon the high priest, and from the people of the Jews:

**[15:18]** And they brought a shield of gold of a thousand pound.

**[15:19]** We thought it good therefore to write unto the kings and countries, that they should do them no harm, nor fight against them, their cities, or countries, nor yet aid their enemies against them.

**[15:20]** It seemed also good to us to receive the shield of them.

**[15:21]** If therefore there be any pestilent fellows, that have fled from their country unto you, deliver them unto Simon the high priest, that he may punish them according to their own law.

**[15:22]** The same things wrote he likewise unto Demetrius the king, and Attalus, to Ariarathes, and Arsaces,

**[15:23]** And to all the countries and to Sampsames, and the Lacedemonians, and to Delus, and Myndus, and Sicyon, and Caria, and Samos, and Pamphylia, and Lycia, and Halicarnassus, and Rhodus, and Aradus, and Cos, and Side, and Aradus, and Gortyna, and Cnidus, and Cyprus, and Cyrene.

**[15:24]** And the copy hereof they wrote to Simon the high priest.

**[15:25]** So Antiochus the king camped against Dora the second day, assaulting it continually, and making engines, by which means he shut up Tryphon, that he could neither go out nor in.

**[15:26]** At that time Simon sent him two thousand chosen men to aid him; silver also, and gold, and much armour.

**[15:27]** Nevertheless he would not receive them, but brake all the covenants which he had made with him afore, and became strange unto him.

**[15:28]** Furthermore he sent unto him Athenobius, one of his friends, to commune with him, and say, Ye withhold Joppa and Gazera; with the tower that is in Jerusalem, which are cities of my realm.

**[15:29]** The borders thereof ye have wasted, and done great hurt in the land, and got the dominion of many places within my kingdom.

**[15:30]** Now therefore deliver the cities which ye have taken, and the tributes of the places, whereof ye have gotten dominion without the borders of Judea:

**[15:31]** Or else give me for them five hundred talents of silver; and for the harm that ye have done, and the tributes of the cities, other five hundred talents: if not, we will come and fight against you

**[15:32]** So Athenobius the king’s friend came to Jerusalem: and when he saw the glory of Simon, and the cupboard of gold and silver plate, and his great attendance, he was astonished, and told him the king’s message.

**[15:33]** Then answered Simon, and said unto him, We have neither taken other men’s land, nor holden that which appertaineth to others, but the inheritance of our fathers, which our enemies had wrongfully in possession a certain time.

**[15:34]** Wherefore we, having opportunity, hold the inheritance of our fathers.

**[15:35]** And whereas thou demandest Joppa and Gazera, albeit they did great harm unto the people in our country, yet will we give thee an hundred talents for them. Hereunto Athenobius answered him not a word;

**[15:36]** But returned in a rage to the king, and made report unto him of these speeches, and of the glory of Simon, and of all that he had seen: whereupon the king was exceeding wroth.

**[15:37]** In the mean time fled Tryphon by ship unto Orthosias.

**[15:38]** Then the king made Cendebeus captain of the sea coast, and gave him an host of footmen and horsemen,

**[15:39]** And commanded him to remove his host toward Judea; also he commanded him to build up Cedron, and to fortify the gates, and to war against the people; but as for the king himself, he pursued Tryphon.

**[15:40]** So Cendebeus came to Jamnia and began to provoke the people and to invade Judea, and to take the people prisoners, and slay them.

**[15:41]** And when he had built up Cedrou, he set horsemen there, and an host of footmen, to the end that issuing out they might make outroads upon the ways of Judea, as the king had commanded him.

**[16:1]** Then came up John from Gazera, and told Simon his father what Cendebeus had done.

**[16:2]** Wherefore Simon called his two eldest sons, Judas and John, and said unto them, I, and my brethren, and my father’s house, have ever from my youth unto this day fought against the enemies of Israel; and things have prospered so well in our hands, that we have delivered Israel oftentimes.

**[16:3]** But now I am old, and ye, by God’s mercy, are of a sufficient age: be ye instead of me and my brother, and go and fight for our nation, and the help from heaven be with you.

**[16:4]** So he chose out of the country twenty thousand men of war with horsemen, who went out against Cendebeus, and rested that night at Modin.

**[16:5]** And when as they rose in the morning, and went into the plain, behold, a mighty great host both of footmen and horsemen came against them: howbeit there was a water brook betwixt them.

**[16:6]** So he and his people pitched over against them: and when he saw that the people were afraid to go over the water brook, he went first over himself, and then the men seeing him passed through after him.

**[16:7]** That done, he divided his men, and set the horsemen in the midst of the footmen: for the enemies’ horsemen were very many.

**[16:8]** Then sounded they with the holy trumpets: whereupon Cendebeus and his host were put to flight, so that many of them were slain, and the remnant gat them to the strong hold.

**[16:9]** At that time was Judas John’s brother wounded; but John still followed after them, until he came to Cedron, which Cendebeus had built.

**[16:10]** So they fled even unto the towers in the fields of Azotus; wherefore he burned it with fire: so that there were slain of them about two thousand men. Afterward he returned into the land of Judea in peace.

**[16:11]** Moreover in the plain of Jericho was Ptolemeus the son of Abubus made captain, and he had abundance of silver and gold:

**[16:12]** For he was the high priest’s son in law.

**[16:13]** Wherefore his heart being lifted up, he thought to get the country to himself, and thereupon consulted deceitfully against Simon and his sons to destroy them.

**[16:14]** Now Simon was visiting the cities that were in the country, and taking care for the good ordering of them; at which time he came down himself to Jericho with his sons, Mattathias and Judas, in the hundred threescore and seventeenth year, in the eleventh month, called Sabat:

**[16:15]** Where the son of Abubus receiving them deceitfully into a little hold, called Docus, which he had built, made them a great banquet: howbeit he had hid men there.

**[16:16]** So when Simon and his sons had drunk largely, Ptolemee and his men rose up, and took their weapons, and came upon Simon into the banqueting place, and slew him, and his two sons, and certain of his servants.

**[16:17]** In which doing he committed a great treachery, and recompensed evil for good.

**[16:18]** Then Ptolemee wrote these things, and sent to the king, that he should send him an host to aid him, and he would deliver him the country and cities.

**[16:19]** He sent others also to Gazera to kill John: and unto the tribunes he sent letters to come unto him, that he might give them silver, and gold, and rewards.

**[16:20]** And others he sent to take Jerusalem, and the mountain of the temple.

**[16:21]** Now one had run afore to Gazera and told John that his father and brethren were slain, and, quoth he, Ptolemee hath sent to slay thee also.

**[16:22]** Hereof when he heard, he was sore astonished: so he laid hands on them that were come to destroy him, and slew them; for he knew that they sought to make him away.

**[16:23]** As concerning the rest of the acts of John, and his wars, and worthy deeds which he did, and the building of the walls which he made, and his doings,

**[16:24]** Behold, these are written in the chronicles of his priesthood, from the time he was made high priest after his father.

