# Jubilees



**[1:1]** And it came to pass in the first year of the exodus of the children of Israel out of Egypt, in the third month, on the sixteenth day of the month, [2450 Anno Mundi] that God spake to Moses, saying: 'Come up to Me on the Mount, and I will give thee two tables of stone of the law and of the commandment, which I have written, that thou mayst teach them.'

**[1:2]** And Moses went up into the mount of God, and the glory of the Lord abode on Mount Sinai, and a cloud overshadowed it six days.

**[1:3]** And He called to Moses on the seventh day out of the midst of the cloud, and the appearance of the glory of the Lord was like a flaming fire on the top of the mount.

**[1:4]** And Moses was on the Mount forty days and forty nights, and God taught him the earlier and the later history of the division of all the days of the law and of the testimony.

**[1:5]** And He said: 'Incline thine heart to every word which I shall speak to thee on this mount, and write them in a book in order that their generations may see how I have not forsaken them for all the evil which they have wrought in transgressing the covenant which I establish between Me and thee for their generations this day on Mount Sinai.

**[1:6]** And thus it will come to pass when all these things come upon them, that they will recognise that I am more righteous than they in all their judgments and in all their actions, and they will recognise that I have been truly with them.

**[1:7]** And do thou write for thyself all these words which I declare unto, thee this day, for I know their rebellion and their stiff neck, before I bring them into the land of which I sware to their fathers, to Abraham and to Isaac and to Jacob, saying: ' Unto your seed will I give a land flowing with milk and honey.

**[1:8]** And they will eat and be satisfied, and they will turn to strange gods, to (gods) which cannot deliver them from aught of their tribulation: and this witness shall be heard for a witness against them. For they will forget all My commandments, (even) all that I command them, and they will walk after the Gentiles, and after their uncleanness, and after their shame, and will serve their gods, and these will prove unto them an offence and a tribulation and an affliction and a snare.

**[1:9]** And many will perish and they will be taken captive, and will fall into the hands of the enemy, because they have forsaken My ordinances and My commandments, and the festivals of My covenant, and My sabbaths, and My holy place which I have hallowed for Myself in their midst, and My tabernacle, and My sanctuary, which I have hallowed for Myself in the midst of the land, that I should set my name upon it, and that it should dwell (there).

**[1:10]** And they will make to themselves high places and groves and graven images, and they will worship, each his own (graven image), so as to go astray, and they will sacrifice their children to demons, and to all the works of the error of their hearts.

**[1:11]** And I will send witnesses unto them, that I may witness against them, but they will not hear, and will slay the witnesses also, and they will persecute those who seek the law, and they will abrogate and change everything so as to work evil before My eyes.

**[1:12]** And I will hide My face from them, and I will deliver them into the hand of the Gentiles for captivity, and for a prey, and for devouring, and I will remove them from the midst of the land, and I will scatter them amongst the Gentiles.

**[1:13]** And they will forget all My law and all My commandments and all My judgments, and will go astray as to new moons, and sabbaths, and festivals, and jubilees, and ordinances.

**[1:14]** And after this they will turn to Me from amongst the Gentiles with all their heart and with all their soul and with all their strength, and I will gather them from amongst all the Gentiles, and they will seek me, so that I shall be found of them, when they seek me with all their heart and with all their soul.

**[1:15]** And I will disclose to them abounding peace with righteousness, and I will remove them the plant of uprightness, with all My heart and with all My soul, and they shall be for a blessing and not for a curse, and they shall be the head and not the tail.

**[1:16]** And I will build My sanctuary in their midst, and I will dwell with them, and I will be their God and they shall be My people in truth and righteousness.

**[1:17]** And I will not forsake them nor fail them; for I am the Lord their God.'

**[1:18]** And Moses fell on his face and prayed and said, 'O Lord my God, do not forsake Thy people and Thy inheritance, so that they should wander in the error of their hearts, and do not deliver them into the hands of their enemies, the Gentiles, lest they should rule over them and cause them to sin against Thee.

**[1:19]** Let thy mercy, O Lord, be lifted up upon Thy people, and create in them an upright spirit, and let not the spirit of Beliar rule over them to accuse them before Thee, and to ensnare them from all the paths of righteousness, so that they may perish from before Thy face.

**[1:20]** But they are Thy people and Thy inheritance, which thou hast delivered with thy great power from the hands of the Egyptians: create in them a clean heart and a holy spirit, and let them not be ensnared in their sins from henceforth until eternity.'

**[1:21]** And the Lord said unto Moses: 'I know their contrariness and their thoughts and their stiffneckedness, and they will not be obedient till they confess their own sin and the sin of their fathers.

**[1:22]** And after this they will turn to Me in all uprightness and with all (their) heart and with all (their) soul, and I will circumcise the foreskin of their heart and the foreskin of the heart of their seed, and I will create in them a holy spirit, and I will cleanse them so that they shall not turn away from Me from that day unto eternity.

**[1:23]** And their souls will cleave to Me and to all My commandments, and they will fulfil My commandments, and I will be their Father and they shall be My children.

**[1:24]** And they all shall be called children of the living God, and every angel and every spirit shall know, yea, they shall know that these are My children, and that I am their Father in uprightness and righteousness, and that I love them.

**[1:25]** And do thou write down for thyself all these words which I declare unto thee on this mountain, the first and the last, which shall come to pass in all the divisions of the days in the law and in the testimony and in the weeks and the jubilees unto eternity, until I descend and dwell with them throughout eternity.'

**[1:26]** And He said to the angel of the presence: 'Write for Moses from the beginning of creation till My sanctuary has been built among them for all eternity.

**[1:27]** And the Lord will appear to the eyes of all, and all shall know that I am the God of Israel and the Father of all the children of Jacob, and King on Mount Zion for all eternity. And Zion and Jerusalem shall be holy.'

**[1:28]** And the angel of the presence who went before the camp of Israel took the tables of the divisions of the years -from the time of the creation- of the law and of the testimony of the weeks of the jubilees, according to the individual years, according to all the number of the jubilees [according, to the individual years], from the day of the [new] creation when the heavens and the earth shall be renewed and all their creation according to the powers of the heaven, and according to all the creation of the earth, until the sanctuary of the Lord shall be made in Jerusalem on Mount Zion, and all the luminaries be renewed for healing and for peace and for blessing for all the elect of Israel, and that thus it may be from that day and unto all the days of the earth.

**[2:1]** And the angel of the presence spake to Moses according to the word of the Lord, saying: Write the complete history of the creation, how in six days the Lord God finished all His works and all that He created, and kept Sabbath on the seventh day and hallowed it for all ages, and appointed it as a sign for all His works.

**[2:2]** For on the first day He created the heavens which are above and the earth and the waters and all the spirits which serve before him -the angels of the presence, and the angels of sanctification, and the angels [of the spirit of fire and the angels] of the spirit of the winds, and the angels of the spirit of the clouds, and of darkness, and of snow and of hail and of hoar frost, and the angels of the voices and of the thunder and of the lightning, and the angels of the spirits of cold and of heat, and of winter and of spring and of autumn and of summer and of all the spirits of his creatures which are in the heavens and on the earth, (He created) the abysses and the darkness, eventide <and night>, and the light, dawn and day, which He hath prepared in the knowledge of his heart.

**[2:3]** And thereupon we saw His works, and praised Him, and lauded before Him on account of all His works; for seven great works did He create on the first day.

**[2:4]** And on the second day He created the firmament in the midst of the waters, and the waters were divided on that day -half of them went up above and half of them went down below the firmament (that was) in the midst over the face of the whole earth. And this was the only work (God) created on the second day.

**[2:5]** And on the third day He commanded the waters to pass from off the face of the whole earth into one place, and the dry land to appear.

**[2:6]** And the waters did so as He commanded them, and they retired from off the face of the earth into one place outside of this firmament, and the dry land appeared.

**[2:7]** And on that day He created for them all the seas according to their separate gathering-places, and all the rivers, and the gatherings of the waters in the mountains and on all the earth, and all the lakes, and all the dew of the earth, and the seed which is sown, and all sprouting things, and fruit-bearing trees, and trees of the wood, and the garden of Eden, in Eden and all plants after their kind.

**[2:8]** These four great works God created on the third day. And on the fourth day He created the sun and the moon and the stars, and set them in the firmament of the heaven, to give light upon all the earth, and to rule over the day and the night, and divide the light from the darkness.

**[2:9]** And God appointed the sun to be a great sign on the earth for days and for sabbaths and for months and for feasts and for years and for sabbaths of years and for jubilees and for all seasons of the years.

**[2:10]** And it divideth the light from the darkness [and] for prosperity, that all things may prosper which shoot and grow on the earth.

**[2:11]** These three kinds He made on the fourth day. And on the fifth day He created great sea monsters in the depths of the waters, for these were the first things of flesh that were created by his hands, the fish and everything that moves in the waters, and everything that flies, the birds and all their kind.

**[2:12]** And the sun rose above them to prosper (them), and above everything that was on the earth, everything that shoots out of the earth, and all fruit-bearing trees, and all flesh.

**[2:13]** These three kinds He created on the fifth day. And on the sixth day He created all the animals of the earth, and all cattle, and everything that moves on the earth.

**[2:14]** And after all this He created man, a man and a woman created He them, and gave him dominion over all that is upon the earth, and in the seas, and over everything that flies, and over beasts and over cattle, and over everything that moves on the earth, and over the whole earth, and over all this He gave him dominion.

**[2:15]** And these four kinds He created on the sixth day. And there were altogether two and twenty kinds.

**[2:16]** And He finished all his work on the sixth day -all that is in the heavens and on the earth, and in the seas and in the abysses, and in the light and in the darkness, and in everything.

**[2:17]** And He gave us a great sign, the Sabbath day, that we should work six days, but keep Sabbath on the seventh day from all work.

**[2:18]** And all the angels of the presence, and all the angels of sanctification, these two great classes -He hath bidden us to keep the Sabbath with Him in heaven and on earth.

**[2:19]** And He said unto us: 'Behold, I will separate unto Myself a people from among all the peoples, and these shall keep the Sabbath day, and I will sanctify them unto Myself as My people, and will bless them; as I have sanctified the Sabbath day and do sanctify (it) unto Myself, even so will I bless them, and they shall be My people and I will be their God.

**[2:20]** And I have chosen the seed of Jacob from amongst all that I have seen, and have written him down as My first-born son,and have sanctified him unto Myself for ever and ever; and I will teach them the Sabbath day, that they may keep Sabbath thereon from all work.'

**[2:21]** And thus He created therein a sign in accordance with which they should keep Sabbath with us on the seventh day, to eat and to drink, and to bless Him who has created all things as He has blessed and sanctified unto Himself a peculiar people above all peoples, and that they should keep Sabbath together with us.

**[2:22]** And He caused His commands to ascend as a sweet savour acceptable before Him all the days . . .

**[2:23]** There (were) two and twenty heads of mankind from Adam to Jacob, and two and twenty kinds of work were made until the seventh day; this is blessed and holy; and the former also is blessed and holy; and this one serves with that one for sanctification and blessing.

**[2:24]** And to this (Jacob and his seed) it was granted that they should always be the blessed and holy ones of the first testimony and law, even as He had sanctified and blessed the Sabbath day on the seventh day.

**[2:25]** He created heaven and earth and everything that He created in six days, and God made the seventh day holy, for all His works; therefore He commanded on its behalf that, whoever does any work thereon shall die, and that he who defiles it shall surely die.

**[2:26]** Wherefore do thou command the children of Israel to observe this day that they may keep it holy and not do thereon any work, and not to defile it, as it is holier than all other days.

**[2:27]** And whoever profanes it shall surely die, and whoever does thereon any work shall surely die eternally, that the children of Israel may observe this day throughout their generations, and not be rooted out of the land; for it is a holy day and a blessed day.

**[2:28]** And every one who observes it and keeps Sabbath thereon from all his work, will be holy and blessed throughout all days like unto us.

**[2:29]** Declare and say to the children of Israel the law of this day both that they should keep Sabbath thereon, and that they should not forsake it in the error of their hearts; (and) that it is not lawful to do any work thereon which is unseemly, to do thereon their own pleasure, and that they should not prepare thereon anything to be eaten or drunk, and (that it is not lawful) to draw water, or bring in or take out thereon through their gates any burden, which they had not prepared for themselves on the sixth day in their dwellings.

**[2:30]** And they shall not bring in nor take out from house to house on that day; for that day is more holy and blessed than any jubilee day of the jubilees; on this we kept Sabbath in the heavens before it was made known to any flesh to keep Sabbath thereon on the earth.

**[2:31]** And the Creator of all things blessed it, but he did not sanctify all peoples and nations to keep Sabbath thereon, but Israel alone: them alone he permitted to eat and drink and to keep Sabbath thereon on the earth.

**[2:32]** And the Creator of all things blessed this day which He had created for blessing and holiness and glory above all days.

**[2:33]** This law and testimony was given to the children of Israel as a law for ever unto their generations.

**[3:1]** And on the six days of the second week we brought, according to the word of God, unto Adam all the beasts, and all the cattle, and all the birds, and everything that moves on the earth, and everything that moves in the water, according to their kinds, and according to their types: the beasts on the first day; the cattle on the second day; the birds on the third day; and all that which moves on the earth on the fourth day; and that which moves in the water on the fifth day.

**[3:2]** And Adam named them all by their respective names, and as he called them, so was their name.

**[3:3]** And on these five days Adam saw all these, male and female, according to every kind that was on the earth, but he was alone and found no helpmeet for him.

**[3:4]** And the Lord said unto us: 'It is not good that the man should be alone: let us make a helpmeet for him.'

**[3:5]** And the Lord our God caused a deep sleep to fall upon him, and he slept, and He took for the woman one rib from amongst his ribs, and this rib was the origin of the woman from amongst his ribs, and He built up the flesh in its stead, and built the woman.

**[3:6]** And He awaked Adam out of his sleep and on awaking he rose on the sixth day, and He brought her to him, and he knew her, and said unto her: 'This is now bone of my bones and flesh of my flesh; she shall be called [my] wife; because she was taken from her husband.'

**[3:7]** Therefore shall man and wife be one and therefore shall a man leave his father and his mother, and cleave unto his wife, and they shall be one flesh.

**[3:8]** In the first week was Adam created, and the rib -his wife: in the second week He showed her unto him: and for this reason the commandment was given to keep in their defilement, for a male seven days, and for a female twice seven days.

**[3:9]** And after Adam had completed forty days in the land where he had been created, we brought him into the garden of Eden to till and keep it, but his wife they brought in on the eightieth day, and after this she entered into the garden of Eden.

**[3:10]** And for this reason the commandment is written on the heavenly tablets in regard to her that gives birth: 'if she bears a male, she shall remain in her uncleanness seven days according to the first week of days, and thirty and three days shall she remain in the blood of her purifying, and she shall not touch any hallowed thing, nor enter into the sanctuary, until she accomplishes these days which (are enjoined) in the case of a male child.

**[3:11]** But in the case of a female child she shall remain in her uncleanness two weeks of days, according to the first two weeks, and sixty-six days in the blood of her purification, and they will be in all eighty days.'

**[3:12]** And when she had completed these eighty days we brought her into the garden of Eden, for it is holier than all the earth besides and every tree that is planted in it is holy.

**[3:13]** Therefore, there was ordained regarding her who bears a male or a female child the statute of those days that she should touch no hallowed thing, nor enter into the sanctuary until these days for the male or female child are accomplished.

**[3:14]** This is the law and testimony which was written down for Israel, in order that they should observe (it) all the days.

**[3:15]** And in the first week of the first jubilee, [1-7 A.M.] Adam and his wife were in the garden of Eden for seven years tilling and keeping it, and we gave him work and we instructed him to do everything that is suitable for tillage.

**[3:16]** And he tilled (the garden), and was naked and knew it not, and was not ashamed, and he protected the garden from the birds and beasts and cattle, and gathered its fruit, and eat, and put aside the residue for himself and for his wife [and put aside that which was being kept].

**[3:17]** And after the completion of the seven years, which he had completed there, seven years exactly, [8 A.M.] and in the second month, on the seventeenth day (of the month), the serpent came and approached the woman, and the serpent said to the woman, 'Hath God commanded you, saying, Ye shall not eat of every tree of the garden?'

**[3:18]** And she said to it, 'Of all the fruit of the trees of the garden God hath said unto us, Eat; but of the fruit of the tree which is in the midst of the garden God hath said unto us, 'Ye shall not eat thereof, neither shall ye touch it, lest ye die.'

**[3:19]** And the serpent said unto the woman, 'Ye shall not surely die: for God doth know that on the day ye shall eat thereof, your eyes will be opened, and ye will be as gods, and ye will know good and evil.

**[3:20]** And the woman saw the tree that it was agreeable and pleasant to the eye, and that its fruit was good for food, and she took thereof and eat.

**[3:21]** And when she had first covered her shame with figleaves, she gave thereof to Adam and he eat, and his eyes were opened, and he saw that he was naked.

**[3:22]** And he took figleaves and sewed (them) together, and made an apron for himself, and ,covered his shame.

**[3:23]** And God cursed the serpent, and was wroth with it for ever . . .

**[3:24]** And He was wroth with the woman, because she harkened to the voice of the serpent, and did eat; and He said unto her: 'I will greatly multiply thy sorrow and thy pains: in sorrow thou shalt bring forth children, and thy return shall be unto thy husband, and he will rule over thee.'

**[3:25]** And to Adam also he said, ' Because thou hast harkened unto the voice of thy wife, and hast eaten of the tree of which I commanded thee that thou shouldst not eat thereof, cursed be the ground for thy sake: thorns and thistles shall it bring forth to thee, and thou shalt eat thy bread in the sweat of thy face, till thou returnest to the earth from whence thou wast taken; for earth thou art, and unto earth shalt thou return.'

**[3:26]** And He made for them coats of skin, and clothed them, and sent them forth from the Garden of Eden.

**[3:27]** And on that day on which Adam went forth from the Garden, he offered as a sweet savour an offering, frankincense, galbanum, and stacte, and spices in the morning with the rising of the sun from the day when he covered his shame.

**[3:28]** And on that day was closed the mouth of all beasts, and of cattle, and of birds, and of whatever walks, and of whatever moves, so that they could no longer speak: for they had all spoken one with another with one lip and with one tongue.

**[3:29]** And He sent out of the Garden of Eden all flesh that was in the Garden of Eden, and all flesh was scattered according to its kinds, and according to its types unto the places which had been created for them.

**[3:30]** And to Adam alone did He give (the wherewithal) to cover his shame, of all the beasts and cattle.

**[3:31]** On this account, it is prescribed on the heavenly tablets as touching all those who know the judgment of the law, that they should cover their shame, and should not uncover themselves as the Gentiles uncover themselves.

**[3:32]** And on the new moon of the fourth month, Adam and his wife went forth from the Garden of Eden, and they dwelt in the land of Elda in the land of their creation.

**[3:33]** And Adam called the name of his wife Eve.

**[3:34]** And they had no son till the first jubilee, [8 A.M.] and after this he knew her.

**[3:35]** Now he tilled the land as he had been instructed in the Garden of Eden.

**[4:1]** And in the third week in the second jubilee [64-70 A.M.] she gave birth to Cain, and in the fourth [71-77 A.M.] she gave birth to Abel, and in the fifth [78-84 A.M.] she gave birth to her daughter Âwân.

**[4:2]** And in the first (year) of the third jubilee [99-105 A.M.], Cain slew Abel because (God) accepted the sacrifice of Abel, and did not accept the offering of Cain.

**[4:3]** And he slew him in the field: and his blood cried from the ground to heaven, complaining because he had slain him.

**[4:4]** And the Lord reproved Cain because of Abel, because he had slain him, and he made him a fugitive on the earth because of the blood of his brother, and he cursed him upon the earth.

**[4:5]** And on this account it is written on the heavenly tables, 'Cursed is ,he who smites his neighbour treacherously, and let all who have seen and heard say, So be it; and the man who has seen and not declared (it), let him be accursed as the other.'

**[4:6]** And for this reason we announce when we come before the Lord our God all the sin which is committed in heaven and on earth, and in light and in darkness, and everywhere.

**[4:7]** And Adam and his wife mourned for Abel four weeks of years, [99-127 A.M] and in the fourth year of the fifth week [130 A.M.] they became joyful, and Adam knew his wife again, and she bare him a son, and he called his name Seth; for he said 'GOD has raised up a second seed unto us on the earth instead of Abel; for Cain slew him.'

**[4:8]** And in the sixth week [134-40 A.M.] he begat his daughter Azûrâ.

**[4:9]** And Cain took Âwân his sister to be his wife and she bare him Enoch at the close of the fourth jubilee. [190-196 A.M.] And in the first year of the first week of the fifth jubilee, [197 A.M.] houses were built on the earth, and Cain built a city, and called its name after the name of his son Enoch.

**[4:10]** And Adam knew Eve his wife and she bare yet nine sons.

**[4:11]** And in the fifth week of the fifth jubilee [225-31 A.M.] Seth took Azûrâ his sister to be his wife, and in the fourth (year of the sixth week) [235 A.M.] she bare him Enos.

**[4:12]** He began to call on the name of the Lord on the earth.

**[4:13]** And in the seventh jubilee in the third week [309-15 A.M.] Enos took Nôâm his sister to be his wife, and she bare him a son in the third year of the fifth week, and he called his name Kenan.

**[4:14]** And at the close of the eighth jubilee [325, 386-3992 A.M.] Kenan took Mûalêlêth his sister to be his wife, and she bare him a son in the ninth jubilee, in the first week in the third year of this week, [395 A.M] and he called his name Mahalalel.

**[4:15]** And in the second week of the tenth jubilee [449-55 A.M.] Mahalalel took unto him to wife DinaH, the daughter of Barakiel the daughter of his father's brother, and she bare him a son in the third week in the sixth year, [461 A.M.] and he called his name Jared, for in his days the angels of the Lord descended on the earth, those who are named the Watchers, that they should instruct the children of men, and that they should do judgment and uprightness on the earth.

**[4:16]** And in the eleventh jubilee [512-18 A.M.] Jared took to himself a wife, and her name was Baraka, the daughter of Râsûjâl, a daughter of his father's brother, in the fourth week of this jubilee, [522 A.M.] and she bare him a son in the fifth week, in the fourth year of the jubilee, and he called his name Enoch.

**[4:17]** And he was the first among men that are born on earth who learnt writing and knowledge and wisdom and who wrote down the signs of heaven according to the order of their months in a book, that men might know the seasons of the years according to the order of their separate months.

**[4:18]** And he was the first to write a testimony and he testified to the sons of men among the generations of the earth, and recounted the weeks of the jubilees, and made known to them the days of the years, and set in order the months and recounted the Sabbaths of the years as we made (them), known to him.

**[4:19]** And what was and what will be he saw in a vision of his sleep, as it will happen to the children of men throughout their generations until the day of judgment; he saw and understood everything, and wrote his testimony, and placed the testimony on earth for all the children of men and for their generations.

**[4:20]** And in the twelfth jubilee, [582-88] in the seventh week thereof, he took to himself a wife, and her name was Edna, the daughter of Danel, the daughter of his father's brother, and in the sixth year in this week [587 A.M.] she bare him a son and he called his name Methuselah.

**[4:21]** And he was moreover with the angels of God these six jubilees of years, and they showed him everything which is on earth and in the heavens, the rule of the sun, and he wrote down everything.

**[4:22]** And he testified to the Watchers, who had sinned with the daughters of men; for these had begun to unite themselves, so as to be defiled, with the daughters of men, and Enoch testified against (them) all.

**[4:23]** And he was taken from amongst the children of men, and we conducted him into the Garden of Eden in majesty and honour, and behold there he writes down the condemnation and judgment of the world, and all the wickedness of the children of men.

**[4:24]** And on account of it (God) brought the waters of the flood upon all the land of Eden; for there he was set as a sign and that he should testify against all the children of men, that he should recount all the deeds of the generations until the day of condemnation.

**[4:25]** And he burnt the incense of the sanctuary, (even) sweet spices acceptable before the Lord on the Mount.

**[4:26]** For the Lord has four places on the earth, the Garden of Eden, and the Mount of the East, and this mountain on which thou art this day, Mount Sinai, and Mount Zion (which) will be sanctified in the new creation for a sanctification of the earth; through it will the earth be sanctified from all (its) guilt and its uncleanness through- out the generations of the world.

**[4:27]** And in the fourteenth jubilee [652 A.M.] Methuselah took unto himself a wife, Edna the daughter of Azrial, the daughter of his father's brother, in the third week, in the first year of this week, [701-7 A.M.] and he begat a son and called his name Lamech.

**[4:28]** And in the fifteenth jubilee in the third week Lamech took to himself a wife, and her name was Betenos the daughter of Baraki'il, the daughter of his father's brother, and in this week she bare him a son and he called his name Noah, saying, 'This one will comfort me for my trouble and all my work, and for the ground which the Lord hath cursed.'

**[4:29]** And at the close of the nineteenth jubilee, in the seventh week in the sixth year [930 A.M.] thereof, Adam died, and all his sons buried him in the land of his creation, and he was the first to be buried in the earth.

**[4:30]** And he lacked seventy years of one thousand years; for one thousand years are as one day in the testimony of the heavens and therefore was it written concerning the tree of knowledge: 'On the day that ye eat thereof ye shall die.' For this reason he did not complete the years of this day; for he died during it.

**[4:31]** At the close of this jubilee Cain was killed after him in the same year; for his house fell upon him and he died in the midst of his house, and he was killed by its stones; for with a stone he had killed Abel, and by a stone was he killed in righteous judgment.

**[4:32]** For this reason it was ordained on the heavenly tablets: With the instrument with which a man kills his neighbour with the same shall he be killed; after the manner that he wounded him, in like manner shall they deal with him.'

**[4:33]** And in the twenty-fifth [1205 A.M.] jubilee Noah took to himself a wife, and her name was `Emzârâ, the daughter of Râkê'êl, the daughter of his father's brother, in the first year in the fifth week [1207 A.M.]: and in the third year thereof she bare him Shem, in the fifth year thereof [1209 A.M.] she bare him Ham, and in the first year in the sixth week [1212 A.M.] she bare him Japheth.

**[5:1]** And it came to pass when the children of men began to multiply on the face of the earth and daughters were born unto them, that the angels of God saw them on a certain year of this jubilee, that they were beautiful to look upon; and they took themselves wives of all whom they chose, and they bare unto them sons and they were giants.

**[5:2]** And lawlessness increased on the earth and all flesh corrupted its way, alike men and cattle and beasts and birds and everything that walks on the earth -all of them corrupted their ways and their orders, and they began to devour each other, and lawlessness increased on the earth and every imagination of the thoughts of all men (was) thus evil continually.

**[5:3]** And God looked upon the earth, and behold it was corrupt, and all flesh had corrupted its orders, and all that were upon the earth had wrought all manner of evil before His eyes.

**[5:4]** And He said that He would destroy man and all flesh upon the face of the earth which He had created.

**[5:5]** But Noah found grace before the eyes of the Lord.

**[5:6]** And against the angels whom He had sent upon the earth, He was exceedingly wroth, and He gave commandment to root them out of all their dominion, and He bade us to bind them in the depths of the earth, and behold they are bound in the midst of them, and are (kept) separate.

**[5:7]** And against their sons went forth a command from before His face that they should be smitten with the sword, and be removed from under heaven.

**[5:8]** And He said 'My spirit shall not always abide on man; for they also are flesh and their days shall be one hundred and twenty years'.

**[5:9]** And He sent His sword into their midst that each should slay his neighbour, and they began to slay each other till they all fell by the sword and were destroyed from the earth.

**[5:10]** And their fathers were witnesses (of their destruction), and after this they were bound in the depths of the earth for ever, until the day of the great condemnation, when judgment is executed on all those who have corrupted their ways and their works before the Lord.

**[5:11]** And He destroyed all from their places, and there was not left one of them whom He judged not according to all their wickedness.

**[5:12]** And he made for all his works a new and righteous nature, so that they should not sin in their whole nature for ever, but should be all righteous each in his kind alway.

**[5:13]** And the judgment of all is ordained and written on the heavenly tablets in righteousness -even (the judgment of) all who depart from the path which is ordained for them to walk in; and if they walk not therein, judgment is written down for every creature and for every kind.

**[5:14]** And there is nothing in heaven or on earth, or in light or in darkness, or in Sheol or in the depth, or in the place of darkness (which is not judged); and all their judgments are ordained and written and engraved.

**[5:15]** In regard to all He will judge,the great according to his greatness, and the small according to his smallness, and each according to his way.

**[5:16]** And He is not one who will regard the person (of any), nor is He one who will receive gifts, if He says that He will execute judgment on each: if one gave everything that is on the earth, He will not regard the gifts or the person (of any), nor accept anything at his hands, for He is a righteous judge.

**[5:17]** [And of the children of Israel it has been written and ordained: If they turn to him in righteousness He will forgive all their transgressions and pardon all their sins.

**[5:18]** It is written and ordained that He will show mercy to all who turn from all their guilt once each year.]

**[5:19]** And as for all those who corrupted their ways and their thoughts before the flood, no man's person was accepted save that of Noah alone; for his person was accepted in behalf of his sons, whom (God) saved from the waters of the flood on his account; for his heart was righteous in all his ways, according as it was commanded regarding him, and he had not departed from aught that was ordained for him.

**[5:20]** And the Lord said that he would destroy everything which was upon the earth, both men and cattle, and

**[5:21]** beasts, and fowls of the air, and that which moveth on the earth. And He commanded Noah to make him an ark, that he might save himself from the waters of the flood.

**[5:22]** And Noah made the ark in all respects as He commanded him, in the twenty-seventh jubilee of years, in the fifth week in the fifth year (on the new moon of the first month). [1307 A.M.]

**[5:23]** And he entered in the sixth (year) thereof, [1308 A.M.] in the second month, on the new moon of the second month, till the sixteenth; and he entered, and all that we brought to him, into the ark, and the Lord closed it from without on the seventeenth evening.

**[5:24]** And the Lord opened seven flood-gates of heaven, And the mouths of the fountains of the great deep, seven mouths in number.

**[5:25]** And the flood-gates began to pour down water from the heaven forty days and forty nights, And the fountains of the deep also sent up waters, until the whole world was full of water.

**[5:26]** And the waters increased upon the earth: Fifteen cubits did the waters rise above all the high mountains, And the ark was lift up above the earth, And it moved upon the face of the waters.

**[5:27]** And the water prevailed on the face of the earth five months -one hundred and fifty days.

**[5:28]** And the ark went and rested on the top of Lubar, one of the mountains of Ararat.

**[5:29]** And (on the new moon) in the fourth month the fountains of the great deep were closed and the flood-gates of heaven were restrained; and on the new moon of the seventh month all the mouths of the abysses of the earth were opened, and the water began to descend into the deep below.

**[5:30]** And on the new moon of the tenth month the tops of the mountains were seen, and on the new moon of the first month the earth became visible.

**[5:31]** And the waters disappeared from above the earth in the fifth week in the seventh year [1309 A.M.] thereof, and on the seventeenth day in the second month the earth was dry.

**[5:32]** And on the twenty-seventh thereof he opened the ark, and sent forth from it beasts, and cattle, and birds, and every moving thing.

**[6:1]** And on the new moon of the third month he went forth from the ark, and built an altar on that mountain.

**[6:2]** And he made atonement for the earth, and took a kid and made atonement by its blood for all the guilt of the earth; for everything that had been on it had been destroyed, save those that were in the ark with Noah.

**[6:3]** And he placed the fat thereof on the altar, and he took an ox, and a goat, and a sheep and kids, and salt, and a turtle-dove, and the young of a dove, and placed a burnt sacrifice on the altar, and poured thereon an offering mingled with oil, and sprinkled wine and strewed frankincense over everything, and caused a goodly savour to arise, acceptable before the Lord.

**[6:4]** And the Lord smelt the goodly savour, and He made a covenant with him that there should not be any more a flood to destroy the earth; that all the days of the earth seed-time and harvest should never cease; cold and heat, and summer and winter, and day and night should not change their order, nor cease for ever.

**[6:5]** 'And you, increase ye and multiply upon the earth, and become many upon it, and be a blessing upon it. The fear of you and the dread of you I will inspire in everything that is on earth and in the sea.

**[6:6]** And behold I have given unto you all beasts, and all winged things, and everything that moves on the earth, and the fish in the waters, and all things for food; as the green herbs, I have given you all things to eat.

**[6:7]** But flesh, with the life thereof, with the blood, ye shall not eat; for the life of all flesh is in the blood, lest your blood of your lives be required. At the hand of every man, at the hand of every (beast) will I require the blood of man.

**[6:8]** Whoso sheddeth man's blood by man shall his blood be shed, for in the image of God made He man.

**[6:9]** And you, increase ye, and multiply on the earth.'

**[6:10]** And Noah and his sons swore that they would not eat any blood that was in any flesh, and he made a covenant before the Lord God for ever throughout all the generations of the earth in this month.

**[6:11]** On this account He spake to thee that thou shouldst make a covenant with the children of Israel in this month upon the mountain with an oath, and that thou shouldst sprinkle blood upon them because of all the words of the covenant, which the Lord made with them for ever.

**[6:12]** And this testimony is written concerning you that you should observe it continually, so that you should not eat on any day any blood of beasts or birds or cattle during all the days of the earth, and the man who eats the blood of beast or of cattle or of birds during all the days of the earth, he and his seed shall be rooted out of the land.

**[6:13]** And do thou command the children of Israel to eat no blood, so that their names and their seed may be before the Lord our God continually.

**[6:14]** And for this law there is no limit of days, for it is for ever. They shall observe it throughout their generations, so that they may continue supplicating on your behalf with blood before the altar; every day and at the time of morning and evening they shall seek forgiveness on your behalf perpetually before the Lord that they may keep it and not be rooted out.

**[6:15]** And He gave to Noah and his sons a sign that there should not again be a flood on the earth.

**[6:16]** He set His bow in the cloud for a sign of the eternal covenant that there should not again be a flood on the earth to destroy it all the days of the earth.

**[6:17]** For this reason it is ordained and written on the heavenly tablets, that they should celebrate the feast of weeks in this month once a year, to renew the covenant every year.

**[6:18]** And this whole festival was celebrated in heaven from the day of creation till the days of Noah -twenty-six jubilees and five weeks of years [1309-1659 A.M.]: and Noah and his sons observed it for seven jubilees and one week of years, till the day of Noah's death, and from the day of Noah's death his sons did away with (it) until the days of Abraham, and they eat blood.

**[6:19]** But Abraham observed it, and Isaac and Jacob and his children observed it up to thy days, and in thy days the children of Israel forgot it until ye celebrated it anew on this mountain.

**[6:20]** And do thou command the children of Israel to observe this festival in all their generations for a commandment unto them: one day in the year in this month they shall celebrate the festival.

**[6:21]** For it is the feast of weeks and the feast of first fruits: this feast is twofold and of a double nature: according to what is written and engraven concerning it, celebrate it.

**[6:22]** For I have written in the book of the first law, in that which I have written for thee, that thou shouldst celebrate it in its season, one day in the year, and I explained to thee its sacrifices that the children of Israel should remember and should celebrate it throughout their generations in this month, one day in every year.

**[6:23]** And on the new moon of the first month, and on the new moon of the fourth month, and on the new moon of the seventh month, and on the new moon of the tenth month are the days of remembrance, and the days of the seasons in the four divisions of the year. These are written and ordained as a testimony for ever.

**[6:24]** And Noah ordained them for himself as feasts for the generations for ever, so that they have become thereby a memorial unto him.

**[6:25]** And on the new moon of the first month he was bidden to make for himself an ark, and on that (day) the earth became dry and he opened (the ark) and saw the earth.

**[6:26]** And on the new moon of the fourth month the mouths of the depths of the abyss beneath were closed. And on the new moon of the seventh month all the mouths of the abysses of the earth were opened, and the waters began to descend into them.

**[6:27]** And on the new moon of the tenth month the tops of the mountains were seen, and Noah was glad.

**[6:28]** And on this account he ordained them for himself as feasts for a memorial for ever, and thus are they ordained.

**[6:29]** And they placed them on the heavenly tablets, each had thirteen weeks; from one to another (passed) their memorial, from the first to the second, and from the second to the third, and from the third to the fourth.

**[6:30]** And all the days of the commandment will be two and fifty weeks of days, and (these will make) the entire year complete. Thus it is engraven and ordained on the heavenly tablets.

**[6:31]** And there is no neglecting (this commandment) for a single year or from year to year.

**[6:32]** And command thou the children of Israel that they observe the years according to this reckoning- three hundred and sixty-four days, and (these) will constitute a complete year, and they will not disturb its time from its days and from its feasts; for everything will fall out in them according to their testimony, and they will not leave out any day nor disturb any feasts.

**[6:33]** But if they do neglect and do not observe them according to His commandment, then they will disturb all their seasons and the years will be dislodged from this (order), [and they will disturb the seasons and the years will be dislodged] and they will neglect their ordinances.

**[6:34]** And all the children of Israel will forget and will not find the path of the years, and will forget the new moons, and seasons, and sabbaths and they will go wrong as to all the order of the years.

**[6:35]** For I know and from henceforth will I declare it unto thee, and it is not of my own devising; for the book (lies) written before me, and on the heavenly tablets the division of days is ordained, lest they forget the feasts of the covenant and walk according to the feasts of the Gentiles after their error and after their ignorance.

**[6:36]** For there will be those who will assuredly make observations of the moon -how (it) disturbs the seasons and comes in from year to year ten days too soon.

**[6:37]** For this reason the years will come upon them when they will disturb (the order), and make an abominable (day) the day of testimony, and an unclean day a feast day, and they will confound all the days, the holy with the unclean, and the unclean day with the holy; for they will go wrong as to the months and sabbaths and feasts and jubilees.

**[6:38]** For this reason I command and testify to thee that thou mayst testify to them; for after thy death thy children will disturb (them), so that they will not make the year three hundred and sixty-four days only, and for this reason they will go wrong as to the new moons and seasons and sabbaths and festivals, and they will eat all kinds of blood with all kinds of flesh.

**[7:1]** And in the seventh week in the first year [1317 A.M.] thereof, in this jubilee, Noah planted vines on the mountain on which the ark had rested, named Lubar, one of the Ararat Mountains, and they produced fruit in the fourth year, [1320 A.M.] and he guarded their fruit, and gathered it in this year in the seventh month.

**[7:2]** And he made wine therefrom and put it into a vessel, and kept it until the fifth year, [1321 A.M.] until the first day, on the new moon of the first month.

**[7:3]** And he celebrated with joy the day of this feast, and he made a burnt sacrifice unto the Lord, one young ox and one ram, and seven sheep, each a year old, and a kid of the goats, that he might make atonement thereby for himself and his sons.

**[7:4]** And he prepared the kid first, and placed some of its blood on the flesh that was on the altar which he had made, and all the fat he laid on the altar where he made the burnt sacrifice, and the ox and the ram and the sheep, and he laid all their flesh upon the altar.

**[7:5]** And he placed all their offerings mingled with oil upon it, and afterwards he sprinkled wine on the fire which he had previously made on the altar, and he placed incense on the altar and caused a sweet savour to ascend acceptable before the Lord his God.

**[7:6]** And he rejoiced and drank of this wine, he and his children with joy.

**[7:7]** And it was evening, and he went into his tent, and being drunken he lay down and slept, and was uncovered in his tent as he slept.

**[7:8]** And Ham saw Noah his father naked, and went forth and told his two brethren without.

**[7:9]** And Shem took his garment and arose, he and Japheth, and they placed the garment on their shoulders and went backward and covered the shame of their father, and their faces were backward.

**[7:10]** And Noah awoke from his sleep and knew all that his younger son had done unto him, and he cursed his son and said: 'Cursed be Canaan; an enslaved servant shall he be unto his brethren.'

**[7:11]** And he blessed Shem, and said: 'Blessed be the Lord God of Shem, and Canaan shall be his servant.

**[7:12]** God shall enlarge Japheth, and God shall dwell in the dwelling of Shem, and Canaan shall be his servant.'

**[7:13]** And Ham knew that his father had cursed his younger son, and he was displeased that he had cursed his son. and he parted from his father, he and his sons with him, Cush and Mizraim and Put and Canaan.

**[7:14]** And he built for himself a city and called its name after the name of his wife Ne'elatama'uk.

**[7:15]** And Japheth saw it, and became envious of his brother, and he too built for himself a city, and he called its name after the name of his wife 'Adataneses.

**[7:16]** And Shem dwelt with his father Noah, and he built a city close to his father on the mountain, and he too called its name after the name of his wife Sedeqetelebab.

**[7:17]** And behold these three cities are near Mount Lubar; Sedeqetelebab fronting the mountain on its east; and Na'eltama'uk on the south; 'Adatan'eses towards the west.

**[7:18]** And these are the sons of Shem: Elam, and Asshur, and Arpachshad -this (son) was born two years after the flood- and Lud, and Aram.

**[7:19]** The sons of Japheth: Gomer and Magog and Madai and Javan, Tubal and Meshech and Tiras: these are the sons of Noah.

**[7:20]** And in the twenty-eighth jubilee [1324-1372 A.M.] Noah began to enjoin upon his sons' sons the ordinances and commandments, and all the judgments that he knew, and he exhorted his sons to observe righteousness, and to cover the shame of their flesh, and to bless their Creator, and honour father and mother, and love their neighbour, and guard their souls from fornication and uncleanness and all iniquity.

**[7:21]** For owing to these three things came the flood upon the earth, namely, owing to the fornication wherein the Watchers against the law of their ordinances went a whoring after the daughters of men, and took themselves wives of all which they chose: and they made the beginning of uncleanness.

**[7:22]** And they begat sons the Naphidim, and they were all unlike, and they devoured one another: and the Giants slew the Naphil, and the Naphil slew the Eljo, and the Eljo mankind, and one man another.

**[7:23]** And every one sold himself to work iniquity and to shed much blood, and the earth was filled with iniquity.

**[7:24]** And after this they sinned against the beasts and birds, and all that moves and walks on the earth: and much blood was shed on the earth, and every imagination and desire of men imagined vanity and evil continually.

**[7:25]** And the Lord destroyed everything from off the face of the earth; because of the wickedness of their deeds, and because of the blood which they had shed in the midst of the earth He destroyed everything.

**[7:26]** 'And we were left, I and you, my sons, and everything that entered with us into the ark, and behold I see your works before me that ye do not walk in righteousness: for in the path of destruction ye have begun to walk, and ye are parting one from another, and are envious one of another, and (so it comes) that ye are not in harmony, my sons, each with his brother.

**[7:27]** For I see, and behold the demons have begun (their) seductions against you and against your children and now I fear on your behalf, that after my death ye will shed the blood of men upon the earth, and that ye, too, will be destroyed from the face of the earth.

**[7:28]** For whoso sheddeth man's blood, and whoso eateth the blood of any flesh, shall all be destroyed from the earth.

**[7:29]** And there shall not be left any man that eateth blood, or that sheddeth the blood of man on the earth, Nor shall there be left to him any seed or descendants living under heaven; For into Sheol shall they go, And into the place of condemnation shall they descend, And into the darkness of the deep shall they all be removed by a violent death.

**[7:30]** There shall be no blood seen upon you of all the blood there shall be all the days in which ye have killed any beasts or cattle or whatever flies upon the earth, and work ye a good work to your souls by covering that which has been shed on the face of the earth.

**[7:31]** And ye shall not be like him who eats with blood, but guard yourselves that none may eat blood before you: cover the blood, for thus have I been commanded to testify to you and your children, together with all flesh.

**[7:32]** And suffer not the soul to be eaten with the flesh, that your blood, which is your life, may not be required at the hand of any flesh that sheds (it) on the earth.

**[7:33]** For the earth will not be clean from the blood which has been shed upon it; for (only) through the blood of him that shed it will the earth be purified throughout all its generations.

**[7:34]** And now, my children, harken: work judgment and righteousness that ye maybe planted in righteousness over the face of the whole earth, and your glory lifted up before my God, who saved me from the waters of the flood.

**[7:35]** And behold, ye will go and build for yourselves cities, and plant in them all the plants that are upon the earth, and moreover all fruit-bearing trees.

**[7:36]** For three years the fruit of everything that is eaten will not be gathered: and in the fourth year its fruit will be accounted holy [and they will offer the first-fruits], acceptable before the Most High God, who created heaven and earth and all things. Let them offer in abundance the first of the wine and oil (as) first-fruits on the altar of the Lord, who receives it, and what is left let the servants of the house of the Lord eat before the altar which receives (it).

**[7:37]** And in the fifth year make ye the release so that ye release it in righteousness and uprightness, and ye shall be righteous, and all that you plant shall prosper.

**[7:38]** For thus did Enoch, the father of your father command Methuselah, his son, and Methuselah his son Lamech, and Lamech commanded me all the things which his fathers commanded him.

**[7:39]** And I also will give you commandment, my sons, as Enoch commanded his son in the first jubilees: whilst still living, the seventh in his generation, he commanded and testified to his son and to his son's sons until the day of his death.'

**[8:1]** In the twenty-ninth jubilee, in the first week, [1373 A.M.] in the beginning thereof Arpachshad took to himself a wife and her name was Rasu'eja, the daughter of Susan, the daughter of Elam, and she bare him a son in the third year in this week, [1375 A.M.] and he called his name Kainam.

**[8:2]** And the son grew, and his father taught him writing, and he went to seek for himself a place where he might seize for himself a city.

**[8:3]** And he found a writing which former (generations) had carved on the rock, and he read what was thereon, and he transcribed it and sinned owing to it; for it contained the teaching of the Watchers in accordance with which they used to observe the omens of the sun and moon and stars in all the signs of heaven.

**[8:4]** And he wrote it down and said nothing regarding it; for he was afraid to speak to Noah about it lest he should be angry with him on account of it.

**[8:5]** And in the thirtieth jubilee, [1429 A.M.] in the second week, in the first year thereof, he took to himself a wife, and her name was Melka, the daughter of Madai, the son of Japheth, and in the fourth year [1432 A.M.] he begat a son, and called his name Shelah; for he said: 'Truly I have been sent.'

**[8:6]** [And in the fourth year he was born], and Shelah grew up and took to himself a wife, and her name was Mu'ak, the daughter of Kesed, his father's brother, in the one and thirtieth jubilee, in the fifth week, in the first year [1499 A.M.] thereof.

**[8:7]** And she bare him a son in the fifth year [1503 A.M.] thereof, and he called his name Eber: and he took unto himself a wife, and her name was 'Azûrâd, the daughter of Nebrod, in the thirty-second jubilee, in the seventh week, in the third year thereof. [1564 A.M.]

**[8:8]** And in the sixth year [1567 A.M.] thereof, she bare him son, and he called his name Peleg; for in the days when he was born the children of Noah began to divide the earth amongst themselves: for this reason he called his name Peleg.

**[8:9]** And they divided (it) secretly amongst themselves, and told it to Noah.

**[8:10]** And it came to pass in the beginning of the thirty-third jubilee [1569 A.M.] that they divided the earth into three parts, for Shem and Ham and Japheth, according to the inheritance of each, in the first year in the first week, when one of us who had been sent, was with them.

**[8:11]** And he called his sons, and they drew nigh to him, they and their children, and he divided the earth into the lots, which his three sons were to take in possession, and they reached forth their hands, and took the writing out of the bosom of Noah, their father.

**[8:12]** And there came forth on the writing as Shem's lot the middle of the earth which he should take as an inheritance for himself and for his sons for the generations of eternity, from the middle of the mountain range of Rafa, from the mouth of the water from the river Tina, and his portion goes towards the west through the midst of this river, and it extends till it reaches the water of the abysses, out of which this river goes forth and pours its waters into the sea Me'at, and this river flows into the great sea. And all that is towards the north is Japheth's, and all that is towards the south belongs to Shem.

**[8:13]** And it extends till it reaches Karaso: this is in the bosom of the tongue which looks towards the south.

**[8:14]** And his portion extends along the great sea, and it extends in a straight line till it reaches the west of the tongue which looks towards the south: for this sea is named the tongue of the Egyptian Sea.

**[8:15]** And it turns from here towards the south towards the mouth of the great sea on the shore of (its) waters, and it extends to the west to 'Afra, and it extends till it reaches the waters of the river Gihon, and to the south of the waters of Gihon, to the banks of this river.

**[8:16]** And it extends towards the east, till it reaches the Garden of Eden, to the south thereof, [to the south] and from the east of the whole land of Eden and of the whole east, it turns to the east and proceeds till it reaches the east of the mountain named Rafa, and it descends to the bank of the mouth of the river Tina.

**[8:17]** This portion came forth by lot for Shem and his sons, that they should possess it for ever unto his generations for evermore.

**[8:18]** And Noah rejoiced that this portion came forth for Shem and for his sons, and he remembered all that he had spoken with his mouth in prophecy; for he had said: 'Blessed be the Lord God of Shem And may the Lord dwell in the dwelling of Shem.'

**[8:19]** And he knew that the Garden of Eden is the holy of holies, and the dwelling of the Lord, and Mount Sinai the centre of the desert, and Mount Zion -the centre of the navel of the earth: these three were created as holy places facing each other.

**[8:20]** And he blessed the God of gods, who had put the word of the Lord into his mouth, and the Lord for evermore.

**[8:21]** And he knew that a blessed portion and a blessing had come to Shem and his sons unto the generations for ever -the whole land of Eden and the whole land of the Red Sea, and the whole land of the east and India, and on the Red Sea and the mountains thereof, and all the land of Bashan, and all the land of Lebanon and the islands of Kaftur, and all the mountains of Sanir and 'Amana, and the mountains of Asshur in the north, and all the land of Elam, Asshur, and Babel, and Susan and Ma'edai, and all the mountains of Ararat, and all the region beyond the sea, which is beyond the mountains of Asshur towards the north, a blessed and spacious land, and all that is in it is very good.

**[8:22]** And for Ham came forth the second portion, beyond the Gihon towards the south to the right of the Garden, and it extends towards the south and it extends to all the mountains of fire, and it extends towards the west to the sea of 'Atel and it extends towards the west till it reaches the sea of Ma'uk -that (sea) into which everything which is not destroyed descends.

**[8:23]** And it goes forth towards the north to the limits of Gadir, and it goes forth to the coast of the waters of the sea to the waters of the great sea till it draws near to the river Gihon, and goes along the river Gihon till it reaches the right of the Garden of Eden.

**[8:24]** And this is the land which came forth for Ham as the portion which he was to occupy for ever for himself and his sons unto their generations for ever.

**[8:25]** And for Japheth came forth the third portion beyond the river Tina to the north of the outflow of its waters, and it extends north- easterly to the whole region of Gog, and to all the country east thereof.

**[8:26]** And it extends northerly to the north, and it extends to the mountains of Qelt towards the north, and towards the sea of Ma'uk, and it goes forth to the east of Gadir as far as the region of the waters of the sea.

**[8:27]** And it extends until it approaches the west of Fara and it returns towards 'Aferag, and it extends easterly to the waters of the sea of Me'at.

**[8:28]** And it extends to the region of the river Tina in a north-easterly direction until it approaches the boundary of its waters towards the mountain Rafa, and it turns round towards the north.

**[8:29]** This is the land which came forth for Japheth and his sons as the portion of his inheritance which he should possess for himself and his sons, for their generations for ever; five great islands, and a great land in the north.

**[8:30]** But it is cold, and the land of Ham is hot, and the land of Shem is neither hot nor cold, but it is of blended cold and heat.

**[9:1]** And Ham divided amongst his sons, and the first portion came forth for Cush towards the east, and to the west of him for Mizraim, and to the west of him for Put, and to the west of him [and to the west thereof] on the sea for Canaan.

**[9:2]** And Shem also divided amongst his sons, and the first portion came forth for Ham and his sons, to the east of the river Tigris till it approachcs the east, the whole land of India, and on the Red Sea on its coast, and the waters of Dedan, and all the mountains of Mebri and Ela, and all the land of Susan and all that is on the side of Pharnak to the Red Sea and the river Tina.

**[9:3]** And for Asshur came forth the second Portion, all the land of Asshur and Nineveh and Shinar and to the border of India, and it ascends and skirts the river.

**[9:4]** And for Arpachshad came forth the third portion, all the land of the region of the Chaldees to the east of the Euphrates, bordering on the Red Sea, and all the waters of the desert close to the tongue of the sea which looks towards Egypt, all the land of Lebanon and Sanir and 'Amana to the border of the Euphrates.

**[9:5]** And for Aram there came forth the fourth portion, all the land of Mesopotamia between the Tigris and the Euphrates to the north of the Chaldees to the border of the mountains of Asshur and the land of 'Arara.

**[9:6]** And there came forth for Lud the fifth portion, the mountains of Asshur and all appertaining to them till it reaches the Great Sea, and till it reaches the east of Asshur his brother.

**[9:7]** And Japheth also divided the land of his inheritance amongst his sons.

**[9:8]** And the first portion came forth for Gomer to the east from the north side to the river Tina; and in the north there came forth for Magog all the inner portions of the north until it reaches to the sea of Me'at.

**[9:9]** And for Madai came forth as his portion that he should posses from the west of his two brothers to the islands, and to the coasts of the islands.

**[9:10]** And for Javan came forth the fourth portion every island and the islands which are towards the border of Lud.

**[9:11]** And for Tubal there came forth the fifth portion in the midst of the tongue which approaches towards the border of the portion of Lud to the second tongue, to the region beyond the second tongue unto the third tongue.

**[9:12]** And for Meshech came forth the sixth portion, all the region beyond the third tongue till it approaches the east of Gadir.

**[9:13]** And for Tiras there came forth the seventh portion, four great islands in the midst of the sea, which reach to the portion of Ham [and the islands of Kamaturi came out by lot for the sons of Arpachshad as his inheritance].

**[9:14]** And thus the sons of Noah divided unto their sons in the presence of Noah their father, and he bound them all by an oath, imprecating a curse on every one that sought to seize the portion which had not fallen (to him) by his lot.

**[9:15]** And they all said, 'So be it; so be it ' for themselves and their sons for ever throughout their generations till the day of judgment, on which the Lord God shall judge them with a sword and with fire for all the unclean wickedness of their errors, wherewith they have filled the earth with transgression and uncleanness and fornication and sin.

**[10:1]** And in the third week of this jubilee the unclean demons began to lead astray the children of the sons of Noah, and to make to err and destroy them.

**[10:2]** And the sons of Noah came to Noah their father, and they told him concerning the demons which were leading astray and blinding and slaying his sons' sons.

**[10:3]** And he prayed before the Lord his God, and said: 'God of the spirits of all flesh, who hast shown mercy unto me And hast saved me and my sons from the waters of the flood, And hast not caused me to perish as Thou didst the sons of perdition; For Thy grace has been great towards me, And great has been Thy mercy to my soul; Let Thy grace be lift up upon my sons, And let not wicked spirits rule over them Lest they should destroy them from the earth.

**[10:4]** But do Thou bless me and my sons, that we may increase and Multiply and replenish the earth.

**[10:5]** And Thou knowest how Thy Watchers, the fathers of these spirits, acted in my day: and as for these spirits which are living, imprison them and hold them fast in the place of condemnation, and let them not bring destruction on the sons of thy servant, my God; for these are malignant, and created in order to destroy.

**[10:6]** And let them not rule over the spirits of the living; for Thou alone canst exercise dominion over them. And let them not have power over the sons of the righteous from henceforth and for evermore.'

**[10:7]** And the Lord our God bade us to bind all.

**[10:8]** And the chief of the spirits, Mastêmâ, came and said: 'Lord, Creator, let some of them remain before me, and let them harken to my voice, and do all that I shall say unto them; for if some of them are not left to me, I shall not be able to execute the power of my will on the sons of men; for these are for corruption and leading astray before my judgment, for great is the wickedness of the sons of men.'

**[10:9]** And He said: 'Let the tenth part of them remain before him, and let nine parts descend into the place of condemnation.'

**[10:10]** And one of us He commanded that we should teach Noah all their medicines; for He knew that they would not walk in uprightness, nor strive in righteousness.

**[10:11]** And we did according to all His words: all the malignant evil ones we bound in the place of condemnation and a tenth part of them we left that they might be subject before Satan on the earth.

**[10:12]** And we explained to Noah all the medicines of their diseases, together with their seductions, how he might heal them with herbs of the earth.

**[10:13]** And Noah wrote down all things in a book as we instructed him concerning every kind of medicine. Thus the evil spirits were precluded from (hurting) the sons of Noah.

**[10:14]** And he gave all that he had written to Shem, his eldest son; for he loved him exceedingly above all his sons.

**[10:15]** And Noah slept with his fathers, and was buried on Mount Lubar in the land of Ararat.

**[10:16]** Nine hundred and fifty years he completed in his life, nineteen jubilees and two weeks and five years. [1659 A.M.]

**[10:17]** And in his life on earth he excelled the children of men save Enoch because of the righteousness, wherein he was perfect. For Enoch's office was ordained for a testimony to the generations of the world, so that he should recount all the deeds of generation unto generation, till the day of judgment.

**[10:18]** And in the three and thirtieth jubilee, in the first year in the second week, Peleg took to himself a wife, whose name was Lomna the daughter of Sina'ar, and she bare him a son in the fourth year of this week, and he called his name Reu; for he said: 'Behold the children of men have become evil through the wicked purpose of building for themselves a city and a tower in the land of Shinar.'

**[10:19]** For they departed from the land of Ararat eastward to Shinar; for in his days they built the city and the tower, saying, 'Go to, let us ascend thereby into heaven.'

**[10:20]** And they began to build, and in the fourth week they made brick with fire, and the bricks served them for stone, and the clay with which they cemented them together was asphalt which comes out of the sea, and out of the fountains of water in the land of Shinar.

**[10:21]** And they built it: forty and three years [1645-1688 A.M.] were they building it; its breadth was 203 bricks, and the height (of a brick) was the third of one; its height amounted to 5433 cubits and 2 palms, and (the extent of one wall was) thirteen stades (and of the other thirty stades).

**[10:22]** And the Lord our God said unto us: 'Behold, they are one people, and (this) they begin to do, and now nothing will be withholden from them. Go to, let us go down and confound their language, that they may not understand one another's speech, and they may be dispersed into cities and nations, and one purpose will no longer abide with them till the day of judgment.'

**[10:23]** And the Lord descended, and we descended with him to see the city and the tower which the children of men had built.

**[10:24]** And he confounded their language, and they no longer understood one another's speech, and they ceased then to build the city and the tower.

**[10:25]** For this reason the whole land of Shinar is called Babel, because the Lord did there confound all the language of the children of men, and from thence they were dispersed into their cities, each according to his language and his nation.

**[10:26]** And the Lord sent a mighty wind against the tower and overthrew it upon the earth, and behold it was between Asshur and Babylon in the land of Shinar, and they called its name 'Overthrow'.

**[10:27]** In the fourth week in the first year [1688 A.M.] in the beginning thereof in the four and thirtieth jubilee, were they dispersed from the land of Shinar.

**[10:28]** And Ham and his sons went into the land which he was to occupy, which he acquired as his portion in the land of the south.

**[10:29]** And Canaan saw the land of Lebanon to the river of Egypt, that it was very good, and he went not into the land of his inheritance to the west (that is to) the sea, and he dwelt in the land of Lebanon, eastward and westward from the border of Jordan and from the border of the sea.

**[10:30]** And Ham, his father, and Cush and Mizraim his brothers said unto him: 'Thou hast settled in a land which is not thine, and which did not fall to us by lot: do not do so; for if thou dost do so, thou and thy sons will fall in the land and (be) accursed through sedition; for by sedition ye have settled, and by sedition will thy children fall, and thou shalt be rooted out for ever.

**[10:31]** Dwell not in the dwelling of Shem; for to Shem and to his sons did it come by their lot.

**[10:32]** Cursed art thou, and cursed shalt thou be beyond all the sons of Noah, by the curse by which we bound ourselves by an oath in the presence of the holy judge, and in the presence of Noah our father.'

**[10:33]** But he did not harken unto them, and dwelt in the land of Lebanon from Hamath to the entering of Egypt, he and his sons until this day.

**[10:34]** And for this reason that land is named Canaan.

**[10:35]** And Japheth and his sons went towards the sea and dwelt in the land of their portion, and Madai saw the land of the sea and it did not please him, and he begged a (portion) from Ham and Asshur and Arpachshad, his wife's brother, and he dwelt in the land of Media, near to his wife's brother until this day.

**[10:36]** And he called his dwelling-place, and the dwelling-place of his sons, Media, after the name of their father Madai.

**[11:1]** And in the thirty-fifth jubilee, in the third week, in the first year [1681 A.M.] thereof, Reu took to himself a wife, and her name was 'Ôrâ, the daughter of 'Ûr, the son of Kesed, and she bare him a son, and he called his name Sêrôh, in the seventh year of this week in this jubilee. [1687 A.M.]

**[11:2]** And the sons of Noah began to war on each other, to take captive and to slay each other, and to shed the blood of men on the earth, and to eat blood, and to build strong cities, and walls, and towers, and individuals (began) to exalt themselves above the nation, and to found the beginnings of kingdoms, and to go to war people against people, and nation against nation, and city against city, and all (began) to do evil, and to acquire arms, and to teach their sons war, and they began to capture cities, and to sell male and female slaves.

**[11:3]** And 'Ûr, the son of Kesed, built the city of 'Ara of the Chaldees, and called its name after his own name and the name of his father. And they made for themselves molten images, and they worshipped each the idol, the molten image which they had made for themselves, and they began to make graven images and unclean simulacra, and malignant spirits assisted and seduced (them) into committing transgression and uncleanness.

**[11:4]** And the prince Mastêmâ exerted himself to do all this, and he sent forth other spirits, those which were put under his hand, to do all manner of wrong and sin, and all manner of transgression, to corrupt and destroy, and to shed blood upon the earth.

**[11:5]** For this reason he called the name of Sêrôh, Serug, for every one turned to do all manner of sin and transgression.

**[11:6]** And he grew up, and dwelt in Ur of the Chaldees, near to the father of his wife's mother, and he worshipped idols, and he took to himself a wife in the thirty-sixth jubilee, in the fifth week, in the first year thereof, [1744 A.M.] and her name was Melka, the daughter of Kaber, the daughter of his father's brother.

**[11:7]** And she bare him Nahor, in the first year of this week, and he grew and dwelt in Ur of the Chaldees, and his father taught him the researches of the Chaldees to divine and augur, according to the signs of heaven.

**[11:8]** And in the thirty-seventh jubilee in the sixth week, in the first year thereof, [1800 A.M.] he took to himself a wife, and her name was 'Ijaska, the daughter of Nestag of the Chaldees.

**[11:9]** And she bare him Terah in the seventh year of this week. [1806 A.M.]

**[11:10]** And the prince Mastêmâ sent ravens and birds to devour the seed which was sown in the land, in order to destroy the land, and rob the children of men of their labours. Before they could plough in the seed, the ravens picked (it) from the surface of the ground.

**[11:11]** And for this reason he called his name Terah because the ravens and the birds reduced them to destitution and devoured their seed.

**[11:12]** And the years began to be barren, owing to the birds, and they devoured all the fruit of the trees from the trees: it was only with great effort that they could save a little of all the fruit of the earth in their days.

**[11:13]** And in this thirty-ninth jubilee, in the second week in the first year, [1870 A.M.] Terah took to himself a wife, and her name was 'Edna, the daughter of 'Abram, the daughter of his father's sister. And in the seventh year of this week [1876 A.M.] she bare him a son, and he called his name Abram, by the name of the father of his mother;

**[11:14]** for he had died before his daughter had conceived a son.

**[11:15]** And the child began to understand the errors of the earth that all went astray after graven images and after uncleanness, and his father taught him writing, and he was two weeks of years old, [1890 A.M.] and he separated himself from his father, that he might not worship idols with him.

**[11:16]** And he began to pray to the Creator of all things that He might save him from the errors of the children of men, and that his portion should not fall into error after uncleanness and vileness.

**[11:17]** And the seed time came for the sowing of seed upon the land, and they all went forth together to protect their seed against the ravens, and Abram went forth with those that went, and the child was a lad of fourteen years.

**[11:18]** And a cloud of ravens came to devour the seed, and Abram ran to meet them before they settled on the ground, and cried to them before they settled on the ground to devour the seed, and said, ' Descend not: return to the place whence ye came,' and they proceeded to turn back.

**[11:19]** And he caused the clouds of ravens to turn back that day seventy times, and of all the ravens throughout all the land where Abram was there settled there not so much as one.

**[11:20]** And all who were with him throughout all the land saw him cry out, and all the ravens turn back, and his name became great in all the land of the Chaldees.

**[11:21]** And there came to him this year all those that wished to sow, and he went with them until the time of sowing ceased: and they sowed their land, and that year they brought enough grain home and eat and were satisfied.

**[11:22]** And in the first year of the fifth week [1891 A.M.] Abram taught those who made implements for oxen, the artificers in wood, and they made a vessel above the ground, facing the frame of the plough, in order to put the seed thereon, and the seed fell down therefrom upon the share of the plough, and was hidden in the earth, and they no longer feared the ravens.

**[11:23]** And after this manner they made (vessels) above the ground on all the frames of the ploughs, and they sowed and tilled all the land, according as Abram commanded them, and they no longer feared the birds.

**[12:1]** And it came to pass in the sixth week, in the seventh year thereof, [1904 A.M.] that Abram said to Terah his father, saying, 'Father!'

**[12:2]** And he said, 'Behold, here am I, my son.' And he said, 'What help and profit have we from those idols which thou dost worship, And before which thou dost bow thyself?

**[12:3]** For there is no spirit in them, For they are dumb forms, and a misleading of the heart. Worship them not:

**[12:4]** Worship the God of heaven, Who causes the rain and the dew to descend on the earth And does everything upon the earth, And has created everything by His word, And all life is from before His face.

**[12:5]** Why do ye worship things that have no spirit in them? For they are the work of (men's) hands, And on your shoulders do ye bear them, And ye have no help from them, But they are a great cause of shame to those who make them, And a misleading of the heart to those who worship them: Worship them not.'

**[12:6]** And his father said unto him, 'I also know it, my son, but what shall I do with a people who have made me to serve before them?

**[12:7]** And if I tell them the truth, they will slay me; for their soul cleaves to them to worship them and honour them.

**[12:8]** Keep silent, my son, lest they slay thee.' And these words he spake to his two brothers, and they were angry with him and he kept silent.

**[12:9]** And in the fortieth jubilee, in the second week, in the seventh year thereof, [1925 A.M.] Abram took to himself a wife, and her name was Sarai, the daughter of his father, and she became his wife.

**[12:10]** And Haran, his brother, took to himself a wife in the third year of the third week, [1928 A.M.] and she bare him a son in the seventh year of this week, [1932 A.M.] and he called his name Lot.

**[12:11]** And Nahor, his brother, took to himself a wife.

**[12:12]** And in the sixtieth year of the life of Abram, that is, in the fourth week, in the fourth year thereof, [1936 A.M.] Abram arose by night, and burned the house of the idols, and he burned all that was in the house and no man knew it.

**[12:13]** And they arose in the night and sought to save their gods from the midst of the fire.

**[12:14]** And Haran hasted to save them, but the fire flamed over him, and he was burnt in the fire, and he died in Ur of the Chaldees before Terah his father, and they buried him in Ur of the Chaldees.

**[12:15]** And Terah went forth from Ur of the Chaldees, he and his sons, to go into the land of Lebanon and into the land of Canaan, and he dwelt in the land of Haran, and Abram dwelt with Terah his father in Haran two weeks of years.

**[12:16]** And in the sixth week, in the fifth year thereof, [1951 A.M.] Abram sat up throughout the night on the new moon of the seventh month to observe the stars from the evening to the morning, in order to see what would be the character of the year with regard to the rains, and he was alone as he sat and observed.

**[12:17]** And a word came into his heart and he said: 'All the signs of the stars, and the signs of the moon and of the sun are all in the hand of the Lord. Why do I search (them) out?

**[12:18]** If He desires, He causes it to rain, morning and evening; And if He desires, He withholds it, And all things are in his hand.'

**[12:19]** And he prayed that night and said, 'My God, God Most High, Thou alone art my God, And Thee and Thy dominion have I chosen. And Thou hast created all things, And all things that are the work of thy hands.

**[12:20]** Deliver me from the hands of evil spirits who have dominion over the thoughts of men's hearts, And let them not lead me astray from Thee, my God. And stablish Thou me and my seed for ever That we go not astray from henceforth and for evermore.'

**[12:21]** And he said, 'Shall I return unto Ur of the Chaldees who seek my face that I may return to them, am I to remain here in this place? The right path before Thee prosper it in the hands of Thy servant that he may fulfil (it) and that I may not walk in the deceitfulness of my heart, O my God.'

**[12:22]** And he made an end of speaking and praying, and behold the word of the Lord was sent to him through me, saying: 'Get thee up from thy country, and from thy kindred and from the house of thy father unto a land which I will show thee, and I shall make thee a great and numerous nation.

**[12:23]** And I will bless thee And I will make thy name great, And thou shalt be blessed in the earth, And in Thee shall all families of the earth be blessed, And I will bless them that bless thee, And curse them that curse thee.

**[12:24]** And I will be a God to thee and thy son, and to thy son's son, and to all thy seed: fear not, from henceforth and unto all generations of the earth I am thy God.'

**[12:25]** And the Lord God said: 'Open his mouth and his ears, that he may hear and speak with his mouth, with the language which has been revealed'; for it had ceased from the mouths of all the children of men from the day of the overthrow (of Babel).

**[12:26]** And I opened his mouth, and his ears and his lips, and I began to speak with him in Hebrew in the tongue of the creation.

**[12:27]** And he took the books of his fathers, and these were written in Hebrew, and he transcribed them, and he began from henceforth to study them, and I made known to him that which he could not (understand), and he studied them during the six rainy months.

**[12:28]** And it came to pass in the seventh year of the sixth week [1953 A.M.] that he spoke to his father and informed him, that he would leave Haran to go into the land of Canaan to see it and return to him.

**[12:29]** And Terah his father said unto him; 'Go in peace: May the eternal God make thy path straight. And the Lord [(be) with thee, and] protect thee from all evil, And grant unto thee grace, mercy and favour before those who see thee, And may none of the children of men have power over thee to harm thee; Go in peace.

**[12:30]** And if thou seest a land pleasant to thy eyes to dwell in, then arise and take me to thee and take Lot with thee, the son of Haran thy brother as thine own son: the Lord be with thee.

**[12:31]** And Nahor thy brother leave with me till thou returnest in peace, and we go with thee all together.'

**[13:1]** And Abram journeyed from Haran, and he took Sarai, his wife, and Lot, his brother Haran's son, to the land of Canaan, and he came into Asshur, and proceeded to Shechem, and dwelt near a lofty oak.

**[13:2]** And he saw, and, behold, the land was very pleasant from the entering of Hamath to the lofty oak.

**[13:3]** And the Lord said to him: 'To thee and to thy seed will I give this land.'

**[13:4]** And he built an altar there, and he offered thereon a burnt sacrifice to the Lord, who had appeared to him.

**[13:5]** And he removed from thence unto the mountain . . . Bethel on the west and Ai on the east, and pitched his tent there.

**[13:6]** And he saw and behold, the land was very wide and good, and everything grew thereon -vines and figs and pomegranates, oaks and ilexes, and terebinths and oil trees, and cedars and cypresses and date trees, and all trees of the field, and there was water on the mountains.

**[13:7]** And he blessed the Lord who had led him out of Ur of the Chaldees, and had brought him to this land.

**[13:8]** And it came to pass in the first year, in the seventh week, on the new moon of the first month, 1954 A.M.] that he built an altar on this mountain, and called on the name of the Lord: 'Thou, the eternal God, art my God.'

**[13:9]** And he offered on the altar a burnt sacrifice unto the Lord that He should be with him and not forsake him all the days of his life.

**[13:10]** And he removed from thence and went towards the south, and he came to Hebron and Hebron was built at that time, and he dwelt there two years, and he went (thence) into the land of the south, to Bealoth, and there was a famine in the land.

**[13:11]** And Abram went into Egypt in the third year of the week, and he dwelt in Egypt five years before his wife was torn away from him.

**[13:12]** Now Tanais in Egypt was at that time built- seven years after Hebron.

**[13:13]** And it came to pass when Pharaoh seized Sarai, the wife of Abram that the Lord plagued Pharaoh and his house with great plagues because of Sarai, Abram's wife.

**[13:14]** And Abram was very glorious by reason of possessions in sheep, and cattle, and asses, and horses, and camels, and menservants, and maidservants, and in silver and gold exceedingly. And Lot also his brother's son, was wealthy.

**[13:15]** And Pharaoh gave back Sarai, the wife of Abram, and he sent him out of the land of Egypt, and he journeyed to the place where he had pitched his tent at the beginning, to the place of the altar, with Ai on the east, and Bethel on the west, and he blessed the Lord his God who had brought him back in peace.

**[13:16]** And it came to pass in the forty-first jubilee in the third year of the first week, [1963 A.M.] that he returned to this place and offered thereon a burnt sacrifice, and called on the name of the Lord, and said: 'Thou, the most high God, art my God for ever and ever.'

**[13:17]** And in the fourth year of this week [1964 A.M.] Lot parted from him, and Lot dwelt in Sodom, and the men of Sodom were sinners exceedingly.

**[13:18]** And it grieved him in his heart that his brother's son had parted from him; for he had no children.

**[13:19]** In that year when Lot was taken captive, the Lord said unto Abram, after that Lot had parted from him, in the fourth year of this week: 'Lift up thine eyes from the place where thou art dwelling, northward and southward, and westward and eastward.

**[13:20]** For all the land which thou seest I will give to thee and to thy seed for ever, and I will make thy seed as the sand of the sea: though a man may number the dust of the earth, yet thy seed shall not be numbered.

**[13:21]** Arise, walk (through the land) in the length of it and the breadth of it, and see it all; for to thy seed will I give it.' And Abram went to Hebron, and dwelt there.

**[13:22]** And in this year came Chedorlaomer, king of Elam, and Amraphel, king of Shinar, and Arioch king of Sellasar, and Tergal, king of nations, and slew the king of Gomorrah, and the king of Sodom fled, and many fell through wounds in the vale of Siddim, by the Salt Sea.

**[13:23]** And they took captive Sodom and Adam and Zeboim, and they took captive Lot also, the son of Abram's brother, and all his possessions, and they went to Dan.

**[13:24]** And one who had escaped came and told Abram that his brother's son had been taken captive and (Abram) armed his household servants . . .

**[13:25]** . . . . for Abram, and for his seed, a tenth of the first fruits to the Lord, and the Lord ordained it as an ordinance for ever that they should give it to the priests who served before Him, that they should possess it for ever.

**[13:26]** And to this law there is no limit of days; for He hath ordained it for the generations for ever that they should give to the Lord the tenth of everything, of the seed and of the wine and of the oil and of the cattle and of the sheep.

**[13:27]** And He gave (it) unto His priests to eat and to drink with joy before Him.

**[13:28]** And the king of Sodom came to him and bowed himself before him, and said: 'Our Lord Abram, give unto us the souls which thou hast rescued, but let the booty be thine.'

**[13:29]** And Abram said unto him: 'I lift up my hands to the Most High God, that from a thread to a shoe-latchet I shall not take aught that is thine lest thou shouldst say, I have made Abram rich; save only what the young men have eaten, and the portion of the men who went with me -Aner, Eschol, and Mamre. These shall take their portion.'

**[14:1]** After these things, in the fourth year of this week, on the new moon of the third month, the word of the Lord came to Abram in a dream, saying: 'Fear not, Abram; I am thy defender, and thy reward will be exceeding great.'

**[14:2]** And he said: 'Lord, Lord, what wilt thou give me, seeing I go hence childless, and the son of Maseq, the son of my handmaid, is the Dammasek Eliezer: he will be my heir, and to me thou hast given no seed.'

**[14:3]** And he said unto him: 'This (man) will not be thy heir, but one that will come out of thine own bowels; he will be thine heir.'

**[14:4]** And He brought him forth abroad, and said unto him: 'Look toward heaven and number the stars if thou art able to number them.'

**[14:5]** And he looked toward heaven, and beheld the stars. And He said unto him: 'So shall thy seed be.'

**[14:6]** And he believed in the Lord, and it was counted to him for righteousness.

**[14:7]** And He said unto him: 'I am the Lord that brought thee out of Ur of the Chaldees, to give thee the land of the Canaanites to possess it for ever; and I will be God unto thee and to thy seed after thee.'

**[14:8]** And he said: 'Lord, Lord, whereby shall I know that I shall inherit (it)?'

**[14:9]** And He said unto him: 'Take Me an heifer of three years, and a goat of three years, and a sheep of three years, and a turtle-dove, and a pigeon.'

**[14:10]** And he took all these in the middle of the month and he dwelt at the oak of Mamre, which is near Hebron.

**[14:11]** And he built there an altar, and sacrificed all these; and he poured their blood upon the altar, and divided them in the midst, and laid them over against each other; but the birds divided he not.

**[14:12]** And birds came down upon the pieces, and Abram drove them away, and did not suffer the birds to touch them.

**[14:13]** And it came to pass, when the sun had set, that an ecstasy fell upon Abram, and lo ! an horror of great darkness fell upon him, and it was said unto Abram: 'Know of a surety that thy seed shall be a stranger in a land (that is) not theirs, and they shall bring them into bondage, and afflict them four hundred years.

**[14:14]** And the nation also to whom they will be in bondage will I judge, and after that they shall come forth thence with much substance.

**[14:15]** And thou shalt go to thy fathers in peace, and be buried in a good old age.

**[14:16]** But in the fourth generation they shall return hither; for the iniquity of the Amorites is not yet full.'

**[14:17]** And he awoke from his sleep, and he arose, and the sun had set; and there was a flame, and behold ! a furnace was smoking, and a flame of fire passed between the pieces.

**[14:18]** And on that day the Lord made a covenant with Abram, saying: 'To thy seed will I give this land, from the river of Egypt unto the great river, the river Euphrates, the Kenites, the Kenizzites, the Kadmonites, the Perizzites, and the Rephaim, the Phakorites, and the Hivites, and the Amorites, and the Canaanites, and the Girgashites, and the Jebusites.

**[14:19]** And the day passed, and Abram offered the pieces, and the birds, and their fruit offerings, and their drink offerings, and the fire devoured them.

**[14:20]** And on that day we made a covenant with Abram, according as we had covenanted with Noah in this month; and Abram renewed the festival and ordinance for himself for ever.

**[14:21]** And Abram rejoiced, and made all these things known to Sarai his wife; and he believed that he would have seed, but she did not bear.

**[14:22]** And Sarai advised her husband Abram, and said unto him: 'Go in unto Hagar, my Egyptian maid: it may be that I shall build up seed unto thee by her.'

**[14:23]** And Abram harkened unto the voice of Sarai his wife, and said unto her, 'Do (so).' And Sarai took Hagar, her maid, the Egyptian, and gave her to Abram, her husband, to be his wife.

**[14:24]** And he went in unto her, and she conceived and bare him a son, and he called his name Ishmael, in the fifth year of this week [1965 A.M.]; and this was the eighty-sixth year in the life of Abram.

**[15:1]** And in the fifth year of the fourth week of this jubilee, [1979 A.M.] in the third month, in the middle of the month, Abram celebrated the feast of the first-fruits of the grain harvest.

**[15:2]** And he offered new offerings on the altar, the first-fruits of the produce, unto the Lord, an heifer and a goat and a sheep on the altar as a burnt sacrifice unto the Lord; their fruit offerings and their drink offerings he offered upon the altar with frankincense.

**[15:3]** And the Lord appeared to Abram, and said unto him: 'I am God Almighty; approve thyself before me and be thou perfect.

**[15:4]** And I will make My covenant between Me and thee, and I will multiply thee exceedingly.'

**[15:5]** And Abram fell on his face, and God talked with him, and said:

**[15:6]** 'Behold my ordinance is with thee, And thou shalt be the father of many nations.

**[15:7]** Neither shall thy name any more be called Abram, But thy name from henceforth, even for ever, shall be Abraham. For the father of many nations have I made thee.

**[15:8]** And I will make thee very great, And I will make thee into nations, And kings shall come forth from thee.

**[15:9]** And I shall establish My covenant between Me and thee, and thy seed after thee, throughout their generations, for an eternal covenant, so that I may be a God unto thee, and to thy seed after thee.

**[15:10]** <And I will give to thee and to thy seed after thee> the land where thou hast been a sojourner, the land of Canaan, that thou mayst possess it for ever, and I will be their God.'

**[15:11]** And the Lord said unto Abraham: 'And as for thee, do thou keep my covenant, thou and thy seed after thee: and circumcise ye every male among you, and circumcise your foreskins, and it shall be a token of an eternal covenant between Me and you.

**[15:12]** And the child on the eighth day ye shall circumcise, every male throughout your generations, him that is born in the house, or whom ye have bought with money from any stranger, whom ye have acquired who is not of thy seed.

**[15:13]** He that is born in thy house shall surely be circumcised, and those whom thou hast bought with money shall be circumcised, and My covenant shall be in your flesh for an eternal ordinance.

**[15:14]** And the uncircumcised male who is not circumcised in the flesh of his foreskin on the eighth day, that soul shall be cut off from his people, for he has broken My covenant.'

**[15:15]** And God said unto Abraham: 'As for Sarai thy wife, her name shall no more be called Sarai, but Sarah shall be her name.

**[15:16]** And I will bless her, and give thee a son by her, and I will bless him, and he shall become a nation, and kings of nations shall proceed from him.'

**[15:17]** And Abraham fell on his face, and rejoiced, and said in his heart: 'Shall a son be born to him that is a hundred years old, and shall Sarah, who is ninety years old, bring forth?'

**[15:18]** And Abraham said unto God: 'O that Ishmael might live before thee!'

**[15:19]** And God said: 'Yea, and Sarah also shall bear thee a son, and thou shalt call his name Isaac, and I will establish My covenant with him, an everlasting covenant, and for his seed after him.

**[15:20]** And as for Ishmael also have I heard thee, and behold I will bless him, and make him great, and multiply him exceedingly, and he shall beget twelve princes, and I will make him a great nation.

**[15:21]** But My covenant will I establish with Isaac, whom Sarah shall bear to thee, in these days, in the next year.'

**[15:22]** And He left off speaking with him, and God went up from Abraham.

**[15:23]** And Abraham did according as God had said unto him, and he took Ishmael his son, and all that were born in his house, and whom he had bought with his money, every male in his house, and circumcised the flesh of their foreskin.

**[15:24]** And on the selfsame day was Abraham circumcised, and all the men of his house, <and those born in the house>, and all those, whom he had bought with money from the children of the stranger, were circumcised with him.

**[15:25]** This law is for all the generations for ever, and there is no circumcision of the days, and no omission of one day out of the eight days; for it is an eternal ordinance, ordained and written on the heavenly tablets.

**[15:26]** And every one that is born, the flesh of whose foreskin is not circumcised on the eighth day, belongs not to the children of the covenant which the Lord made with Abraham, but to the children of destruction; nor is there, moreover, any sign on him that he is the Lord's, but (he is destined) to be destroyed and slain from the earth, and to be rooted out of the earth, for he has broken the covenant of the Lord our God.

**[15:27]** For all the angels of the presence and all the angels of sanctification have been so created from the day of their creation, and before the angels of the presence and the angels of sanctification He hath sanctified Israel, that they should be with Him and with His holy angels.

**[15:28]** And do thou command the children of Israel and let them observe the sign of this covenant for their generations as an eternal ordinance, and they will not be rooted out of the land.

**[15:29]** For the command is ordained for a covenant, that they should observe it for ever among all the children of Israel.

**[15:30]** For Ishmael and his sons and his brothers and Esau, the Lord did not cause to approach Him, and he chose them not because they are the children of Abraham, because He knew them, but He chose Israel to be His people.

**[15:31]** And He sanctified it, and gathered it from amongst all the children of men; for there are many nations and many peoples, and all are His, and over all hath He placed spirits in authority to lead them astray from Him.

**[15:32]** But over Israel He did not appoint any angel or spirit, for He alone is their ruler, and He will preserve them and require them at the hand of His angels and His spirits, and at the hand of all His powers in order that He may preserve them and bless them, and that they may be His and He may be theirs from henceforth for ever.

**[15:33]** And now I announce unto thee that the children of Israel will not keep true to this ordinance, and they will not circumcise their sons according to all this law; for in the flesh of their circumcision they will omit this circumcision of their sons, and all of them, sons of Beliar, will leave their sons uncircumcised as they were born.

**[15:34]** And there will be great wrath from the Lord against the children of Israel. because they have forsaken His covenant and turned aside from His word, and provoked and blasphemed, inasmuch as they do not observe the ordinance of this law; for they have treated their members like the Gentiles, so that they may be removed and rooted out of the land. And there will no more be pardon or forgiveness unto them [so that there should be forgiveness and pardon] for all the sin of this eternal error.

**[16:1]** And on the new moon of the fourth month we appeared unto Abraham, at the oak of Mamre, and we talked with him, and we announced to him that a son would be given to him by Sarah his wife.

**[16:2]** And Sarah laughed, for she heard that we had spoken these words with Abraham, and we admonished her, and she became afraid, and denied that she had laughed on account of the words.

**[16:3]** And we told her the name of her son, as his name is ordained and written in the heavenly tablets (i.e.) Isaac,

**[16:4]** And (that) when we returned to her at a set time, she would have conceived a son.

**[16:5]** And in this month the Lord executed his judgments on Sodom, and Gomorrah, and Zeboim, and all the region of the Jordan, and He burned them with fire and brimstone, and destroyed them until this day, even as [lo] I have declared unto thee all their works, that they are wicked and sinners exceedingly, and that they defile themselves and commit fornication in their flesh, and work uncleanness on the earth.

**[16:6]** And, in like manner, God will execute judgment on the places where they have done according to the uncleanness of the Sodomites, like unto the judgment of Sodom.

**[16:7]** But Lot we saved; for God remembered Abraham, and sent him out from the midst of the overthrow.

**[16:8]** And he and his daughters committed sin upon the earth, such as had not been on the earth since the days of Adam till his time; for the man lay with his daughters.

**[16:9]** And, behold, it was commanded and engraven concerning all his seed, on the heavenly tablets, to remove them and root them out, and to execute judgment upon them like the judgment of Sodom, and to leave no seed of the man on earth on the day of condemnation.

**[16:10]** And in this month Abraham moved from Hebron, and departed and dwelt between Kadesh and Shur in the mountains of Gerar.

**[16:11]** And in the middle of the fifth month he moved from thence, and dwelt at the Well of the Oath.

**[16:12]** And in the middle of the sixth month the Lord visited Sarah and did unto her as He had spoken and she conceived.

**[16:13]** And she bare a son in the third month, and in the middle of the month, at the time of which the Lord had spoken to Abraham, on the festival of the first fruits of the harvest, Isaac was born.

**[16:14]** And Abraham circumcised his son on the eighth day: he was the first that was circumcised according to the covenant which is ordained for ever.

**[16:15]** And in the sixth year of the fourth week we came to Abraham, to the Well of the Oath, and we appeared unto him [as we had told Sarah that we should return to her, and she would have conceived a son.

**[16:16]** And we returned in the seventh month, and found Sarah with child before us] and we blessed him, and we announced to him all the things which had been decreed concerning him, that he should not die till he should beget six sons more, and should see (them) before he died; but (that) in Isaac should his name and seed be called:

**[16:17]** And (that) all the seed of his sons should be Gentiles, and be reckoned with the Gentiles; but from the sons of Isaac one should become a holy seed, and should not be reckoned among the Gentiles.

**[16:18]** For he should become the portion of the Most High, and all his seed had fallen into the possession of God, that it should be unto the Lord a people for (His) possession above all nations and that it should become a kingdom and priests and a holy nation.

**[16:19]** And we went our way, and we announced to Sarah all that we had told him, and they both rejoiced with exceeding great joy.

**[16:20]** And he built there an altar to the Lord who had delivered him, and who was making him rejoice in the land of his sojourning, and he celebrated a festival of joy in this month seven days, near the altar which he had built at the Well of the Oath.

**[16:21]** And he built booths for himself and for his servants on this festival, and he was the first to celebrate the feast of tabernacles on the earth.

**[16:22]** And during these seven days he brought each day to the altar a burnt offering to the Lord, two oxen, two rams, seven sheep, one he-goat, for a sin offering, that he might atone thereby for himself and for his seed.

**[16:23]** And, as a thank-offering, seven rams, seven kids, seven sheep, and seven he-goats, and their fruit offerings and their drink offerings; and he burnt all the fat thereof on the altar, a chosen offering unto the Lord for a sweet smelling savour.

**[16:24]** And morning and evening he burnt fragrant substances, frankincense and galbanum, and stackte, and nard, and myrrh, and spice, and costum; all these seven he offered, crushed, mixed together in equal parts (and) pure.

**[16:25]** And he celebrated this feast during seven days, rejoicing with all his heart and with all his soul, he and all those who were in his house, and there was no stranger with him, nor any that was uncircumcised.

**[16:26]** And he blessed his Creator who had created him in his generation, for He had created him according to His good pleasure; for He knew and perceived that from him would arise the plant of righteousness for the eternal generations, and from him a holy seed, so that it should become like Him who had made all things.

**[16:27]** And he blessed and rejoiced, and he called the name of this festival the festival of the Lord, a joy acceptable to the Most High God.

**[16:28]** And we blessed him for ever, and all his seed after him throughout all the generations of the earth, because he celebrated this festival in its season, according to the testimony of the heavenly tablets.

**[16:29]** For this reason it is ordained on the heavenly tablets concerning Israel, that they shall celebrate the feast of tabernacles seven days with joy, in the seventh month, acceptable before the Lord -a statute for ever throughout their generations every year.

**[16:30]** And to this there is no limit of days; for it is ordained for ever regarding Israel that they should celebrate it and dwell in booths, and set wreaths upon their heads, and take leafy boughs, and willows from the brook.

**[16:31]** And Abraham took branches of palm trees, and the fruit of goodly trees, and every day going round the altar with the branches seven times [a day] in the morning, he praised and gave thanks to his God for all things in joy.

**[17:1]** And in the first year of the fifth week Isaac was weaned in this jubilee, [1982 A.M.] and Abraham made a great banquet in the third month, on the day his son Isaac was weaned.

**[17:2]** And Ishmael, the son of Hagar, the Egyptian, was before the face of Abraham, his father, in his place, and Abraham rejoiced and blessed God because he had seen his sons and had not died childless.

**[17:3]** And he remembered the words which He had spoken to him on the day on which Lot had parted from him, and he rejoiced because the Lord had given him seed upon the earth to inherit the earth, and he blessed with all his mouth the Creator of all things.

**[17:4]** And Sarah saw Ishmael playing and dancing, and Abraham rejoicing with great joy, and she became jealous of Ishmael and said to Abraham, 'Cast out this bondwoman and her son; for the son of this bondwoman will not be heir with my son, Isaac.'

**[17:5]** And the thing was grievous in Abraham's sight, because of his maidservant and because of his son, that he should drive them from him.

**[17:6]** And God said to Abraham 'Let it not be grievous in thy sight, because of the child and because of the bondwoman; in all that Sarah hath said unto thee, harken to her words and do (them); for in Isaac shall thy name and seed be called.

**[17:7]** But as for the son of this bondwoman I will make him a great nation, because he is of thy seed.'

**[17:8]** And Abraham rose up early in the morning, and took bread and a bottle of water, and placed them on the shoulders of Hagar and the child, and sent her away.

**[17:9]** And she departed and wandered in the wilderness of Beersheba, and the water in the bottle was spent, and the child thirsted, and was not able to go on, and fell down.

**[17:10]** And his mother took him and cast him under an olive tree, and went and sat her down over against him, at the distance of a bow-shot; for she said, 'Let me not see the death of my child,' and as she sat she wept.

**[17:11]** And an angel of God, one of the holy ones, said unto her, 'Why weepest thou, Hagar? Arise take the child, and hold him in thine hand; for God hath heard thy voice, and hath seen the child.'

**[17:12]** And she opened her eyes, and she saw a well of water, and she went and filled her bottle with water, and she gave her child to drink, and she arose and went towards the wilderness of Paran.

**[17:13]** And the child grew and became an archer, and God was with him, and his mother took him a wife from among the daughters of Egypt.

**[17:14]** And she bare him a son, and he called his name Nebaioth; for she said, 'The Lord was nigh to me when I called upon him.'

**[17:15]** And it came to pass in the seventh week, in the first year thereof, [2003 A.M.] in the first month in this jubilee, on the twelfth of this month, there were voices in heaven regarding Abraham, that he was faithful in all that He told him, and that he loved the Lord, and that in every affliction he was faithful.

**[17:16]** And the prince Mastêmâ came and said before God, 'Behold, Abraham loves Isaac his son, and he delights in him above all things else; bid him offer him as a burnt-offering on the altar, and Thou wilt see if he will do this command, and Thou wilt know if he is faithful in everything wherein Thou dost try him.

**[17:17]** And the Lord knew that Abraham was faithful in all his afflictions; for He had tried him through his country and with famine, and had tried him with the wealth of kings, and had tried him again through his wife, when she was torn (from him), and with circumcision; and had tried him through Ishmael and Hagar, his maid-servant, when he sent them away.

**[17:18]** And in everything wherein He had tried him, he was found faithful, and his soul was not impatient, and he was not slow to act; for he was faithful and a lover of the Lord.

**[18:1]** And God said to him, 'Abraham, Abraham'; and he said, 'Behold, (here) am I.'

**[18:2]** And he said, 'Take thy beloved son whom thou lovest, (even) Isaac, and go unto the high country, and offer him on one of the mountains which I will point out unto thee.'

**[18:3]** And he rose early in the morning and saddled his ass, and took his two young men with him, and Isaac his son, and clave the wood of the burnt offering, and he went to the place on the third day, and he saw the place afar off.

**[18:4]** And he came to a well of water, and he said to his young men, 'Abide ye here with the ass, and I and the lad shall go (yonder), and when we have worshipped we shall come again to you.'

**[18:5]** And he took the wood of the burnt-offering and laid it on Isaac his son, and he took in his hand the fire and the knife, and they went both of them together to that place.

**[18:6]** And Isaac said to his father, 'Father;' and he said, 'Here am I, my son.' And he said unto him, 'Behold the fire, and the knife, and the wood; but where is the sheep for the burnt-offering, father?'

**[18:7]** And he said, 'God will provide for himself a sheep for a burnt-offering, my son.' And he drew near to the place of the mount of God.

**[18:8]** And he built an altar, and he placed the wood on the altar, and bound Isaac his son, and placed him on the wood which was upon the altar, and stretched forth his hand to take the knife to slay Isaac his son.

**[18:9]** And I stood before him, and before the prince Mastêmâ, and the Lord said, 'Bid him not to lay his hand on the lad, nor to do anything to him, for I have shown that he fears the Lord.'

**[18:10]** And I called to him from heaven, and said unto him: 'Abraham, Abraham;' and he was terrified and said: 'Behold, (here) am I.'

**[18:11]** And I said unto him: 'Lay not thy hand upon the lad, neither do thou anything to him; for now I have shown that thou fearest the Lord, and hast not withheld thy son, thy first-born son, from me.'

**[18:12]** And the prince Mastêmâ was put to shame; and Abraham lifted up his eyes and looked, and, behold a ram caught . . . by his horns, and Abraham went and took the ram and offered it for a burnt-offering in the stead of his son.

**[18:13]** And Abraham called that place 'The Lord hath seen', so that it is said in the mount the Lord hath seen: that is Mount Sion.

**[18:14]** And the Lord called Abraham by his name a second time from heaven, as he caused us to appear to speak to him in the name of the Lord.

**[18:15]** And he said: 'By Myself have I sworn, saith the Lord, Because thou hast done this thing, And hast not withheld thy son, thy beloved son, from Me, That in blessing I will bless thee, And in multiplying I will multiply thy seed As the stars of heaven, And as the sand which is on the seashore. And thy seed shall inherit the cities of its enemies,

**[18:16]** And in thy seed shall all nations of the earth be blessed; Because thou hast obeyed My voice, And I have shown to all that thou art faithful unto Me in all that I have said unto thee: Go in peace.'

**[18:17]** And Abraham went to his young men, and they arose and went together to Beersheba, and Abraham [2010 A.M.] dwelt by the Well of the Oath.

**[18:18]** And he celebrated this festival every year, seven days with joy, and he called it the festival of the Lord according to the seven days during which he went and returned in peace.

**[18:19]** And accordingly has it been ordained and written on the heavenly tablets regarding Israel and its seed that they should observe this festival seven days with the joy of festival.

**[19:1]** And in the first year of the first week in the forty-second jubilee, Abraham returned and dwelt opposite Hebron, that is Kirjath Arba, two weeks of years.

**[19:2]** And in the first year of the third week of this jubilee the days of the life of Sarah were accomplished, and she died in Hebron.

**[19:3]** And Abraham went to mourn over her and bury her, and we tried him [to see] if his spirit were patient and he were not indignant in the words of his mouth; and he was found patient in this, and was not disturbed.

**[19:4]** For in patience of spirit he conversed with the children of Heth, to the intent that they should give him a place in which to bury his dead.

**[19:5]** And the Lord gave him grace before all who saw him, and he besought in gentleness the sons of Heth, and they gave him the land of the double cave over against Mamre, that is Hebron, for four hundred pieces of silver.

**[19:6]** And they besought him saying, We shall give it to thee for nothing; but he would not take it from their hands for nothing, for he gave the price of the place, the money in full, and he bowed down before them twice, and after this he buried his dead in the double cave.

**[19:7]** And all the days of the life of Sarah were one hundred and twenty-seven years, that is, two jubilees and four weeks and one year: these are the days of the years of the life of Sarah.

**[19:8]** This is the tenth trial wherewith Abraham was tried, and he was found faithful, patient in spirit.

**[19:9]** And he said not a single word regarding the rumour in the land how that God had said that He would give it to him and to his seed after him, and he begged a place there to bury his dead; for he was found faithful, and was recorded on the heavenly tablets as the friend of God.

**[19:10]** And in the fourth year thereof he took a wife for his son Isaac and her name was Rebecca [2020 A.M.] [the daughter of Bethuel, the son of Nahor, the brother of Abraham] the sister of Laban and daughter of Bethuel; and Bethuel was the son of Melca, who was the wife of Nahor, the brother of Abraham.

**[19:11]** And Abraham took to himself a third wife, and her name was Keturah, from among the daughters of his household servants, for Hagar had died before Sarah. And she bare him six sons, Zimram, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah, in the two weeks of years.

**[19:12]** And in the sixth week, in the second year thereof, Rebecca bare to Isaac two sons, Jacob and Esau,

**[19:13]** and [2046 A.M.] Jacob was a smooth and upright man, and Esau was fierce, a man of the field, and hairy, and Jacob dwelt in tents.

**[19:14]** And the youths grew, and Jacob learned to write; but Esau did not learn, for he was a man of the field and a hunter, and he learnt war, and all his deeds were fierce.

**[19:15]** And Abraham loved Jacob, but Isaac loved Esau.

**[19:16]** And Abraham saw the deeds of Esau, and he knew that in Jacob should his name and seed be called; and he called Rebecca and gave commandment regarding Jacob, for he knew that she (too) loved Jacob much more than Esau.

**[19:17]** And he said unto her: My daughter, watch over my son Jacob, For he shall be in my stead on the earth, And for a blessing in the midst of the children of men, And for the glory of the whole seed of Shem.

**[19:18]** For I know that the Lord will choose him to be a people for possession unto Himself, above all peoples that are upon the face of the earth.

**[19:19]** And behold, Isaac my son loves Esau more than Jacob, but I see that thou truly lovest Jacob.

**[19:20]** Add still further to thy kindness to him, And let thine eyes be upon him in love; For he shall be a blessing unto us on the earth from henceforth unto all generations of the earth.

**[19:21]** Let thy hands be strong And let thy heart rejoice in thy son Jacob; For I have loved him far beyond all my sons. He shall be blessed for ever, And his seed shall fill the whole earth.

**[19:22]** If a man can number the sand of the earth, His seed also shall be numbered.

**[19:23]** And all the blessings wherewith the Lord hath blessed me and my seed shall belong to Jacob and his seed alway.

**[19:24]** And in his seed shall my name be blessed, and the name of my fathers, Shem, and Noab, and Enoch, and Mahalalel, and Enos, and Seth, and Adam.

**[19:25]** And these shall serve To lay the foundations of the heaven, And to strengthen the earth, And to renew all the luminaries which are in the firmament.

**[19:26]** And he called Jacob before the eyes of Rebecca his mother, and kissed him, and blessed him, and said:

**[19:27]** 'Jacob, my beloved son, whom my soul loveth, may God bless thee from above the firmament, and may He give thee all the blessings wherewith He blessed Adam, and Enoch, and Noah, and Shem; and all the things of which He told me, and all the things which He promised to give me, may he cause to cleave to thee and to thy seed for ever, according to the days of heaven above the earth.

**[19:28]** And the Spirits of Mastêmâ shall not rule over thee or over thy seed to turn thee from the Lord, who is thy God from henceforth for ever.

**[19:29]** And may the Lord God be a father to thee and thou the first-born son, and to the people alway.

**[19:30]** Go in peace, my son.' And they both went forth together from Abraham.

**[19:31]** And Rebecca loved Jacob, with all her heart and with all her soul, very much more than Esau; but Isaac loved Esau much more than Jacob.

**[20:1]** And in the forty-second jubilee, in the first year of the seventh week, Abraham called Ishmael, [2052 (2045?) A.M.] and his twelve sons, and Isaac and his two sons, and the six sons of Keturah, and their sons.

**[20:2]** And he commanded them that they should observe the way of the Lord; that they should work righteousness, and love each his neighbour, and act on this manner amongst all men; that they should each so walk with regard to them as to do judgment and righteousness on the earth.

**[20:3]** That they should circumcise their sons, according to the covenant which He had made with them, and not deviate to the right hand or the left of all the paths which the Lord had commanded us; and that we should keep ourselves from all fornication and uncleanness, [and renounce from amongst us all fornication and uncleanness].

**[20:4]** And if any woman or maid commit fornication amongst you, burn her with fire and let them not commit fornication with her after their eyes and their heart; and let them not take to themselves wives from the daughters of Canaan; for the seed of Canaan will be rooted out of the land.

**[20:5]** And he told them of the judgment of the giants, and the judgment of the Sodomites, how they had been judged on account of their wickedness, and had died on account of their fornication, and uncleanness, and mutual corruption through fornication.

**[20:6]** 'And guard yourselves from all fornication and uncleanness, And from all pollution of sin, Lest ye make our name a curse, And your whole life a hissing, And all your sons to be destroyed by the sword, And ye become accursed like Sodom, And all your remnant as the sons of Gomorrah.

**[20:7]** I implore you, my sons, love the God of heaven And cleave ye to all His commandments. And walk not after their idols, and after their uncleannesses,

**[20:8]** And make not for yourselves molten or graven gods; For they are vanity, And there is no spirit in them; For they are work of (men's) hands, And all who trust in them, trust in nothing.

**[20:9]** Serve them not, nor worship them, But serve ye the most high God, and worship Him continually: And hope for His countenance always, And work uprightness and righteousness before Him, That He may have pleasure in you and grant you His mercy, And send rain upon you morning and evening, And bless all your works which ye have wrought upon the earth, And bless thy bread and thy water, And bless the fruit of thy womb and the fruit of thy land, And the herds of thy cattle, and the flocks of thy sheep.

**[20:10]** And ye will be for a blessing on the earth, And all nations of the earth will desire you, And bless your sons in my name, That they may be blessed as I am.

**[20:11]** And he gave to Ishmael and to his sons, and to the sons of Keturah, gifts, and sent them away from Isaac his son, and he gave everything to Isaac his son.

**[20:12]** And Ishmael and his sons, and the sons of Keturah and their sons, went together and dwelt from Paran to the entering in of Babylon in all the land which is towards the East facing the desert.

**[20:13]** And these mingled with each other, and their name was called Arabs, and Ishmaelites.

**[21:1]** And in the sixth year of the seventh week of this jubilee Abraham called Isaac his son, and [2057 (2050?) A.M.] commanded him: saying, 'I am become old, and know not the day of my death, and am full of my days.

**[21:2]** And behold, I am one hundred and seventy-five years old, and throughout all the days of my life I have remembered the Lord, and sought with all my heart to do His will, and to walk uprightly in all His ways.

**[21:3]** My soul has hated idols, <and I have despised those that served them, and I have given my heart and spirit> that I might observe to do the will of Him who created me.

**[21:4]** For He is the living God, and He is holy and faithful, and He is righteous beyond all, and there is with Him no accepting of (men's) persons and no accepting of gifts; for God is righteous, and executeth judgment on all those who transgress His commandments and despise His covenant.

**[21:5]** And do thou, my son, observe His commandments and His ordinances and His judgments, and walk not after the abominations and after the graven images and after the molten images.

**[21:6]** And eat no blood at all of animals or cattle, or of any bird which flies in the heaven.

**[21:7]** And if thou dost slay a victim as an acceptable peace offering, slay ye it, and pour out its blood upon the altar, and all the fat of the offering offer on the altar with fine flour and the meat offering mingled with oil, with its drink offering -offer them all together on the altar of burnt offering; it is a sweet savour before the Lord.

**[21:8]** And thou wilt offer the fat of the sacrifice of thank offerings on the fire which is upon the altar, and the fat which is on the belly, and all the fat on the inwards and the two kidneys, and all the fat that is upon them, and upon the loins and liver thou shalt remove, together with the kidneys.

**[21:9]** And offer all these for a sweet savour acceptable before the Lord, with its meat-offering and with its drink- offering, for a sweet savour, the bread of the offering unto the Lord.

**[21:10]** And eat its meat on that day and on the second day, and let not the sun on the second day go down upon it till it is eaten, and let nothing be left over for the third day; for it is not acceptable [for it is not approved] and let it no longer be eaten, and all who eat thereof will bring sin upon themselves; for thus I have found it written in the books of my forefathers, and in the words of Enoch, and in the words of Noah.

**[21:11]** And on all thy oblations thou shalt strew salt, and let not the salt of the covenant be lacking in all thy oblations before the Lord.

**[21:12]** And as regards the wood of the sacrifices, beware lest thou bring (other) wood for the altar in addition to these: cypress, bay, almond, fir, pine, cedar, savin, fig, olive, myrrh, laurel, aspalathus.

**[21:13]** And of these kinds of wood lay upon the altar under the sacrifice, such as have been tested as to their appearance, and do not lay (thereon) any split or dark wood, (but) hard and clean, without fault, a sound and new growth; and do not lay (thereon) old wood, [for its fragrance is gone] for there is no longer fragrance in it as before.

**[21:14]** Besides these kinds of wood there is none other that thou shalt place (on the altar), for the fragrance is dispersed, and the smell of its fragrance goes not up to heaven.

**[21:15]** Observe this commandment and do it, my son, that thou mayst be upright in all thy deeds.

**[21:16]** And at all times be clean in thy body, and wash thyself with water before thou approachest to offer on the altar, and wash thy hands and thy feet before thou drawest near to the altar; and when thou art done sacrificing, wash again thy hands and thy feet.

**[21:17]** And let no blood appear upon you nor upon your clothes; be on thy guard, my son, against blood, be on thy guard exceedingly; cover it with dust.

**[21:18]** And do not eat any blood for it is the soul; eat no blood whatever.

**[21:19]** And take no gifts for the blood of man, lest it be shed with impunity, without judgment; for it is the blood that is shed that causes the earth to sin, and the earth cannot be cleansed from the blood of man save by the blood of him who shed it.

**[21:20]** And take no present or gift for the blood of man: blood for blood, that thou mayest be accepted before the Lord, the Most High God; for He is the defence of the good: and that thou mayest be preserved from all evil, and that He may save thee from every kind of death.

**[21:21]** I see, my son, That all the works of the children of men are sin and wickedness, And all their deeds are uncleanness and an abomination and a pollution, And there is no righteousness with them.

**[21:22]** Beware, lest thou shouldest walk in their ways And tread in their paths, And sin a sin unto death before the Most High God. Else He will [hide His face from thee And] give thee back into the hands of thy transgression, And root thee out of the land, and thy seed likewise from under heaven, And thy name and thy seed shall perish from the whole earth.

**[21:23]** Turn away from all their deeds and all their uncleanness, And observe the ordinance of the Most High God, And do His will and be upright in all things.

**[21:24]** And He will bless thee in all thy deeds, And will raise up from thee a plant of righteousness through all the earth, throughout all generations of the earth, And my name and thy name shall not be forgotten under heaven for ever.

**[21:25]** Go, my son in peace. May the Most High God, my God and thy God, strengthen thee to do His will, And may He bless all thy seed and the residue of thy seed for the generations for ever, with all righteous blessings, That thou mayest be a blessing on all the earth.'

**[21:26]** And he went out from him rejoicing.

**[22:1]** And it came to pass in the first week in the forty-fourth jubilee, in the second year, that is, the year in which Abraham died, that Isaac and Ishmael came from the Well of the Oath to celebrate the feast of weeks -that is, the feast of the first fruits of the harvest-to Abraham, their father, and Abraham rejoiced because his two sons had come.

**[22:2]** For Isaac had many possessions in Beersheba, and Isaac was wont to go and see his possessions and to return to his father.

**[22:3]** And in those days Ishmael came to see his father, and they both came together, and Isaac offered a sacrifice for a burnt offering, and presented it on the altar of his father which he had made in Hebron.

**[22:4]** And he offered a thank offering and made a feast of joy before Ishmael, his brother: and Rebecca made new cakes from the new grain, and gave them to Jacob, her son, to take them to Abraham, his father, from the first fruits of the land, that he might eat and bless the Creator of all things before he died.

**[22:5]** And Isaac, too, sent by the hand of Jacob to Abraham a best thank offering, that he might eat and drink.

**[22:6]** And he eat and drank, and blessed the Most High God, Who hath created heaven and earth, Who hath made all the fat things of the earth, And given them to the children of men That they might eat and drink and bless their Creator.

**[22:7]** 'And now I give thanks unto Thee, my God, because thou hast caused me to see this day: behold, I am one hundred three score and fifteen years, an old man and full of days, and all my days have been unto me peace.

**[22:8]** The sword of the adversary has not overcome me in all that Thou hast given me and my children all the days of my life until this day.

**[22:9]** My God, may Thy mercy and Thy peace be upon Thy servant, and upon the seed of his sons, that they may be to Thee a chosen nation and an inheritance from amongst all the nations of the earth from henceforth unto all the days of the generations of the earth, unto all the ages.'

**[22:10]** And he called Jacob and said: 'My son Jacob, may the God of all bless thee and strengthen thee to do righteousness, and His will before Him, and may He choose thee and thy seed that ye may become a people for His inheritance according to His will alway.

**[22:11]** And do thou, my son, Jacob, draw near and kiss me.' And he drew near and kissed him, and he said: 'Blessed be my son Jacob And all the sons of God Most High, unto all the ages: May God give unto thee a seed of righteousness; And some of thy sons may He sanctify in the midst of the whole earth; May nations serve thee, And all the nations bow themselves before thy seed.

**[22:12]** Be strong in the presence of men, And exercise authority over all the seed of Seth. Then thy ways and the ways of thy sons will be justified, So that they shall become a holy nation.

**[22:13]** May the Most High God give thee all the blessings Wherewith He has blessed me And wherewith He blessed Noah and Adam; May they rest on the sacred head of thy seed from generation to generation for ever.

**[22:14]** And may He cleanse thee from all unrighteousness and impurity, That thou mayest be forgiven all the transgressions; which thou hast committed ignorantly. And may He strengthen thee, And bless thee. And mayest thou inherit the whole earth,

**[22:15]** And may He renew His covenant with thee. That thou mayest be to Him a nation for His inheritance for all the ages, And that He may be to thee and to thy seed a God in truth and righteousness throughout all the days of the earth.

**[22:16]** And do thou, my son Jacob, remember my words, And observe the commandments of Abraham, thy father: Separate thyself from the nations, And eat not with them: And do not according to their works, And become not their associate; For their works are unclean, And all their ways are a Pollution and an abomination and uncleanness.

**[22:17]** They offer their sacrifices to the dead And they worship evil spirits, And they eat over the graves, And all their works are vanity and nothingness.

**[22:18]** They have no heart to understand And their eyes do not see what their works are, And how they err in saying to a piece of wood: 'Thou art my God,' And to a stone: 'Thou art my Lord and thou art my deliverer.' [And they have no heart.]

**[22:19]** And as for thee, my son Jacob, May the Most High God help thee And the God of heaven bless thee And remove thee from their uncleanness and from all their error.

**[22:20]** Be thou ware, my son Jacob, of taking a wife from any seed of the daughters of Canaan; For all his seed is to be rooted out of the earth.

**[22:21]** For, owing to the transgression of Ham, Canaan erred, And all his seed shall be destroyed from off the earth and all the residue thereof, And none springing from him shall be saved on the day of judgment.

**[22:22]** And as for all the worshippers of idols and the profane (b) There shall be no hope for them in the land of the living; (c) And there shall be no remembrance of them on the earth; (c) For they shall descend into Sheol, (d) And into the place of condemnation shall they go, As the children of Sodom were taken away from the earth So will all those who worship idols be taken away.

**[22:23]** Fear not, my son Jacob, And be not dismayed, O son of Abraham: May the Most High God preserve thee from destruction, And from all the paths of error may he deliver thee.

**[22:24]** This house have I built for myself that I might put my name upon it in the earth: [it is given to thee and to thy seed for ever], and it will be named the house of Abraham; it is given to thee and to thy seed for ever; for thou wilt build my house and establish my name before God for ever: thy seed and thy name will stand throughout all generations of the earth.'

**[22:25]** And he ceased commanding him and blessing him.

**[22:26]** And the two lay together on one bed, and Jacob slept in the bosom of Abraham, his father's father and he kissed him seven times, and his affection and his heart rejoiced over him.

**[22:27]** And he blessed him with all his heart and said: 'The Most High God, the God of all, and Creator of all, who brought me forth from Ur of the Chaldees that he might give me this land to inherit it for ever, and that I might establish a holy seed-blessed be the Most High for ever.'

**[22:28]** And he blessed Jacob and said: 'My son, over whom with all my heart and my affection I rejoice, may Thy grace and Thy mercy be lift up upon him and upon his seed alway.

**[22:29]** And do not forsake him, nor set him at nought from henceforth unto the days of eternity, and may Thine eyes be opened upon him and upon his seed, that Thou mayst preserve him, and bless him, and mayest sanctify him as a nation for Thine inheritance;

**[22:30]** And bless him with all Thy blessings from henceforth unto all the days of eternity, and renew Thy covenant and Thy grace with him and with his seed according to all Thy good pleasure unto all the generations of the earth.'

**[23:1]** And he placed two fingers of Jacob on his eyes, and he blessed the God of gods, and he covered his face and stretched out his feet and slept the sleep of eternity, and was gathered to his fathers.

**[23:2]** And notwithstanding all this Jacob was lying in his bosom, and knew not that Abraham, his father's father, was dead.

**[23:3]** And Jacob awoke from his sleep, and behold Abraham was cold as ice, and he said 'Father, father'; but there was none that spake, and he knew that he was dead.

**[23:4]** And he arose from his bosom and ran and told Rebecca, his mother; and Rebecca went to Isaac in the night, and told him; and they went together, and Jacob with them, and a lamp was in his hand, and when they had gone in they found Abraham lying dead.

**[23:5]** And Isaac fell on the face of his father and wept and kissed him.

**[23:6]** And the voices were heard in the house of Abraham, and Ishmael his son arose, and went to Abraham his father, and wept over Abraham his father, he and all the house of Abraham, and they wept with a great weeping.

**[23:7]** And his sons Isaac and Ishmael buried him in the double cave, near Sarah his wife, and they wept for him forty days, all the men of his house, and Isaac and Ishmael, and all their sons, and all the sons of Keturah in their places; and the days of weeping for Abraham were ended.

**[23:8]** And he lived three jubilees and four weeks of years, one hundred and seventy-five years, and completed the days of his life, being old and full of days.

**[23:9]** For the days of the forefathers, of their life, were nineteen jubilees; and after the Flood they began to grow less than nineteen jubilees, and to decrease in jubilees, and to grow old quickly, and to be full of their days by reason of manifold tribulation and the wickedness of their ways, with the exception of Abraham.

**[23:10]** For Abraham was perfect in all his deeds with the Lord, and well-pleasing in righteousness all the days of his life; and behold, he did not complete four jubilees in his life, when he had grown old by reason of the wickedness, and was full of his days.

**[23:11]** And all the generations which shall arise from this time until the day of the great judgment shall grow old quickly, before they complete two jubilees, and their knowledge shall forsake them by reason of their old age Land all their know- ledge shall vanish away].

**[23:12]** And in those days, if a man live a jubilee and a-half of years, they shall say regarding him: 'He has lived long, and the greater part of his days are pain and sorrow and tribulation, and there is no peace:

**[23:13]** For calamity follows on calamity, and wound on wound, and tribulation on tribulation, and evil tidings on evil tidings, and illness on illness, and all evil judgments such as these, one with another, illness and overthrow, and snow and frost and ice, and fever, and chills, and torpor, and famine, and death, and sword, and captivity, and all kinds of calamities and pains.'

**[23:14]** And all these shall come on an evil generation, which transgresses on the earth: their works are uncleanness and fornication, and pollution and abominations.

**[23:15]** Then they shall say: 'The days of the forefathers were many (even), unto a thousand years, and were good; but behold, the days of our life, if a man has lived many, are three score years and ten, and, if he is strong, four score years, and those evil, and there is no peace in the days of this evil generation.'

**[23:16]** And in that generation the sons shall convict their fathers and their elders of sin and unrighteousness, and of the words of their mouth and the great wickednesses which they perpetrate, and concerning their forsaking the covenant which the Lord made between them and Him, that they should observe and do all His commandments and His ordinances and all His laws, without departing either to the right hand or the left.

**[23:17]** For all have done evil, and every mouth speaks iniquity and all their works are an uncleanness and an abomination, and all their ways are pollution, uncleanness and destruction.

**[23:18]** Behold the earth shall be destroyed on account of all their works, and there shall be no seed of the vine, and no oil; for their works are altogether faithless, and they shall all perish together, beasts and cattle and birds, and all the fish of the sea, on account of the children of men.

**[23:19]** And they shall strive one with another, the young with the old, and the old with the young, the poor with the rich, the lowly with the great, and the beggar with the prince, on account of the law and the covenant; for they have forgotten commandment, and covenant, and feasts, and months, and Sabbaths, and jubilees, and all judgments.

**[23:20]** And they shall stand <with bows and> swords and war to turn them back into the way; but they shall not return until much blood has been shed on the earth, one by another.

**[23:21]** And those who have escaped shall not return from their wickedness to the way of righteousness, but they shall all exalt themselves to deceit and wealth, that they may each take all that is his neighbour's, and they shall name the great name, but not in truth and not in righteousness, and they shall defile the holy of holies with their uncleanness and the corruption of their pollution.

**[23:22]** And a great punishment shall befall the deeds of this generation from the Lord, and He will give them over to the sword and to judgment and to captivity, and to be plundered and devoured.

**[23:23]** And He will wake up against them the sinners of the Gentiles, who have neither mercy nor compassion, and who shall respect the person of none, neither old nor young, nor any one, for they are more wicked and strong to do evil than all the children of men. And they shall use violence against Israel and transgression against Jacob, And much blood shall be shed upon the earth, And there shall be none to gather and none to bury.

**[23:24]** In those days they shall cry aloud, And call and pray that they may be saved from the hand of the sinners, the Gentiles; But none shall be saved.

**[23:25]** And the heads of the children shall be white with grey hair, And a child of three weeks shall appear old like a man of one hundred years, And their stature shall be destroyed by tribulation and oppression.

**[23:26]** And in those days the children shall begin to study the laws, And to seek the commandments, And to return to the path of righteousness.

**[23:27]** And the days shall begin to grow many and increase amongst those children of men Till their days draw nigh to one thousand years. And to a greater number of years than (before) was the number of the days.

**[23:28]** And there shall be no old man Nor one who is <not> satisfied with his days, For all shall be (as) children and youths.

**[23:29]** And all their days they shall complete and live in peace and in joy, And there shall be no Satan nor any evil destroyer; For all their days shall be days of blessing and healing.

**[23:30]** And at that time the Lord will heal His servants, And they shall rise up and see great peace, And drive out their adversaries. And the righteous shall see and be thankful, And rejoice with joy for ever and ever, And shall see all their judgments and all their curses on their enemies.

**[23:31]** And their bones shall rest in the earth, And their spirits shall have much joy, And they shall know that it is the Lord who executes judgment, And shows mercy to hundreds and thousands and to all that love Him

**[23:32]** And do thou, Moses, write down these words; for thus are they written, and they record (them) on the heavenly tablets for a testimony for the generations for ever.

**[24:1]** And it came to pass after the death of Abraham, that the Lord blessed Isaac his son, and he arose from Hebron and went and dwelt at the Well of the Vision in the first year of the third week [2073 A.M.] of this jubilee, seven years.

**[24:2]** And in the first year of the fourth week a famine began in the land, [2080 A.M.] besides the first famine, which had been in the days of Abraham.

**[24:3]** And Jacob sod lentil pottage, and Esau came from the field hungry. And he said to Jacob his brother: 'Give me of this red pottage.' And Jacob said to him: 'Sell to me thy [primogeniture, this] birthright and I will give thee bread, and also some of this lentil pottage.'

**[24:4]** And Esau said in his heart: 'I shall die; of what profit to me is this birthright?

**[24:5]** 'And he said to Jacob: 'I give it to thee.' And Jacob said: 'Swear to me, this day,' and he sware unto him.

**[24:6]** And Jacob gave his brother Esau bread and pottage, and he eat till he was satisfied, and Esau despised his birthright; for this reason was Esau's name called Edom, on account of the red pottage which Jacob gave him for his birthright.

**[24:7]** And Jacob became the elder, and Esau was brought down from his dignity.

**[24:8]** And the famine was over the land, and Isaac departed to go down into Egypt in the second year of this week, and went to the king of the Philistines to Gerar, unto Abimelech.

**[24:9]** And the Lord appeared unto him and said unto him: 'Go not down into Egypt; dwell in the land that I shall tell thee of, and sojourn in this land, and I will be with thee and bless thee.

**[24:10]** For to thee and to thy seed will I give all this land, and I will establish My oath which I sware unto Abraham thy father, and I will multiply thy seed as the stars of heaven, and will give unto thy seed all this land.

**[24:11]** And in thy seed shall all the nations of the earth be blessed, because thy father obeyed My voice, and kept My charge and My commandments, and My laws, and My ordinances, and My covenant; and now obey My voice and dwell in this land.'

**[24:12]** And he dwelt in Gelar three weeks of years.

**[24:13]** And Abimelech charged concerning him, [2080-2101 A.M.] and concerning all that was his, saying: 'Any man that shall touch him or aught that is his shall surely die.'

**[24:14]** And Isaac waxed strong among the Philistines, and he got many possessions, oxen and sheep and camels and asses and a great household.

**[24:15]** And he sowed in the land of the Philistines and brought in a hundred-fold, and Isaac became exceedingly great, and the Philistines envied him.

**[24:16]** Now all the wells which the servants of Abraham had dug during the life of Abraham, the Philistines had stopped them after the death of Abraham, and filled them with earth.

**[24:17]** And Abimelech said unto Isaac: 'Go from us, for thou art much mightier than we', and Isaac departed thence in the first year of the seventh week, and sojourned in the valleys of Gerar.

**[24:18]** And they digged again the wells of water which the servants of Abraham, his father, had digged, and which the Philistines had closed after the death of Abraham his father, and he called their names as Abraham his father had named them.

**[24:19]** And the servants of Isaac dug a well in the valley, and found living water, and the shepherds of Gerar strove with the shepherds of Isaac, saying: 'The water is ours'; and Isaac called the name of the well 'Perversity', because they had been perverse with us.

**[24:20]** And they dug a second well, and they strove for that also, and he called its name 'Enmity'. And he arose from thence and they digged another well, and for that they strove not, and he called the name of it 'Room', and Isaac said: 'Now the Lord hath made room for us, and we have increased in the land.'

**[24:21]** And he went up from thence to the Well of the Oath in the first year of the first week in the [2108 A.M.] forty-fourth jubilee.

**[24:22]** And the Lord appeared to him that night, on the new moon of the first month, and said unto him: 'I am the God of Abraham thy father; fear not, for I am with thee, and shall bless thee and shall surely multiply thy seed as the sand of the earth, for the sake of Abraham my servant.'

**[24:23]** And he built an altar there, which Abraham his father had first built, and he called upon the name of the Lord, and he offered sacrifice to the God of Abraham his father.

**[24:24]** And they digged a well and they found living water.

**[24:25]** And the servants of Isaac digged another well and did not find water, and they went and told Isaac that they had not found water, and Isaac said: 'I have sworn this day to the Philistines and this thing has been announced to us.'

**[24:26]** And he called the name of that place the Well of the Oath; for there he had sworn to Abimelech and Ahuzzath his friend and Phicol the prefect Or his host.

**[24:27]** And Isaac knew that day that under constraint he had sworn to them to make peace with them.

**[24:28]** And Isaac on that day cursed the Philistines and said: 'Cursed be the Philistines unto the day of wrath and indignation from the midst of all nations; may God make them a derision and a curse and an object of wrath and indignation in the hands of the sinners the Gentiles and in the hands of the Kittim.

**[24:29]** And whoever escapes the sword of the enemy and the Kittim, may the righteous nation root out in judgment from under heaven; for they shall be the enemies and foes of my children throughout their generations upon the earth.

**[24:30]** And no remnant shall be left to them, Nor one that shall be saved on the day of the wrath of judgment; For destruction and rooting out and expulsion from the earth is the whole seed of the Philistines (reserved), And there shall no longer be left for these Caphtorim a name or a seed on the earth.

**[24:31]** For though he ascend unto heaven, Thence shall he be brought down, And though he make himself strong on earth, Thence shall he be dragged forth, And though he hide himself amongst the nations, Even from thence shall he be rooted out; And though he descend into Sheol, There also shall his condemnation be great, And there also he shall have no peace.

**[24:32]** And if he go into captivity, By the hands of those that seek his life shall they slay him on the way, And neither name nor seed shall be left to him on all the earth; For into eternal malediction shall he depart.'

**[24:33]** And thus is it written and engraved concerning him on the heavenly tablets, to do unto him on the day of judgment, so that he may be rooted out of the earth.

**[25:1]** And in the second year of this week in this jubilee, Rebecca called Jacob her son, and spake unto [2109 A.M.] him, saying: 'My son, do not take thee a wife of the daughters of Canaan, as Esau, thy brother, who took him two wives of the daughters of Canaan, and they have embittered my soul with all their unclean deeds: for all their deeds are fornication and lust, and there is no righteousness with them, for (their deeds) are evil.

**[25:2]** And I, my son, love thee exceedingly, and my heart and my affection bless thee every hour of the day and watch of the night.

**[25:3]** And now, my son, hearken to my voice, and do the will of thy mother, and do not take thee a wife of the daughters of this land, but only of the house of my father, and of my father's kindred. Thou shalt take thee a wife of the house of my father, and the Most High God will bless thee, and thy children shall be a righteous generation and a holy seed.'

**[25:4]** And then spake Jacob to Rebecca, his mother, and said unto her: 'Behold, mother, I am nine weeks of years old, and I neither know nor have I touched any woman, nor have I betrothed myself to any, nor even think of taking me a wife of the daughters of Canaan.

**[25:5]** For I remember, mother, the words of Abraham, our father, for he commanded me not to take a wife of the daughters of Canaan, but to take me a wife from the seed of my father's house and from my kindred.

**[25:6]** I have heard before that daughters have been born to Laban, thy brother, and I have set my heart on them to take a wife from amongst them.

**[25:7]** And for this reason I have guarded myself in my spirit against sinning or being corrupted in all my ways throughout all the days of my life; for with regard to lust and fornication, Abraham, my father, gave me many commands.

**[25:8]** And, despite all that he has commanded me, these two and twenty years my brother has striven with me, and spoken frequently to me and said: 'My brother, take to wife a sister of my two wives'; but I refuse to do as he has done.

**[25:9]** I swear before thee, mother, that all the days of my life I will not take me a wife from the daughters of the seed of Canaan, and I will not act wickedly as my brother has done.

**[25:10]** Fear not, mother; be assured that I shall do thy will and walk in uprightness, and not corrupt my ways for ever.'

**[25:11]** And thereupon she lifted up her face to heaven and extended the fingers of her hands, and opened her mouth and blessed the Most High God, who had created the heaven and the earth, and she gave Him thanks and praise.

**[25:12]** And she said: 'Blessed be the Lord God, and may His holy name be blessed for ever and ever, who has given me Jacob as a pure son and a holy seed; for he is Thine, and Thine shall his seed be continually and throughout all the generations for evermore.

**[25:13]** Bless him, O Lord, and place in my mouth the blessing of righteousness, that I may bless him.'

**[25:14]** And at that hour, when the spirit of righteousness descended into her mouth, she placed both her hands on the head of Jacob, and said:

**[25:15]** 'Blessed art thou, Lord of righteousness and God of the ages And may He bless thee beyond all the generations of men. May He give thee, my Son, the path of righteousness, And reveal righteousness to thy seed.

**[25:16]** And may He make thy sons many during thy life, And may they arise according to the number of the months of the year. And may their sons become many and great beyond the stars of heaven, And their numbers be more than the sand of the sea.

**[25:17]** And may He give them this goodly land -as He said He would give it to Abraham and to his seed after him alway- And may they hold it as a possession for ever.

**[25:18]** And may I see (born) unto thee, my son, blessed children during my life, And a blessed and holy seed may all thy seed be.

**[25:19]** And as thou hast refreshed thy mother's spirit during her life, The womb of her that bare thee blesses thee thus, [My affection] and my breasts bless thee And my mouth and my tongue praise thee greatly.

**[25:20]** Increase and spread over the earth, And may thy seed be perfect in the joy of heaven and earth for ever; And may thy seed rejoice, And on the great day of peace may it have peace.

**[25:21]** And may thy name and thy seed endure to all the ages, And may the Most High God be their God, And may the God of righteousness dwell with them, And by them may His sanctuary be built unto all the ages.

**[25:22]** Blessed be he that blesseth thee, And all flesh that curseth thee falsely, may it be cursed.'

**[25:23]** And she kissed him, and said to him; 'May the Lord of the world love thee As the heart of thy mother and her affection rejoice in thee and bless thee.' And she ceased from blessing.

**[26:1]** And in the seventh year of this week Isaac called Esau, his elder Son, and said unto him: ' I am [2114 A.M.] old, my son, and behold my eyes are dim in seeing, and I know not the day of my death.

**[26:2]** And now take thy hunting weapons thy quiver and thy bow, and go out to the field, and hunt and catch me (venison), my son, and make me savoury meat, such as my soul loveth, and bring it to me that I may eat, and that my soul may bless thee before I die.'

**[26:3]** But Rebecca heard Isaac speaking to Esau.

**[26:4]** And Esau went forth early to the field to hunt and catch and bring home to his father.

**[26:5]** And Rebecca called Jacob, her son, and said unto him: 'Behold, I heard Isaac, thy father, speak unto Esau, thy brother, saying: "Hunt for me, and make me savoury meat, and bring (it) to me that

**[26:6]** I may eat and bless thee before the Lord before I die." And now, my son, obey my voice in that which I command thee: Go to thy flock and fetch me two good kids of the goats, and I will make them savoury meat for thy father, such as he loves, and thou shalt bring (it) to thy father that he may eat and bless thee before the Lord before he die, and that thou mayst be blessed.'

**[26:7]** And Jacob said to Rebecca his mother: 'Mother, I shall not withhold anything which my father would eat, and which would please him: only I fear, my mother, that he will recognise my voice and wish to touch me.

**[26:8]** And thou knowest that I am smooth, and Esau, my brother, is hairy, and I shall appear before his eyes as an evildoer, and shall do a deed which he had not commanded me, and he will be wroth with me, and I shall bring upon myself a curse, and not a blessing.'

**[26:9]** And Rebecca, his mother, said unto him: 'Upon me be thy curse, my son, only obey my voice.'

**[26:10]** And Jacob obeyed the voice of Rebecca, his mother, and went and fetched two good and fat kids of the goats, and brought them to his mother, and his mother made them ~savoury meat~ such as he loved.

**[26:11]** And Rebecca took the goodly rainment of Esau, her elder son, which was with her in the house, and she clothed Jacob, her younger son, (with them), and she put the skins of the kids upon his hands and on the exposed parts of his neck.

**[26:12]** And she gave the meat and the bread which she had prepared into the hand of her son Jacob.

**[26:13]** And Jacob went in to his father and said: 'I am thy son: I have done according as thou badest me: arise and sit and eat of that which I have caught, father, that thy soul may bless me.'

**[26:14]** And Isaac said to his son: 'How hast thou found so quickly, my son?

**[26:15]** 'And Jacob said: 'Because <the Lord> thy God caused me to find.'

**[26:16]** And Isaac said unto him: 'Come near, that I may feel thee, my son, if thou art my son Esau or not.'

**[26:17]** And Jacob went near to Isaac, his father, and he felt him and said: 'The voice is Jacob's voice, but the hands are the hands of Esau,'

**[26:18]** and he discerned him not, because it was a dispensation from heaven to remove his power of perception and Isaac discerned not, for his hands were hairy as his brother Esau's, so that he blessed him.

**[26:19]** And he said: 'Art thou my son Esau? ' and he said: 'I am thy son': and he said, 'Bring near to me that I may eat of that which thou hast caught, my son, that my soul may bless thee.'

**[26:20]** And he brought near to him, and he did eat, and he brought him wine and he drank.

**[26:21]** And Isaac, his father, said unto him: 'Come near and kiss me, my son.

**[26:22]** And he came near and kissed him. And he smelled the smell of his raiment, and he blessed him and said: 'Behold, the smell of my son is as the smell of a <full> field which the Lord hath blessed.

**[26:23]** And may the Lord give thee of the dew of heaven And of the dew of the earth, and plenty of corn and oil: Let nations serve thee, And peoples bow down to thee.

**[26:24]** Be lord over thy brethren, And let thy mother's sons bow down to thee; And may all the blessings wherewith the Lord hath blessed me and blessed Abraham, my father; Be imparted to thee and to thy seed for ever: Cursed be he that curseth thee, And blessed be he that blesseth thee.'

**[26:25]** And it came to pass as soon as Isaac had made an end of blessing his son Jacob, and Jacob had gone forth from Isaac his father he hid himself and Esau, his brother, came in from his hunting.

**[26:26]** And he also made savoury meat, and brought (it) to his father, and said unto his father: 'Let my father arise, and eat of my venison that thy soul may bless me.'

**[26:27]** And Isaac, his father, said unto him: 'Who art thou? 'And he said unto him: 'I am thy first born, thy son Esau: I have done as thou hast commanded me.'

**[26:28]** And Isaac was very greatly astonished, and said: 'Who is he that hath hunted and caught and brought (it) to me, and I have eaten of all before thou camest, and have blessed him: (and) he shall be blessed, and all his seed for ever.'

**[26:29]** And it came to pass when Esau heard the words of his father Isaac that he cried with an exceeding great and bitter cry, and said unto his father: 'Bless me, (even) me also, father.'

**[26:30]** And he said unto him: 'Thy brother came with guile, and hath taken away thy blessing.' And he said: 'Now I know why his name is named Jacob: behold, he hath supplanted me these two times: he took away my birth-right, and now he hath taken away my blessing.'

**[26:31]** And he said: 'Hast thou not reserved a blessing for me, father?' and Isaac answered and said unto Esau: 'Behold, I have made him thy lord, And all his brethren have I given to him for servants, And with plenty of corn and wine and oil have I strengthened him: And what now shall I do for thee, my son?'

**[26:32]** And Esau said to Isaac, his father: 'Hast thou but one blessing, O father? Bless me, (even) me also, father: '

**[26:33]** And Esau lifted up his voice and wept. And Isaac answered and said unto him: 'Behold, far from the dew of the earth shall be thy dwelling, And far from the dew of heaven from above.

**[26:34]** And by thy sword wilt thou live, And thou wilt serve thy brother. And it shall come to pass when thou becomest great, And dost shake his yoke from off thy neck, Thou shalt sin a complete sin unto death, And thy seed shall be rooted out from under heaven.'

**[26:35]** And Esau kept threatening Jacob because of the blessing wherewith his father blessed him, and he: said in his heart: 'May the days of mourning for my father now come, so that I may slay my brother Jacob.'

**[27:1]** And the words of Esau, her elder son, were told to Rebecca in a dream, and Rebecca sent and called Jacob her younger son,

**[27:2]** and said unto him: 'Behold Esau thy brother will take vengeance on thee so as to kill thee.

**[27:3]** Now, therefore, my son, obey my voice, and arise and flee thou to Laban, my brother, to Haran, and tarry with him a few days until thy brother's anger turns away, and he remove his anger from thee, and forget all that thou hast done; then I will send and fetch thee from thence.'

**[27:4]** And Jacob said: 'I am not afraid; if he wishes to kill me, I will kill him.'

**[27:5]** But she said unto him: 'Let me not be bereft of both my sons on one day.'

**[27:6]** And Jacob said to Rebecca his mother: 'Behold, thou knowest that my father has become old, and does not see because his eyes are dull, and if I leave him it will be evil in his eyes, because I leave him and go away from you, and my father will be angry, and will curse me. I will not go; when he sends me, then only will I go.'

**[27:7]** And Rebecca said to Jacob: 'I will go in and speak to him, and he will send thee away.'

**[27:8]** And Rebecca went in and said to Isaac: 'I loathe my life because of the two daughters of Heth, whom Esau has taken him as wives; and if Jacob take a wife from among the daughters of the land such as these, for what purpose do I further live, for the daughters of Canaan are evil.'

**[27:9]** And Isaac called Jacob and blessed him, and admonished him and said unto him: 'Do not take thee a wife of any of the daughters of Canaan;

**[27:10]** arise and go to Mesopotamia, to the house of Bethuel, thy mother's father, and take thee a wife from thence of the daughters of Laban, thy mother's brother.

**[27:11]** And God Almighty bless thee and increase and multiply thee that thou mayest become a company of nations, and give thee the blessings of my father Abraham, to thee and to thy seed after thee, that thou mayest inherit the land of thy sojournings and all the land which God gave to Abraham: go, my son, in peace.'

**[27:12]** And Isaac sent Jacob away, and he went to Mesopotamia, to Laban the son of Bethuel the Syrian, the brother of Rebecca, Jacob's mother.

**[27:13]** And it came to pass after Jacob had arisen to go to Mesopotamia that the spirit of Rebecca was grieved after her son, and she wept.

**[27:14]** And Isaac said to Rebecca: 'My sister, weep not on account of Jacob, my son; for he goeth in peace, and in peace will he return.

**[27:15]** The Most High God will preserve him from all evil, and will be with him; for He will not forsake him all his days;

**[27:16]** For I know that his ways will be prospered in all things wherever he goes, until he return in peace to us, and we see him in peace.

**[27:17]** Fear not on his account, my sister, for he is on the upright path and he is a perfect man: and he is faithful and will not perish. Weep not.'

**[27:18]** And Isaac comforted Rebecca on account of her son Jacob, and blessed him.

**[27:19]** And Jacob went from the Well of the Oath to go to Haran on the first year of the second week in the forty-fourth jubilee, and he came to Luz on the mountains, that is, Bethel, on the new moon of the first month of this week, [2115 A.M.] and he came to the place at even and turned from the way to the west of the road that night: and he slept there; for the sun had set.

**[27:20]** And he took one of the stones of that place and laid <it at his head> under the tree, and he was journeying alone, and he slept.

**[27:21]** And he dreamt that night, and behold a ladder set up on the earth, and the top of it reached to heaven, and behold, the angels of the Lord ascended and descended on it: and behold, the Lord stood upon it.

**[27:22]** And he spake to Jacob and said: 'I am the Lord God of Abraham, thy father, and the God of Isaac; the land whereon thou art sleeping, to thee will I give it, and to thy seed after thee.

**[27:23]** And thy seed shall be as the dust of the earth, and thou shalt increase to the west and to the east, to the north and the south, and in thee and in thy seed shall all the families of the nations be blessed.

**[27:24]** And behold, I will be with thee, and will keep thee whithersoever thou goest, and I will bring thee again into this land in peace; for I will not leave thee until I do everything that I told thee of.'

**[27:25]** And Jacob awoke from his sleep, and said, 'Truly this place is the house of the Lord, and I knew it not.' And he was afraid and said: 'Dreadful is this place which is none other than the house of God, and this is the gate of heaven.'

**[27:26]** And Jacob arose early in the morning, and took the stone which he had put under his head and set it up as a pillar for a sign, and he poured oil upon the top of it. And he called the name of that place Bethel; but the name of the place was Luz at the first.

**[27:27]** And Jacob vowed a vow unto the Lord, saying: 'If the Lord will be with me, and will keep me in this way that I go, and give me bread to eat and raiment to put on, so that I come again to my father's house in peace, then shall the Lord be my God, and this stone which I have set up as a pillar for a sign in this place, shall be the Lord's house, and of all that thou givest me, I shall give the tenth to thee, my God.'

**[28:1]** And he went on his journey, and came to the land of the east, to Laban, the brother of Rebecca, and he was with him, and served him for Rachel his daughter one week.

**[28:2]** And in the first year of the third week [2122 A.M.] he said unto him: 'Give me my wife, for whom I have served thee seven years '; and Laban said unto Jacob: 'I will give thee thy wife.'

**[28:3]** And Laban made a feast, and took Leah his elder daughter, and gave (her) to Jacob as a wife, and gave her Zilpah his handmaid for an hand- maid; and Jacob did not know, for he thought that she was Rachel.

**[28:4]** And he went in unto her, and behold, she was Leah; and Jacob was angry with Laban, and said unto him: 'Why hast thou dealt thus with me? Did not I serve thee for Rachel and not for Leah? Why hast thou wronged me?

**[28:5]** Take thy daughter, and I will go; for thou hast done evil to me.' For Jacob loved Rachel more than Leah; for Leah's eyes were weak, but her form was very handsome; but Rachel had beautiful eyes and a beautiful and very handsome form.

**[28:6]** And Laban said to Jacob: 'It is not so done in our country, to give the younger before the elder.' And it is not right to do this; for thus it is ordained and written in the heavenly tablets, that no one should give his younger daughter before the elder; but the elder, one gives first and after her the younger -and the man who does so, they set down guilt against him in heaven, and none is righteous that does this thing, for this deed is evil before the Lord.

**[28:7]** And command thou the children of Israel that they do not this thing; let them neither take nor give the younger before they have given the elder, for it is very wicked.

**[28:8]** And Laban said to Jacob: 'Let the seven days of the feast of this one pass by, and I shall give thee Rachel, that thou mayst serve me another seven years, that thou mayst pasture my sheep as thou didst in the former week.'

**[28:9]** And on the day when the seven days of the feast of Leah had passed, Laban gave Rachel to Jacob, that he might serve him another seven years, and he gave to Rachel Bilhah, the sister of Zilpah, as a handmaid.

**[28:10]** And he served yet other seven years for Rachel, for Leah had been given to him for nothing.

**[28:11]** And the Lord opened the womb of Leah, and she conceived and bare Jacob a son, and he called his name Reuben, on the fourteenth day of the ninth month, in the first year of the third week. [2122 A.M.]

**[28:12]** But the womb of Rachel was closed, for the Lord saw that Leah was hated and Rachel loved.

**[28:13]** And again Jacob went in unto Leah, and she conceived, and bare Jacob a second son, and he called his name Simeon, on the twenty-first of the tenth month, and in the third year of this week. [2124 A.M.]

**[28:14]** And again Jacob went in unto Leah, and she conceived, and bare him a third son, and he called his name Levi, in the new moon of the first month in the sixth year of this week. [2127 A.M.]

**[28:15]** And again Jacob went in unto her, and she conceived, and bare him a fourth son, and he called his name Judah, on the fifteenth of the third month, in the first year of the fourth week. [2129 A.M.]

**[28:16]** And on account of all this Rachel envied Leah, for she did not bear, and she said to Jacob: 'Give me children'; and Jacob said: 'Have I withheld from thee the fruits of thy womb? Have I forsaken thee?'

**[28:17]** And when Rachel saw that Leah had borne four sons to Jacob, Reuben and Simeon and Levi and Judah, she said unto him: 'Go in unto Bilhah my handmaid, and she will conceive, and bear a son unto me.' (And she gave (him) Bilhah her handmaid to wife).

**[28:18]** And he went in unto her, and she conceived, and bare him a son, and he called his name Dan, on the ninth of the sixth month, in the sixth year of the third week. [2127 A.M.]

**[28:19]** And Jacob went in again unto Bilhah a second time, and she conceived, and bare Jacob another son, and Rachel called his name Napthali, on the fifth of the seventh month, in the second year of the fourth week. [2130 A.M.]

**[28:20]** And when Leah saw that she had become sterile and did not bear, she envied Rachel, and she also gave her handmaid Zilpah to Jacob to wife, and she conceived, and bare a son, and Leah called his name Gad, on the twelfth of the eighth month, in the third year of the fourth week. [2131 A.M.]

**[28:21]** And he went in again unto her, and she conceived, and bare him a second son, and Leah called his name Asher, on the second of the eleventh month, in the fifth year of the fourth week. [2133 A.M.]

**[28:22]** And Jacob went in unto Leah, and she conceived, and bare a son, and she called his name Issachar, on the fourth of the fifth month, in the fourth year of the fourth week,[2132 A.M.] and she gave him to a nurse.

**[28:23]** And Jacob went in again unto her, and she conceived, and bare two (children), a son and a daughter, and she called the name of the son Zabulon, and the name of the daughter Dinah, in the seventh of the seventh month, in the sixth year of the fourth week. [2134 A.M.]

**[28:24]** And the Lord was gracious to Rachel, and opened her womb, and she conceived, and bare a son, and she called his name Joseph, on the new moon of the fourth month, in the sixth year in this fourth week. [2134 A.M.]

**[28:25]** And in the days when Joseph was born, Jacob said to Laban: 'Give me my wives and sons, and let me go to my father Isaac, and let me make me an house; for I have completed the years in which I have served thee for thy two daughters, and I will go to the house of my father.'

**[28:26]** And Laban said to Jacob: 'Tarry with me for thy wages, and pasture my flock for me again, and take thy wages.'

**[28:27]** And they agreed with one another that he should give him as his wages those of the lambs and kids which were born black and spotted and white, (these) were to be his wages.

**[28:28]** And all the sheep brought forth spotted and speckled and black, variously marked, and they brought forth again lambs like themselves, and all that were spotted were Jacob's and those which were not were Laban's.

**[28:29]** And Jacob's possessions multiplied exceedingly, and he possessed oxen and sheep and asses and camels, and menservants and maid-servants.

**[28:30]** And Laban and his sons envied Jacob, and Laban took back his sheep from him, and he observed him with evil intent.

**[29:1]** And it came to pass when Rachel had borne Joseph, that Laban went to shear his sheep; for they were distant from him a three days' journey.

**[29:2]** And Jacob saw that Laban was going to shear his sheep, and Jacob called Leah and Rachel, and spake kindly unto them that they should come with him to the land of Canaan.

**[29:3]** For he told them how he had seen everything in a dream, even all that He had spoken unto him that he should return to his father's house, and they said: 'To every place whither thou goest we will go with thee.'

**[29:4]** And Jacob blessed the God of Isaac his father, and the God of Abraham his father's father, and he arose and mounted his wives and his children, and took all his possessions and crossed the river, and came to the land of Gilead, and Jacob hid his intention from Laban and told him not.

**[29:5]** And in the seventh year of the fourth week Jacob turned (his face) toward Gilead in the first month, on the twenty-first thereof. [2135 A.M.] And Laban pursued after him and overtook Jacob in the mountain of Gilead in the third month, on the thirteenth thereof.

**[29:6]** And the Lord did not suffer him to injure Jacob; for he appeared to him in a dream by night. And Laban spake to Jacob.

**[29:7]** And on the fifteenth of those days Jacob made a feast for Laban, and for all who came with him, and Jacob sware to Laban that day, and Laban also to Jacob, that neither should cross the mountain of Gilead to the other with evil purpose.

**[29:8]** And he made there a heap for a witness; wherefore the name of that place is called: 'The Heap of Witness,' after this heap.

**[29:9]** But before they used to call the land of Gilead the land of the Rephaim; for it was the land of the Rephaim, and the Rephaim were born (there), giants whose height was ten, nine, eight down to seven cubits.

**[29:10]** And their habitation was from the land of the children of Ammon to Mount Hermon, and the seats of their kingdom were Karnaim and Ashtaroth, and Edrei, and Misur, and Beon.

**[29:11]** And the Lord destroyed them because of the evil of their deeds; for they were very malignant, and the Amorites dwelt in their stead, wicked and sinful, and there is no people to-day which has wrought to the full all their sins, and they have no longer length of life on the earth.

**[29:12]** And Jacob sent away Laban, and he departed into Mesopotamia, the land of the East, and Jacob returned to the land of Gilead.

**[29:13]** And he passed over the Jabbok in the ninth month, on the eleventh thereof. And on that day Esau, his brother, came to him, and he was reconciled to him, and departed from him unto the land of Seir, but Jacob dwelt in tents.

**[29:14]** And in the first year of the fifth week in this jubilee [2136 A.M.] he crossed the Jordan, and dwelt beyond the Jordan, and he pastured his sheep from the sea of the heap unto Bethshan, and unto Dothan and unto the forest of Akrabbim.

**[29:15]** And he sent to his father Isaac of all his substance, clothing, and food, and meat, and drink, and milk, and butter, and cheese, and some dates of the valley.

**[29:16]** And to his mother Rebecca also four times a year, between the times of the months, between ploughing and reaping, and between autumn and the rain (season) and between winter and spring, to the tower of Abraham.

**[29:17]** For Isaac had returned from the Well of the Oath and gone up to the tower of his father Abraham, and he dwelt there apart from his son Esau.

**[29:18]** For in the days when Jacob went to Mesopotamia, Esau took to himself a wife Mahalath, the daughter of Ishmael, and he gathered together all the flocks of his father and his wives, and went Up and dwelt on Mount Seir, and left Isaac his father at the Well of the Oath alone.

**[29:19]** And Isaac went up from the Well of the Oath and dwelt in the tower of Abraham his father on the mountains of Hebron,

**[29:20]** And thither Jacob sent all that he did send to his father and his mother from time to time, all they needed, and they blessed Jacob with all their heart and with all their soul.

**[30:1]** And in the first year of the sixth week [2143 A.M.] he went up to Salem, to the east of Shechem, in peace, in the fourth month.

**[30:2]** And there they carried off Dinah, the daughter of Jacob, into the house of Shechem, the son of Hamor, the Hivite, the prince of the land, and he lay with her and defiled her, and she was a little girl, a child of twelve years.

**[30:3]** And he besought his father and her brothers that she might be given to him to wife. And Jacob and his sons were wroth because of the men of Shechem; for they had defiled Dinah, their sister, and they spake to them with evil intent and dealt deceitfully with them and beguiled them.

**[30:4]** And Simeon and Levi came unexpectedly to Shechem and executed judgment on all the men of Shechem, and slew all the men whom they found in it, and left not a single one remaining in it: they slew all in torments because they had dishonoured their sister Dinah.

**[30:5]** And thus let it not again be done from henceforth that a daughter of Israel be defiled; for judgment is ordained in heaven against them that they should destroy with the sword all the men of the Shechemites because they had wrought shame in Israel.

**[30:6]** And the Lord delivered them into the hands of the sons of Jacob that they might exterminate them with the sword and execute judgment upon them, and that it might not thus again be done in Israel that a virgin of Israel should be defiled.

**[30:7]** And if there is any man who wishes in Israel to give his daughter or his sister to any man who is of the seed of the Gentiles he shall surely die, and they shall stone him with stones; for he hath wrought shame in Israel; and they shall burn the woman with fire, because she has dishonoured the name of the house of her father, and she shall be rooted out of Israel.

**[30:8]** And let not an adulteress and no uncleanness be found in Israel throughout all the days of the generations of the earth; for Israel is holy unto the Lord, and every man who has defiled (it) shall surely die: they shall stone him with stones.

**[30:9]** For thus has it been ordained and written in the heavenly tablets regarding all the seed of Israel: he who defileth (it) shall surely die, and he shall be stoned with stones.

**[30:10]** And to this law there is no limit of days, and no remission, nor any atonement: but the man who has defiled his daughter shall be rooted out in the midst of all Israel, because he has given of his seed to Moloch, and wrought impiously so as to defile it.

**[30:11]** And do thou, Moses, command the children of Israel and exhort them not to give their daughters to the Gentiles, and not to take for their sons any of the daughters of the Gentiles, for this is abominable before the Lord.

**[30:12]** For this reason I have written for thee in the words of the Law all the deeds of the Shechemites, which they wrought against Dinah, and how the sons of Jacob spake, saying: 'We will not give our daughter to a man who is uncircumcised; for that were a reproach unto us.'

**[30:13]** And it is a reproach to Israel, to those who live, and to those that take the daughters of the Gentiles; for this is unclean and abominable to Israel.

**[30:14]** And Israel will not be free from this uncleanness if it has a wife of the daughters of the Gentiles, or has given any of its daughters to a man who is of any of the Gentiles.

**[30:15]** For there will be plague upon plague, and curse upon curse, and every judgment and plague and curse will come upon him: if he do this thing, or hide his eyes from those who commit uncleanness, or those who defile the sanctuary of the Lord, or those who profane His holy name, (then) will the whole nation together be judged for all the uncleanness and profanation of this man.

**[30:16]** And there will be no respect of persons [and no consideration of persons] and no receiving at his hands of fruits and offerings and burnt-offerings and fat, nor the fragrance of sweet savour, so as to accept it: and so fare every man or woman in Israel who defiles the sanctuary.

**[30:17]** For this reason I have commanded thee, saying: 'Testify this testimony to Israel: see how the Shechemites fared and their sons: how they were delivered into the hands of two sons of Jacob, and they slew them under tortures, and it was (reckoned) unto them for righteousness, and it is written down to them for righteousness.

**[30:18]** And the seed of Levi was chosen for the priesthood, and to be Levites, that they might minister before the Lord, as we, continually, and that Levi and his sons may be blessed for ever; for he was zealous to execute righteousness and judgment and vengeance on all those who arose against Israel.

**[30:19]** And so they inscribe as a testimony in his favour on the heavenly tablets blessing and righteousness before the God of all:

**[30:20]** And we remember the righteousness which the man fulfilled during his life, at all periods of the year; until a thousand generations they will record it, and it will come to him and to his descendants after him, and he has been recorded on the heavenly tablets as a friend and a righteous man.

**[30:21]** All this account I have written for thee, and have commanded thee to say to the children of Israel, that they should not commit sin nor transgress the ordinances nor break the covenant which has been ordained for them, (but) that they should fulfil it and be recorded as friends.

**[30:22]** But if they transgress and work uncleanness in every way, they will be recorded on the heavenly tablets as adversaries, and they will be destroyed out of the book of life, and they will be recorded in the book of those who will be destroyed and with those who will be rooted out of the earth.

**[30:23]** And on the day when the sons of Jacob slew Shechem a writing was recorded in their favour in heaven that they had executed righteousness and uprightness and vengeance on the sinners, and it was written for a blessing.

**[30:24]** And they brought Dinah, their sister, out of the house of Shechem, and they took captive everything that was in Shechem, their sheep and their oxen and their asses, and all their wealth, and all their flocks, and brought them all to Jacob their father.

**[30:25]** And he reproached them because they had put the city to the sword for he feared those who dwelt in the land, the Canaanites and the Perizzites.

**[30:26]** And the dread of the Lord was upon all the cities which are around about Shechem, and they did not rise to pursue after the sons of Jacob; for terror had fallen upon them.

**[31:1]** And on the new moon of the month Jacob spake to all the people of his house. saying: 'Purify yourselves and change your garments, and let us arise and go up to Bethel, where I vowed a vow to Him on the day when I fled from the face of Esau my brother, because he has been with me and brought me into this land in peace, and put ye away the strange gods that arc among you.'

**[31:2]** And they gave up the strange gods and that which was in their ears and which was on their necks and the idols which Rachel stole from Laban her father she gave wholly to Jacob. And he burnt and brake them to pieces and destroyed them, and hid them under an oak which is in the land of Shechem.

**[31:3]** And he went up on the new moon of the seventh month to Bethel. And he built an altar at the place where he had slept, and he set up a pillar there, and he sent word to his father Isaac to come to him to his sacrifice, and to his mother Rebecca.

**[31:4]** And Isaac said: 'Let my son Jacob come, and let me see him before I die.'

**[31:5]** And Jacob went to his father Isaac and to his mother Rebecca, to the house of his father Abraham, and he took two of his sons with him, Levi and Judah, and he came to his father Isaac and to his mother Rebecca.

**[31:6]** And Rebecca came forth from the tower to the front of it to kiss Jacob and embrace him; for her spirit had revived when she heard: 'Behold Jacob thy son has come'; and she kissed him.

**[31:7]** And she saw his two sons, and she recognised them, and said unto him: 'Are these thy sons, my son?' and she embraced them and kissed them, and blessed them, saying: 'In you shall the seed of Abraham become illustrious, and ye shall prove a blessing on the earth.'

**[31:8]** And Jacob went in to Isaac his father, to the chamber where he lay, and his two sons were with him, and he took the hand of his father, and stooping down he kissed him, and Isaac clung to the neck of Jacob his son, and wept upon his neck.

**[31:9]** And the darkness left the eyes of Isaac, and he saw the two sons of Jacob, Levi, and Judah, and he said: 'Are these thy sons, my son? for they are like thee.'

**[31:10]** And he said unto him that they were truly his sons: 'And thou hast truly seen that they are truly my sons'.

**[31:11]** And they came near to him, and he turned and kissed them and embraced them both together.

**[31:12]** And the spirit of prophecy came down into his mouth, and he took Levi by his right hand and Judah by his left.

**[31:13]** And he turned to Levi first, and began to bless him first, and said unto him: 'May the God of all, the very Lord of all the ages, bless thee and thy children throughout all the ages.

**[31:14]** And may the Lord give to thee and to thy seed greatness and great glory, and cause thee and thy seed, from among all flesh, to approach Him to serve in His sanctuary as the angels of the presence and as the holy ones. (Even) as they, shall the seed of thy sons be for glory and greatness and holiness, and may He make them great unto all the ages.

**[31:15]** And they shall be judges and princes, and chiefs of all the seed of the sons of Jacob; They shall speak the word of the Lord in righteousness, And they shall judge all His judgments in righteousness. And they shall declare My ways to Jacob And My paths to Israel. The blessing of the Lord shall be given in their mouths To bless all the seed of the beloved.

**[31:16]** Thy mother has called thy name Levi, And justly has she called thy name; Thou shalt be joined to the Lord And be the companion of all the sons of Jacob; Let His table be thine, And do thou and thy sons eat thereof; And may thy table be full unto all generations, And thy food fail not unto all the ages.

**[31:17]** And let all who hate thee fall down before thee, And let all thy adversaries be rooted out and perish; And blessed be he that blesses thee, And cursed be every nation that curses thee.'

**[31:18]** And to Judah he said: 'May the Lord give thee strength and power to tread down all that hate thee; A prince shalt thou be, thou and one of thy sons, over the sons of Jacob; May thy name and the name of thy sons go forth and traverse every land and region. Then shall the Gentiles fear before thy face, And all the nations shall quake [And all the peoples shall quake].

**[31:19]** In thee shall be the help of Jacob, And in thee be found the salvation of Israel.

**[31:20]** And when thou sittest on the throne of honour of thy righteousness There shall be great peace for all the seed of the sons of the beloved; Blessed be he that blesseth thee, And all that hate thee and afflict thee and curse thee Shall be rooted out and destroyed from the earth and be accursed.'

**[31:21]** And turning he kissed him again and embraced him, and rejoiced greatly; for he had seen the sons of Jacob his son in very truth.

**[31:22]** And he went forth from between his feet and fell down and bowed down to him, and he blessed them and rested there with Isaac his father that night, and they eat and drank with joy.

**[31:23]** And he made the two sons of Jacob sleep, the one on his right hand and the other on his left, and it was counted to him for righteousness.

**[31:24]** And Jacob told his father everything during the night, how the Lord had shown him great mercy, and how he had prospered (him in) all his ways, and protected him from all evil.

**[31:25]** And Isaac blessed the God of his father Abraham, who had not withdrawn his mercy and his righteousness from the sons of his servant Isaac.

**[31:26]** And in the morning Jacob told his father Isaac the vow which he had vowed to the Lord, and the vision which he had seen, and that he had built an altar, and that everything was ready for the sacrifice to be made before the Lord as he had vowed, and that he had come to set him on an ass.

**[31:27]** And Isaac said unto Jacob his son: 'I am not able to go with thee; for I am old and not able to bear the way: go, my son, in peace; for I am one hundred and sixty-five years this day; I am no longer able to journey; set thy mother (on an ass) and let her go with thee.

**[31:28]** And I know, my son, that thou hast come on my account, and may this day be blessed on which thou hast seen me alive, and I also have seen thee, my son.

**[31:29]** Mayest thou prosper and fulfil the vow which thou hast vowed; and put not off thy vow; for thou shalt be called to account as touching the vow; now therefore make haste to perform it, and may He be pleased who has made all things, to whom thou hast vowed the vow.'

**[31:30]** And he said to Rebecca: 'Go with Jacob thy son'; and Rebecca went with Jacob her son, and Deborah with her, and they came to Bethel.

**[31:31]** And Jacob remembered the prayer with which his father had blessed him and his two sons, Levi and Judah, and he rejoiced and blessed the God of his fathers, Abraham and Isaac.

**[31:32]** And he said: 'Now I know that I have an eternal hope, and my sons also, before the God of all'; and thus is it ordained concerning the two; and they record it as an eternal testimony unto them on the heavenly tablets how Isaac blessed them.

**[32:1]** And he abode that night at Bethel, and Levi dreamed that they had ordained and made him the priest of the Most High God, him and his sons for ever; and he awoke from his sleep and blessed the Lord.

**[32:2]** And Jacob rose early in the morning, on the fourteenth of this month, and he gave a tithe of all that came with him, both of men and cattle, both of gold and every vessel and garment, yea, he gave tithes of all.

**[32:3]** And in those days Rachel became pregnant with her son Benjamin. And Jacob counted his sons from him upwards and Levi fell to the portion of the Lord, and his father clothed him in the garments of the priesthood and filled his hands.

**[32:4]** And on the fifteenth of this month, he brought to the altar fourteen oxen from amongst the cattle, and twenty-eight rams, and forty-nine sheep, and seven lambs, and twenty-one kids of the goats as a burnt-offering on the altar of sacrifice, well pleasing for a sweet savour before God.

**[32:5]** This was his offering, in consequence of the vow which he had vowed that he would give a tenth, with their fruit-offerings and their drink- offerings.

**[32:6]** And when the fire had consumed it, he burnt incense on the fire over the fire, and for a thank-offering two oxen and four rams and four sheep, four he-goats, and two sheep of a year old, and two kids of the goats; and thus he did daily for seven days.

**[32:7]** And he and all his sons and his men were eating (this) with joy there during seven days and blessing and thanking the Lord, who had delivered him out of all his tribulation and had given him his vow.

**[32:8]** And he tithed all the clean animals, and made a burnt sacrifice, but the unclean animals he gave (not) to Levi his son, and he gave him all the souls of the men.

**[32:9]** And Levi discharged the priestly office at Bethel before Jacob his father in preference to his ten brothers, and he was a priest there, and Jacob gave his vow: thus he tithed again the tithe to the Lord and sanctified it, and it became holy unto Him.

**[32:10]** And for this reason it is ordained on the heavenly tablets as a law for the tithing again the tithe to eat before the Lord from year to year, in the place where it is chosen that His name should dwell, and to this law there is no limit of days for ever.

**[32:11]** This ordinance is written that it may be fulfilled from year to year in eating the second tithe before the Lord in the place where it has been chosen, and nothing shall remain over from it from this year to the year following.

**[32:12]** For in its year shall the seed be eaten till the days of the gathering of the seed of the year, and the wine till the days of the wine, and the oil till the days of its season.

**[32:13]** And all that is left thereof and becomes old, let it be regarded as polluted: let it be burnt with fire, for it is unclean.

**[32:14]** And thus let them eat it together in the sanctuary, and let them not suffer it to become old.

**[32:15]** And all the tithes of the oxen and sheep shall be holy unto the Lord, and shall belong to his priests, which they will eat before Him from year to year; for thus is it ordained and engraven regarding the tithe on the heavenly tablets.

**[32:16]** And on the following night, on the twenty-second day of this month, Jacob resolved to build that place, and to surround the court with a wall, and to sanctify it and make it holy for ever, for himself and his children after him.

**[32:17]** And the Lord appeared to him by night and blessed him and said unto him: 'Thy name shall not be called Jacob, but Israel shall they name thy name.'

**[32:18]** And He said unto him again: 'I am the Lord who created the heaven and the earth, and I will increase thee and multiply thee exceedingly, and kings shall come forth from thee, and they shall judge everywhere wherever the foot of the sons of men has trodden.

**[32:19]** And I will give to thy seed all the earth which is under heaven, and they shall judge all the nations according to their desires, and after that they shall get possession of the whole earth and inherit it for ever.'

**[32:20]** And He finished speaking with him, and He went up from him. and Jacob looked till He had ascended into heaven.

**[32:21]** And he saw in a vision of the night, and behold an angel descended from heaven with seven tablets in his hands, and he gave them to Jacob, and he read them and knew all that was written therein which would befall him and his sons throughout all the ages.

**[32:22]** And he showed him all that was written on the tablets, and said unto him: 'Do not build this place, and do not make it an eternal sanctuary, and do not dwell here; for this is not the place. Go to the house of Abraham thy father and dwell with Isaac thy father until the day of the death of thy father.

**[32:23]** For in Egypt thou shalt die in peace, and in this land thou shalt be buried with honour in the sepulchre of thy fathers, with Abraham and Isaac.

**[32:24]** Fear not, for as thou hast seen and read it, thus shall it all be; and do thou write down everything as thou hast seen and read.'

**[32:25]** And Jacob said: 'Lord, how can I remember all that I have read and seen? 'And he said unto him: 'I will bring all things to thy remembrance.'

**[32:26]** And he went up from him, and he awoke from his sleep, and he remembered everything which he had read and seen, and he wrote down all the words which he had read and seen.

**[32:27]** And he celebrated there yet another day, and he sacrificed thereon according to all that he sacrificed on the former days, and called its name 'Addition,' for this day was added and the former days he called 'The Feast '.

**[32:28]** And thus it was manifested that it should be, and it is written on the heavenly tablets: wherefore it was revealed to him that he should celebrate it, and add it to the seven days of the feast.

**[32:29]** And its name was called 'Addition,' because that it was recorded amongst the days of the feast days, according to the number of the days of the year.

**[32:30]** And in the night, on the twenty-third of this month, Deborah Rebecca's nurse died, and they buried her beneath the city under the oak of the river, and he called the name of this place, 'The river of Deborah,' and the oak, 'The oak of the mourning of Deborah.'

**[32:31]** And Rebecca went and returned to her house to his father Isaac, and Jacob sent by her hand rams and sheep and he-goats that she should prepare a meal for his father such as he desired.

**[32:32]** And he went after his mother till he came to the land of Kabratan, and he dwelt there.

**[32:33]** And Rachel bare a son in the night, and called his name 'Son of my sorrow '; for she suffered in giving him birth: but his father called his name Benjamin, on the eleventh of the eighth month in the first of the sixth week of this jubilee. [2143 A.M.]

**[32:34]** And Rachel died there and she was buried in the land of Ephrath, the same is Bethlehem, and Jacob built a pillar on the grave of Rachel, on the road above her grave.

**[33:1]** And Jacob went and dwelt to the south of Magdaladra'ef. And he went to his father Isaac, he and Leah his wife, on the new moon of the tenth month.

**[33:2]** And Reuben saw Bilhah, Rachel's maid, the concubine of his father, bathing in water in a secret place, and he loved her.

**[33:3]** And he hid himself at night, and he entered the house of Bilhah [at night], and he found her sleeping alone on a bed in her house.

**[33:4]** And he lay with her, and she awoke and saw, and behold Reuben was lying with her in the bed, and she uncovered the border of her covering and seized him, and cried out, and discovered that it was Reuben.

**[33:5]** And she was ashamed because of him, and released her hand from him, and he fled.

**[33:6]** And she lamented because of this thing exceedingly, and did not tell it to any one.

**[33:7]** And when Jacob returned and sought her, she said unto him: 'I am not clean for thee, for I have been defiled as regards thee; for Reuben has defiled me, and has lain with me in the night, and I was asleep, and did not discover until he uncovered my skirt and slept with me.'

**[33:8]** And Jacob was exceedingly wroth with Reuben because he had lain with Bilhah, because he had uncovered his father's skirt.

**[33:9]** And Jacob did not approach her again because Reuben had defiled her. And as for any man who uncovers his father's skirt his deed is wicked exceedingly, for he is abominable before the Lord.

**[33:10]** For this reason it is written and ordained on the heavenly tablets that a man should not lie with his father's wife, and should not uncover his father's skirt, for this is unclean: they shall surely die together, the man who lies with his father's wife and the woman also, for they have wrought uncleanness on the earth.

**[33:11]** And there shall be nothing unclean before our God in the nation which He has chosen for Himself as a possession.

**[33:12]** And again, it is written a second time: 'Cursed be he who lieth with the wife of his father, for he hath uncovered his father's shame'; and all the holy ones of the Lord said 'So be it; so be it.'

**[33:13]** And do thou, Moses, command the children of Israel that they observe this word; for it (entails) a punishment of death; and it is unclean, and there is no atonement for ever to atone for the man who has committed this, but he is to be put to death and slain, and stoned with stones, and rooted out from the midst of the people of our God.

**[33:14]** For to no man who does so in Israel is it permitted to remain alive a single day on the earth, for he is abominable and unclean.

**[33:15]** And let them not say: to Reuben was granted life and forgiveness after he had lain with his father's concubine, and to her also though she had a husband, and her husband Jacob, his father, was still alive.

**[33:16]** For until that time there had not been revealed the ordinance and judgment and law in its completeness for all, but in thy days (it has been revealed) as a law of seasons and of days, and an everlasting law for the everlasting generations.

**[33:17]** And for this law there is no consummation of days, and no atonement for it, but they must both be rooted out in the midst of the nation: on the day whereon they committed it they shall slay them.

**[33:18]** And do thou, Moses, write (it) down for Israel that they may observe it, and do according to these words, and not commit a sin unto death; for the Lord our God is judge, who respects not persons and accepts not gifts.

**[33:19]** And tell them these words of the covenant, that they may hear and observe, and be on their guard with respect to them, and not be destroyed and rooted out of the land; for an uncleanness, and an abomination, and a contamination, and a pollution are all they who commit it on the earth before our God.

**[33:20]** And there is no greater sin than the fornication which they commit on earth; for Israel is a holy nation unto the Lord its God, and a nation of inheritance, and a priestly and royal nation and for (His own) possession; and there shall no such uncleanness appear in the midst of the holy nation.

**[33:21]** And in the third year of this sixth week [2145 A.M.] Jacob and all his sons went and dwelt in the house of Abraham, near Isaac his father and Rebecca his mother.

**[33:22]** And these were the names of the sons of Jacob: the first-born Reuben, Simeon, Levi, Judah, Issachar, Zebulon, the sons of Leah; and the sons of Rachel, Joseph and Benjamin; and the sons of Bilhah, Dan and Naphtali; and the sons of Zilpah, Gad and Asher; and Dinah, the daughter of Leah, the only daughter of Jacob.

**[33:23]** And they came and bowed themselves to Isaac and Rebecca, and when they saw them they blessed Jacob and all his sons, and Isaac rejoiced exceedingly, for he saw the sons of Jacob, his younger son and he blessed them.

**[34:1]** And in the sixth year of this week of this forty-fourth jubilee [2148 A.M.] Jacob sent his sons to pasture their sheep, and his servants with them to the pastures of Shechem.

**[34:2]** And the seven kings of the Amorites assembled themselves together against them, to slay them, hiding themselves under the trees, and to take their cattle as a prey.

**[34:3]** And Jacob and Levi and Judah and Joseph were in the house with Isaac their father; for his spirit was sorrowful, and they could not leave him: and Benjamin was the youngest, and for this reason remained with his father.

**[34:4]** And there came the king[s] of Taphu and the king[s] of 'Aresa, and the king[s] of Seragan, and the king[s] of Selo, and the king[s] of Ga'as, and the king of Bethoron, and the king of Ma'anisakir, and all those who dwell in these mountains (and) who dwell in the woods in the land of Canaan.

**[34:5]** And they announced this to Jacob saying: 'Behold, the kings of the Amorites have surrounded thy sons, and plundered their herds.'

**[34:6]** And he arose from his house, he and his three sons and all the servants of his father, and his own servants, and he went against them with six thousand men, who carried swords.

**[34:7]** And he slew them in the pastures of Shechem, and pursued those who fled, and he slew them with the edge of the sword, and he slew 'Aresa and Taphu and Saregan and Selo and 'Amani- sakir and Ga[ga]'as, and he recovered his herds.

**[34:8]** And he prevailed over them, and imposed tribute on them that they should pay him tribute, five fruit products of their land, and he built Robel and Tamnatares.

**[34:9]** And he returned in peace, and made peace with them, and they became his servants, until the day that he and his sons went down into Egypt.

**[34:10]** And in the seventh year of this week [2149 A.M.] he sent Joseph to learn about the welfare of his brothers from his house to the land of Shechem, and he found them in the land of Dothan.

**[34:11]** And they dealt treacherously with him, and formed a plot against him to slay him, but changing their minds, they sold him to Ishmaelite merchants, and they brought him down into Egypt, and they sold him to Potiphar, the eunuch of Pharaoh, the chief of the cooks, priest of the city of 'Elew.

**[34:12]** And the sons of Jacob slaughtered a kid, and dipped the coat of Joseph in the blood, and sent (it) to Jacob their father on the tenth of the seventh month.

**[34:13]** And he mourned all that night, for they had brought it to him in the evening, and he became feverish with mourning for his death, and he said: 'An evil beast hath devoured Joseph'; and all the members of his house [mourned with him that day, and they] were grieving and mourning with him all that day.

**[34:14]** And his sons and his daughter rose up to comfort him, but he refused to be comforted for his son.

**[34:15]** And on that day Bilhah heard that Joseph had perished, and she died mourning him, and she was living in Qafratef, and Dinah also, his daughter, died after Joseph had perished.

**[34:16]** And there came these three mournings upon Israel in one month. And they buried Bilhah over against the tomb of Rachel, and Dinah also. his daughter, they buried there.

**[34:17]** And he mourned for Joseph one year, and did not cease, for he said 'Let me go down to the grave mourning for my son'.

**[34:18]** For this reason it is ordained for the children of Israel that they should afflict themselves on the tenth of the seventh month -on the day that the news which made him weep for Joseph came to Jacob his father- that they should make atonement for themselves thereon with a young goat on the tenth of the seventh month, once a year, for their sins; for they had grieved the affection of their father regarding Joseph his son.

**[34:19]** And this day has been ordained that they should grieve thereon for their sins, and for all their transgressions and for all their errors, so that they might cleanse themselves on that day once a year.

**[34:20]** And after Joseph perished, the sons of Jacob took unto themselves wives. The name of Reuben's wife is 'Ada; and the name of Simeon's wife is 'Adlba'a, a Canaanite; and the name of Levi's wife is Melka, of the daughters of Aram, of the seed of the sons of Terah; and the name of Judah's wife, Betasu'el, a Canaanite; and the name of Issachar's wife, Hezaqa: and the name of Zabulon's wife, Ni'iman; and the name of Dan's wife, 'Egla; and the name of Naphtali's wife, Rasu'u, of Mesopotamia; and the name of Gad's wife, Maka; and the name of Asher's wife, 'Ijona; and the name of Joseph's wife, Asenath, the Egyptian; and the name of Benjamin's wife, 'Ijasaka.

**[34:21]** And Simeon repented, and took a second wife from Mesopotamia as his brothers.

**[35:1]** And in the first year of the first week of the forty-fifth jubilee [2157 A.M.] Rebecca called Jacob, her son, and commanded him regarding his father and regarding his brother, that he should honour them all the days of his life.

**[35:2]** And Jacob said: 'I will do everything as thou hast commanded me; for this thing will be honour and greatness to me, and righteousness before the Lord, that I should honour them.

**[35:3]** And thou too, mother, knowest from the time I was born until this day, all my deeds and all that is in my heart, that I always think good concerning all.

**[35:4]** And how should I not do this thing which thou hast commanded me, that I should honour my father and my brother!

**[35:5]** Tell me, mother, what perversity hast thou seen in me and I shall turn away from it, and mercy will be upon me.'

**[35:6]** And she said unto him: 'My son, I have not seen in thee all my days any perverse but (only) upright deeds. And yet I will tell thee the truth, my son: I shall die this year, and I shall not survive this year in my life; for I have seen in a dream the day of my death, that I should not live beyond a hundred and fifty-five years: and behold I have completed all the days of my life which I am to live.'

**[35:7]** And Jacob laughed at the words of his mother. because his mother had said unto him that she should die; and she was sitting opposite to him in possession of her strength, and she was not infirm in her strength; for she went in and out and saw, and her teeth were strong, and no ailment had touched her all the days of her life.

**[35:8]** And Jacob said unto her: 'Blessed am I, mother, if my days approach the days of thy life, and my strength remain with me thus as thy strength: and thou wilt not die, for thou art jesting idly with me regarding thy death.'

**[35:9]** And she went in to Isaac and said unto him: 'One petition I make unto thee: make Esau swear that he will not injure Jacob, nor pursue him with enmity; for thou knowest Esau's thoughts that they are perverse from his youth, and there is no goodness in him; for he desires after thy death to kill him.

**[35:10]** And thou knowest all that he has done since the day Jacob his brother went to Haran until this day: how he has forsaken us with his whole heart, and has done evil to us; thy flocks he has taken to himself, and carried off all thy possessions from before thy face.

**[35:11]** And when we implored and besought him for what was our own, he did as a man who was taking pity on us.

**[35:12]** And he is bitter against thee because thou didst bless Jacob thy perfect and upright son; for there is no evil but only goodness in him, and since he came from Haran unto this day he has not robbed us of aught, for he brings us everything in its season always, and rejoices with all his heart when we take at his hands and he blesses us, and has not parted from us since he came from Haran until this day, and he remains with us continually at home honouring us.'

**[35:13]** And Isaac said unto her: 'I, too, know and see the deeds of Jacob who is with us, how that with all his heart he honours us; but I loved Esau formerly more than Jacob, because he was the firstborn; but now I love Jacob more than Esau, for he has done manifold evil deeds, and there is no righteousness in him, for all his ways are unrighteousness and violence, [and there is no righteousness around him.]

**[35:14]** And now my heart is troubled because of all his deeds, and neither he nor his seed is to be saved, for they are those who will be destroyed from the earth and who will be rooted out from under heaven, for he has forsaken the God of Abraham and gone after his wives and after their uncleanness and after their error, he and his children.

**[35:15]** And thou dost bid me make him swear that he will not slay Jacob his brother; even if he swear he will not abide by his oath, and he will not do good but evil only.

**[35:16]** But if he desires to slay Jacob, his brother, into Jacob's hands will he be given, and he will not escape from his hands, [for he will descend into his hands.]

**[35:17]** And fear thou not on account of Jacob; for the guardian of Jacob is great and powerful and honoured, and praised more than the guardian of Esau.'

**[35:18]** And Rebecca sent and called Esau and he came to her, and she said unto him: 'I have a petition, my son, to make unto thee, and do thou promise to do it, my son.'

**[35:19]** And he said: 'I will do everything that thou sayest unto me, and I will not refuse thy petition.'

**[35:20]** And she said unto him: 'I ask you that the day I die, thou wilt take me in and bury me near Sarah, thy father's mother, and that thou and Jacob will love each other and that neither will desire evil against the other, but mutual love only, and (so) ye will prosper, my sons, and be honoured in the midst of the land, and no enemy will rejoice over you, and ye will be a blessing and a mercy in the eyes of all those that love you.'

**[35:21]** And he said: 'I will do all that thou hast told me, and I shall bury thee on the day thou diest near Sarah, my father's mother, as thou hast desired that her bones may be near thy bones.

**[35:22]** And Jacob, my brother, also, I shall love above all flesh; for I have not a brother in all the earth but him only: and this is no great merit for me if I love him; for he is my brother, and we were sown together in thy body, and together came we forth from thy womb, and if I do not love my brother, whom shall I love?

**[35:23]** And I, myself, beg thee to exhort Jacob concerning me and concerning my sons, for I know that he will assuredly be king over me and my sons, for on the day my father blessed him he made him the higher and me the lower.

**[35:24]** And I swear unto thee that I shall love him, and not desire evil against him all the days of my life but good only.'

**[35:25]** And he sware unto her regarding all this matter. And she called Jacob before the eyes of Esau, and gave him commandment according to the words which she had spoken to Esau.

**[35:26]** And he said: 'I shall do thy pleasure; believe me that no evil will proceed from me or from my sons against Esau, and I shall be first in naught save in love only.'

**[35:27]** And they eat and drank, she and her sons that night, and she died, three jubilees and one week and one year old, on that night, and her two sons, Esau and Jacob, buried her in the double cave near Sarah, their father's mother.

**[36:1]** And in the sixth year of this week [2162 A.M.] Isaac called his two sons Esau and Jacob, and they came to him, and he said unto them: 'My sons, I am going the way of my fathers, to the eternal house where my fathers are.

**[36:2]** Wherefore bury me near Abraham my father, in the double cave in the field of Ephron the Hittite, where Abraham purchased a sepulchre to bury in; in the sepulchre which I digged for myself, there bury me.

**[36:3]** And this I command you, my sons, that ye practise righteousness and uprightness on the earth, so that the Lord may bring upon you all that the Lord said that he would do to Abraham and to his seed.

**[36:4]** And love one another, my sons, your brothers as a man who loves his own soul, and let each seek in what he may benefit his brother, and act together on the earth; and let them love each other as their own souls.

**[36:5]** And concerning the question of idols, I command and admonish you to reject them and hate them, and love them not, for they are full of deception for those that worship them and for those that bow down to them.

**[36:6]** Remember ye, my sons, the Lord God of Abraham your father, and how I too worshipped Him and served Him in righteousness and in joy, that He might multiply you and increase your seed as the stars of heaven in multitude, and establish you on the earth as the plant of righteousness which will not be rooted out unto all the generations for ever.

**[36:7]** And now I shall make you swear a great oath -for there is no oath which is greater than it by the name glorious and honoured and great and splendid and wonderful and mighty, which created the heavens and the earth and all things together- that ye will fear Him and worship Him.

**[36:8]** And that each will love his brother with affection and righteousness, and that neither will desire evil against his brother from henceforth for ever all the days of your life so that ye may prosper in all your deeds and not be destroyed.

**[36:9]** And if either of you devises evil against his brother, know that from henceforth everyone that devises evil against his brother shall fall into his hand, and shall be rooted out of the land of the living, and his seed shall be destroyed from under heaven.

**[36:10]** But on the day of turbulence and execration and indignation and anger, with flaming devouring fire as He burnt Sodom, so likewise will He burn his land and his city and all that is his, and he shall be blotted out of the book of the discipline of the children of men, and not be recorded in the book of life, but in that which is appointed to destruction, and he shall depart into eternal execration; so that their condemnation may be always renewed in hate and in execration and in wrath and in torment and in indignation and in plagues and in disease for ever.

**[36:11]** I say and testify to you, my sons, according to the judgment which shall come upon the man who wishes to injure his brother.

**[36:12]** And he divided all his possessions between the two on that day and he gave the larger portion to him that was the first-born, and the tower and all that was about it, and all that Abraham possessed at the Well of the Oath.

**[36:13]** And he said: 'This larger portion I will give to the firstborn.'

**[36:14]** And Esau said, 'I have sold to Jacob and given my birthright to Jacob; to him let it be given, and I have not a single word to say regarding it, for it is his.'

**[36:15]** And Isaac said, 'May a blessing rest upon you, my sons, and upon your seed this day, for ye have given me rest, and my heart is not pained concerning the birthright, lest thou shouldest work wickedness on account of it.

**[36:16]** May the Most High God bless the man that worketh righteousness, him and his seed for ever.'

**[36:17]** And he ended commanding them and blessing them, and they eat and drank together before him, and he rejoiced because there was one mind between them, and they went forth from him and rested that day and slept.

**[36:18]** And Isaac slept on his bed that day rejoicing; and he slept the eternal sleep, and died one hundred and eighty years old. He completed twenty-five weeks and five years; and his two sons Esau and Jacob buried him.

**[36:19]** And Esau went to the land of Edom, to the mountains of Seir, and dwelt there.

**[36:20]** And Jacob dwelt in the mountains of Hebron, in the tower of the land of the sojournings of his father Abraham, and he worshipped the Lord with all his heart and according to the visible commands according as He had divided the days of his generations.

**[36:21]** And Leah his wife died in the fourth year of the second week of the forty-fifth jubilee, [2167 A.M.] and he buried her in the double cave near Rebecca his mother to the left of the grave of Sarah, his father's mother

**[36:22]** and all her sons and his sons came to mourn over Leah his wife with him and to comfort him regarding her, for he was lamenting her for he loved her exceedingly after Rachel her sister died;

**[36:23]** for she was perfect and upright in all her ways and honoured Jacob,and all the days that she lived with him he did not hear from her mouth a harsh word, for she was gentle and peaceable and upright and honourable.

**[36:24]** And he remembered all her deeds which she had done during her life and he lamented her exceedingly; for he loved her with all his heart and with all his soul.

**[37:1]** And on the day that Isaac the father of Jacob and Esau died, [2162 A.M.] the sons of Esau heard that Isaac had given the portion of the elder to his younger son Jacob and they were very angry.

**[37:2]** And they strove with their father, saying 'Why has thy father given Jacob the portion of the elder and passed over thee, although thou art the elder and Jacob the younger?'

**[37:3]** And he said unto them 'Because I sold my birthright to Jacob for a small mess of lentils, and on the day my father sent me to hunt and catch and bring him something that he should eat and bless me, he came with guile and brought my father food and drink, and my father blessed him and put me under his hand.

**[37:4]** And now our father has caused us to swear, me and him, that we shall not mutually devise evil, either against his brother, and that we shall continue in love and in peace each with his brother and not make our ways corrupt.'

**[37:5]** And they said unto him, 'We shall not hearken unto thee to make peace with him; for our strength is greater than his strength, and we are more powerful than he; we shall go against him and slay him, and destroy him and his sons. And if thou wilt not go with us, we shall do hurt to thee also.

**[37:6]** And now hearken unto us: Let us send to Aram and Philistia and Moab and Ammon, and let us choose for ourselves chosen men who are ardent for battle, and let us go against him and do battle with him, and let us exterminate him from the earth before he grows strong.'

**[37:7]** And their father said unto them, 'Do not go and do not make war with him lest ye fall before him.'

**[37:8]** And they said unto him, 'This too, is exactly thy mode of action from thy youth until this day, and thou art putting thy neck under his yoke.

**[37:9]** We shall not hearken to these words.' And they sent to Aram, and to 'Aduram to the friend of their father, and they hired along with them one thousand fighting men, chosen men of war.

**[37:10]** And there came to them from Moab and from the children of Ammon, those who were hired, one thousand chosen men, and from Philistia, one thousand chosen men of war, and from Edom and from the Horites one thousand chosen fighting men, and from the Kittim mighty men of war.

**[37:11]** And they said unto their father: Go forth with them and lead them, else we shall slay thee.'

**[37:12]** And he was filled with wrath and indignation on seeing that his sons were forcing him to go before (them) to lead them against Jacob his brother.

**[37:13]** But afterward he remembered all the evil which lay hidden in his heart against Jacob his brother; and he remembered not the oath which he had sworn to his father and to his mother that he would devise no evil all his days against Jacob his brother.

**[37:14]** And notwithstanding all this, Jacob knew not that they were coming against him to battle, and he was mourning for Leah, his wife, until they approached very near to the tower with four thousand warriors and chosen men of war.

**[37:15]** And the men of Hebron sent to him saying, 'Behold thy brother has come against thee, to fight thee, with four thousand girt with the sword, and they carry shields and weapons'; for they loved Jacob more than Esau. So they told him; for Jacob was a more liberal and merciful man than Esau.

**[37:16]** But Jacob would not believe until they came very near to the tower.

**[37:17]** And he closed the gates of the tower; and he stood on the battlements and spake to his brother Esau and said, 'Noble is the comfort wherewith thou hast come to comfort me for my wife who has died. Is this the oath that thou didst swear to thy father and again to thy mother before they died? Thou hast broken the oath, and on the moment that thou didst swear to thy father wast thou condemned.'

**[37:18]** And then Esau answered and said unto him, 'Neither the children of men nor the beasts of the earth have any oath of righteousness which in swearing they have sworn (an oath valid) for ever; but every day they devise evil one against another, and how each may slay his adversary and foe.

**[37:19]** And thou dost hate me and my children for ever. And there is no observing the tie of brotherhood with thee.

**[37:20]** Hear these words which I declare unto thee, If the boar can change its skin and make its bristles as soft as wool, Or if it can cause horns to sprout forth on its head like the horns of a stag or of a sheep, Then will I observe the tie of brotherhood with thee And if the breasts separated themselves from their mother, for thou hast not been a brother to me.

**[37:21]** And if the wolves make peace with the lambs so as not to devour or do them violence, And if their hearts are towards them for good, Then there shall be peace in my heart towards thee

**[37:22]** And if the lion becomes the friend of the ox and makes peace with him And if he is bound under one yoke with him and ploughs with him, Then will I make peace with thee.

**[37:23]** And when the raven becomes white as the raza, Then know that I have loved thee And shall make peace with thee Thou shalt be rooted out, And thy sons shall be rooted out, And there shall be no peace for thee'

**[37:24]** And when Jacob saw that he was (so) evilly disposed towards him with his heart, and with all his soul as to slay him, and that he had come springing like the wild boar which comes upon the spear that pierces and kills it, and recoils not from it;

**[37:25]** then he spake to his own and to his servants that they should attack him and all his companions.

**[38:1]** And after that Judah spake to Jacob, his father, and said unto him: 'Bend thy bow, father, and send forth thy arrows and cast down the adversary and slay the enemy; and mayst thou have the power, for we shall not slay thy brother, for he is such as thou, and he is like thee let us give him (this) honour.'

**[38:2]** Then Jacob bent his bow and sent forth the arrow and struck Esau, his brother (on his right breast) and slew him.

**[38:3]** And again he sent forth an arrow and struck 'Adoran the Aramaean, on the left breast, and drove him backward and slew him.

**[38:4]** And then went forth the sons of Jacob, they and their servants, dividing themselves into companies on the four sides of the tower.

**[38:5]** And Judah went forth in front, and Naphtali and Gad with him and fifty servants with him on the south side of the tower, and they slew all they found before them, and not one individual of them escaped.

**[38:6]** And Levi and Dan and Asher went forth on the east side of the tower, and fifty (men) with them, and they slew the fighting men of Moab and Ammon.

**[38:7]** And Reuben and Issachar and Zebulon went forth on the north side of the tower, and fifty men with them, and they slew the fighting men of the Philistines.

**[38:8]** And Simeon and Benjamin and Enoch, Reuben's son, went forth on the west side of the tower, and fifty (men) with them, and they slew of Edom and of the Horites four hundred men, stout warriors; and six hundred fled, and four of the sons of Esau fled with them, and left their father lying slain, as he had fallen on the hill which is in 'Aduram.

**[38:9]** And the sons of Jacob pursued after them to the mountains of Seir. And Jacob buried his brother on the hill which is in 'Aduram, and he returned to his house.

**[38:10]** And the sons of Jacob pressed hard upon the sons of Esau in the mountains of Seir, and bowed their necks so that they became servants of the sons of Jacob.

**[38:11]** And they sent to their father (to inquire) whether they should make peace with them or slay them.

**[38:12]** And Jacob sent word to his sons that they should make peace, and they made peace with them, and placed the yoke of servitude upon them, so that they paid tribute to Jacob and to his sons always.

**[38:13]** And they continued to pay tribute to Jacob until the day that he went down into Egypt.

**[38:14]** And the sons of Edom have not got quit of the yoke of servitude which the twelve sons of Jacob had imposed on them until this day.

**[38:15]** And these are the kings that reigned in Edom before there reigned any king over the children of Israel [until this day] in the land of Edom.

**[38:16]** And Balaq, the son of Beor, reigned in Edom, and the name of his city was Danaba.

**[38:17]** And Balaq died, and Jobab, the son of Zara of Boser, reigned in his stead.

**[38:18]** And Jobab died, and 'Asam, of the land of Teman, reigned in his stead.

**[38:19]** And 'Asam died, and 'Adath, the son of Barad, who slew Midian in the field of Moab, reigned in his stead, and the name of his city was Avith.

**[38:20]** And 'Adath died, and Salman, from 'Amaseqa, reigned in his stead.

**[38:21]** And Salman died,and Saul of Ra'aboth (by the) river, reigned in his stead.

**[38:22]** And Saul died, and Ba'elunan, the son of Achbor, reigned in his stead.

**[38:23]** And Ba'elunan, the son of Achbor died, and 'Adath reigned in his stead, and the name of his wife was Maitabith, the daughter of Matarat, the daughter of Metabedza'ab.

**[38:24]** These are the kings who reigned in the land of Edom.

**[39:1]** And Jacob dwelt in the land of his father's sojournings in the land of Canaan. These are the generations of Jacob.

**[39:2]** And Joseph was seventeen years old when they took him down into the land of Egypt, and Potiphar, an eunuch of Pharaoh, the chief cook bought him.

**[39:3]** And he set Joseph over all his house and the blessing of the Lord came upon the house of the Egyptian on account of Joseph, and the Lord prospered him in all that he did.

**[39:4]** And the Egyptian committed everything into the hands of Joseph; for he saw that the Lord was with him, and that the Lord prospered him in all that he did.

**[39:5]** And Joseph's appearance was comely [and very beautiful was his appearance], and his master's wife lifted up her eyes and saw Joseph, and she loved him and besought him to lie with her.

**[39:6]** But he did not surrender his soul, and he remembered the Lord and the words which Jacob, his father, used to read from amongst the words of Abraham, that no man should commit fornication with a woman who has a husband; that for him the punishment of death has been ordained in the heavens before the Most High God, and the sin will be recorded against him in the eternal books continually before the Lord.

**[39:7]** And Joseph remembered these words and refused to lie with her.

**[39:8]** And she besought him for a year, but he refused and would not listen.

**[39:9]** But she embraced him and held him fast in the house in order to force him to lie with her, and closed the doors of the house and held him fast; but he left his garment in her hands and broke through the door and fled without from her presence.

**[39:10]** And the woman saw that he would not lie with her, and she calumniated him in the presence of his lord, saying 'Thy Hebrew servant, whom thou lovest, sought to force me so that he might lie with me; and it came to pass when I lifted up my voice that he fled and left his garment in my hands when I held him, and he brake through the door.'

**[39:11]** And the Egyptian saw the garment of Joseph and the broken door, and heard the words of his wife, and cast Joseph into prison into the place where the prisoners were kept whom the king imprisoned.

**[39:12]** And he was there in the prison; and the Lord gave Joseph favour in the sight of the chief of the prison guards and compassion before him, for he saw that the Lord was with him, and that the Lord made all that he did to prosper.

**[39:13]** And he committed all things into his hands, and the chief of the prison guards knew of nothing that was with him, for Joseph did every thing, and the Lord perfected it.

**[39:14]** And he remained there two years. And in those days Pharaoh, king of Egypt was wroth against his two eunuchs, against the chief butler, and against the chief baker, and he put them in ward in the house of the chief cook, in the prison where Joseph was kept.

**[39:15]** And the chief of the prison guards appointed Joseph to serve them; and he served before them.

**[39:16]** And they both dreamed a dream, the chief butler and the chief baker, and they told it to Joseph.

**[39:17]** And as he interpreted to them so it befell them, and Pharaoh restored the chief butler to his office and the (chief) baker he slew, as Joseph had interpreted to them.

**[39:18]** But the chief butler forgot Joseph in the prison, although he had informed him what would befall him, and did not remember to inform Pharaoh how Joseph had told him, for he forgot.

**[40:1]** And in those days Pharaoh dreamed two dreams in one night concerning a famine which was to be in all the land, and he awoke from his sleep and called all the interpreters of dreams that were in Egypt, and magicians, and told them his two dreams, and they were not able to declare (them).

**[40:2]** And then the chief butler remembered Joseph and spake of him to the king, and he brought him forth from the prison, and he to]d his two dreams before him.

**[40:3]** And he said before Pharaoh that his two dreams were one, and he said unto him: 'Seven years shall come (in which there shall be) plenty over all the land of Egypt, and after that seven years of famine, such a famine as has not been in all the land.

**[40:4]** And now let Pharaoh appoint overseers in all the land of Egypt, and let them store up food in every city throughout the days of the years of plenty, and there will be food for the seven years of famine, and the land will not perish through the famine, for it will be very severe.'

**[40:5]** And the Lord gave Joseph favour and mercy in the eyes of Pharaoh, and Pharaoh said unto his servants: 'We shall not find such a wise and discreet man as this man, for the spirit of the Lord is with him.'

**[40:6]** And he appointed him the second in all his kingdom and gave him authority over all Egypt, and caused him to ride in the second chariot of Pharaoh.

**[40:7]** And he clothed him with byssus garments, and he put a gold chain upon his neck, and (a herald) proclaimed before him ' 'El 'El wa 'Abirer,' and placed a ring on his hand and made him ruler over all his house, and magnified him, and said unto him. 'Only on the throne shall I be greater than thou.'

**[40:8]** And Joseph ruled over all the land of Egypt, and all the princes of Pharaoh, and all his servants, and all who did the king's business loved him, for he walked in uprightness, for he was without pride and arrogance, and he had no respect of persons, and did not accept gifts, but he judged in uprightness all the people of the land.

**[40:9]** And the land of Egypt was at peace before Pharaoh because of Joseph, for the Lord was with him, and gave him favour and mercy for all his generations before all those who knew him and those who heard concerning him, and Pharaoh's kingdom was well ordered, and there was no Satan and no evil person (therein).

**[40:10]** And the king called Joseph's name Sephantiphans, and gave Joseph to wife the daughter of Potiphar, the daughter of the priest of Heliopolis, the chief cook.

**[40:11]** And on the day that Joseph stood before Pharaoh he was thirty years old [when he stood before Pharaoh].

**[40:12]** And in that year Isaac died. And it came to pass as Joseph had said in the interpretation of his two dreams, according as he had said it, there were seven years of plenty over all the land of Egypt, and the land of Egypt abundantly produced, one measure (producing) eighteen hundred measures.

**[40:13]** And Joseph gathered food into every city until they were full of corn until they could no longer count and measure it for its multitude.

**[41:1]** And in the forty-fifth jubilee, in the second week, (and) in the second year, [2165 A.M.] Judah took for his first-born Er, a wife from the daughters of Aram, named Tamar.

**[41:2]** But he hated, and did not lie with her, because his mother was of the daughters of Canaan, and he wished to take him a wife of the kinsfolk of his mother, but Judah, his father, would not permit him.

**[41:3]** And this Er, the first-born of Judah, was wicked, and the Lord slew him.

**[41:4]** And Judah said unto Onan, his brother 'Go in unto thy brother's wife and perform the duty of a husband's brother unto her, and raise up seed unto thy brother.'

**[41:5]** And Onan knew that the seed would not be his, (but) his brother's only, and he went into the house of his brother's wife, and spilt the seed on the ground, and he was wicked in the eyes of the Lord, and He slew him.

**[41:6]** And Judah said unto Tamar, his daughter-in-law: 'Remain in thy father's house as a widow till Shelah my son be grown up, and I shall give thee to him to wife.'

**[41:7]** And he grew up; but Bedsu'el, the wife of Judah, did not permit her son Shelah to marry. And Bedsu'el, the wife of Judah, died [2168 A.M.] in the fifth year of this week.

**[41:8]** And in the sixth year Judah went up to shear his sheep at Timnah. [2169 A.M.] And they told Tamar: 'Behold thy father-in-law goeth up to Timnah to shear his sheep.'

**[41:9]** And she put off her widow's clothes, and put on a veil, and adorned herself, and sat in the gate adjoining the way to Timnah.

**[41:10]** And as Judah was going along he found her, and thought her to be an harlot, and he said unto her: 'Let me come in unto thee'; and she said unto him Come in,' and he went in.

**[41:11]** And she said unto him: 'Give me my hire'; and he said unto her: 'I have nothing in my hand save my ring that is on my finger, and my necklace, and my staff which is in my hand.'

**[41:12]** And she said unto him 'Give them to me until thou dost send me my hire', and he said unto her: 'I will send unto thee a kid of the goats'; and he gave them to her, and he went in unto her, and she conceived by him.

**[41:13]** And Judah went unto his sheep, and she went to her father's house.

**[41:14]** And Judah sent a kid of the goats by the hand of his shepherd, an Adullamite, and he found her not; and he asked the people of the place, saying: 'Where is the harlot who was here?' And they said unto him; 'There is no harlot here with us.'

**[41:15]** And he returned and informed him, and said unto him that he had not found her: 'I asked the people of the place, and they said unto me: "There is no harlot here." '

**[41:16]** And he said: 'Let her keep (them) lest we become a cause of derision.' And when she had completed three months, it was manifest that she was with child, and they told Judah, saying: 'Behold Tamar, thy daughter-in-law, is with child by whoredom.'

**[41:17]** And Judah went to the house of her father, and said unto her father and her brothers: 'Bring her forth, and let them burn her, for she hath wrought uncleanness in Israel.'

**[41:18]** And it came to pass when they brought her forth to burn her that she sent to her father-in-law the ring and the necklace, and the staff, saying: 'Discern whose are these, for by him am I with child.'

**[41:19]** And Judah acknowledged, and said: 'Tamar is more righteous than I am.

**[41:20]** And therefore let them burn her not' And for that reason she was not given to Shelah, and he did not again approach her.

**[41:21]** And after that she bare two sons, Perez [2170 A.M.] and Zerah, in the seventh year of this second week.

**[41:22]** And thereupon the seven years of fruitfulness were accomplished, of which Joseph spake to Pharaoh.

**[41:23]** And Judah acknowledged that the deed which he had done was evil, for he had lain with his daughter-in-law, and he esteemed it hateful in his eyes, and he acknowledged that he had transgressed and gone astray, for he had uncovered the skirt of his son, and he began to lament and to supplicate before the Lord because of his transgression.

**[41:24]** And we told him in a dream that it was forgiven him because he supplicated earnestly, and lamented, and did not again commit it.

**[41:25]** And he received forgiveness because he turned from his sin and from his ignorance, for he transgressed greatly before our God; and every one that acts thus, every one who lies with his mother-in-law, let them burn him with fire that he may burn therein, for there is uncleanness and pollution upon them, with fire let them burn them.

**[41:26]** And do thou command the children of Israel that there be no uncleanness amongst them, for every one who lies with his daughter-in-law or with his mother-in-law hath wrought uncleanness; with fire let them burn the man who has lain with her, and likewise the woman, and He will turn away wrath and punishment from Israel.

**[41:27]** And unto Judah we said that his two sons had not lain with her, and for this reason his seed was stablished for a second generation, and would not be rooted out.

**[41:28]** For in singleness of eye he had gone and sought for punishment, namely, according to the judgment of Abraham, which he had commanded his sons, Judah had sought to burn her with fire.

**[42:1]** And in the first year of the third week of the forty-fifth jubilee the famine began to come into the [2171 A.M.] land, and the rain refused to be given to the earth, for none whatever fell.

**[42:2]** And the earth grew barren, but in the land of Egypt there was food, for Joseph had gathered the seed of the land in the seven years of plenty and had preserved it.

**[42:3]** And the Egyptians came to Joseph that he might give them food, and he opened the store-houses where was the grain of the first year, and he sold it to the people of the land for gold.

**[42:4]** <Now the famine was very sore in the land of Canaan>, and Jacob heard that there was food in Egypt, and he sent his ten sons that they should procure food for him in Egypt; but Benjamin he did not send, and <the ten sons of Jacob> arrived <in Egypt> among those that went (there).

**[42:5]** And Joseph recognised them, but they did not recognise him, and he spake unto them and questioned them, and he said unto them; 'Are ye not spies and have ye not come to explore the approaches of the land? 'And he put them in ward.

**[42:6]** And after that he set them free again, and detained Simeon alone and sent off his nine brothers.

**[42:7]** And he filled their sacks with corn, and he put their gold in their sacks, and they did not know.

**[42:8]** And he commanded them to bring their younger brother, for they had told him their father was living and their younger brother.

**[42:9]** And they went up from the land of Egypt and they came to the land of Canaan; and they told their father all that had befallen them, and how the lord of the country had spoken roughly to them, and had seized Simeon till they should bring Benjamin.

**[42:10]** And Jacob said: 'Me have ye bereaved of my children! Joseph is not and Simeon also is not, and ye will take Benjamin away. On me has your wickedness come.

**[42:11]** 'And he said: 'My son will not go down with you lest perchance he fall sick; for their mother gave birth to two sons, and one has perished, and this one also ye will take from me. If perchance he took a fever on the road, ye would bring down my old age with sorrow unto death.'

**[42:12]** For he saw that their money had been returned to every man in his sack, and for this reason he feared to send him.

**[42:13]** And the famine increased and became sore in the land of Canaan, and in all lands save in the land of Egypt, for many of the children of the Egyptians had stored up their seed for food from the time when they saw Joseph gathering seed together and putting it in storehouses and preserving it for the years of famine.

**[42:14]** And the people of Egypt fed themselves thereon during the first year of their famine.

**[42:15]** But when Israel saw that the famine was very sore in the land, and that there was no deliverance, he said unto his sons: 'Go again, and procure food for us that we die not.'

**[42:16]** And they said: 'We shall not go; unless our youngest brother go with us, we shall not go.'

**[42:17]** And Israel saw that if he did not send him with them, they should all perish by reason of the famine

**[42:18]** And Reuben said: 'Give him into my hand, and if I do not bring him back to thee, slay my two sons instead of his soul.'

**[42:19]** And he said unto him: 'He shall not go with thee.' And Judah came near and said: 'Send him with me, and if I do not bring him back to thee, let me bear the blame before thee all the days of my life.'

**[42:20]** And he sent him with them in the second year of this week on the [2172 A.m.] first day of the month, and they came to the land of Egypt with all those who went, and (they had) presents in their hands, stacte and almonds and terebinth nuts and pure honey.

**[42:21]** And they went and stood before Joseph, and he saw Benjamin his brother, and he knew him, and said unto them: 'Is this your youngest brother?' And they said unto him: 'It is he.' And he said 'The Lord be gracious to thee, my son!'

**[42:22]** And he sent him into his house and he brought forth Simeon unto them and he made a feast for them, and they presented to him the gift which they had brought in their hands.

**[42:23]** And they eat before him and he gave them all a portion, but the portion of Benjamin was seven times larger than that of any of theirs.

**[42:24]** And they eat and drank and arose and remained with their asses.

**[42:25]** And Joseph devised a plan whereby he might learn their thoughts as to whether thoughts of peace prevailed amongst them, and he said to the steward who was over his house: 'Fill all their sacks with food, and return their money unto them into their vessels, and my cup, the silver cup out of which I drink, put it in the sack of the youngest, and send them away.'

**[43:1]** And he did as Joseph had told him, and filled all their sacks for them with food and put their money in their sacks, and put the cup in Benjamin's sack.

**[43:2]** And early in the morning they departed, and it came to pass that, when they had gone from thence, Joseph said unto the steward of his house: 'Pursue them, run and seize them, saying, "For good ye have requited me with evil; you have stolen from me the silver cup out of which my lord drinks." And bring back to me their youngest brother, and fetch (him) quickly before I go forth to my seat of judgment.'

**[43:3]** And he ran after them and said unto them according to these words.

**[43:4]** And they said unto him: 'God forbid that thy servants should do this thing, and steal from the house of thy lord any utensil, and the money also which we found in our sacks the first time, we thy servants brought back from the land of Canaan.

**[43:5]** How then should we steal any utensil? Behold here are we and our sacks search, and wherever thou findest the cup in the sack of any man amongst us, let him be slain, and we and our asses will serve thy lord.'

**[43:6]** And he said unto them: 'Not so, the man with whom I find, him only shall I take as a servant, and ye shall return in peace unto your house.'

**[43:7]** And as he was searching in their vessels, beginning with the eldest and ending with the youngest, it was found in Benjamin's sack.

**[43:8]** And they rent their garments, and laded their asses, and returned to the city and came to the house of Joseph, and they all bowed themselves on their faces to the ground before him.

**[43:9]** And Joseph said unto them: 'Ye have done evil.' And they said: 'What shall we say and how shall we defend ourselves? Our lord hath discovered the transgression of his servants; behold we are the servants of our lord, and our asses also.

**[43:10]** 'And Joseph said unto them: 'I too fear the Lord; as for you, go ye to your homes and let your brother be my servant, for ye have done evil. Know ye not that a man delights in his cup as I with this cup? And yet ye have stolen it from me.'

**[43:11]** And Judah said: 'O my lord, let thy servant, I pray thee, speak a word in my lord's ear two brothers did thy servant's mother bear to our father: one went away and was lost, and hath not been found, and he alone is left of his mother, and thy servant our father loves him, and his life also is bound up with the life of this (lad).

**[43:12]** And it will come to pass, when we go to thy servant our father, and the lad is not with us, that he will die, and we shall bring down our father with sorrow unto death.

**[43:13]** Now rather let me, thy servant, abide instead of the boy as a bondsman unto my lord, and let the lad go with his brethren, for I became surety for him at the hand of thy servant our father, and if I do not bring him back, thy servant will hear the blame to our father for ever.'

**[43:14]** And Joseph saw that they were all accordant in goodness one with another, and he could not refrain himself, and he told them that he was Joseph.

**[43:15]** And he conversed with them in the Hebrew tongue and fell on their neck and wept.

**[43:16]** But they knew him not and they began to weep. And he said unto them: 'Weep not over me, but hasten and bring my father to me; and ye see that it is my mouth that speaketh and the eyes of my brother Benjamin see.

**[43:17]** For behold this is the second year of the famine, and there are still five years without harvest or fruit of trees or ploughing.

**[43:18]** Come down quickly ye and your households, so that ye perish not through the famine, and do not be grieved for your possessions, for the Lord sent me before you to set things in order that many people might live.

**[43:19]** And tell my father that I am still alive, and ye, behold, ye see that the Lord has made me as a father to Pharaoh, and ruler over his house and over all the land of Egypt.

**[43:20]** And tell my father of all my glory, and all the riches and glory that the Lord hath given me.'

**[43:21]** And by the command of the mouth of Pharaoh he gave them chariots and provisions for the way, and he gave them all many-coloured raiment and silver.

**[43:22]** And to their father he sent raiment and silver and ten asses which carried corn, and he sent them away.

**[43:23]** And they went up and told their father that Joseph was alive, and was measuring out corn to all the nations of the earth, and that he was ruler over all the land of Egypt.

**[43:24]** And their father did not believe it, for he was beside himself in his mind; but when he saw the wagons which Joseph had sent, the life of his spirit revived, and he said: 'It is enough for me if Joseph lives; I will go down and see him before I die.'

**[44:1]** And Israel took his journey from Haran from his house on the new moon of the third month, and he went on the way of the Well of the Oath, and he offered a sacrifice to the God of his father Isaac on the seventh of this month.

**[44:2]** And Jacob remembered the dream that he had seen at Bethel, and he feared to go down into Egypt.

**[44:3]** And while he was thinking of sending word to Joseph to come to him, and that he would not go down, he remained there seven days, if perchance he could see a vision as to whether he should remain or go down.

**[44:4]** And he celebrated the harvest festival of the first-fruits with old grain, for in all the land of Canaan there was not a handful of seed [in the land], for the famine was over all the beasts and cattle and birds, and also over man.

**[44:5]** And on the sixteenth the Lord appeared unto him, and said unto him, 'Jacob, Jacob'; and he said, 'Here am I.' And He said unto him: 'I am the God of thy fathers, the God of Abraham and Isaac; fear not to go down into Egypt, for I will there make of thee a great nation I will go down with thee, and I will bring thee up (again), and in this land shalt thou be buried, and Joseph shall put his hands upon thy eyes.

**[44:6]** Fear not; go down into Egypt.'

**[44:7]** And his sons rose up, and his sons' sons, and they placed their father and their possessions upon wagons.

**[44:8]** And Israel rose up from the Well of the Oath on the sixteenth of this third month, and he went to the land of Egypt.

**[44:9]** And Israel sent Judah before him to his son Joseph to examine the Land of Goshen, for Joseph had told his brothers that they should come and dwell there that they might be near him.

**[44:10]** And this was the goodliest (land) in the land of Egypt, and near to him, for all (of them) and also for the cattle.

**[44:11]** And these are the names of the sons of Jacob who went into Egypt with Jacob their father.

**[44:12]** Reuben, the First-born of Israel; and these are the names of his sons Enoch, and Pallu, and Hezron and Carmi-five.

**[44:13]** Simeon and his sons; and these are the names of his sons: Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul, the son of the Zephathite woman-seven.

**[44:14]** Levi and his sons; and these are the names of his sons: Gershon, and Kohath, and Merari-four.

**[44:15]** Judah and his sons; and these are the names of his sons: Shela, and Perez, and Zerah-four.

**[44:16]** Issachar and his sons; and these are the names of his sons: Tola, and Phua, and Jasub, and Shimron-five.

**[44:17]** Zebulon and his sons; and these are the names of his sons: Sered, and Elon, and Jahleel-four.

**[44:18]** And these are the sons of Jacob and their sons whom Leah bore to Jacob in Mesopotamia, six, and their one sister, Dinah and all the souls of the sons of Leah, and their sons, who went with Jacob their father into Egypt, were twenty-nine, and Jacob their father being with them, they were thirty.

**[44:19]** And the sons of Zilpah, Leah's handmaid, the wife of Jacob, who bore unto Jacob Gad and Ashur.

**[44:20]** And these are the names of their sons who went with him into Egypt. The sons of Gad: Ziphion, and Haggi, and Shuni, and Ezbon, <and Eri>, and Areli, and Arodi-eight.

**[44:21]** And the sons of Asher: Imnah, and Ishvah, <and Ishvi>, and Beriah, and Serah, their one sister-six.

**[44:22]** All the souls were fourteen, and all those of Leah were forty-four.

**[44:23]** And the sons of Rachel, the wife of Jacob: Joseph and Benjamin.

**[44:24]** And there were born to Joseph in Egypt before his father came into Egypt, those whom Asenath, daughter of Potiphar priest of Heliopolis bare unto him, Manasseh, and Ephraim-three.

**[44:25]** And the sons of Benjamin: Bela and Becher and Ashbel, Gera, and Naaman, and Ehi, and Rosh, and Muppim, and Huppim, and Ard-eleven.

**[44:26]** And all the souls of Rachel were fourteen.

**[44:27]** And the sons of Bilhah, the handmaid of Rachel, the wife of Jacob, whom she bare to Jacob, were Dan and Naphtali.

**[44:28]** And these are the names of their sons who went with them into Egypt. And the sons of Dan were Hushim, and Samon, and Asudi. and 'Ijaka, and Salomon-six.

**[44:29]** And they died the year in which they entered into Egypt, and there was left to Dan Hushim alone.

**[44:30]** And these are the names of the sons of Naphtali Jahziel, and Guni and Jezer, and Shallum, and 'Iv.

**[44:31]** And 'Iv, who was born after the years of famine, died in Egypt.

**[44:32]** And all the souls of Rachel were twenty-six.

**[44:33]** And all the souls of Jacob which went into Egypt were seventy souls. These are his children and his children's children, in all seventy, but five died in Egypt before Joseph, and had no children.

**[44:34]** And in the land of Canaan two sons of Judah died, Er and Onan, and they had no children, and the children of Israel buried those who perished, and they were reckoned among the seventy Gentile nations.

**[45:1]** And Israel went into the country of Egypt, into the land of Goshen, on the new moon of the fourth [2172 A.M]. month, in the second year of the third week of the forty-fifth jubilee.

**[45:2]** And Joseph went to meet his father Jacob, to the land of Goshen, and he fell on his father's neck and wept.

**[45:3]** And Israel said unto Joseph: 'Now let me die since I have seen thee, and now may the Lord God of Israel be blessed the God of Abraham and the God of Isaac who hath not withheld His mercy and His grace from His servant Jacob.

**[45:4]** It is enough for me that I have seen thy face whilst I am yet alive; yea, true is the vision which I saw at Bethel. Blessed be the Lord my God for ever and ever, and blessed be His name.'

**[45:5]** And Joseph and his brothers eat bread before their father and drank wine, and Jacob rejoiced with exceeding great joy because he saw Joseph eating with his brothers and drinking before him, and he blessed the Creator of all things who had preserved him, and had preserved for him his twelve sons.

**[45:6]** And Joseph had given to his father and to his brothers as a gift the right of dwelling in the land of Goshen and in Rameses and all the region round about, which he ruled over before Pharaoh. And Israel and his sons dwelt in the land of Goshen, the best part of the land of Egypt and Israel was one hundred and thirty years old when he came into Egypt.

**[45:7]** And Joseph nourished his father and his brethren and also their possessions with bread as much as sufficed them for the seven years of the famine.

**[45:8]** And the land of Egypt suffered by reason of the famine, and Joseph acquired all the land of Egypt for Pharaoh in return for food, and he got possession of the people and their cattle and everything for Pharaoh.

**[45:9]** And the years of the famine were accomplished, and Joseph gave to the people in the land seed and food that they might sow (the land) in the eighth year, for the river had overflowed all the land of Egypt.

**[45:10]** For in the seven years of the famine it had (not) overflowed and had irrigated only a few places on the banks of the river, but now it overflowed and the Egyptians sowed the land, and it bore much corn that year.

**[45:11]** And this was the first year of [2178 A.M.] the fourth week of the forty-fifth jubilee.

**[45:12]** And Joseph took of the corn of the harvest the fifth part for the king and left four parts for them for food and for seed, and Joseph made it an ordinance for the land of Egypt until this day.

**[45:13]** And Israel lived in the land of Egypt seventeen years, and all the days which he lived were three jubilees, one hundred and forty-seven years, and he died in the fourth [2188 A.M.] year of the fifth week of the forty-fifth jubilee.

**[45:14]** And Israel blessed his sons before he died and told them everything that would befall them in the land of Egypt; and he made known to them what would come upon them in the last days, and blessed them and gave to Joseph two portions in the land.

**[45:15]** And he slept with his fathers, and he was buried in the double cave in the land of Canaan, near Abraham his father in the grave which he dug for himself in the double cave in the land of Hebron.

**[45:16]** And he gave all his books and the books of his fathers to Levi his son that he might preserve them and renew them for his children until this day.

**[46:1]** And it came to pass that after Jacob died the children of Israel multiplied in the land of Egypt, and they became a great nation, and they were of one accord in heart, so that brother loved brother and every man helped his brother, and they increased abundantly and multiplied exceedingly, ten [2242 A.M.] weeks of years, all the days of the life of Joseph.

**[46:2]** And there was no Satan nor any evil all the days of the life of Joseph which he lived after his father Jacob, for all the Egyptians honoured the children of Israel all the days of the life of Joseph.

**[46:3]** And Joseph died being a hundred and ten years old; seventeen years he lived in the land of Canaan, and ten years he was a servant, and three years in prison, and eighty years he was under the king, ruling all the land of Egypt.

**[46:4]** And he died and all his brethren and all that generation.

**[46:5]** And he commanded the children of Israel before he died that they should carry his bones with them when they went forth from the land of Egypt.

**[46:6]** And he made them swear regarding his bones, for he knew that the Egyptians would not again bring forth and bury him in the land of Canaan, for Makamaron, king of Canaan, while dwelling in the land of Assyria, fought in the valley with the king of Egypt and slew him there, and pursued after the Egyptians to the gates of 'Ermon.

**[46:7]** But he was not able to enter, for another, a new king, had become king of Egypt, and he was stronger than he, and he returned to the land of Canaan, and the gates of Egypt were closed, and none went out and none came into Egypt.

**[46:8]** And Joseph died in the forty-sixth jubilee, in the sixth week, in the second year, and they buried him in the land of Egypt, and [2242 A.M.] all his brethren died after him.

**[46:9]** And the king of Egypt went forth to war with the king of Canaan [2263 A.M.] in the forty-seventh jubilee, in the second week in the second year, and the children of Israel brought forth all the bones of the children of Jacob save the bones of Joseph, and they buried them in the field in the double cave in the mountain.

**[46:10]** And the most (of them) returned to Egypt, but a few of them remained in the mountains of Hebron, and Amram thy father remained with them.

**[46:11]** And the king of Canaan was victorious over the king of Egypt, and he closed the gates of Egypt.

**[46:12]** And he devised an evil device against the children of Israel of afflicting them and he said unto the people of Egypt: 'Behold the people of the children of Israel have increased and multiplied more than we.

**[46:13]** Come and let us deal wisely with them before they become too many, and let us afflict them with slavery before war come upon us and before they too fight against us; else they will join themselves unto our enemies and get them up out of our land, for their hearts and faces are towards the land of Canaan.'

**[46:14]** And he set over them taskmasters to afflict them with slavery; and they built strong cities for Pharaoh, Pithom, and Raamses and they built all the walls and all the fortifications which had fallen in the cities of Egypt.

**[46:15]** And they made them serve with rigour, and the more they dealt evilly with them, the more they increased and multiplied.

**[46:16]** And the people of Egypt abominated the children of Israel

**[47:1]** And in the seventh week, in the seventh year, in the forty-seventh jubilee, thy father went forth [2303 A.M.] from the land of Canaan, and thou wast born in the fourth week, in the sixth year thereof, in the [2330 A.M.] forty-eighth jubilee; this was the time of tribulation on the children of Israel.

**[47:2]** And Pharaoh, king of Egypt, issued a command regarding them that they should cast all their male children which were born into the river.

**[47:3]** And they cast them in for seven months until the day that thou wast born

**[47:4]** And thy mother hid thee for three months, and they told regarding her. And she made an ark for thee, and covered it with pitch and asphalt, and placed it in the flags on the bank of the river, and she placed thee in it seven days, and thy mother came by night and suckled thee, and by day Miriam, thy sister, guarded thee from the birds.

**[47:5]** And in those days Tharmuth, the daughter of Pharaoh, came to bathe in the river, and she heard thy voice crying, and she told her maidens to bring thee forth, and they brought thee unto her.

**[47:6]** And she took thee out of the ark, and she had compassion on thee.

**[47:7]** And thy sister said unto her: 'Shall I go and call unto thee one of the Hebrew women to nurse and suckle this babe for thee?'

**[47:8]** And she said <unto her>: 'Go.' And she went and called thy mother Jochebed, and she gave her wages, and she nursed thee.

**[47:9]** And afterwards, when thou wast grown up, they brought thee unto the daughter of Pharaoh, and thou didst become her son, and Amram thy father taught thee writing, and after thou hadst completed three weeks they brought thee into the royal court.

**[47:10]** And thou wast three weeks of years at court until the time [2351-] when thou didst go forth from the royal court and didst see an Egyptian smiting thy friend who was [2372 A.M.] of the children of Israel, and thou didst slay him and hide him in the sand.

**[47:11]** And on the second day thou didst and two of the children of Israel striving together, and thou didst say to him who was doing the wrong: 'Why dost thou smite thy brother?'

**[47:12]** And he was angry and indignant, and said: 'Who made thee a prince and a judge over us? Thinkest thou to kill me as thou killedst the Egyptian yesterday?' And thou didst fear and flee on account of these words.

**[48:1]** And in the sixth year of the third week of the forty-ninth jubilee thou didst depart and dwell <in [2372 A.M.] the land of Midian>, five weeks and one year. And thou didst return into Egypt in the second week in the second year in the fiftieth jubilee.

**[48:2]** And thou thyself knowest what He spake unto thee on [2410 A.M.] Mount Sinai, and what prince Mastêmâ desired to do with thee when thou wast returning into Egypt <on the way when thou didst meet him at the lodging-place>.

**[48:3]** Did he not with all his power seek to slay thee and deliver the Egyptians out of thy hand when he saw that thou wast sent to execute judgment and vengeance on the Egyptians?

**[48:4]** And I delivered thee out of his hand, and thou didst perform the signs and wonders which thou wast sent to perform in Egypt against Pharaoh, and against all his house, and against his servants and his people.

**[48:5]** And the Lord executed a great vengeance on them for Israel's sake, and smote them through (the plagues of) blood and frogs, lice and dog-flies, and malignant boils breaking forth in blains; and their cattle by death; and by hail-stones, thereby He destroyed everything that grew for them; and by locusts which devoured the residue which had been left by the hail, and by darkness; and <by the death> of the first-born of men and animals, and on all their idols the Lord took vengeance and burned them with fire.

**[48:6]** And everything was sent through thy hand, that thou shouldst declare (these things) before they were done, and thou didst speak with the king of Egypt before all his servants and before his people.

**[48:7]** And everything took place according to thy words; ten great and terrible judgments came on the land of Egypt that thou mightest execute vengeance on it for Israel.

**[48:8]** And the Lord did everything for Israel's sake, and according to His covenant, which he had ordained with Abraham that He would take vengeance on them as they had brought them by force into bondage.

**[48:9]** And the prince Mastêmâ stood up against thee, and sought to cast thee into the hands of Pharaoh, and he helped the Egyptian sorcerers,

**[48:10]** and they stood up and wrought before thee the evils indeed we permitted them to work, but the remedies we did not allow to be wrought by their hands.

**[48:11]** And the Lord smote them with malignant ulcers, and they were not able to stand, for we destroyed them so that they could not perform a single sign.

**[48:12]** And notwithstanding all (these) signs and wonders the prince Mastêmâ was not put to shame because he took courage and cried to the Egyptians to pursue after thee with all the powers of the Egyptians, with their chariots, and with their horses, and with all the hosts of the peoples of Egypt.

**[48:13]** And I stood between the Egyptians and Israel, and we delivered Israel out of his hand, and out of the hand of his people, and the Lord brought them through the midst of the sea as if it were dry land.

**[48:14]** And all the peoples whom he brought to pursue after Israel, the Lord our God cast them into the midst of the sea, into the depths of the abyss beneath the children of Israel, even as the people of Egypt had cast their children into the river He took vengeance on 1,000,000 of them, and one thousand strong and energetic men were destroyed on account of one suckling of the children of thy people which they had thrown into the river.

**[48:15]** And on the fourteenth day and on the fifteenth and on the sixteenth and on the seventeenth and on the eighteenth the prince Mastêmâ was bound and imprisoned behind the children of Israel that he might not accuse them.

**[48:16]** And on the nineteenth we let them loose that they might help the Egyptians and pursue the children of Israel.

**[48:17]** And he hardened their hearts and made them stubborn, and the device was devised by the Lord our God that He might smite the Egyptians and cast them into the sea.

**[48:18]** And on the fourteenth we bound him that he might not accuse the children of Israel on the day when they asked the Egyptians for vessels and garments, vessels of silver, and vessels of gold, and vessels of bronze, in order to despoil the Egyptians in return for the bondage in which they had forced them to serve.

**[48:19]** And we did not lead forth the children of Israel from Egypt empty handed.

**[49:1]** Remember the commandment which the Lord commanded thee concerning the passover, that thou shouldst celebrate it in its season on the fourteenth of the first month, that thou shouldst kill it before it is evening, and that they should eat it by night on the evening of the fifteenth from the time of the setting of the sun.

**[49:2]** For on this night -the beginning of the festival and the beginning of the joy- ye were eating the passover in Egypt, when all the powers of Mastêmâ had been let loose to slay all the first-born in the land of Egypt, from the first-born of Pharaoh to the first-born of the captive maid-servant in the mill, and to the cattle.

**[49:3]** And this is the sign which the Lord gave them: Into every house on the lintels of which they saw the blood of a lamb of the first year, into (that) house they should not enter to slay, but should pass by (it), that all those should be saved that were in the house because the sign of the blood was on its lintels.

**[49:4]** And the powers of the Lord did everything according as the Lord commanded them, and they passed by all the children of Israel, and the plague came not upon them to destroy from amongst them any soul either of cattle, or man, or dog.

**[49:5]** And the plague was very grievous in Egypt, and there was no house in Egypt where there was not one dead, and weeping and lamentation.

**[49:6]** And all Israel was eating the flesh of the paschal lamb, and drinking the wine, and was lauding, and blessing, and giving thanks to the Lord God of their fathers, and was ready to go forth from under the yoke of Egypt, and from the evil bondage.

**[49:7]** And remember thou this day all the days of thy life, and observe it from year to year all the days of thy life, once a year, on its day, according to all the law thereof, and do not adjourn (it) from day to day, or from month to month.

**[49:8]** For it is an eternal ordinance, and engraven on the heavenly tablets regarding all the children of Israel that they should observe it every year on its day once a year, throughout all their generations; and there is no limit of days, for this is ordained for ever.

**[49:9]** And the man who is free from uncleanness, and does not come to observe it on occasion of its day, so as to bring an acceptable offering before the Lord, and to eat and to drink before the Lord on the day of its festival, that man who is clean and close at hand shall be cut off: because he offered not the oblation of the Lord in its appointed season, he shall take the guilt upon himself.

**[49:10]** Let the children of Israel come and observe the passover on the day of its fixed time, on the fourteenth day of the first month, between the evenings, from the third part of the day to the third part of the night, for two portions of the day are given to the light, and a third part to the evening.

**[49:11]** This is that which the Lord commanded thee that thou shouldst observe it between the evenings.

**[49:12]** And it is not permissible to slay it during any period of the light, but during the period bordering on the evening, and let them eat it at the time of the evening, until the third part of the night, and whatever is left over of all its flesh from the third part of the night and onwards, let them burn it with fire.

**[49:13]** And they shall not cook it with water, nor shall they eat it raw, but roast on the fire: they shall eat it with diligence, its head with the inwards thereof and its feet they shall roast with fire, and not break any bone thereof; for of the children of Israel no bone shall be crushed.

**[49:14]** For this reason the Lord commanded the children of Israel to observe the passover on the day of its fixed time, and they shall not break a bone thereof; for it is a festival day, and a day commanded, and there may be no passing over from day to day, and month to month, but on the day of its festival let it be observed.

**[49:15]** And do thou command the children of Israel to observe the passover throughout their days, every year, once a year on the day of its fixed time, and it shall come for a memorial well pleasing before the Lord, and no plague shall come upon them to slay or to smite in that year in which they celebrate the passover in its season in every respect according to His command.

**[49:16]** And they shall not eat it outside the sanctuary of the Lord, but before the sanctuary of the Lord, and all the people of the congregation of Israel shall celebrate it in its appointed season.

**[49:17]** And every man who has come upon its day shall eat it in the sanctuary of your God before the Lord from twenty years old and upward; for thus is it written and ordained that they should eat it in the sanctuary of the Lord.

**[49:18]** And when the children of Israel come into the land which they are to possess, into the land of Canaan, and set up the tabernacle of the Lord in the midst of the land in one of their tribes until the sanctuary of the Lord has been built in the land, let them come and celebrate the passover in the midst of the tabernacle of the Lord, and let them slay it before the Lord from year to year.

**[49:19]** And in the days when the house has been built in the name of the Lord in the land of their inheritance, they shall go there and slay the passover in the evening, at sunset, at the third part of the day.

**[49:20]** And they shall offer its blood on the threshold of the altar, and shall place its fat on the fire which is upon the altar, and they shall eat its flesh roasted with fire in the court of the house which has been sanctified in the name of the Lord.

**[49:21]** And they may not celebrate the passover in their cities, nor in any place save before the tabernacle of the Lord, or before His house where His name hath dwelt; and they shall not go astray from the Lord.

**[49:22]** And do thou, Moses, command the children of Israel to observe the ordinances of the passover, as it was commanded unto thee; declare thou unto them every year and the day of its days, and the festival of unleavened bread, that they should eat unleavened bread seven days, (and) that they should observe its festival, and that they bring an oblation every day during those seven days of joy before the Lord on the altar of your God.

**[49:23]** For ye celebrated this festival with haste when ye went forth from Egypt till ye entered into the wilderness of Shur; for on the shore of the sea ye completed it.

**[50:1]** And after this law I made known to thee the days of the Sabbaths in the desert of Sin[ai], which is between Elim and Sinai.

**[50:2]** And I told thee of the Sabbaths of the land on Mount Sinai, and I told thee of the jubilee years in the sabbaths of years: but the year thereof have I not told thee till ye enter the land which ye are to possess.

**[50:3]** And the land also shall keep its sabbaths while they dwell upon it, and they shall know the jubilee year.

**[50:4]** Wherefore I have ordained for thee the year-weeks and the years and the jubilees: there are forty-nine jubilees from the days of Adam until this day, [2410 A.M.] and one week and two years: and there are yet forty years to come (lit. 'distant') for learning the [2450 A.M.] commandments of the Lord, until they pass over into the land of Canaan, crossing the Jordan to the west.

**[50:5]** And the jubilees shall pass by, until Israel is cleansed from all guilt of fornication, and uncleanness, and pollution, and sin, and error, and dwells with confidence in all the land, and there shall be no more a Satan or any evil one, and the land shall be clean from that time for evermore.

**[50:6]** And behold the commandment regarding the Sabbaths -I have written (them) down for thee- and all the judgments of its laws.

**[50:7]** Six days shalt thou labour, but on the seventh day is the Sabbath of the Lord your God. In it ye shall do no manner of work, ye and your sons, and your men- servants and your maid-servants, and all your cattle and the sojourner also who is with you.

**[50:8]** And the man that does any work on it shall die: whoever desecrates that day, whoever lies with (his) wife, or whoever says he will do something on it, that he will set out on a journey thereon in regard to any buying or selling: and whoever draws water thereon which he had not prepared for himself on the sixth day, and whoever takes up any burden to carry it out of his tent or out of his house shall die.

**[50:9]** Ye shall do no work whatever on the Sabbath day save what ye have prepared for yourselves on the sixth day, so as to eat, and drink, and rest, and keep Sabbath from all work on that day, and to bless the Lord your God, who has given you a day of festival and a holy day: and a day of the holy kingdom for all Israel is this day among their days for ever.

**[50:10]** For great is the honour which the Lord has given to Israel that they should eat and drink and be satisfied on this festival day, and rest thereon from all labour which belongs to the labour of the children of men save burning frankincense and bringing oblations and sacrifices before the Lord for days and for Sabbaths.

**[50:11]** This work alone shall be done on the Sabbath-days in the sanctuary of the Lord your God; that they may atone for Israel with sacrifice continually from day to day for a memorial well-pleasing before the Lord, and that He may receive them always from day to day according as thou hast been commanded.

**[50:12]** And every man who does any work thereon, or goes a journey, or tills (his) farm, whether in his house or any other place, and whoever lights a fire, or rides on any beast, or travels by ship on the sea, and whoever strikes or kills anything, or slaughters a beast or a bird, or whoever catches an animal or a bird or a fish, or whoever fasts or makes war on the Sabbaths:

**[50:13]** The man who does any of these things on the Sabbath shall die, so that the children of Israel shall observe the Sabbaths according to the commandments regarding the Sabbaths of the land, as it is written in the tablets, which He gave into my hands that I should write out for thee the laws of the seasons, and the seasons according to the division of their days. Herewith is completed the account of the division of the days.

