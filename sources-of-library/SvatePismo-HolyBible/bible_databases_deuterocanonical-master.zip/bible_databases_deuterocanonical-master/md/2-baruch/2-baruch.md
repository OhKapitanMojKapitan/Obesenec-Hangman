# Second Baruch



**[1:1]** And it came to pass in the twenty-fifth year of Jeconiah, king of Judah, that the word of the Lord came to Baruch, the son of Neriah,

**[1:2]** and said to him: 'Hast thou seen all that this people are doing to Me, that the evils which these two tribes which remained have done are greater than (those of) the ten tribes which were carried away captive?

**[1:3]** For the former tribes were forced by their kings to commit sin, but these two of themselves have been forcing and compelling their kings to commit sin.

**[1:4]** For this reason, behold I bring evil upon this city, and upon its inhabitants, and it shall be removed from before Me for a time, and I will scatter this people among the Gentiles that they may do good to the Gentiles.

**[1:5]** And My people shall be chastened, and the time shall come when they will seek for the prosperity of their times.

**[2:1]** For I have said these things to thee that thou mayst bid Jeremiah, and all those that are like you, to retire from this city. For your works are to this city as a firm pillar, And your prayers as a strong wall.'

**[3:1]** And I said:

**[3:2]** 'O Lord, my Lord, have I come into the world for this purpose that I might see the evils of my mother?

**[3:3]** Not (so) my Lord. If I have found grace in Thy sight, first take my spirit that I may go to my fathers and not behold the destruction of my mother.

**[3:4]** For two things vehemently constrain me: for I cannot resist Thee, and my soul, moreover, cannot behold the evils of my mother. But one thing I will say in Thy presence, O Lord. What, therefore, will there be after these things?

**[3:5]** for if Thou destroyest Thy city, and deliverest up Thy land to those that hate us, how shall the name of Israel be again remembered?

**[3:6]** Or how shall one speak of Thy praises? or to whom shall that which is in Thy law be explained?

**[3:7]** Or shall the world return to its nature (of), aforetime and the age revert to primeval silence?

**[3:8]** And shall the multitude of souls be taken away, and the nature of man not again be named?

**[3:9]** And where is all that which Thou didst say to Moses regarding us?'

**[4:1]** And the Lord said unto me: 'This city shall be delivered up for a time, And the people shall be chastened during a time, And the world will not be given over to oblivion.

**[4:2]** [Dost thou think that this is that city of which I said: "On the palms of My hands have I graven thee"?

**[4:3]** This building now built in your midst is not that which is revealed with Me, that which was prepared beforehand here from the time when I took counsel to make Paradise, and showed it to Adam before he sinned, but when he transgressed the commandment it was removed from him, as also Paradise.

**[4:4]** And after these things I showed it to My servant Abraham by night among the portions of the victims.

**[4:5]** And again also I showed it to Moses on Mount Sinai when I showed to him the likeness of the tabernacle and all its vessels.

**[4:6]** And now, behold, it is preserved with Me, as also

**[4:7]** Paradise. Go. therefore, and do as I command thee.']

**[5:1]** And I answered and said: So then I am destined to grieve for Zion, For Thine enemies will come to this place and pollute Thy sanctuary, And lead Thine inheritance into captivity, And make themselves masters of those whom Thou hast loved. And they will depart again to the place of their idols, And will boast before them: And what wilt Thou do for Thy great name?'

**[5:2]** And the Lord said unto me: My name and My glory are unto all eternity; And My judgement shall maintain its right in its own time.

**[5:3]** And thou shalt see with thine eyes That the enemy will not overthrow Zion, Nor shall they burn Jerusalem, But be the ministers of the Judge for the time.

**[5:4]** But do thou go and do whatsoever I have said unto thee.'

**[5:5]** And I went and took Jeremiah, and Adu, and Seriah, and Jabish, and Gedaliah, and all the honourable men of the people, and I led them to the valley of Cedron, and I narrated to them all that had been said to me.

**[5:6]** And they lifted up their voice, and they all wept.

**[5:7]** And we sat there and fasted until the evening.

**[6:1]** And it came to pass on the morrow that, lo! the army of the Chaldees surrounded the city, and at the time of the evening, I, Baruch, left the people, and I went forth and stood by the oak.

**[6:2]** And I was grieving over Zion, and lamenting over the captivity which had come upon the people.

**[6:3]** And lo! suddenly a strong spirit raised me, and bore me aloft over the wall of Jerusalem.

**[6:4]** And I beheld, and lo! four angels standing at the four corners of the city, each of them holding a torch of fire in his hands.

**[6:5]** And another angel began to descend from heaven, and said unto them: 'Hold your lamps, and do not light them till I tell you.

**[6:6]** For I am first sent to speak a word to the earth, and to place in it what the Lord the Most High has commanded me

**[6:7]** And I saw him descend into the Holy of holies, and take from thence the veil, and the holy ark, and the mercy-seat, and the two tables, and the holy raiment of the priests, and the altar of incense, and the forty-eight precious stones, wherewith the priest was adorned and all the holy vessels of the tabernacle.

**[6:8]** And he spake to the earth with a loud voice: 'Earth, earth, earth, hear the word of the mighty God, And receive what I commit to thee, And guard them until the last times, So that, when thou art ordered, thou mayst restore them, So that strangers may not get possession of them.

**[6:9]** For the time comes when Jerusalem also will be delivered for a time, Until it is said, that it is again restored for ever.'

**[6:10]** And the earth opened its mouth and swallowed them up.

**[7:1]** And after these things I heard that angel saying unto those angels who held the lamps:

**[7:2]** Destroy, therefore, and overthrow its wall to its foundations, lest the enemy should boast and say: "We have overthrown the wall of Zion, And we have burnt the place of the mighty God." And ye have seized the place where I had been standing before.

**[8:1]** Now the angels did as he had commanded them, and when they had broken up the corners of the walls, a voice was heard from the interior of the temple, after the wall had fallen, saying:

**[8:2]** 'Enter, ye enemies, And come, ye adversaries; For he who kept the house has forsaken (it).'

**[8:3]** And I, Baruch, departed.

**[8:4]** And it came to pass after these things that the army of the Chaldees entered and seized the house,

**[8:5]** and all that was around it. And they led the people away captive, and slew some of them, and bound Zedekiah the king, and sent him to the king of Babylon.

**[9:1]** And I, Baruch, came, and Jeremiah, whose heart was found pure from sins, who had not been captured in the seizure of the city.

**[9:2]** And we rent our garments, we wept, and mourned, and fasted seven days.

**[10:1]** And it came to pass after seven days, that the word of God came to me, and said unto me:

**[10:2]** 'Tell Jeremiah to go and support the captivity of the people unto Babylon,

**[10:3]** But do thou remain here amid the desolation of Zion, and I will show to thee after these days' what will befall at the end of days.'

**[10:5]** And I said to Jeremiah as the Lord commanded me. And he, indeed, departed with the people, but I, Baruch, returned and sat before the gates of the temple, and I lamented with the following lamentation over Zion and said:

**[10:6]** 'Blessed is he who was not born, Or he, who having been born, has died.

**[10:7]** But as for us who live, woe unto us, Because we see the afflictions of Zion, And what has befallen Jerusalem.

**[10:8]** I will call the Sirens from the sea, And ye Lilin, come ye from the desert, And ye Shedim and dragons from the forests: Awake and gird up your loins unto mourning, And take up with me the dirges, And make lamentation with me.

**[10:9]** Ye husbandmen, sow not again; And, O earth, wherefore givest thou thy harvest fruits? Keep within thee the sweets of thy sustenance.

**[10:10]** And thou, vine, why further dost thou give thy wine; For an offering will not again be made therefrom in Zion. Nor will the first-fruits again be offered.

**[10:11]** And do ye, O heavens, withhold your dew, And open not the treasuries of rain:

**[10:12]** And do thou, O sun, withhold the light of thy rays. And do thou, O moon, extinguish the multitude of thy light; For why should light rise again Where the light of Zion is darkened?

**[10:13]** And you, ye bridegrooms, enter not in, And let not the brides adorn themselves with garlands

**[10:14]** And, ye women, pray not that ye may bear. For the barren shall above all rejoice, And those who have no sons shall be glad, And those who have sons shall have anguish.

**[10:15]** For why should they bear in pain, Only to bury in grief?

**[10:16]** Or why, again, should mankind have sons? Or why should the seed of their kind again be named, Where this mother is desolate, And her sons are led into captivity?

**[10:17]** From this time forward speak not of beauty, And discourse not of gracefulness.

**[10:18]** Moreover, ye priests, take ye the keys of the sanctuary And cast them into the height of heaven, And give them to the Lord and say: "Guard Thy house Thyself. For lo! we are found false stewards."

**[10:19]** And you, ye virgins; who weave fine linen And silk with gold of Ophir, Take with haste all (these) things And cast (them) into the fire, That it may bear them to Him who made them, And the flame send them to Him who created them, Lest the enemy get possession of them.'

**[11:1]** Moreover, I, Baruch, say this against thee, Babylon: If thou hadst prospered, And Zion had dwelt in her glory, Yet the grief to us had been great That thou shouldst be equal to Zion.

**[11:2]** But now, lo! the grief is infinite, And the lamentation measureless, For lo! thou art prospered And Zion desolate.

**[11:3]** Who will be judge regarding these things? Or to whom shall we complain regarding that which has befallen us?

**[11:4]** O Lord, how hast Thou borne (it)? Our fathers went to rest without grief And lo! the righteous sleep in the earth in tranquillity;

**[11:5]** For they knew not this anguish, Nor yet had they heard of that which had befallen us.

**[11:6]** Would that thou hadst ears, O earth, And that thou hadst a heart, O dust. That ye might go and announce in Sheol, And say to the dead:

**[11:7]** "Blessed are ye more than we who live."

**[12:1]** But I will say this as I think. And I will speak against thee, O land, which art prospering.

**[12:2]** The noonday does not always burn. Nor do the rays of the sun constantly give light.

**[12:3]** Do not expect [and hope] that thou wilt always be prosperous and rejoicing. And be not greatly up-lifted and boastful.

**[12:4]** For assuredly in its own season shall the (divine) wrath awake against thee. Which now in long-suffering is held in as it were by reins.

**[12:5]** And when I had said these things, I fasted seven days.

**[13:1]** And it came to pass after these things, that I, Baruch, was standing upon Mount Zion, and lo! a voice came from the height and said unto me:

**[13:2]** 'Stand upon thy feet, Baruch, and hear the word of the mighty God.'

**[13:3]** Because thou hast been astonied at what has befallen Zion, thou shalt therefore be assuredly preserved to the consummation of the times, that thou mayst be for a testimony.

**[13:4]** So that, if ever those prosperous cities say: 'Why hath the mighty God brought upon us this retribution?'

**[13:5]** Say thou, to them, thou and those like thee who shall have seen this evil: '(This is the evil) and retribution which is coming upon you and upon your people in its (destined) time that the nations may be thoroughly smitten.

**[13:6]** And then they shall be in anguish.

**[13:7]** And if they say at that time: For how long? Thou wilt say to them:

**[13:8]** Ye who have drunk the strained wine, Drink ye also of its dregs, The judgement of the Lofty One Who has no respect of persons."

**[13:9]** On this account he had aforetime no mercy on His own sons, But afflicted them as His enemies, because they sinned,

**[13:10]** Then therefore were they chastened That they might be sanctified.

**[13:11]** But now, ye peoples and nations, ye are guilty Because ye have always trodden down the earth, And used the creation unrighteously.

**[13:12]** For I have always benefitted you. And ye have always been ungrateful for the beneficence

**[14:1]** And I answered and said: 'Lo! Thou hast shown me the method of the times, and that which shall be alter these things

**[14:2]** And Thou hast said unto me, that the retribution, which has been spoken of by Thee, shall come upon the nations. And now I know that those who have sinned are many, and they have lived in prosperity, and departed from the world, but that few nations will be left in those times, to whom those words shall be said which Thou didst say.

**[14:3]** For what advantage is there in this, or what (evil), worse than what we have seen befall us, are we to expect to see?

**[14:4]** But again I will speak in Thy presence:

**[14:5]** What have they profited who had knowledge before Thee, and have not walked in vanity as the rest of the nations, and have not said to the dead: "Give us life," but always feared Thee, and have not left Thy ways?

**[14:6]** And lo! they have been carried off, nor on their account hast Thou had mercy on Zion.

**[14:7]** And if others did evil, it was due to Zion, that on account of the works of those who wrought good works she should be forgiven, and should not be overwhelmed on account of the works of those who wrought unrighteousness.

**[14:8]** But who, O Lord, my Lord, will comprehend Thy judgement, Or who will search out the profoundness of Thy way? Or who will think out the weight of Thy path?

**[14:9]** Or who will be able to think out Thy incomprehensible counsel? Or who of those that are born has ever found The beginning or end of Thy wisdom?

**[14:10]** For we have all been made like a breath.

**[14:11]** For as the breath ascends involuntarily, and again dies, so it is with the nature of men, who depart not according to their own will, and know not what will befall them in the end.

**[14:12]** For the righteous justly hope for the end, and without fear depart from this habitation, because they have with Thee a store of works preserved in treasuries.

**[14:13]** On this account also these without fear leave this world, and trusting with joy they hope to receive the world which Thou hast promised them.

**[14:14]** But as for us -- woe to us, who also are now shamefully entreated, and at that time look forward (only) to evils.

**[14:15]** But Thou knowest accurately what Thou hast done by means of Thy servants; for we are not able to understand that which is good as Thou art, our Creator.

**[14:16]** But again I will speak in Thy presence, O LORD, my Lord.

**[14:17]** When of old there was no world with its inhabitants, Thou didst devise and speak with a word, and forthwith the works of creation stood before Thee.

**[14:18]** And Thou didst say that Thou wouldst make for Thy world man as the administrator of Thy works, that it might be known that he was by no means made on account of the world, but the world on account of him.

**[14:19]** And now I see that as for the world which was made on account of us, lo! it abides, but we, on account of whom it was made, depart.'

**[15:1]** And the Lord answered and said unto me: 'Thou art rightly astonied regarding the departure of man, but thou hast not judged well regarding the evils which befall those who sin.

**[15:2]** And as regards what thou hast said, that the righteous are carried off and the impious are prospered,

**[15:3]** And as regards what thou hast said "Man knows not Thy judgement"

**[15:4]** -- On this account hear, and I will speak to thee, and hearken, and I will cause thee to hear My words.

**[15:5]** Man would not rightly have understood My judgement, unless he had accepted the law, and I had instructed him in understanding.

**[15:6]** But now, because he transgressed wittingly, yea, just on this ground that he wot (thereof), he shall be tormented.

**[15:7]** And as regards what thou didst say touching the righteous, that on account of them has this world come, so also again shall that, which is to come, come on their account.

**[15:8]** For this world is to them a strife and a labour with much trouble; and that accordingly which is to come, a crown with great glory.'

**[16:1]** And I answered and said: 'O LORD, my Lord, lo! the years of this time are few and evil, and who is able in his little time to acquire that which is measureless?'

**[17:1]** And the Lord answered and said unto me: 'With the Most High account is not taken of much time nor of a few years.

**[17:2]** For what did it profit Adam that he lived nine hundred and thirty years, and transgressed that which he was commanded?

**[17:3]** Therefore the multitude of time that he lived did not profit him, but brought death and cut off the years of those who were born from him.

**[17:4]** Or wherein did Moses suffer loss in that he lived only one hundred and twenty years, and, inasmuch as he was subject to Him who formed him, brought the law to the seed of Jacob, and lighted a lamp for the nation of Israel?'

**[18:1]** And I answered and said: 'He that lighted has taken from the light, and there are but few that have imitated him.

**[18:2]** But those many whom he has lighted have taken from the darkness of Adam and have not rejoiced in the light of the lamp.'

**[19:1]** And He answered and said unto me: 'Wherefore at that time he appointed for them a covenant and said: "Behold I have placed before you life and death," And he called heaven and earth to witness against them.

**[19:2]** For he knew that his time was but short, But that heaven and earth endure always.

**[19:3]** But after his death they sinned and transgressed, Though they knew that they had the law reproving (them), And the light in which nothing could err, Also the spheres which testify, and Me.

**[19:4]** Now regarding everything that is, it is I that judge, but do not thou take counsel in thy soul regarding these things, nor afflict thyself because of those which have been.

**[19:5]** For now it is the consummation of time that should be considered, whether of business, or of prosperity, or of shame, and not the beginning thereof.

**[19:6]** Because if a man be prospered in his beginnings and shamefully entreated in his old age, he forgets all the prosperity that he had.

**[19:7]** And again, if a man is shamefully entreated in his beginnings, and at his end is prospered, he remembereth not again his evil entreatment.

**[19:8]** And again hearken: though each one were prospered all that time all the time from the day on which death was decreed against those who transgress, and in his end was destroyed, in vain would have been everything.'

**[20:1]** Therefore, behold! the days come, And the times shall hasten more than the former, And the seasons shall speed on more than those that are past, And the years shall pass more quickly than the present (years).

**[20:2]** Therefore have I now taken away Zion, That I may the more speedily visit the world in its season.

**[20:3]** Now therefore hold fast in thy heart everything that I command thee, And seal it in the recesses of thy mind.

**[20:4]** And then I will show thee the judgement of My might, And My ways which are unsearchable.

**[20:5]** Go therefore and sanctify thyself seven days, and eat no bread, nor drink water, nor speak to anyone.

**[20:6]** And afterwards come to that place and I will reveal Myself to thee, and speak true things with thee, and I will give thee commandment regarding the method of the times; for they are coming and tarry not.'

**[21:1]** And I went thence and sat in the valley of Cedron in a cave of the earth, and I sanctified my soul there, and I eat no bread, yet I was not hungry, and I drank no water, yet I thirsted not, and I was there till the seventh day, as He had commanded me.

**[21:2]** And afterwards I came to that place where He had spoken with me.

**[21:3]** And it came to pass at sunset that my soul took much thought, and I began to speak in the presence of the Mighty One, and said:

**[21:4]** 'O Thou that hast made the earth, hear me, that hast fixed the firmament by the word, and hast made firm the height of the heaven by the spirit, that hast called from the beginning of the world that which did not yet exist, and they obey Thee.

**[21:5]** Thou that hast commanded the air by Thy nod, and hast seen those things which are to be as those things which Thou art doing.

**[21:6]** Thou that rulest with great thought the hosts that stand before Thee: also the countless holy beings, which Thou didst make from the beginning, of flame and fire, which stand around Thy throne Thou rulest with indignation.

**[21:7]** To Thee only does this belong that Thou shouldst do forth with whatsoever Thou dost wish.

**[21:8]** Who causest the drops of rain to rain by number upon the earth, and alone knowest the consummation of the times before they come; have respect unto my prayer.

**[21:9]** For Thou alone art able to sustain all who are, and those who have passed away, and those who are to be, those who sin, and those who are righteous [as living (and) being past finding out].

**[21:10]** For Thou alone dost live immortal and past finding out, and knowest the number of mankind.

**[21:11]** And if in time many have sinned, yet others not a few have been righteous.

**[21:12]** Thou knowest where Thou preservest the end of those who have sinned, or the consummation of those who have been righteous.

**[21:13]** For if there were this life only, which belongs to all men, nothing could be more bitter than this,

**[21:14]** For of what profit is strength that turns to sickness, Or fullness of food that turns to famine, Or beauty that turns to ugliness.

**[21:15]** For the nature of man is always changeable.

**[21:16]** For what we were formerly now we no longer are, and what we now are we shall not afterwards remain.

**[21:17]** For if a consummation had not been prepared for all, in vain would have been their beginning.

**[21:18]** But regarding everything that comes from Thee, do Thou inform me, and regarding everything about which I ask Thee, do Thou enlighten me.

**[21:19]** How long will that which is corruptible remain, and how long will the time of mortals be prospered, and until what time will those who transgress in the world be polluted with much wickedness?

**[21:20]** Command therefore in mercy and accomplish all that Thou saidst Thou wouldst bring, that Thy might may be made known to those who think that Thy long-suffering is weakness.

**[21:21]** And show to those who know not, that everything that has befallen us and our city until now has been according to the long-suffering of Thy power, because on account of Thy name Thou hast called us a beloved people.

**[21:22]** Bring to an end therefore henceforth mortality.

**[21:23]** And reprove accordingly the angel of death, and let Thy glory appear, and let the might of Thy beauty be known, and let Sheol be sealed so that from this time forward it may not receive the dead, and let the treasuries of souls restore those which are enclosed in them.

**[21:24]** For there have been many years like those that are desolate from the days of Abraham and Isaac and Jacob, and of all those who are like them, who sleep in the earth, on whose account Thou didst say that Thou hadst created the world.

**[21:25]** And now quickly show Thy glory, and do not defer what has been promised by Thee.'

**[21:26]** And (when) I had completed the words of this prayer I was greatly weakened.

**[22:1]** And it came to pass after these things that lo! the heavens were opened, and I saw, and power was given to me, and a voice was heard from on high, and it said unto me:

**[22:2]** 'Baruch, Baruch, why art thou troubled?

**[22:3]** He who travels by a road but does not complete it, or who departs by sea but does not arrive at the port, can he be comforted?

**[22:4]** Or he who promises to give a present to another, but does not fulfill it, is it not robbery?

**[22:5]** Or he who sows the earth, but does not reap its fruit in its season, does he not lose everything?

**[22:6]** Or he who plants a plant unless it grows till the time suitable to it, does he who planted it expect to receive fruit from it?

**[22:7]** Or a woman who has conceived, if she bring forth untimely, does she not assuredly slay her infant?

**[22:8]** Or he who builds a house, if he does not roof it and complete it, can it be called a house? Tell Me that first.'

**[23:1]** And I answered and said: 'Not so, O LORD, my Lord.'

**[23:2]** And He answered and said unto me: Why therefore art thou troubled about that which thou knowest not, and why art thou ill at ease about things in which thou art ignorant?

**[23:3]** For as thou hast not forgotten the people who now are and those who have passed away, so I remember those who are appointed to come.

**[23:4]** Because when Adam sinned and death was decreed against those who should be born, then the multitude of those who should be born was numbered, and for that number a place was prepared where the living might dwell and the dead might be guarded.

**[23:5]** Before therefore the number aforesaid is fulfilled, the creature will not live again [for My spirit is the creator of life], and Sheol will receive the dead.

**[23:6]** And again it is given to thee to hear what things are to come after these times.

**[23:7]** For truly My redemption has drawn nigh, and is not far distant as aforetime.

**[24:1]** For behold! the days come and the books shall be opened in which are written the sins of all those who have sinned, and again also the treasuries in which the righteousness of all those who have been righteous in creation is gathered.

**[24:2]** For it shall come to pass at that time that thou shalt see - and the many that are with thee -the long-suffering of the Most High, which has been throughout all generations, who has been long-suffering towards all who are born, (alike) those who sin and (those who) are righteous.'

**[24:3]** And I answered and said: 'But, behold! O Lord, no one knows the number of those things which have passed nor yet of those things which are to come.

**[24:4]** For I know indeed that which has befallen us, but what will happen to our enemies I know not, and when Thou wilt visit Thy works.'

**[25:1]** And He answered and said unto me: 'Thou too shalt be preserved till that time till that sign which the Most High will work for the inhabitants of the earth in the end of days.

**[25:2]** This therefore shall be the sign.

**[25:3]** When a stupor shall seize the inhabitants of the earth, and they shall fall into many tribulations, and again when they shall fall into great torments.

**[25:4]** And it will come to pass when they say in their thoughts by reason of their much tribulation: "The Mighty One doth no longer remember the earth" yea, it will come to pass when they abandon hope, that the time will then awake.'

**[26:1]** And I answered and said: 'Will that tribulation which is to be continue a long time, and will that necessity embrace many years?'

**[27:1]** And He answered and said unto me: 'Into twelve parts is that time divided, and each one of them is reserved for that which is appointed for it.

**[27:2]** In the first part there shall be the beginning of commotions.

**[27:3]** And in the second part (there shall be) slayings of the great ones.

**[27:4]** And in the third part the fall of many by death.

**[27:5]** And in the fourth part the sending of the sword.

**[27:6]** And in the fifth part famine and the withholding of rain.

**[27:7]** And in the sixth part earthquakes and terrors.

**[27:8]** And in the eighth part a multitude of spectres and attacks of the Shedim.

**[27:9]** And in the ninth part the fall of fire.

**[27:10]** And in the tenth part rapine and much oppression,

**[27:11]** And in the eleventh part wickedness and unchastity.

**[27:12]** And in the twelfth part confusion from the mingling together of all those things aforesaid.

**[27:13]** For these parts of that time are reserved, and shall be mingled one with another and minister one to another.

**[27:14]** For some shall leave out some of their own, and receive (in its stead) from others, and some complete their own and that of others, so that those may not understand who are upon the earth in those days that this is the consummation of the times.

**[28:1]** 'Nevertheless, whosoever understandeth shall then be wise.

**[28:2]** For the measure and reckoning of that time are two parts a week of seven weeks.'

**[28:3]** And I answered and said: 'It is good for a man to come and behold, but it is better that he should not come lest he fall.

**[28:4]** [But I will say this also:

**[28:5]** Will he who is incorruptible despise those things which are corruptible, and whatever befalls in the case of those things which are corruptible, so that he might look only to those things which are not corruptible?]

**[28:6]** But if, O Lord, those things shall assuredly come to pass which Thou hast foretold to me, so do Thou show this also unto me if indeed I have found grace in Thy sight.

**[28:7]** Is it in one place or in one of the parts of the earth that those things are come to pass, or will the whole earth experience (them)?'

**[29:1]** And He answered and said unto me: 'Whatever will then befall (will befall) the whole earth; therefore all who live will experience (them).

**[29:2]** For at that time I will protect only those who are found in those self-same days in this land.

**[29:3]** And it shall come to pass when all is accomplished that was to come to pass in those parts, that the Messiah shall then begin to be revealed.

**[29:4]** And Behemoth shall be revealed from his place and Leviathan shall ascend from the sea, those two great monsters which I created on the fifth day of creation, and shall have kept until that time; and then they shall be for food for all that are left.

**[29:5]** The earth also shall yield its fruit ten thousandfold and on each (?) vine there shall be a thousand branches, and each branch shall produce a thousand clusters, and each cluster produce a thousand grapes, and each grape produce a cor of wine.

**[29:6]** And those who have hungered shall rejoice: moreover, also, they shall behold marvels every day.

**[29:7]** For winds shall go forth from before Me to bring every morning the fragrance of aromatic fruits, and at the close of the day clouds distilling the dew of health.

**[29:8]** And it shall come to pass at that self-same time that the treasury of manna shall again descend from on high, and they will eat of it in those years, because these are they who have come to the consummation of time.

**[30:1]** And it shall come to pass after these things, when the time of the advent of the Messiah is fulfilled, that He shall return in glory. Then all who have fallen asleep in hope of Him shall rise again.

**[30:2]** And it shall come to pass at that time that the treasuries will be opened in which is preserved the number of the souls of the righteous, and they shall come forth, and a multitude of souls shall be seen together in one assemblage of one thought, and the first shall rejoice and the last shall not be grieved.

**[30:3]** For they know that the time has come of which it is said, that it is the consummation of the times.

**[30:4]** But the souls of the wicked, when they behold all these things, shall then waste away the more.

**[30:5]** For they shall know that their torment has come and their perdition has arrived.'

**[31:1]** And it came to pass after these things: that I went to the people and said unto them: 'Assemble unto me all your elders and I will speak words unto them.'

**[31:2]** And they all assembled in the valley of the Cedron.

**[31:3]** And I answered and said unto them: Hear, O Israel, and I will speak to thee, And give ear, O seed of Jacob, and I will instruct thee.

**[31:4]** Forget not Zion, But hold in remembrance the anguish of Jerusalem.

**[31:5]** For lo! the days come, When everything that is shall become the prey of corruption And be as though it had not been.

**[32:1]** 'But as for you, if ye prepare your hearts, so as to sow in them the fruits of the law, it shall protect you in that time in which the Mighty One is to shake the whole creation.

**[32:2]** [Because after a little time the building of Zion will be shaken in order that it may be built again.

**[32:3]** But that building will not remain, but will again after a time be rooted out, and will remain desolate until the time.

**[32:4]** And afterwards it must be renewed in glory, and perfected for evermore.]

**[32:5]** Therefore we should not be distressed so much over the evil which has now come as over that which is still to be.

**[32:6]** For there will be a greater trial than these two tribulations when the Mighty One will renew His creation.

**[32:7]** And now do not draw near to me for a few days, nor seek me till I come to you.'

**[32:8]** And it came to pass when I had spoken to them all these words, that I, Baruch, went my way, and when the people saw me setting out, they lifted up their voice and lamented and said:

**[32:9]** 'Whither departest thou from us, Baruch, and forsakest us as a father who forsakes his orphan children, and departs from them?

**[33:1]** 'Are these the commands which thy companion, Jeremiah the prophet, commanded thee, and said unto thee:

**[33:2]** "Look to this people till I go and make ready the rest of the brethren in Babylon, against whom has gone forth the sentence that they should be led into captivity"?

**[33:3]** And now if thou also forsakest us, it were good for us all to die before thee, and then that thou shouldst withdraw from us.'

**[34:4]** And I answered and said unto the people: 'Far be it from me to forsake you or to withdraw from you, but I will only go unto the Holy of Holies to inquire of the Mighty One concerning you and concerning Zion, if in some respect I should receive more illumination: and after these things I will return to you.'

**[35:1]** And I, Baruch, went to the holy place, and sat down upon the ruins and wept, and said:

**[35:2]** 'O that mine eyes were springs, And mine eyelids a fount of tears.

**[35:3]** For how shall I lament for Zion, And how shall I mourn for Jerusalem?

**[35:4]** Because in that place where I am now prostrate, Of old the high priest offered holy sacrifices, And placed thereon an incense of fragrant odours.

**[35:5]** But now our glorying has been made into dust, And the desire of our soul into sand.'

**[36:1]** And when I had said these things I fell asleep there, and I saw a vision in the night.

**[36:2]** And lo! a forest of trees planted on the plain, and lofty and rugged rocky mountains surrounded it, and that forest occupied much space.

**[36:3]** And lo! over against it arose a vine, and from under it there went forth a fountain peacefully.

**[36:4]** Now that fountain came to the forest and was (stirred) into great waves, and those waves submerged that forest, and suddenly they rooted out the greater part of that forest, and overthrew all the mountains which were round about it.

**[36:5]** And the height of the forest began to be made low, and the top of the mountains was made low and that fountain prevailed greatly, so that it left nothing of that great forest save one cedar only.

**[36:6]** Also when it had cast it down and had destroyed and rooted out the greater part of that forest, so that nothing was left of it, nor could its place be recognized, then that vine began to come with the fountain in peace and great tranquillity, and it came to a place which was not far from that cedar, and they brought the cedar which had been cast down to it.

**[36:7]** And I beheld and lo! that vine opened its mouth and spake and said to that cedar: 'Art thou not that cedar which was left of the forest of wickedness, and by whose means wickedness persisted, and was wrought all those years, and goodness never.

**[36:8]** And thou didst keep conquering that which was not thine, and to that which was thine thou didst never show compassion, and thou didst keep extending thy power over those who were far from thee, and those who drew nigh thee thou didst hold fast in the toils of thy wickedness, and thou didst uplift thyself always as one that could not be rooted out!

**[36:9]** But now thy time has sped and thine hour is come.

**[36:10]** Do thou also therefore depart O cedar, after the forest. which departed before thee, and become dust with it. And let your ashes be mingled together,

**[36:11]** And now recline in anguish and rest in torment till thy last time come, in which thou wilt come again, and be tormented still more.'

**[37:12]** And after these things I saw that cedar burning, and the vine glowing, itself and all around it, the plain full of unfading flowers. 

**[37:13]** And I indeed awoke and arose.

**[38:1]** And I prayed and said: 'O LORD, my Lord, Thou dost always enlighten those who are led by understanding.

**[38:2]** Thy law is life, and Thy wisdom is right guidance.

**[38:3]** Make known to me therefore the interpretation of this vision.

**[38:4]** For Thou knowest that my soul hath always walked in Thy law, and from my (earliest) days I departed not from Thy wisdom.'

**[39:1]** And He answered and said unto me: 'Baruch, this is the interpretation of the vision which thou hast seen.

**[39:2]** As thou hast seen the great forest which lofty and rugged mountains surrounded, this is the word.

**[39:3]** Behold! the days come, and this kingdom will be destroyed which once destroyed Zion, and it will be subjected to that which comes after it.

**[39:4]** Moreover, that also again after a time will be destroyed, and another, a third, will arise, and that also will have dominion for its time, and will be destroyed.

**[39:5]** And after these things a fourth kingdom will arise, whose power will be harsh and evil far beyond those which were before it, and it will rule many times as the forests on the plain, and it will hold fast for times, and will exalt itself more than the cedars of Lebanon.

**[39:6]** And by it the truth will be hidden, and all those who are polluted with iniquity will flee to it, as evil beasts flee and creep into the forest.

**[39:7]** And it will come to pass when the time of its consummation that it should fall has approached, then the principate of My Messiah will be revealed, which is like the fountain and the vine, and when it is revealed it will root out the multitude of its host.

**[39:8]** And as touching that which thou hast seen, the lofty cedar, which was left of that forest, and the fact, that the vine spoke those words with it which thou didst hear, this is the word.

**[40:1]** The last leader of that time will be left alive, when the multitude of his hosts will be put to the sword, and he will be bound, and they will take him up to Mount Zion, and My Messiah will convict him of all his impieties, and will gather and set before him all the works of his hosts.

**[40:2]** And afterwards he will put him to death, and protect the rest of My people which shall be found in the place which I have chosen.

**[40:3]** And his principate will stand for ever, until the world of corruption is at an end, and until the times aforesaid are fulfilled.

**[40:4]** This is thy vision, and this is its interpretation.'

**[41:1]** And I answered and said: 'For whom and for how many shall these things be? or who will be worthy to live at that time?

**[41:2]** For I will speak before thee everything that I think, and I will ask of Thee regarding those things which I meditate.

**[41:3]** For lo! I see many of Thy people who have withdrawn from Thy covenant, and cast from them the yoke of Thy law.

**[41:4]** But others again I have seen who have forsaken their vanity, and fled for refuge beneath Thy wings.

**[41:5]** What therefore will be to them? or how will the last time receive them?

**[41:6]** Or perhaps the time of these will assuredly be weighed, and as the beam inclines will they be judged accordingly?'

**[42:1]** And He answered and said unto me:

**[42:2]** 'These things also will I show unto thee. As for what thou didst say -- "To whom will these things be, and how many (will they be)?"- to those who have believed there shall be the good which was spoken of aforetime, and to those who despise there shall be the contrary of these things.

**[42:3]** And as for what thou didst say regarding those who have drawn near and those who have withdrawn this is the word.

**[42:4]** As for those who were before subject, and afterwards withdrew and mingled themselves with the seed of mingled peoples, the time of these was the former and was accounted as something exalted.

**[42:5]** And as for those who before knew not but afterwards knew life, and mingled (only) with the seed of the people which had separated itself the time of these (is) the latter, and is accounted as something exalted.

**[42:6]** And time shall succeed to time and season to season, and one shall receive from another, and then with a view to the consummation shall everything be compared according to the measure of the times and the hours of the seasons.

**[42:7]** For corruption shall take those that belong to it, and life those that belong to it.

**[42:8]** And the dust shall be called, and there shall be said to it: "Give back that which is not thine, and raise up all that thou hast kept until its time."

**[43:1]** 'But, do thou, Baruch, direct thy heart to that which has been said to thee, And understand those things which have been shown to thee; For there are many eternal consolations for thee.

**[43:2]** For thou shalt depart from this place, And thou shalt pass from the regions which are now seen by thee, And thou shalt forget whatever is corruptible, And shalt not again recall those things which happen among mortals.

**[43:3]** Go therefore and command thy people, and come to this place, and afterwards fast seven days, and then I will come to thee and speak with thee.'

**[44:1]** And I, Baruch, went from thence, and came to my people, and I called my first-born son and [the Gedaliahs] my friends, and seven of the elders of the people, and I said unto them:

**[44:2]** 'Behold, I go unto my fathers According to the way of all the earth.

**[44:3]** But withdraw ye not from the way of the law, But guard and admonish the people which remain; Lest they withdraw from the commandments of the Mighty One,

**[44:4]** For ye see that He whom we serve is just, And our Creator is no respecter of persons.

**[44:5]** And see ye what hath befallen Zion, And what hath happened to Jerusalem.

**[44:6]** For the judgement of the Mighty One shall (thereby) be made known, And His ways, which, though past finding out, are right.

**[44:7]** For if ye endure and persevere in His fear, And do not forget His law, The times shall change over you for good. And ye shall see the consolation of Zion.

**[44:8]** Because whatever is now is nothing, But that which shall be is very great. For everything that is corruptible shall pass away,

**[44:9]** And everything that dies shall depart, And all the present time shall be forgotten, Nor shall there be any remembrance of the present time, which is defiled with evils.

**[44:10]** For that which runs now runs unto vanity, And that which prospers shall quickly fall and be humiliated.

**[44:11]** For that which is to be shall be the object of desire, And for that which comes afterwards shall we hope; For it is a time that passes not away,

**[44:12]** And the hour comes which abides for ever. And the new world (comes) which does not turn to corruption those who depart to its blessedness, And has no mercy on those who depart to torment, And leads not to perdition those who live in it.

**[44:13]** For these are they who shall inherit that time which has been spoken of, And theirs is the inheritance of the promised time.

**[44:14]** These are they who have acquired for themselves treasures of wisdom, And with them are found stores of understanding, And from mercy have they not withdrawn, And the truth of the law have they preserved.

**[44:15]** For to them shall be given the world to come, But the dwelling of the rest who are many shall be in the fire.'

**[45:1]** 'Do ye therefore so far as ye are able instruct the people, for that labour is ours.

**[45:2]** For if ye teach them, ye will quicken them.'

**[46:1]** And my son and the elders of the people answered and said unto me: 'Has the Mighty One humiliated us to such a degree As to take thee from us quickly?

**[46:2]** And truly we shall be in darkness, And there shall be no light to the people who are left For where again shall we seek the law,

**[46:3]** Or who will distinguish for us between death and life?'

**[46:4]** And I said unto them: 'The throne of the Mighty One I cannot resist; Nevertheless, there shall not be wanting to Israel a wise man Nor a son of the law to the race of Jacob.

**[46:5]** But only prepare ye your hearts, that ye may obey the law, And be subject to those who in fear are wise and understanding; And prepare your souls that ye may not depart from them.

**[46:6]** For if ye do these things, Good tidings shall come unto you. [Which I before told you of; nor shall ye fall into the torment, of which I testified to you before.'

**[46:7]** But with regard to the word that I was to be taken I did not make (it) known to them or to my son.]

**[47:1]** And when I had gone forth and dismissed them, I went thence and said unto them: 'Behold! I go to Hebron: for thither the Mighty One hath sent me.'

**[47:2]** And I came to that place where the word had been spoken unto me, and I sat there, and fasted seven days.

**[48:1]** And it came to pass after the seventh day, that I prayed before the Mighty One and said

**[48:2]** 'O my Lord, Thou summonest the advent of the times, And they stand before Thee; Thou causest the power of the ages to pass away, And they do not resist Thee; Thou arrangest the method of the seasons, And they obey Thee.

**[48:3]** Thou alone knowest the duration of the generations, And Thou revealest not Thy mysteries to many.

**[48:4]** Thou makest known the multitude of the fire, And Thou weighest the lightness of the wind.

**[48:5]** Thou explorest the limit of the heights, And Thou scrutinizest the depths of the darkness.

**[48:6]** Thou carest for the number which pass away that they may be preserved And Thou preparest an abode for those that are to be.

**[48:7]** Thou rememberest the beginning which Thou hast made, And the destruction that is to be Thou forgettest not.

**[48:8]** With nods of fear and indignation Thou commandest the flames, And they change into spirits, And with a word Thou quickenest that which was not, And with mighty power Thou holdest that which has not yet come.

**[48:9]** Thou instructest created things in the understanding of Thee, And Thou makest wise the spheres so as to minister in their orders.

**[48:10]** Armies innumerable stand before Thee And minister in their orders quietly at Thy nod.

**[48:11]** Hear Thy servant And give ear to my petition.

**[48:12]** For in a little time are we born, And in a little time do we return.

**[48:13]** But with Thee hours are as a time, And days as generations.

**[48:14]** Be not therefore wroth with man; for he is nothing And take not account of our works; For what are we?

**[48:15]** For lo! by Thy gift do we come into the world, And we depart not of our own will.

**[48:16]** For we said not to our parents, "Beget us," Nor did we send to Sheol and say, "Receive us."

**[48:17]** What therefore is our strength that we should bear Thy wrath Or what are we that we should endure Thy judgement?

**[48:18]** Protect us in Thy compassions, And in Thy mercy help us.

**[48:19]** Behold the little ones that are subject unto Thee, And save all that draw nigh unto Thee: And destroy not the hope of our people, And cut not short 'the times of our aid.

**[48:20]** For this is the nation which Thou hast chosen, And these are the people, to whom Thou findest no equal.

**[48:21]** But I will speak now before Thee, And I will say as my heart thinketh.

**[48:22]** 'In Thee do we trust, for lo! Thy law is with us, And we know that we shall not fall so long as we keep Thy statutes.

**[48:23]** [To all time are we blessed at all events in this that we have not mingled with the Gentiles.] For we are all one celebrated people, Who have received one law from One:

**[48:24]** And the law which is amongst us will aid us, And the surpassing wisdom which is in us will help us.'

**[48:25]** And when I had prayed and said these things, I was greatly weakened.

**[48:26]** And He answered and said unto me: Thou hast prayed simply, O Baruch, And all thy words have been heard.

**[48:27]** But My judgement exacts its own And My law exacts its rights.'

**[48:28]** For from thy words I will answer thee, And from thy prayer I will speak to thee.

**[48:29]** For this is as follows: he that is corrupted is not at all; he has both wrought iniquity so far as he could do anything, and has not remembered My goodness, nor accepted My long-suffering.

**[48:30]** I Therefore thou shalt surely be taken up, as I before told thee.

**[48:31]** For that time shall arise which brings affliction; for it shall come and pass by with quick vehemence, and it shall be turbulent coming in the heat of indignation.

**[48:32]** And it shall come to pass in those days that all the inhabitants of the earth shall be moved one against another, because they know not that My judgement has drawn nigh.

**[48:33]** For there shall not be found many wise at that time, And the intelligent shall be but a few: Moreover, even those who know shall most of all be silent.

**[48:34]** And there shall be many rumours and tidings not a few, And the doings of phantasmata shall be manifest, And promises not a few be recounted. Some of them (shall prove) idle, And some of them shall be confirmed.

**[48:35]** And honour shall be turned into shame, And strength humiliated into contempt, And probity destroyed, And beauty shall become ugliness.

**[48:36]** And many shall say to many at that time: "Where hath the multitude of intelligence hidden itself, And whither hath the multitude of wisdom removed itself?"

**[48:37]** And whilst they are meditating these things, Then envy shall arise in those who had not thought aught of themselves (?) And passion shall seize him that is peaceful, And many shall be stirred up in anger to injure many, And they shall rouse up armies in order to shed blood, And in the end they shall perish together with them.

**[48:38]** And it shall come to pass at the self-same time, That a change of times shall manifestly appear to every man, Because in all those times they polluted themselves And they practised oppression, And walked every man in his own works, And remembered not the law of the Mighty One.

**[48:39]** Therefore a fire shall consume their thoughts, And in flame shall the meditations of their reins be tried; For the Judge shall come and will not tarry.

**[48:40]** Because each of the inhabitants of the earth knew when he was transgressing. But My Law they knew not by reason of their pride.

**[48:41]** But many shall then assuredly weep, Yea, over the living more than over the dead.'

**[48:42]** And I answered and said: 'O Adam, what hast thou done to all those who are born from thee? And what will be said to the first Eve who hearkened to the serpent?

**[48:43]** For all this multitude are going to corruption, Nor is there any numbering of those whom the fire devours.

**[48:44]** But again I will speak in Thy presence.

**[48:45]** Thou, O LORD, my Lord, knowest what is in Thy creature.

**[48:46]** For Thou didst of old command the dust to produce Adam, and Thou knowest the number of those who are born from him, and how far they have sinned before Thee, who have existed and not confessed Thee as their Creator.

**[48:47]** And as regards all these their end shall convict them, and Thy law which they have transgressed shall requite them on Thy day.'

**[48:48]** ['But now let us dismiss the wicked and inquire about the righteous.

**[48:49]** And I will recount their blessedness And not be silent in celebrating their glory, which is reserved for them.

**[48:50]** For assuredly as in a little time in this transitory world in which ye live, ye have endured much labour, So in that world to which there is no end, ye shall receive great light.']

**[49:1]** Nevertheless, I will again ask from Thee, O Mighty One, yea, I will ask mercy from Him who made all things.

**[49:2]** "In what shape will those live who live in Thy day? Or how will the splendour of those who (are) after that time continue?

**[49:3]** Will they then resume this form of the present, And put on these entrammelling members, Which are now involved in evils, And in which evils are consummated, Or wilt Thou perchance change these things which have been in the world, As also the world?" '

**[50:1]** And He answered and said unto me: 'Hear, Baruch, this word, And write in the remembrance of thy heart all that thou shalt learn.

**[50:2]** For the earth shall then assuredly restore the dead, [Which it now receives, in order to preserve them]. It shall make no change in their form, But as it has received, so shall it restore them, And as I delivered them unto it, so also shall it raise them.

**[50:3]** For then it will be necessary to show to the living that the dead have come to life again, and that those who had departed have returned (again).

**[50:4]** And it shall come to pass, when they have severally recognized those whom they now know, then judgement shall grow strong, and those things which before were spoken of shall come.

**[51:1]** And it shall come to pass, when that appointed day has gone by, that then shall the aspect of those who are condemned be afterwards changed, and the glory of those who are justified.

**[51:2]** For the aspect of those who now act wickedly shall become worse than it is, as they shall suffer torment.

**[51:3]** Also (as for) the glory of those who have now been justified in My law, who have had understanding in their life, and who have planted in their heart the root of wisdom, then their splendour shall be glorified in changes, and the form of their face shall be turned into the light of their beauty, that they may be able to acquire and receive the world which does not die, which is then promised to them.

**[51:4]** For over this above all shall those who come then lament, that they rejected My law, and stopped their ears that they might not hear wisdom or receive understanding.

**[51:5]** When therefore they see those, over whom they are now exalted, (but) who shall then be exalted and glorified more than they, they shall respectively be transformed, the latter into the splendour of angels, and the former shall yet more waste away in wonder at the visions and in the beholding of the forms.

**[51:6]** For they shall first behold and afterwards depart to be tormented.

**[51:7]** But those who have been saved by their works. And to whom the law has been now a hope, And understanding an expectation, And wisdom a confidence, Shall wonders appear in their time.

**[51:8]** For they shall behold the world which is now invisible to them, And they shall behold the time which is now hidden from them:

**[51:9]** And time shall no longer age them.

**[51:10]** For in the heights of that world shall they dwell, And they shall be made like unto the angels, And be made equal to the stars, And they shall be changed into every form they desire, From beauty into loveliness, And from light into the splendour of glory.

**[51:11]** For there shall be spread before them the extents of Paradise, and there shall be shown to them the beauty of the majesty of the living creatures which are beneath the throne, and all the armies of the angels, who [are now held fast by My word, lest they should appear, and] are held fast by a command, that they may stand in their places till their advent comes.

**[51:12]** Moreover, there shall then be excellency in the righteous surpassing that in the angels.

**[51:13]** For the first shall receive the last, those whom they were expecting, and the last those of whom they used to hear that they had passed away.

**[51:14]** For they have been delivered from this world of tribulation, And laid down the burden of anguish.

**[51:15]** For what then have men lost their life, And for what have those who were on the earth exchanged their soul?

**[51:16]** For then they chose (not) for themselves this time, Which, beyond the reach of anguish, could not pass away: But they chose for themselves that time, Whose issues are full of lamentations and evils, And they denied the world which ages not those who come to it, And they rejected the time of glory, So that they shall not come to the honour of which I told thee before.'

**[52:1]** And I answered and said: How can we forget those for whom woe is then reserved?

**[52:2]** And why therefore do we again mourn for those who die? Or why do we weep for those who depart to Sheol?

**[52:3]** Let lamentations be reserved for the beginning of that coming torment, And let tears be laid up for the advent of the destruction of that time.

**[52:4]** [But even in the face of these things will I speaks

**[52:5]** And as for the righteous, what will they do now?

**[52:6]** Rejoice ye in the suffering which ye now suffer: For why do ye look for the decline of your enemies?

**[52:7]** Make ready your soul for that which is reserved for you, And prepare your souls for the reward which is laid up for you.']

**[53:1]** And when I had said these things I fell asleep there, and I saw a vision, and lo! a cloud was ascending from a very great sea, and I kept gazing upon it, and lo! it was full of waters white and black, and there were many colours in those self-same waters, and as it were the likeness of great lightning was seen at its summit.

**[53:2]** And I saw the cloud passing swiftly in quick courses, and it covered all the earth.

**[53:3]** And it came to pass after these things that cloud began to pour upon the earth the waters that were in it.

**[53:4]** And I saw that there was not one and the same likeness in the waters which descended from it.

**[53:5]** For in the first beginning they were black and many for a time, and afterwards I saw that the waters became bright, but they were not many, and after these things again I saw black (waters), and after these things again bright, and again black and again bright how this was done twelve times, but the black were always more numerous than the bright.

**[53:6]** And it came to pass at the end of the cloud, that lo! it rained black waters, and they were darker than had been all those waters that were before, and fire was mingled with them, and where those waters descended, they wrought devastation and destruction.

**[53:7]** And after these things I saw how that lightning which I had seen on the summit of the cloud, seized hold of it and hurled it to the earth.

**[53:9]** Now that lightning shone exceedingly, so as to illuminate the whole earth, and it healed those regions where the last waters had descended and wrought devastation.

**[53:10]** And it took hold of the whole earth, and had dominion over it.

**[53:11]** And I saw after these things, and lo! twelve rivers were ascending from the sea, and they began to surround that lightning and to become subject to it.

**[53:12]** And by reason of my fear I awoke.

**[54:1]** And I besought the Mighty One, and said: Thou alone, O Lord, knowest of aforetime the deep things of the world, And the things which befall in their times Thou bringest about by Thy word, And against the works of the inhabitants of the earth Thou dost hasten the beginnings of the times, And the end of the seasons Thou alone knowest.

**[54:2]** (Thou) for whom nothing is too hard, But who dost everything easily by a nod:

**[54:3]** (Thou) to whom the depths come as the heights, And whose word the beginnings of the ages serve:

**[54:4]** (Thou) who revealest to those who fear Thee what is prepared for them, That thenceforth they may be comforted.

**[54:5]** Thou showest great acts to those who know not; Thou breakest up the enclosure of those who are ignorant, And lightest up what is dark, And revealest what is hidden to the pure, [Who in faith have submitted themselves to Thee and Thy law.]

**[54:6]** Thou hast shown to Thy servant this vision; Reveal to me also its interpretation.

**[54:7]** For I know that as regards those things wherein I besought Thee, I have received a response, And as regards what I besought, Thou didst reveal to me with what voice I should praise Thee, And from what members I should cause praises and hallelujahs to ascend to Thee.

**[54:8]** For if my members were mouths, And the hairs of my head voices, Even so I could not give Thee the meed of praise, Nor laud thee as is befitting, Nor could I recount Thy praise, Nor tell the glory of Thy beauty.

**[54:9]** For what am I amongst men, Or why am I reckoned amongst those who are more excellent than I, That I have heard all these marvelous things from the Most High, And numberless promises from Him who created me?

**[54:10]** Blessed be my mother among those that bear, And praised among women be she that bare me.

**[54:11]** For I will not be silent in praising the Mighty One, And with the voice of praise I will recount His marvellous deeds.

**[54:12]** For who doeth like unto Thy marvellous deeds, O God, Or who comprehendeth Thy deep thought of life.

**[54:13]** For with Thy counsel Thou dost govern all the creatures which Thy right hand has created, And Thou hast established every fountain of light beside Thee, And the treasures of wisdom beneath Thy throne hast Thou prepared.

**[54:14]** And justly do they perish who have not loved Thy law, And the torment of judgement shall await those who have not submitted themselves to Thy power.

**[54:15]** For though Adam first sinned And brought untimely death upon all, Yet of those who were born from him Each one of them has prepared for his own soul torment to come, And again each one of them has chosen for himself glories to come.

**[54:16]** [For assuredly he who believeth will receive reward.

**[54:17]** But now, as for you, ye wicked that now are, turn ye to destruction, because ye shall speedily be visited, in that formerly ye rejected the understanding of the Most High.

**[54:18]** For His works have not taught you, Nor has the skill of His creation which is at all times persuaded you.]

**[54:19]** Adam is therefore not the cause, save only of his own soul, But each of us has been the Adam of his own soul.

**[54:20]** But do Thou, O Lord, expound to me regarding those things which Thou hast revealed to me, And inform me regarding that which I besought Thee.

**[54:21]** For at the consummation of the world vengeance shall be taken upon those who have done wickedness according to their wickedness, And Thou wilt glorify the faithful according to their faithfulness.

**[54:22]** For those who are amongst Thine own Thou rulest, And those who sin Thou blottest out from amongst Thine own.'

**[55:1]** And it came to pass when I had finished speaking the words of this prayer, that I sat there under a tree, that I might rest in the shade of the branches.

**[55:2]** And I wondered and was astonied, and pondered in my thoughts regarding the multitude of goodness which sinners who are upon the earth have rejected, and regarding the great torment which they have despised, though they knew that they should be tormented because of the sin they had committed.

**[55:3]** And when I was pondering on these things and the like, lo! the angel Ramiel who presides over true visions was sent to me, and he said unto me:

**[55:4]** 'Why does thy heart trouble thee, Baruch, and why does thy thought disturb thee?

**[55:5]** For if owing to the report which thou hast only heard of judgement thou art so moved, What (wilt thou be) when thou shalt see it manifestly with thine eyes?

**[55:6]** And if with the expectation wherewith thou dost expect the day of the Mighty One thou art so overcome, What (wilt thou be) when thou shalt come to its advent?

**[55:7]** And, if at the word of the announcement of the torment of those who have done foolishly thou art so wholly distraught, How much more when the event will reveal marvellous things?

**[55:8]** And if thou hast heard tidings of the good and evil things which are then coming and art grieved, What (wilt thou be) when thou shalt behold what the majesty will reveal, Which shall convict these and cause those to rejoice.'

**[56:1]** Nevertheless, because thou hast besought the Most High to reveal to thee the interpretation of the vision which thou hast seen,

**[56:2]** I have been sent to tell thee. And the Mighty One hath assuredly made known to thee the methods of the times that have passed, and of those that are destined to pass in His world from the beginning of its creation even unto its consummation, of those things which (are) deceit and of those which (are) in truth.

**[56:3]** For as thou didst see a great cloud which ascended from the sea, and went and covered the earth, this is the duration of the world which the Mighty One made when he took counsel to make the world.

**[56:4]** And it came to pass when the word had gone forth from His presence, that the duration of the world had come into being in a small degree, and was established according to the multitude of the intelligence of Him who sent it.

**[56:5]** And as thou didst previously see on the summit of the cloud black waters which descended previously on the earth, this is the transgression wherewith Adam the first man transgressed.

**[56:6]** For [since] when he transgressed Untimely death came into being, Grief was named And anguish was prepared, And pain was created, And trouble consummated, And disease began to be established, And Sheol kept demanding that it should be renewed in blood, And the begetting of children was brought about, And the passion of parents produced, And the greatness of humanity was humiliated, And goodness languished.

**[56:7]** What therefore can be blacker or darker than these things?

**[56:8]** This is the beginning of the black waters which thou hast seen.

**[56:9]** And from these black (waters) again were black derived, and the darkness of darkness was produced.

**[56:10]** For he became a danger to his own soul: even to the angels became he a danger.

**[56:11]** For, moreover, at that time when he was created, they enjoyed liberty.

**[56:12]** And some of them descended, and mingled with the women.

**[56:13]** And then those who did so were tormented in chains.

**[56:14]** But the rest of the multitude of the angels, of which there is (no) number, restrained themselves.

**[56:15]** And those who dwelt on the earth perished together (with them) through the waters of the deluge.

**[56:16]** These are the black first waters.

**[57:1]** And after these (waters) thou didst see bright waters: this is the fount of Abraham, also his generations and advent of his son, and of his son's son, and of those like them.

**[57:2]** Because at that time the unwritten law was named amongst them, And the works of the commandments were then fulfilled, And belief in the coming judgement was then generated, And hope of the world that was to be renewed was then built up, And the promise of the life that should come hereafter was implanted.

**[57:3]** These are the bright waters, which thou hast seen.

**[58:1]** And the black third waters which thou hast seen, these are the mingling of all sins, which the nations afterwards wrought after the death of those righteous men, and the wickedness of the land of Egypt, wherein they did wickedly in the service wherewith they made their sons to serve.

**[58:2]** Nevertheless, these also perished at last.

**[59:1]** And the bright fourth waters which thou hast seen are the advent of Moses and Aaron and Miriam and Joshua the son of Nun and Caleb and of all those like them.

**[59:2]** For at that time the lamp of the eternal law shone on all those who sat in darkness, which announced to them that believe the promise of their reward, and to them that deny, the torment of fire which is reserved for them.

**[59:3]** But also the heavens at that time were shaken from their place, and those who were under the throne of the Mighty One were perturbed, when He was taking Moses unto Himself

**[59:4]** For He showed him many admonitions together with the principles of the law and the consummation of the times, as also to thee, and likewise the pattern of Zion and its measures, in the pattern of which the sanctuary of the present time was to be made.

**[59:5]** But then also He showed to him the measures of the fire, also the depths of the abyss, and the weight of the winds, and the number of the drops of rain:

**[59:6]** And the suppression of anger, and the multitude of long-suffering, and the truth of judgement:

**[59:7]** And the root of wisdom, and the riches of understanding, and the fount of knowledge:

**[59:8]** And the height of the air, and the greatness of Paradise, and the consummation of the ages, and the beginning of the day of judgement:

**[59:9]** And the number of the offerings, and the earths which have not yet come:

**[59:10]** And the mouth of Gehenna, and the station of vengeance, and the place of faith, and the region of hope:

**[59:11]** And the likeness of future torment, and the multitude of innumerable angels, and the flaming hosts, and the splendour of the lightning and the voice of the thunders, and the orders of the chiefs of the angels, and the treasuries of light, and the changes of the times, and the investigations of the law.

**[59:12]** These are the bright fourth waters which thou hast seen.

**[60:1]** 'And the black fifth waters which thou hast seen raining are the works which the Amorites wrought, and the spells of their incantations which they wrought, and the wickedness of their mysteries, and the mingling of their pollution.

**[60:2]** But even Israel was then polluted by sins in the days of the judges, though they saw many sip which were from Him who made them.

**[61:1]** 'And the bright sixth waters which thou didst see, this is the time in which David and Solomon were born.

**[61:2]** And there was at that time the building of Zion, And the dedication of the sanctuary, And the shedding of much blood of the nations that sinned then, And many offerings which were offered then in the dedication of the sanctuary.

**[61:3]** And peace and tranquillity existed at that time,

**[61:4]** And wisdom was heard in the assembly: And the riches of understanding were magnified in the congregations,

**[61:5]** And the holy festivals were fulfilled in blessedness and in much joy.

**[61:6]** And the judgement of the rulers was then seen to be without guile, And the righteousness of the precepts of the Mighty One was accomplished with truth.

**[61:7]** And the land [which] was then beloved by the Lord, And because its inhabitants sinned not, it was glorified beyond all lands, And the city Zion ruled then over all lands and regions.

**[61:8]** These are the bright waters which thou hast seen.

**[62:1]** 'And the black seventh waters which thou bast seen, this is the perversion (brought about) by the counsel of Jeroboam, who took counsel to make two calves of gold:

**[62:2]** And all the iniquities which kings who were after him iniquitously wrought.

**[62:3]** And the curse of Jezebel and the worship of idols which Israel practised at that time.

**[62:4]** And the withholding of rain, and the famines which occurred until women eat the fruit of their wombs.

**[62:5]** And the time of their captivity which came upon the nine tribes and a half, because they were in many sins.

**[62:6]** And Salmanasar king of Assyria came and led them away captive.

**[62:7]** But regarding the Gentiles it were tedious to tell how they always wrought impiety and wickedness, and never wrought righteousness.

**[62:8]** These are the black seventh waters which thou hast seen.

**[63:1]** 'And the bright eighth waters which thou hast seen, this is the rectitude and uprightness of Hezekiah king of Judah and the grace (of God) which came upon him.

**[63:2]** For when Sennacherib was stirred up in order that he might perish, and his wrath troubled him in order that he might thereby perish, for the multitude also of the nations which were with him.

**[63:3]** When, moreover, Hezekiah the king heard those things which the king of Assyria was devising, (i.e.) to come and seize him and destroy his people, the two and a half tribes which remained: nay, more he wished to overthrow Zion also: then Hezekiah trusted in his works, and had hope in his righteousness, and spake with the Mighty One and said:

**[63:4]** "Behold, for lo! Sennacherib is prepared to destroy us, and he will be boastful and uplifted when he has destroyed Zion."

**[63:5]** And the Mighty One heard him, for Hezekiah was wise, And He had respect unto his prayer, because he was righteous.

**[63:6]** And thereupon the Mighty One commanded Ramiel His angel who speaks with thee.

**[63:7]** And I went forth and destroyed their multitude, the number of whose chiefs only was a hundred and eighty-five thousand, and each one of them had an equal number (at his command).

**[63:8]** And at that time I burned their bodies within, but their raiment and arms I preserved outwardly, in order that the still more wonderful deeds of the Mighty One might appear, and that thereby His name might be spoken of throughout the whole earth.

**[63:9]** And Zion was saved and Jerusalem delivered: Israel also was freed from tribulation.

**[63:10]** And all those who were in the holy land rejoiced, and the name of the Mighty One was glorified so that it was spoken of.

**[63:11]** These are the bright waters which thou hast seen.

**[64:1]** 'And the black ninth waters which thou hast seen, this is all the wickedness which was in the days of Manasseh the son of Hezekiah.

**[64:2]** For he wrought much impiety, and he slew the righteous, and he wrested judgement. and he shed the blood of the innocent, and wedded women he violently polluted, and he overturned the altars, and destroyed their offerings, and drove forth their priests lest they should minister in the sanctuary.

**[64:3]** And he made an image with five faces: four of them looked to the four winds, and the fifth on the summit of the image as an adversary of the zeal of the Mighty One.

**[64:4]** And then wrath went forth from the presence of the Mighty One to the intent that Zion should be rooted out, as also it befell in your days.

**[64:5]** But also against the two tribes and a half went forth a decree that they should also be led away captive, as thou hast now seen.

**[64:6]** And to such a degree did the impiety of Manasseh increase, that it removed the praise of the Most High from the sanctuary.

**[64:7]** On this account Manasseh was at that time named "the impious", and finally his abode was in the fire.

**[64:8]** For though his prayer was heard with the Most High, finally, when he was cast into the brazen horse and the brazen horse was melted, it served as a sign unto him for the hour.

**[64:9]** For he had not lived perfectly, for he was not worthy but that thenceforward he might know by whom finally he should be tormented.

**[64:10]** For he who is able to benefit is also able to torment.

**[65:1]** Thus, moreover, did Manasseh act impiously, and thought that in his time the Mighty One would not inquire into these things.

**[65:2]** These are the black ninth waters which thou hast seen.

**[66:1]** 'And the bright tenth waters which thou hast seen: this is the purity of the generations of Josiah king of Judah, who was the only one at the time who submitted himself to the Mighty One with all his heart and with all his soul.

**[66:2]** And he cleansed the land from idols, and hallowed all the vessels which had been polluted, and restored the offerings to the altar, and raised the horn of the holy, and exalted the righteous, and honoured all that were wise in understanding, and brought back the priests to their ministry, and destroyed and removed the magicians and enchanters and necromancers from the land.

**[66:3]** And not only did he slay the impious that were living, but they also took from the sepulchres the bones of the dead and burned them with fire.

**[66:4]** [And the festivals and the sabbaths he established in their sanctity], and their polluted ones he burnt in the fire, and the lying prophets which deceived the people these also he burnt in the fire, and the people who listened to them when they were living, he cast them into the brook Cedron, and heaped stones upon them.

**[66:5]** And he was zealous with zeal for the Mighty One with all his soul, and he alone was firm in the law at that time, so that he left none that was uncircumcised, or that wrought impiety in all the land, all the days of his life.

**[66:6]** Therefore he shall receive an eternal reward, and he shall be glorified with the Mighty One beyond many at a later time.

**[66:7]** For on his account and on account of those who are like him were the honourable glories, of which thou wast told before, created and prepared.

**[66:8]** These are the bright waters which thou hast seen.

**[67:1]** 'And the black eleventh waters which thou hast seen: this is the calamity which is now befalling Zion.

**[67:2]** Dost thou think that there is no anguish to the angels in the presence of the Mighty One, That Zion was so delivered up, And that lo! the Gentiles boast in their hearts, And assemble before their idols and say, "She is trodden down who oft times trod down, And she has been reduced to servitude who reduced (others)"?

**[67:3]** Dost thou think that in these things the Most High rejoices, Or that His name is glorified?

**[67:4]** [But how will it serve towards His righteous judgement?]

**[67:5]** Yet after these things shall the dispersed among the Gentiles be taken hold of by tribulation, And in shame shall they dwell in every place.

**[67:6]** Because so far as Zion is delivered up And Jerusalem laid waste, Shall idols prosper in the cities of the Gentiles, And the vapour of the smoke of the incense of the righteousness which is by the law is extinguished in Zion, And in the region of Zion in every place lo! there is the smoke of impiety.

**[67:7]** But the king of Babylon will arise who has now destroyed Zion, And he will boast over the people, And he will speak great things in his heart in the presence of the Most High.

**[67:8]** But he also shall fall at last.

**[67:9]** These are the black waters.

**[68:1]** 'And the bright twelfth waters which thou hast seen: this is the word.

**[68:2]** For after these things a time will come when thy people shall fall into distress, so that they shall all run the risk of perishing together.

**[68:3]** Nevertheless, they will be saved, and their enemies will fall in their presence.

**[68:4]** And they will have in (due) time much joy.

**[68:5]** And at that time after a little interval Zion will again be builded, and its offerings will again be restored, and the priests will return to their ministry, and also the Gentiles will come to glorify it.

**[68:6]** Nevertheless, not fully as in the beginning.

**[68:8]** But it will come to pass after these things that there will be the fall of many nations.

**[68:9]** These are the bright waters which thou hast seen.

**[69:1]** 'For the last waters which thou hast seen which were darker than all that were before them, those which were after the twelfth number, which were collected together, belong to the whole world.

**[69:2]** For the Most High made division from the beginning, because He alone knows what will befall.

**[69:3]** For as to the enormities and the impieties which should be wrought before Him, He foresaw six kinds of them.

**[69:4]** And of the good works of the righteous which should be accomplished before Him, He foresaw six kinds of them, beyond those which He should work at the consummation of the age.

**[69:5]** On his account there were not black waters with black, nor bright with bright; for it is the consummation.

**[70:1]** 'Hear therefore the interpretation of the last black waters which are to come [after the black]: this is the word.

**[70:2]** Behold! the days come, and it shall be when the time of the age has ripened, And the harvest of its evil and good seeds has come, That the Mighty One will bring upon the earth and its inhabitants and upon its rulers Perturbation of spirit and stupor of heart. And they shall hate one another, And provoke one another to fight,

**[70:3]** And the mean shall rule over the honourable, And those of low degree shall be extolled above the famous.

**[70:4]** And the many shall be delivered into the hands of the few, And those who were nothing shall rule over the strong, And the poor shall have abundance beyond the rich, And the impious shall exalt themselves above the heroic.

**[70:5]** And the wise shall be silent, And the foolish shall speak, Neither shall the thought of men be then confirmed, Nor the counsel of the mighty, Nor shall the hope of those who hope be confirmed.

**[70:6]** And when those things which were predicted have come to pass, Then shall confusion fall upon all men, And some of them shall fall in battle, And some of them shall perish in anguish, And some of them shall be destroyed by their own.

**[70:7]** Then the Most High will reveal those peoples whom He has prepared before, And they shall come and make war with the leaders that shall then be left.

**[70:8]** And it shall come to pass that whosoever gets safe out of the war shall die in the earthquake, And whosoever gets safe out of the earthquake shall be burned by the fire, And whosoever gets safe out of the fire shall be destroyed by famine.

**[70:9]** [And it shall come to pass that whosoever of the victors and the vanquished gets safe out of and escapes all these things aforesaid will be delivered into the hands of My servant Messiah.]

**[70:10]** For all the earth shall devour its inhabitants.

**[71:1]** 'And the holy land shall have mercy on its own, And it shall protect its inhabiters at that time.

**[71:2]** This is the vision which thou hast seen, and this is the interpretation.

**[71:3]** For I have come to tell thee these things, because thy prayer has been heard with the Most High.

**[72:1]** 'Hear now also regarding the bright lightning which is to come at the consummation after these black (waters): this is the word.

**[72:2]** After the signs have come, of which thou wast told before, when the nations become turbulent, and the time of My Messiah is come, he shall both summon all the nations, and some of them he shall spare, and some of them he shall slay.

**[72:3]** These things therefore shall come upon the nations which are to be spared by Him.

**[72:4]** Every nation, which knows not Israel and has not trodden down the seed of Jacob, shall indeed be spared.

**[72:5]** And this because some out of every nation shall be subjected to thy people.

**[72:6]** But all those who have ruled over you, or have known you, shall be given up to the sword.

**[73:1]** 'And it shall come to pass, when He has brought low everything that is in the world, And has sat down in peace for the age on the throne of His kingdom, That joy shall then be revealed, And rest shall appear.

**[73:2]** And then healing shall descend in dew, And disease shall withdraw, And anxiety and anguish and lamentation pass from amongst men, And gladness proceed through the whole earth.

**[73:3]** And no one shall again die untimely, Nor shall any adversity suddenly befall.

**[73:4]** And judgements, and revilings, and contentions, and revenges, And blood, and passions, and envy, and hatred, And whatsoever things are like these shall go into condemnation when they are removed.

**[73:5]** For it is these very things which have filled this world with evils, And on account of these the life of man has been greatly troubled.

**[73:6]** And wild beasts shall come from the forest and minister unto men, And asps and dragons shall come forth from their holes to submit themselves to a little child.

**[73:7]** And women shall no longer then have pain when they bear, Nor shall they suffer torment when they yield the fruit of the womb.

**[74:1]** And it shall come to pass in those days that the reapers shall not grow weary, Nor those that build be toil worn; For the works shall of themselves speedily advance Together with those who do them in much tranquillity.

**[74:2]** For that time is the consummation of that which is corruptible, And the beginning of that which is not corruptible.

**[74:3]** Therefore those things which were predicted shall belong to it: Therefore it is far away from evils, and near to those things which die not.

**[74:4]** This is the bright lightning which came after the last dark waters.'

**[75:1]** And I answered and said: Who can understand, O Lord, Thy goodness? For it is incomprehensible.

**[75:2]** Or who can search into thy compassions, Which are infinite?

**[75:3]** Or who can comprehend Thy intelligence?

**[75:4]** Or who is able to recount the thoughts of Thy mind?

**[75:5]** Or who of those who are born can hope to come to those things, Unless he is one to whom Thou art merciful and gracious?

**[75:6]** Because, if assuredly Thou didst not have compassion on man, Those who are under Thy right hand, They could not come to those things, But those who are in the numbers named can be called.

**[75:7]** But if, indeed, we who exist know wherefore we have come, And submit ourselves to Him who brought us out of Egypt, We shall come again and remember those things which have passed, And shall rejoice regarding that which has been.

**[75:8]** But if now we know not wherefore we have come, And recognize not the principate of Him who brought us up out of Egypt, We shall come again and seek after those things which have been now, And be grieved with pain because of those things which have befallen.'

**[76:1]** And He answered and said unto me: ['Inasmuch as the revelation of this vision has been interpreted to thee as thou besoughtest], hear the word of the Most High that thou mayst know what is to befall thee after these things.

**[76:2]** For thou shalt surely depart from this earth, nevertheless not unto death, but thou shalt be preserved unto the consummation of the times.

**[76:3]** Go up therefore to the top of that mountain, and there shall pass before thee all the regions of that land, and the figure of the inhabited world, and the top(s) of the mountains, and the depth(s) of the valleys, and the depths of the seas, and the number of the rivers, that thou mayst see what thou art leaving and whither thou art going.

**[76:4]** Now this shall befall after forty days.

**[76:5]** Go now therefore during these days and instruct the people so far as thou art able, that they may learn so as not to die at the last time, but may learn in order that they may live at the last times.'

**[77:1]** And I, Baruch, went thence and came to the people, and assembled them together from the greatest to the least, and said unto them:

**[77:2]** 'Hear, ye children of Israel, behold how many ye are who remain of the twelve tribes of Israel.

**[77:3]** For to you and to your fathers the Lord gave a law more excellent than to all peoples.

**[77:4]** And because your brethren transgressed the commandments of the Most High, He brought vengeance upon you and upon them, And He spared not the former, And the latter also He gave into captivity: And He left not a residue of them,

**[77:5]** But behold! ye are here with me.

**[77:6]** If, therefore, ye direct your ways aright, Ye also shall not depart as your brethren departed, But they shall come to you.

**[77:7]** For He is merciful whom ye worship, And He is gracious in whom ye hope, And He is true, so that He shall do good and not evil.

**[77:8]** Have ye not seen here what has befallen Zion?

**[77:9]** Or do ye perchance think that the place had sinned, And that on this account it was overthrown? Or that the land had wrought foolishness, And that therefore it was delivered up?

**[77:10]** And know ye not that on account of you who did sin, That which sinned not was overthrown, And, on account of those who wrought wickedly, That which wrought not foolishness was delivered up to (its) enemies?'

**[77:11]** And the whole people answered and said unto me: 'So far as we can recall the good things which the Mighty One has done unto us, we do recall them; and those things which we do not remember He in His mercy knows.

**[77:12]** Nevertheless, do this for us thy people: write also to our brethren in Babylon an epistle of doctrine and a scroll of hope, that thou mayst confirm them also before thou dost depart from us.

**[77:13]** For the shepherds of Israel have perished, And the lamps which gave light are extinguished, And the fountains have withheld their stream whence we used to drink.

**[77:14]** And we are left in the darkness, And amid the trees of the forest, And the thirst of the wilderness.'

**[77:15]** And I answered and said unto them: Shepherds and lamps and fountains come from the law: And though we depart, yet the law abideth.

**[77:16]** If therefore ye have respect to the law, And are intent upon wisdom, A lamp will not be wanting, And a shepherd will not fail, And a fountain will not dry up.

**[77:17]** Nevertheless, as ye said unto me, I will write also unto your brethren in Babylon, and I will send by means of men, and I will write in like manner to the nine tribes and a half, and send by means of a bird.'

**[77:18]** And it came to pass on the one and twentieth day in the eighth month that I, Baruch, came and sat down under the oak under the shadow of the branches, and no man was with me, but I was alone.

**[77:19]** And I wrote these two epistles: one I sent by an eagle to the nine and a half tribes; and the other I sent to those that were at Babylon by means of three men.

**[77:20]** And I called the eagle and spake these words unto it:

**[77:21]** 'The Most High hath made thee that thou shouldst be higher than all birds.

**[77:22]** And now go and tarry not in (any) place, nor enter a nest, nor settle upon any tree, till thou hast passed over the breadth of the many waters of the river Euphrates, and hast gone to the people that dwell there, and cast down to them this epistle.

**[77:23]** Remember, moreover, that, at the time of the deluge, Noah received from a dove the fruit of the olive, when he sent it forth from the ark.

**[77:24]** Yea, also the ravens ministered to Elijah, bearing him food, as they had been commanded. Solomon also, in the time of his kingdom, whithersoever he wished to send or seek for anything, commanded a bird (to go thither), and it obeyed him as he commanded it.

**[77:25]** And now let it not weary thee, and turn not to the right hand nor the left, but fly and go by a direct way, that thou mayst preserve the command of the Mighty One, according as I said unto thee.'

**[78:1]** These are the words of that epistle which Baruch the son of Neriah sent to the nine and a half tribes, which were across the river Euphrates, in which these things were written.

**[78:2]** Thus saith Baruch the son of Neriah to the brethren carried into captivity:

**[78:3]** 'Mercy and peace.' I bear in mind, my brethren, the love of Him who created us, who loved us from of old, and never hated us, but above all educated us.

**[78:4]** And truly I know that behold all we the twelve tribes are bound by one bond, inasmuch as we are born from one father.

**[78:5]** Wherefore I have been the more careful to leave you the words of this epistle before I die, that ye may be comforted regarding the evils which have come upon you, and that ye may be grieved also regarding the evil that has befallen your brethren; and again, also, that ye may justify His judgement which He has decreed against you that ye should be carried away captives for what ye have suffered is disproportioned to what ye have done in order that, at the last times, ye may be found worthy of your fathers.

**[78:6]** Therefore, if ye consider that ye have now suffered those things for your good, that ye may not finally be condemned and tormented, then ye will receive eternal hope; if above all ye destroy from your heart vain error, on account of which ye departed, hence.

**[78:7]** For if ye so do these things, He will continually remember you, He who always promised on our behalf to those who were more excellent than we, that He will never forget or forsake us, but with much mercy will gather together again those who were dispersed.

**[79:1]** Now, my brethren, learn first what befell Zion: how that Nebuchadnezzar king of Babylon came up against us.

**[79:2]** For we have sinned against Him who made us, and we have not kept the commandments which he commanded us,

**[79:3]** yet he hath not chastened us as we deserved.

**[79:4]** For what befell you we also suffer in a pre-eminent degree, for it befell us also.

**[80:1]** And now, my brethren, I make known unto you that when the enemy had surrounded the city, the angels of the Most High were sent, and they overthrew the fortifications of the strong wall, and they destroyed the firm iron corners, which could not be rooted out.

**[80:2]** Nevertheless, they hid all the vessels of the sanctuary, lest the enemy should get possession of them.

**[80:3]** And when they had done these things, they delivered thereupon to the enemy the overthrown wall, and the plundered house, and the burnt temple, and the people who were overcome because they were delivered up, lest the enemy should boast and say: 'Thus by force have we been able to lay waste even the house of the Most High in war.

**[80:4]** 'Your brethren also have they bound and led away to Babylon, and have caused, them to dwell there.

**[80:5]** But we have been left here, being very few.

**[80:6]** This is the tribulation about which I wrote to you.

**[80:7]** For assuredly I know that (the consolation of) the inhabitants of Zion consoleth you: so far as ye knew that it was prospered (your consolation) was greater than the tribulation which ye endured in having to depart from it.

**[81:1]** But regarding consolation, hear ye the word.

**[81:2]** For I was mourning regarding Zion, and I prayed for mercy from the Most High, and I said:

**[81:3]** 'How long will these things endure for us? And will these evils come upon us always?'

**[81:4]** And the Mighty One did according to the multitude of His mercies, And the Most High according to the greatness of His compassion, And He revealed unto me the word, that I might receive consolation, And He showed me visions that I should not again endure anguish, And He made known to me the mystery of the times. And the advent of the hours he showed me.

**[82:1]** Therefore, my brethren, I have written to you, that ye may comfort yourselves regarding the multitude of your tribulations.

**[82:2]** For know ye that our Maker will assuredly avenge us on all our enemies, according to all that they have done to us, also that the consummation which the Most High will make is very nigh, and His mercy that is coming, and the consummation of His judgement is by no means far off.

**[82:3]** For lo! we see now the multitude of the prosperity of the Gentiles, Though they act impiously, But they shall be like a vapour:

**[82:4]** And we behold the multitude of their power, Though they do wickedly, But they shall be made like unto a drop:

**[82:5]** And we see the firmness of their might. Though they resist the Mighty One every hour, But they shall be accounted as spittle.

**[82:6]** And we consider the glory of their greatness, Though they do not keep the statutes of the Most High, But as smoke shall they pass away.

**[82:7]** And we meditate on the beauty of theirs gracefulness, Though they have to do with pollutions, But as grass that withers shall they fade away.

**[82:8]** And we consider the strength of their cruelty, Though they remember not the end (thereof), But as a wave that passes shall they be broken.

**[82:9]** And we remark the boastfulness of their might, Though they deny the beneficence of God, who gave (it) to them, But they shall pass away as a passing cloud.

**[83:1]** [For the Most High will assuredly hasten His times, And He will assuredly bring on His hours.

**[83:2]** And He will assuredly judge those who are in His world, And will visit in truth all things by means of all their hidden works.

**[83:3]** And He will assuredly examine the secret thoughts, And that which is laid up in the secret chambers of all the members of man. And will make (them) manifest in the presence of all with reproof.

**[83:4]** Let none therefore of these present things ascend into your hearts, but above all let us be expectant, because that which is promised to us shall come.

**[83:5]** And let us not now look unto the delights of the Gentiles in the present,

**[83:6]** but let us remember what has been promised to us in the end. For the ends of the times and of the seasons and whatsoever is with them shall assuredly pass by together.

**[83:7]** The consummation, moreover, of the age shall then show the great might of its ruler, when all things come to judgement.

**[83:8]** Do ye therefore prepare your hearts for that which before ye believed, lest ye come to be in bondage in both worlds, so that ye be led away captive here and be tormented there.

**[83:9]** For that which exists now or which has passed away, or which is to come, in all these things, neither is the evil fully evil, nor again the good fully good.

**[83:10]** For all healthinesses of this time are turning into diseases,

**[83:11]** And all might of this time is turning into weakness, And all the force of this time is turning into impotence, And every energy of youth is turning into old age and consummation.

**[83:12]** And every beauty of gracefulness of this time is turning faded and hateful,

**[83:13]** And every proud dominion of the present is turning into humiliation and shame, And every praise of the glory of this time is turning into the shame of silence,

**[83:14]** And every vain splendour and insolence of this time is turning into voiceless ruin.

**[83:15]** And every delight and joy of this time is turning to worms and corruption,

**[83:16]** And every clamour of the pride of this time is turning into dust and stillness.

**[83:17]** And every possession of riches of this time is being turned into Sheol alone,

**[83:18]** And all the rapine of passion of this time is turning into involuntary death, And every passion of the lusts of this time is turning into a judgement of torment.

**[83:19]** And every artifice and craftiness of this time is turning into a proof of the truth,

**[83:20]** And every sweetness of unguents of this time is turning into judgement and condemnation,

**[83:21]** And every love of lying is turning to contumely through truth.

**[83:22]** Since therefore all these things are done now, does anyone think that they will not be avenged;

**[83:23]** But the consummation of all things will come to the truth.]

**[84:1]** Behold! I have therefore made known unto you (these things) whilst I live: for I have said (it) that ye should learn the things that are excellent; for the Mighty One hath commanded me to instruct you: and I will set before you some of the commandments of His judgement before I die.

**[84:2]** Remember that formerly Moses assuredly called heaven and earth to witness against you and said:'If ye transgress the law ye shall be dispersed, but if ye keep it ye shall be kept.'

**[84:3]** And other things also he used to say unto you when ye the twelve tribes were together in the desert.

**[84:4]** And after his death ye cast them away from you: on this account there came upon you what had been predicted.

**[84:5]** And now Moses used to tell you before they befell you, and lo! they have befallen you: for ye have forsaken the law.

**[84:6]** Lo! I also say unto you after ye have suffered, that if ye obey those things which have been said unto you, ye will receive from the Mighty One whatever has been laid up and reserved for you.

**[84:7]** Moreover, let this epistle be for a testimony between me and you, that ye may remember the commandments of the Mighty One, and that also there may be to me a defence in the presence of Him who sent me.

**[84:8]** And remember ye the law and Zion, and the holy land and your brethren, and the covenant of your fathers, and forget not the festivals and the sabbaths.

**[84:9]** And deliver ye this epistle and the traditions of the law to your sons after you, as also your fathers delivered (them) to you.

**[84:10]** And at all times make request perseveringly and pray diligently with your whole heart that the Mighty One may be reconciled to you, and that He may not reckon the multitude of your sins, but remember the rectitude of your fathers.

**[84:11]** For if He judge us not according to the multitude of His mercies, woe unto all us who are born.

**[85:1]** [Know ye, moreover, that In former times and in the generations of old our fathers had helpers, Righteous men and holy prophets:

**[85:2]** Nay more, we were in our own land [And they helped us when we sinned], And they interceded for us with Him who made us, [Because they trusted in their works], And the Mighty One heard their prayer and forgave us.

**[85:3]** But now the righteous have been gathered And the prophets have fallen asleep, And we also have gone forth from the land, And Zion has been taken from us, And we have nothing now save the Mighty One and His law.

**[85:4]** If therefore we direct and dispose our hearts, We shall receive everything that we lost, And much better things than we lost by many times.

**[85:5]** For what we have lost was subject to corruption, And what we shall receive shall not be corruptible.

**[85:6]** [Moreover, also, I have written thus to our brethren to Babylon, that to them also I may attest these very things.]

**[85:7]** And let all those things aforesaid be always before your eyes, Because we are still in the spirit and the power of our liberty.

**[85:8]** Again, moreover, the Most High also is long-suffering towards us here, And He hath shown to us that which is to be, And hath not concealed from us what will befall in the end.

**[85:9]** Before therefore judgement exact its own, And truth that which is its due, Let us prepare our soul That we may possess, and not be taken possession of, And that we may hope and not be put to shame, And that we may rest with our fathers, and not be tormented with our enemies.

**[85:10]** For the youth of the world is past, And the strength of the creation already exhausted, And the advent of the times is very short, Yea, they have passed by; And the pitcher is near to the cistern, And the ship to the port, And the course of the journey to the city, And life to (its) consummation.

**[85:11]** And again prepare your souls, so that when ye sail and ascend from the ship ye may have rest and not be condemned when ye depart.

**[85:12]** For lo! when the Most High will bring to pass all these things, There shall not there be again [a place of repentance, nor] a limit to the times, Nor a duration for the hours, Nor a change of ways, Nor place for prayer, Nor sending of petitions, Nor receiving of knowledge, Nor giving of love, Nor place of repentance for the soul, Nor supplication for offences, Nor intercession of the fathers, Nor prayer of the prophets, Nor help of the righteous.

**[85:13]** There there is the sentence of corruption, The way of fire, And the path which bringeth to Gehenna.

**[85:14]** On this account there is one law by one, One age and an end for all who are in it.

**[85:15]** Then He will preserve those whom He can forgive, And at the same time destroy those who are polluted with sins.]

**[86:1]** When therefore ye receive this my epistle, read it in your congregations with care.

**[86:2]** And meditate thereon, above all on the days of your fasts.

**[86:3]** And bear me in mind by means of this epistle, as I also bear you in mind in it, and always. Fare ye well.

**[87:1]** And it came to pass when I had ended all the words of this epistle, and had written it sedulously to its close, that I folded it, and sealed it carefully, and bound it to the neck of the eagle, and dismissed and sent it.

