# 2 Esdras



**[1:1]** The second book of the prophet Esdras, the son of Saraias, the son of Azarias, the son of Helchias, the son of Sadamias, the sou of Sadoc, the son of Achitob,

**[1:2]** The son of Achias, the son of Phinees, the son of Heli, the son of Amarias, the son of Aziei, the son of Marimoth, the son of And he spake unto the of Borith, the son of Abisei, the son of Phinees, the son of Eleazar,

**[1:3]** The son of Aaron, of the tribe of Levi; which was captive in the land of the Medes, in the reign of Artexerxes king of the Persians.

**[1:4]** And the word of the Lord came unto me, saying,

**[1:5]** Go thy way, and shew my people their sinful deeds, and their children their wickedness which they have done against me; that they may tell their children’s children:

**[1:6]** Because the sins of their fathers are increased in them: for they have forgotten me, and have offered unto strange gods.

**[1:7]** Am not I even he that brought them out of the land of Egypt, from the house of bondage? but they have provoked me unto wrath, and despised my counsels.

**[1:8]** Pull thou off then the hair of thy head, and cast all evil upon them, for they have not been obedient unto my law, but it is a rebellious people.

**[1:9]** How long shall I forbear them, into whom I have done so much good?

**[1:10]** Many kings have I destroyed for their sakes; Pharaoh with his servants and all his power have I smitten down.

**[1:11]** All the nations have I destroyed before them, and in the east I have scattered the people of two provinces, even of Tyrus and Sidon, and have slain all their enemies.

**[1:12]** Speak thou therefore unto them, saying, Thus saith the Lord,

**[1:13]** I led you through the sea and in the beginning gave you a large and safe passage; I gave you Moses for a leader, and Aaron for a priest.

**[1:14]** I gave you light in a pillar of fire, and great wonders have I done among you; yet have ye forgotten me, saith the Lord.

**[1:15]** Thus saith the Almighty Lord, The quails were as a token to you; I gave you tents for your safeguard: nevertheless ye murmured there,

**[1:16]** And triumphed not in my name for the destruction of your enemies, but ever to this day do ye yet murmur.

**[1:17]** Where are the benefits that I have done for you? when ye were hungry and thirsty in the wilderness, did ye not cry unto me,

**[1:18]** Saying, Why hast thou brought us into this wilderness to kill us? it had been better for us to have served the Egyptians, than to die in this wilderness.

**[1:19]** Then had I pity upon your mournings, and gave you manna to eat; so ye did eat angels’ bread.

**[1:20]** When ye were thirsty, did I not cleave the rock, and waters flowed out to your fill? for the heat I covered you with the leaves of the trees.

**[1:21]** I divided among you a fruitful land, I cast out the Canaanites, the Pherezites, and the Philistines, before you: what shall I yet do more for you? saith the Lord.

**[1:22]** Thus saith the Almighty Lord, When ye were in the wilderness, in the river of the Amorites, being athirst, and blaspheming my name,

**[1:23]** I gave you not fire for your blasphemies, but cast a tree in the water, and made the river sweet.

**[1:24]** What shall I do unto thee, O Jacob? thou, Juda, wouldest not obey me: I will turn me to other nations, and unto those will I give my name, that they may keep my statutes.

**[1:25]** Seeing ye have forsaken me, I will forsake you also; when ye desire me to be gracious unto you, I shall have no mercy upon you.

**[1:26]** Whensoever ye shall call upon me, I will not hear you: for ye have defiled your hands with blood, and your feet are swift to commit manslaughter.

**[1:27]** Ye have not as it were forsaken me, but your own selves, saith the Lord.

**[1:28]** Thus saith the Almighty Lord, Have I not prayed you as a father his sons, as a mother her daughters, and a nurse her young babes,

**[1:29]** That ye would be my people, and I should be your God; that ye would be my children, and I should be your father?

**[1:30]** I gathered you together, as a hen gathereth her chickens under her wings: but now, what shall I do unto you? I will cast you out from my face.

**[1:31]** When ye offer unto me, I will turn my face from you: for your solemn feastdays, your new moons, and your circumcisions, have I forsaken.

**[1:32]** I sent unto you my servants the prophets, whom ye have taken and slain, and torn their bodies in pieces, whose blood I will require of your hands, saith the Lord.

**[1:33]** Thus saith the Almighty Lord, Your house is desolate, I will cast you out as the wind doth stubble.

**[1:34]** And your children shall not be fruitful; for they have despised my commandment, and done the thing that is an evil before me.

**[1:35]** Your houses will I give to a people that shall come; which not having heard of me yet shall believe me; to whom I have shewed no signs, yet they shall do that I have commanded them.

**[1:36]** They have seen no prophets, yet they shall call their sins to remembrance, and acknowledge them.

**[1:37]** I take to witness the grace of the people to come, whose little ones rejoice in gladness: and though they have not seen me with bodily eyes, yet in spirit they believe the thing that I say.

**[1:38]** And now, brother, behold what glory; and see the people that come from the east:

**[1:39]** Unto whom I will give for leaders, Abraham, Isaac, and Jacob, Oseas, Amos, and Micheas, Joel, Abdias, and Jonas,

**[1:40]** Nahum, and Abacuc, Sophonias, Aggeus, Zachary, and Malachy, which is called also an angel of the Lord.

**[2:1]** Thus saith the Lord, I brought this people out of bondage, and I gave them my commandments by menservants the prophets; whom they would not hear, but despised my counsels.

**[2:2]** The mother that bare them saith unto them, Go your way, ye children; for I am a widow and forsaken.

**[2:3]** I brought you up with gladness; but with sorrow and heaviness have I lost you: for ye have sinned before the Lord your God, and done that thing that is evil before him.

**[2:4]** But what shall I now do unto you? I am a widow and forsaken: go your way, O my children, and ask mercy of the Lord.

**[2:5]** As for me, O father, I call upon thee for a witness over the mother of these children, which would not keep my covenant,

**[2:6]** That thou bring them to confusion, and their mother to a spoil, that there may be no offspring of them.

**[2:7]** Let them be scattered abroad among the heathen, let their names be put out of the earth: for they have despised my covenant.

**[2:8]** Woe be unto thee, Assur, thou that hidest the unrighteous in thee! O thou wicked people, remember what I did unto Sodom and Gomorrha;

**[2:9]** Whose land lieth in clods of pitch and heaps of ashes: even so also will I do unto them that hear me not, saith the Almighty Lord.

**[2:10]** Thus saith the Lord unto Esdras, Tell my people that I will give them the kingdom of Jerusalem, which I would have given unto Israel.

**[2:11]** Their glory also will I take unto me, and give these the everlasting tabernacles, which I had prepared for them.

**[2:12]** They shall have the tree of life for an ointment of sweet savour; they shall neither labour, nor be weary.

**[2:13]** Go, and ye shall receive: pray for few days unto you, that they may be shortened: the kingdom is already prepared for you: watch.

**[2:14]** Take heaven and earth to witness; for I have broken the evil in pieces, and created the good: for I live, saith the Lord.

**[2:15]** Mother, embrace thy children, and bring them up with gladness, make their feet as fast as a pillar: for I have chosen thee, saith the Lord.

**[2:16]** And those that be dead will I raise up again from their places, and bring them out of the graves: for I have known my name in Israel.

**[2:17]** Fear not, thou mother of the children: for I have chosen thee, saith the Lord.

**[2:18]** For thy help will I send my servants Esau and Jeremy, after whose counsel I have sanctified and prepared for thee twelve trees laden with divers fruits,

**[2:19]** And as many fountains flowing with milk and honey, and seven mighty mountains, whereupon there grow roses and lilies, whereby I will fill thy children with joy.

**[2:20]** Do right to the widow, judge for the fatherless, give to the poor, defend the orphan, clothe the naked,

**[2:21]** Heal the broken and the weak, laugh not a lame man to scorn, defend the maimed, and let the blind man come into the sight of my clearness.

**[2:22]** Keep the old and young within thy walls.

**[2:23]** Wheresoever thou findest the dead, take them and bury them, and I will give thee the first place in my resurrection.

**[2:24]** Abide still, O my people, and take thy rest, for thy quietness still come.

**[2:25]** Nourish thy children, O thou good nurse; stablish their feet.

**[2:26]** As for the servants whom I have given thee, there shall not one of them perish; for I will require them from among thy number.

**[2:27]** Be not weary: for when the day of trouble and heaviness cometh, others shall weep and be sorrowful, but thou shalt be merry and have abundance.

**[2:28]** The heathen shall envy thee, but they shall be able to do nothing against thee, saith the Lord.

**[2:29]** My hands shall cover thee, so that thy children shall not see hell.

**[2:30]** Be joyful, O thou mother, with thy children; for I will deliver thee, saith the Lord.

**[2:31]** Remember thy children that sleep, for I shall bring them out of the sides of the earth, and shew mercy unto them: for I am merciful, saith the Lord Almighty.

**[2:32]** Embrace thy children until I come and shew mercy unto them: for my wells run over, and my grace shall not fail.

**[2:33]** I Esdras received a charge of the Lord upon the mount Oreb, that I should go unto Israel; but when I came unto them, they set me at nought, and despised the commandment of the Lord.

**[2:34]** And therefore I say unto you, O ye heathen, that hear and understand, look for your Shepherd, he shall give you everlasting rest; for he is nigh at hand, that shall come in the end of the world.

**[2:35]** Be ready to the reward of the kingdom, for the everlasting light shall shine upon you for evermore.

**[2:36]** Flee the shadow of this world, receive the joyfulness of your glory: I testify my Saviour openly.

**[2:37]** O receive the gift that is given you, and be glad, giving thanks unto him that hath led you to the heavenly kingdom.

**[2:38]** Arise up and stand, behold the number of those that be sealed in the feast of the Lord;

**[2:39]** Which are departed from the shadow of the world, and have received glorious garments of the Lord.

**[2:40]** Take thy number, O Sion, and shut up those of thine that are clothed in white, which have fulfilled the law of the Lord.

**[2:41]** The number of thy children, whom thou longedst for, is fulfilled: beseech the power of the Lord, that thy people, which have been called from the beginning, may be hallowed.

**[2:42]** I Esdras saw upon the mount Sion a great people, whom I could not number, and they all praised the Lord with songs.

**[2:43]** And in the midst of them there was a young man of a high stature, taller than all the rest, and upon every one of their heads he set crowns, and was more exalted; which I marvelled at greatly.

**[2:44]** So I asked the angel, and said, Sir, what are these?

**[2:45]** He answered and said unto me, These be they that have put off the mortal clothing, and put on the immortal, and have confessed the name of God: now are they crowned, and receive palms.

**[2:46]** Then said I unto the angel, What young person is it that crowneth them, and giveth them palms in their hands?

**[2:47]** So he answered and said unto me, It is the Son of God, whom they have confessed in the world. Then began I greatly to commend them that stood so stiffly for the name of the Lord.

**[2:48]** Then the angel said unto me, Go thy way, and tell my people what manner of things, and how great wonders of the Lord thy God, thou hast seen.

**[3:1]** In the thirtieth year after the ruin of the city I was in Babylon, and lay troubled upon my bed, and my thoughts came up over my heart:

**[3:2]** For I saw the desolation of Sion, and the wealth of them that dwelt at Babylon.

**[3:3]** And my spirit was sore moved, so that I began to speak words full of fear to the most High, and said,

**[3:4]** O Lord, who bearest rule, thou spakest at the beginning, when thou didst plant the earth, and that thyself alone, and commandedst the people,

**[3:5]** And gavest a body unto Adam without soul, which was the workmanship of thine hands, and didst breathe into him the breath of life, and he was made living before thee.

**[3:6]** And thou leadest him into paradise, which thy right hand had planted, before ever the earth came forward.

**[3:7]** And unto him thou gavest commandment to love thy way: which he transgressed, and immediately thou appointedst death in him and in his generations, of whom came nations, tribes, people, and kindreds, out of number.

**[3:8]** And every people walked after their own will, and did wonderful things before thee, and despised thy commandments.

**[3:9]** And again in process of time thou broughtest the flood upon those that dwelt in the world, and destroyedst them.

**[3:10]** And it came to pass in every of them, that as death was to Adam, so was the flood to these.

**[3:11]** Nevertheless one of them thou leftest, namely, Noah with his household, of whom came all righteous men.

**[3:12]** And it happened, that when they that dwelt upon the earth began to multiply, and had gotten them many children, and were a great people, they began again to be more ungodly than the first.

**[3:13]** Now when they lived so wickedly before thee, thou didst choose thee a man from among them, whose name was Abraham.

**[3:14]** Him thou lovedst, and unto him only thou shewedst thy will:

**[3:15]** And madest an everlasting covenant with him, promising him that thou wouldest never forsake his seed.

**[3:16]** And unto him thou gavest Isaac, and unto Isaac also thou gavest Jacob and Esau. As for Jacob, thou didst choose him to thee, and put by Esau: and so Jacob became a great multitude.

**[3:17]** And it came to pass, that when thou leadest his seed out of Egypt, thou broughtest them up to the mount Sinai.

**[3:18]** And bowing the heavens, thou didst set fast the earth, movedst the whole world, and madest the depths to tremble, and troubledst the men of that age.

**[3:19]** And thy glory went through four gates, of fire, and of earthquake, and of wind, and of cold; that thou mightest give the law unto the seed of Jacob, and diligence unto the generation of Israel.

**[3:20]** And yet tookest thou not away from them a wicked heart, that thy law might bring forth fruit in them.

**[3:21]** For the first Adam bearing a wicked heart transgressed, and was overcome; and so be all they that are born of him.

**[3:22]** Thus infirmity was made permanent; and the law (also) in the heart of the people with the malignity of the root; so that the good departed away, and the evil abode still.

**[3:23]** So the times passed away, and the years were brought to an end: then didst thou raise thee up a servant, called David:

**[3:24]** Whom thou commandedst to build a city unto thy name, and to offer incense and oblations unto thee therein.

**[3:25]** When this was done many years, then they that inhabited the city forsook thee,

**[3:26]** And in all things did even as Adam and all his generations had done: for they also had a wicked heart:

**[3:27]** And so thou gavest thy city over into the hands of thine enemies.

**[3:28]** Are their deeds then any better that inhabit Babylon, that they should therefore have the dominion over Sion?

**[3:29]** For when I came thither, and had seen impieties without number, then my soul saw many evildoers in this thirtieth year, so that my heart failed me.

**[3:30]** For I have seen how thou sufferest them sinning, and hast spared wicked doers: and hast destroyed thy people, and hast preserved thine enemies, and hast not signified it.

**[3:31]** I do not remember how this way may be left: Are they then of Babylon better than they of Sion?

**[3:32]** Or is there any other people that knoweth thee beside Israel? or what generation hath so believed thy covenants as Jacob?

**[3:33]** And yet their reward appeareth not, and their labour hath no fruit: for I have gone here and there through the heathen, and I see that they flow in wealth, and think not upon thy commandments.

**[3:34]** Weigh thou therefore our wickedness now in the balance, and their’s also that dwell the world; and so shall thy name no where be found but in Israel.

**[3:35]** Or when was it that they which dwell upon the earth have not sinned in thy sight? or what people have so kept thy commandments?

**[3:36]** Thou shalt find that Israel by name hath kept thy precepts; but not the heathen.

**[4:1]** And the angel that was sent unto me, whose name was Uriel, gave me an answer,

**[4:2]** And said, Thy heart hath gone to far in this world, and thinkest thou to comprehend the way of the most High?

**[4:3]** Then said I, Yea, my lord. And he answered me, and said, I am sent to shew thee three ways, and to set forth three similitudes before thee:

**[4:4]** Whereof if thou canst declare me one, I will shew thee also the way that thou desirest to see, and I shall shew thee from whence the wicked heart cometh.

**[4:5]** And I said, Tell on, my lord. Then said he unto me, Go thy way, weigh me the weight of the fire, or measure me the blast of the wind, or call me again the day that is past.

**[4:6]** Then answered I and said, What man is able to do that, that thou shouldest ask such things of me?

**[4:7]** And he said unto me, If I should ask thee how great dwellings are in the midst of the sea, or how many springs are in the beginning of the deep, or how many springs are above the firmament, or which are the outgoings of paradise:

**[4:8]** Peradventure thou wouldest say unto me, I never went down into the deep, nor as yet into hell, neither did I ever climb up into heaven.

**[4:9]** Nevertheless now have I asked thee but only of the fire and wind, and of the day wherethrough thou hast passed, and of things from which thou canst not be separated, and yet canst thou give me no answer of them.

**[4:10]** He said moreover unto me, Thine own things, and such as are grown up with thee, canst thou not know;

**[4:11]** How should thy vessel then be able to comprehend the way of the Highest, and, the world being now outwardly corrupted to understand the corruption that is evident in my sight?

**[4:12]** Then said I unto him, It were better that we were not at all, than that we should live still in wickedness, and to suffer, and not to know wherefore.

**[4:13]** He answered me, and said, I went into a forest into a plain, and the trees took counsel,

**[4:14]** And said, Come, let us go and make war against the sea that it may depart away before us, and that we may make us more woods.

**[4:15]** The floods of the sea also in like manner took counsel, and said, Come, let us go up and subdue the woods of the plain, that there also we may make us another country.

**[4:16]** The thought of the wood was in vain, for the fire came and consumed it.

**[4:17]** The thought of the floods of the sea came likewise to nought, for the sand stood up and stopped them.

**[4:18]** If thou wert judge now betwixt these two, whom wouldest thou begin to justify? or whom wouldest thou condemn?

**[4:19]** I answered and said, Verily it is a foolish thought that they both have devised, for the ground is given unto the wood, and the sea also hath his place to bear his floods.

**[4:20]** Then answered he me, and said, Thou hast given a right judgment, but why judgest thou not thyself also?

**[4:21]** For like as the ground is given unto the wood, and the sea to his floods: even so they that dwell upon the earth may understand nothing but that which is upon the earth: and he that dwelleth above the heavens may only understand the things that are above the height of the heavens.

**[4:22]** Then answered I and said, I beseech thee, O Lord, let me have understanding:

**[4:23]** For it was not my mind to be curious of the high things, but of such as pass by us daily, namely, wherefore Israel is given up as a reproach to the heathen, and for what cause the people whom thou hast loved is given over unto ungodly nations, and why the law of our forefathers is brought to nought, and the written covenants come to none effect,

**[4:24]** And we pass away out of the world as grasshoppers, and our life is astonishment and fear, and we are not worthy to obtain mercy.

**[4:25]** What will he then do unto his name whereby we are called? of these things have I asked.

**[4:26]** Then answered he me, and said, The more thou searchest, the more thou shalt marvel; for the world hasteth fast to pass away,

**[4:27]** And cannot comprehend the things that are promised to the righteous in time to come: for this world is full of unrighteousness and infirmities.

**[4:28]** But as concerning the things whereof thou askest me, I will tell thee; for the evil is sown, but the destruction thereof is not yet come.

**[4:29]** If therefore that which is sown be not turned upside down, and if the place where the evil is sown pass not away, then cannot it come that is sown with good.

**[4:30]** For the grain of evil seed hath been sown in the heart of Adam from the beginning, and how much ungodliness hath it brought up unto this time? and how much shall it yet bring forth until the time of threshing come?

**[4:31]** Ponder now by thyself, how great fruit of wickedness the grain of evil seed hath brought forth.

**[4:32]** And when the ears shall be cut down, which are without number, how great a floor shall they fill?

**[4:33]** Then I answered and said, How, and when shall these things come to pass? wherefore are our years few and evil?

**[4:34]** And he answered me, saying, Do not thou hasten above the most Highest: for thy haste is in vain to be above him, for thou hast much exceeded.

**[4:35]** Did not the souls also of the righteous ask question of these things in their chambers, saying, How long shall I hope on this fashion? when cometh the fruit of the floor of our reward?

**[4:36]** And unto these things Uriel the archangel gave them answer, and said, Even when the number of seeds is filled in you: for he hath weighed the world in the balance.

**[4:37]** By measure hath he measured the times; and by number hath he numbered the times; and he doth not move nor stir them, until the said measure be fulfilled.

**[4:38]** Then answered I and said, O Lord that bearest rule, even we all are full of impiety.

**[4:39]** And for our sakes peradventure it is that the floors of the righteous are not filled, because of the sins of them that dwell upon the earth.

**[4:40]** So he answered me, and said, Go thy way to a woman with child, and ask of her when she hath fulfilled her nine months, if her womb may keep the birth any longer within her.

**[4:41]** Then said I, No, Lord, that can she not. And he said unto me, In the grave the chambers of souls are like the womb of a woman:

**[4:42]** For like as a woman that travaileth maketh haste to escape the necessity of the travail: even so do these places haste to deliver those things that are committed unto them.

**[4:43]** From the beginning, look, what thou desirest to see, it shall be shewed thee.

**[4:44]** Then answered I and said, If I have found favour in thy sight, and if it be possible, and if I be meet therefore,

**[4:45]** Shew me then whether there be more to come than is past, or more past than is to come.

**[4:46]** What is past I know, but what is for to come I know not.

**[4:47]** And he said unto me, Stand up upon the right side, and I shall expound the similitude unto thee.

**[4:48]** So I stood, and saw, and, behold, an hot burning oven passed by before me: and it happened that when the flame was gone by I looked, and, behold, the smoke remained still.

**[4:49]** After this there passed by before me a watery cloud, and sent down much rain with a storm; and when the stormy rain was past, the drops remained still.

**[4:50]** Then said he unto me, Consider with thyself; as the rain is more than the drops, and as the fire is greater than the smoke; but the drops and the smoke remain behind: so the quantity which is past did more exceed.

**[4:51]** Then I prayed, and said, May I live, thinkest thou, until that time? or what shall happen in those days?

**[4:52]** He answered me, and said, As for the tokens whereof thou askest me, I may tell thee of them in part: but as touching thy life, I am not sent to shew thee; for I do not know it.

**[5:1]** Nevertheless as coming the tokens, behold, the days shall come, that they which dwell upon earth shall be taken in a great number, and the way of truth shall be hidden, and the land shall be barren of faith.

**[5:2]** But iniquity shall be increased above that which now thou seest, or that thou hast heard long ago.

**[5:3]** And the land, that thou seest now to have root, shalt thou see wasted suddenly.

**[5:4]** But if the most High grant thee to live, thou shalt see after the third trumpet that the sun shall suddenly shine again in the night, and the moon thrice in the day:

**[5:5]** And blood shall drop out of wood, and the stone shall give his voice, and the people shall be troubled:

**[5:6]** And even he shall rule, whom they look not for that dwell upon the earth, and the fowls shall take their flight away together:

**[5:7]** And the Sodomitish sea shall cast out fish, and make a noise in the night, which many have not known: but they shall all hear the voice thereof.

**[5:8]** There shall be a confusion also in many places, and the fire shall be oft sent out again, and the wild beasts shall change their places, and menstruous women shall bring forth monsters:

**[5:9]** And salt waters shall be found in the sweet, and all friends shall destroy one another; then shall wit hide itself, and understanding withdraw itself into his secret chamber,

**[5:10]** And shall be sought of many, and yet not be found: then shall unrighteousness and incontinency be multiplied upon earth.

**[5:11]** One land also shall ask another, and say, Is righteousness that maketh a man righteous gone through thee? And it shall say, No.

**[5:12]** At the same time shall men hope, but nothing obtain: they shall labour, but their ways shall not prosper.

**[5:13]** To shew thee such tokens I have leave; and if thou wilt pray again, and weep as now, and fast even days, thou shalt hear yet greater things.

**[5:14]** Then I awaked, and an extreme fearfulness went through all my body, and my mind was troubled, so that it fainted.

**[5:15]** So the angel that was come to talk with me held me, comforted me, and set me up upon my feet.

**[5:16]** And in the second night it came to pass, that Salathiel the captain of the people came unto me, saying, Where hast thou been? and why is thy countenance so heavy?

**[5:17]** Knowest thou not that Israel is committed unto thee in the land of their captivity?

**[5:18]** Up then, and eat bread, and forsake us not, as the shepherd that leaveth his flock in the hands of cruel wolves.

**[5:19]** Then said I unto him, Go thy ways from me, and come not nigh me. And he heard what I said, and went from me.

**[5:20]** And so I fasted seven days, mourning and weeping, like as Uriel the angel commanded me.

**[5:21]** And after seven days so it was, that the thoughts of my heart were very grievous unto me again,

**[5:22]** And my soul recovered the spirit of understanding, and I began to talk with the most High again,

**[5:23]** And said, O Lord that bearest rule, of every wood of the earth, and of all the trees thereof, thou hast chosen thee one only vine:

**[5:24]** And of all lands of the whole world thou hast chosen thee one pit: and of all the flowers thereof one lily:

**[5:25]** And of all the depths of the sea thou hast filled thee one river: and of all builded cities thou hast hallowed Sion unto thyself:

**[5:26]** And of all the fowls that are created thou hast named thee one dove: and of all the cattle that are made thou hast provided thee one sheep:

**[5:27]** And among all the multitudes of people thou hast gotten thee one people: and unto this people, whom thou lovedst, thou gavest a law that is approved of all.

**[5:28]** And now, O Lord, why hast thou given this one people over unto many? and upon the one root hast thou prepared others, and why hast thou scattered thy only one people among many?

**[5:29]** And they which did gainsay thy promises, and believed not thy covenants, have trodden them down.

**[5:30]** If thou didst so much hate thy people, yet shouldest thou punish them with thine own hands.

**[5:31]** Now when I had spoken these words, the angel that came to me the night afore was sent unto me,

**[5:32]** And said unto me, Hear me, and I will instruct thee; hearken to the thing that I say, and I shall tell thee more.

**[5:33]** And I said, Speak on, my Lord. Then said he unto me, Thou art sore troubled in mind for Israel’s sake: lovest thou that people better than he that made them?

**[5:34]** And I said, No, Lord: but of very grief have I spoken: for my reins pain me every hour, while I labour to comprehend the way of the most High, and to seek out part of his judgment.

**[5:35]** And he said unto me, Thou canst not. And I said, Wherefore, Lord? whereunto was I born then? or why was not my mother’s womb then my grave, that I might not have seen the travail of Jacob, and the wearisome toil of the stock of Israel?

**[5:36]** And he said unto me, Number me the things that are not yet come, gather me together the dross that are scattered abroad, make me the flowers green again that are withered,

**[5:37]** Open me the places that are closed, and bring me forth the winds that in them are shut up, shew me the image of a voice: and then I will declare to thee the thing that thou labourest to know.

**[5:38]** And I said, O Lord that bearest rule, who may know these things, but he that hath not his dwelling with men?

**[5:39]** As for me, I am unwise: how may I then speak of these things whereof thou askest me?

**[5:40]** Then said he unto me, Like as thou canst do none of these things that I have spoken of, even so canst thou not find out my judgment, or in the end the love that I have promised unto my people.

**[5:41]** And I said, Behold, O Lord, yet art thou nigh unto them that be reserved till the end: and what shall they do that have been before me, or we that be now, or they that shall come after us?

**[5:42]** And he said unto me, I will liken my judgment unto a ring: like as there is no slackness of the last, even so there is no swiftness of the first.

**[5:43]** So I answered and said, Couldest thou not make those that have been made, and be now, and that are for to come, at once; that thou mightest shew thy judgment the sooner?

**[5:44]** Then answered he me, and said, The creature may not haste above the maker; neither may the world hold them at once that shall be created therein.

**[5:45]** And I said, As thou hast said unto thy servant, that thou, which givest life to all, hast given life at once to the creature that thou hast created, and the creature bare it: even so it might now also bear them that now be present at once.

**[5:46]** And he said unto me, Ask the womb of a woman, and say unto her, If thou bringest forth children, why dost thou it not together, but one after another? pray her therefore to bring forth ten children at once.

**[5:47]** And I said, She cannot: but must do it by distance of time.

**[5:48]** Then said he unto me, Even so have I given the womb of the earth to those that be sown in it in their times.

**[5:49]** For like as a young child may not bring forth the things that belong to the aged, even so have I disposed the world which I created.

**[5:50]** And I asked, and said, Seeing thou hast now given me the way, I will proceed to speak before thee: for our mother, of whom thou hast told me that she is young, draweth now nigh unto age.

**[5:51]** He answered me, and said, Ask a woman that beareth children, and she shall tell thee.

**[5:52]** Say unto her, Wherefore are unto they whom thou hast now brought forth like those that were before, but less of stature?

**[5:53]** And she shall answer thee, They that be born in the the strength of youth are of one fashion, and they that are born in the time of age, when the womb faileth, are otherwise.

**[5:54]** Consider thou therefore also, how that ye are less of stature than those that were before you.

**[5:55]** And so are they that come after you less than ye, as the creatures which now begin to be old, and have passed over the strength of youth.

**[5:56]** Then said I, Lord, I beseech thee, if I have found favour in thy sight, shew thy servant by whom thou visitest thy creature.

**[6:1]** And he said unto me, In the beginning, when the earth was made, before the borders of the world stood, or ever the winds blew,

**[6:2]** Before it thundered and lightened, or ever the foundations of paradise were laid,

**[6:3]** Before the fair flowers were seen, or ever the moveable powers were established, before the innumerable multitude of angels were gathered together,

**[6:4]** Or ever the heights of the air were lifted up, before the measures of the firmament were named, or ever the chimneys in Sion were hot,

**[6:5]** And ere the present years were sought out, and or ever the inventions of them that now sin were turned, before they were sealed that have gathered faith for a treasure:

**[6:6]** Then did I consider these things, and they all were made through me alone, and through none other: by me also they shall be ended, and by none other.

**[6:7]** Then answered I and said, What shall be the parting asunder of the times? or when shall be the end of the first, and the beginning of it that followeth?

**[6:8]** And he said unto me, From Abraham unto Isaac, when Jacob and Esau were born of him, Jacob’s hand held first the heel of Esau.

**[6:9]** For Esau is the end of the world, and Jacob is the beginning of it that followeth.

**[6:10]** The hand of man is betwixt the heel and the hand: other question, Esdras, ask thou not.

**[6:11]** I answered then and said, O Lord that bearest rule, if I have found favour in thy sight,

**[6:12]** I beseech thee, shew thy servant the end of thy tokens, whereof thou shewedst me part the last night.

**[6:13]** So he answered and said unto me, Stand up upon thy feet, and hear a mighty sounding voice.

**[6:14]** And it shall be as it were a great motion; but the place where thou standest shall not be moved.

**[6:15]** And therefore when it speaketh be not afraid: for the word is of the end, and the foundation of the earth is understood.

**[6:16]** And why? because the speech of these things trembleth and is moved: for it knoweth that the end of these things must be changed.

**[6:17]** And it happened, that when I had heard it I stood up upon my feet, and hearkened, and, behold, there was a voice that spake, and the sound of it was like the sound of many waters.

**[6:18]** And it said, Behold, the days come, that I will begin to draw nigh, and to visit them that dwell upon the earth,

**[6:19]** And will begin to make inquisition of them, what they be that have hurt unjustly with their unrighteousness, and when the affliction of Sion shall be fulfilled;

**[6:20]** And when the world, that shall begin to vanish away, shall be finished, then will I shew these tokens: the books shall be opened before the firmament, and they shall see all together:

**[6:21]** And the children of a year old shall speak with their voices, the women with child shall bring forth untimely children of three or four months old, and they shall live, and be raised up.

**[6:22]** And suddenly shall the sown places appear unsown, the full storehouses shall suddenly be found empty:

**[6:23]** And tha trumpet shall give a sound, which when every man heareth, they shall be suddenly afraid.

**[6:24]** At that time shall friends fight one against another like enemies, and the earth shall stand in fear with those that dwell therein, the springs of the fountains shall stand still, and in three hours they shall not run.

**[6:25]** Whosoever remaineth from all these that I have told thee shall escape, and see my salvation, and the end of your world.

**[6:26]** And the men that are received shall see it, who have not tasted death from their birth: and the heart of the inhabitants shall be changed, and turned into another meaning.

**[6:27]** For evil shall be put out, and deceit shall be quenched.

**[6:28]** As for faith, it shall flourish, corruption shall be overcome, and the truth, which hath been so long without fruit, shall be declared.

**[6:29]** And when he talked with me, behold, I looked by little and little upon him before whom I stood.

**[6:30]** And these words said he unto me; I am come to shew thee the time of the night to come.

**[6:31]** If thou wilt pray yet more, and fast seven days again, I shall tell thee greater things by day than I have heard.

**[6:32]** For thy voice is heard before the most High: for the Mighty hath seen thy righteous dealing, he hath seen also thy chastity, which thou hast had ever since thy youth.

**[6:33]** And therefore hath he sent me to shew thee all these things, and to say unto thee, Be of good comfort and fear not

**[6:34]** And hasten not with the times that are past, to think vain things, that thou mayest not hasten from the latter times.

**[6:35]** And it came to pass after this, that I wept again, and fasted seven days in like manner, that I might fulfil the three weeks which he told me.

**[6:36]** And in the eighth night was my heart vexed within me again, and I began to speak before the most High.

**[6:37]** For my spirit was greatly set on fire, and my soul was in distress.

**[6:38]** And I said, O Lord, thou spakest from the beginning of the creation, even the first day, and saidst thus; Let heaven and earth be made; and thy word was a perfect work.

**[6:39]** And then was the spirit, and darkness and silence were on every side; the sound of man’s voice was not yet formed.

**[6:40]** Then commandedst thou a fair light to come forth of thy treasures, that thy work might appear.

**[6:41]** Upon the second day thou madest the spirit of the firmament, and commandedst it to part asunder, and to make a division betwixt the waters, that the one part might go up, and the other remain beneath.

**[6:42]** Upon the third day thou didst command that the waters should be gathered in the seventh part of the earth: six pats hast thou dried up, and kept them, to the intent that of these some being planted of God and tilled might serve thee.

**[6:43]** For as soon as thy word went forth the work was made.

**[6:44]** For immediately there was great and innumerable fruit, and many and divers pleasures for the taste, and flowers of unchangeable colour, and odours of wonderful smell: and this was done the third day.

**[6:45]** Upon the fourth day thou commandedst that the sun should shine, and the moon give her light, and the stars should be in order:

**[6:46]** And gavest them a charge to do service unto man, that was to be made.

**[6:47]** Upon the fifth day thou saidst unto the seventh part, where the waters were gathered that it should bring forth living creatures, fowls and fishes: and so it came to pass.

**[6:48]** For the dumb water and without life brought forth living things at the commandment of God, that all people might praise thy wondrous works.

**[6:49]** Then didst thou ordain two living creatures, the one thou calledst Enoch, and the other Leviathan;

**[6:50]** And didst separate the one from the other: for the seventh part, namely, where the water was gathered together, might not hold them both.

**[6:51]** Unto Enoch thou gavest one part, which was dried up the third day, that he should dwell in the same part, wherein are a thousand hills:

**[6:52]** But unto Leviathan thou gavest the seventh part, namely, the moist; and hast kept him to be devoured of whom thou wilt, and when.

**[6:53]** Upon the sixth day thou gavest commandment unto the earth, that before thee it should bring forth beasts, cattle, and creeping things:

**[6:54]** And after these, Adam also, whom thou madest lord of all thy creatures: of him come we all, and the people also whom thou hast chosen.

**[6:55]** All this have I spoken before thee, O Lord, because thou madest the world for our sakes

**[6:56]** As for the other people, which also come of Adam, thou hast said that they are nothing, but be like unto spittle: and hast likened the abundance of them unto a drop that falleth from a vessel.

**[6:57]** And now, O Lord, behold, these heathen, which have ever been reputed as nothing, have begun to be lords over us, and to devour us.

**[6:58]** But we thy people, whom thou hast called thy firstborn, thy only begotten, and thy fervent lover, are given into their hands.

**[6:59]** If the world now be made for our sakes, why do we not possess an inheritance with the world? how long shall this endure?

**[7:1]** And when I had made an end of speaking these words, there was sent unto me the angel which had been sent unto me the nights afore:

**[7:2]** And he said unto me, Up, Esdras, and hear the words that I am come to tell thee.

**[7:3]** And I said, Speak on, my God. Then said he unto me, The sea is set in a wide place, that it might be deep and great.

**[7:4]** But put the case the entrance were narrow, and like a river;

**[7:5]** Who then could go into the sea to look upon it, and to rule it? if he went not through the narrow, how could he come into the broad?

**[7:6]** There is also another thing; A city is builded, and set upon a broad field, and is full of all good things:

**[7:7]** The entrance thereof is narrow, and is set in a dangerous place to fall, like as if there were a fire on the right hand, and on the left a deep water:

**[7:8]** And one only path between them both, even between the fire and the water, so small that there could but one man go there at once.

**[7:9]** If this city now were given unto a man for an inheritance, if he never shall pass the danger set before it, how shall he receive this inheritance?

**[7:10]** And I said, It is so, Lord. Then said he unto me, Even so also is Israel’s portion.

**[7:11]** Because for their sakes I made the world: and when Adam transgressed my statutes, then was decreed that now is done.

**[7:12]** Then were the entrances of this world made narrow, full of sorrow and travail: they are but few and evil, full of perils,: and very painful.

**[7:13]** For the entrances of the elder world were wide and sure, and brought immortal fruit.

**[7:14]** If then they that live labour not to enter these strait and vain things, they can never receive those that are laid up for them.

**[7:15]** Now therefore why disquietest thou thyself, seeing thou art but a corruptible man? and why art thou moved, whereas thou art but mortal?

**[7:16]** Why hast thou not considered in thy mind this thing that is to come, rather than that which is present?

**[7:17]** Then answered I and said, O Lord that bearest rule, thou hast ordained in thy law, that the righteous should inherit these things, but that the ungodly should perish.

**[7:18]** Nevertheless the righteous shall suffer strait things, and hope for wide: for they that have done wickedly have suffered the strait things, and yet shall not see the wide.

**[7:19]** And he said unto me. There is no judge above God, and none that hath understanding above the Highest.

**[7:20]** For there be many that perish in this life, because they despise the law of God that is set before them.

**[7:21]** For God hath given strait commandment to such as came, what they should do to live, even as they came, and what they should observe to avoid punishment.

**[7:22]** Nevertheless they were not obedient unto him; but spake against him, and imagined vain things;

**[7:23]** And deceived themselves by their wicked deeds; and said of the most High, that he is not; and knew not his ways:

**[7:24]** But his law have they despised, and denied his covenants; in his statutes have they not been faithful, and have not performed his works.

**[7:25]** And therefore, Esdras, for the empty are empty things, and for the full are the full things.

**[7:26]** Behold, the time shall come, that these tokens which I have told thee shall come to pass, and the bride shall appear, and she coming forth shall be seen, that now is withdrawn from the earth.

**[7:27]** And whosoever is delivered from the foresaid evils shall see my wonders.

**[7:28]** For my son Jesus shall be revealed with those that be with him, and they that remain shall rejoice within four hundred years.

**[7:29]** After these years shall my son Christ die, and all men that have life.

**[7:30]** And the world shall be turned into the old silence seven days, like as in the former judgments: so that no man shall remain.

**[7:31]** And after seven days the world, that yet awaketh not, shall be raised up, and that shall die that is corrupt

**[7:32]** And the earth shall restore those that are asleep in her, and so shall the dust those that dwell in silence, and the secret places shall deliver those souls that were committed unto them.

**[7:33]** And the most High shall appear upon the seat of judgment, and misery shall pass away, and the long suffering shall have an end:

**[7:34]** But judgment only shall remain, truth shall stand, and faith shall wax strong:

**[7:35]** And the work shall follow, and the reward shall be shewed, and the good deeds shall be of force, and wicked deeds shall bear no rule.

**[7:36]** Then said I, Abraham prayed first for the Sodomites, and Moses for the fathers that sinned in the wilderness:

**[7:37]** And Jesus after him for Israel in the time of Achan:

**[7:38]** And Samuel and David for the destruction: and Solomon for them that should come to the sanctuary:

**[7:39]** And Helias for those that received rain; and for the dead, that he might live:

**[7:40]** And Ezechias for the people in the time of Sennacherib: and many for many.

**[7:41]** Even so now, seeing corruption is grown up, and wickedness increased, and the righteous have prayed for the ungodly: wherefore shall it not be so now also?

**[7:42]** He answered me, and said, This present life is not the end where much glory doth abide; therefore have they prayed for the weak.

**[7:43]** But the day of doom shall be the end of this time, and the beginning of the immortality for to come, wherein corruption is past,

**[7:44]** Intemperance is at an end, infidelity is cut off, righteousness is grown, and truth is sprung up.

**[7:45]** Then shall no man be able to save him that is destroyed, nor to oppress him that hath gotten the victory.

**[7:46]** I answered then and said, This is my first and last saying, that it had been better not to have given the earth unto Adam: or else, when it was given him, to have restrained him from sinning.

**[7:47]** For what profit is it for men now in this present time to live in heaviness, and after death to look for punishment?

**[7:48]** O thou Adam, what hast thou done? for though it was thou that sinned, thou art not fallen alone, but we all that come of thee.

**[7:49]** For what profit is it unto us, if there be promised us an immortal time, whereas we have done the works that bring death?

**[7:50]** And that there is promised us an everlasting hope, whereas ourselves being most wicked are made vain?

**[7:51]** And that there are laid up for us dwellings of health and safety, whereas we have lived wickedly?

**[7:52]** And that the glory of the most High is kept to defend them which have led a wary life, whereas we have walked in the most wicked ways of all?

**[7:53]** And that there should be shewed a paradise, whose fruit endureth for ever, wherein is security and medicine, since we shall not enter into it?

**[7:54]** (For we have walked in unpleasant places.)

**[7:55]** And that the faces of them which have used abstinence shall shine above the stars, whereas our faces shall be blacker than darkness?

**[7:56]** For while we lived and committed iniquity, we considered not that we should begin to suffer for it after death.

**[7:57]** Then answered he me, and said, This is the condition of the battle, which man that is born upon the earth shall fight;

**[7:58]** That, if he be overcome, he shall suffer as thou hast said: but if he get the victory, he shall receive the thing that I say.

**[7:59]** For this is the life whereof Moses spake unto the people while he lived, saying, Choose thee life, that thou mayest live.

**[7:60]** Nevertheless they believed not him, nor yet the prophets after him, no nor me which have spoken unto them,

**[7:61]** That there should not be such heaviness in their destruction, as shall be joy over them that are persuaded to salvation.

**[7:62]** I answered then, and said, I know, Lord, that the most High is called merciful, in that he hath mercy upon them which are not yet come into the world,

**[7:63]** And upon those also that turn to his law;

**[7:64]** And that he is patient, and long suffereth those that have sinned, as his creatures;

**[7:65]** And that he is bountiful, for he is ready to give where it needeth;

**[7:66]** And that he is of great mercy, for he multiplieth more and more mercies to them that are present, and that are past, and also to them which are to come.

**[7:67]** For if he shall not multiply his mercies, the world would not continue with them that inherit therein.

**[7:68]** And he pardoneth; for if he did not so of his goodness, that they which have committed iniquities might be eased of them, the ten thousandth part of men should not remain living.

**[7:69]** And being judge, if he should not forgive them that are cured with his word, and put out the multitude of contentions,

**[7:70]** There should be very few left peradventure in an innumerable multitude.

**[8:1]** And he answered me, saying, The most High hath made this world for many, but the world to come for few.

**[8:2]** I will tell thee a similitude, Esdras; As when thou askest the earth, it shall say unto thee, that it giveth much mould whereof earthen vessels are made, but little dust that gold cometh of: even so is the course of this present world.

**[8:3]** There be many created, but few shall be saved.

**[8:4]** So answered I and said, Swallow then down, O my soul, understanding, and devour wisdom.

**[8:5]** For thou hast agreed to give ear, and art willing to prophesy: for thou hast no longer space than only to live.

**[8:6]** O Lord, if thou suffer not thy servant, that we may pray before thee, and thou give us seed unto our heart, and culture to our understanding, that there may come fruit of it; how shall each man live that is corrupt, who beareth the place of a man?

**[8:7]** For thou art alone, and we all one workmanship of thine hands, like as thou hast said.

**[8:8]** For when the body is fashioned now in the mother’s womb, and thou givest it members, thy creature is preserved in fire and water, and nine months doth thy workmanship endure thy creature which is created in her.

**[8:9]** But that which keepeth and is kept shall both be preserved: and when the time cometh, the womb preserved delivereth up the things that grew in it.

**[8:10]** For thou hast commanded out of the parts of the body, that is to say, out of the breasts, milk to be given, which is the fruit of the breasts,

**[8:11]** That the thing which is fashioned may be nourished for a time, till thou disposest it to thy mercy.

**[8:12]** Thou broughtest it up with thy righteousness, and nurturedst it in thy law, and reformedst it with thy judgment.

**[8:13]** And thou shalt mortify it as thy creature, and quicken it as thy work.

**[8:14]** If therefore thou shalt destroy him which with so great labour was fashioned, it is an easy thing to be ordained by thy commandment, that the thing which was made might be preserved.

**[8:15]** Now therefore, Lord, I will speak; touching man in general, thou knowest best; but touching thy people, for whose sake I am sorry;

**[8:16]** And for thine inheritance, for whose cause I mourn; and for Israel, for whom I am heavy; and for Jacob, for whose sake I am troubled;

**[8:17]** Therefore will I begin to pray before thee for myself and for them: for I see the falls of us that dwell in the land.

**[8:18]** But I have heard the swiftness of the judge which is to come.

**[8:19]** Therefore hear my voice, and understand my words, and I shall speak before thee. This is the beginning of the words of Esdras, before he was taken up: and I said,

**[8:20]** O Lord, thou that dwellest in everlastingness which beholdest from above things in the heaven and in the air;

**[8:21]** Whose throne is inestimable; whose glory may not be comprehended; before whom the hosts of angels stand with trembling,

**[8:22]** Whose service is conversant in wind and fire; whose word is true, and sayings constant; whose commandment is strong, and ordinance fearful;

**[8:23]** Whose look drieth up the depths, and indignation maketh the mountains to melt away; which the truth witnesseth:

**[8:24]** O hear the prayer of thy servant, and give ear to the petition of thy creature.

**[8:25]** For while I live I will speak, and so long as I have understanding I will answer.

**[8:26]** O look not upon the sins of thy people; but on them which serve thee in truth.

**[8:27]** Regard not the wicked inventions of the heathen, but the desire of those that keep thy testimonies in afflictions.

**[8:28]** Think not upon those that have walked feignedly before thee: but remember them, which according to thy will have known thy fear.

**[8:29]** Let it not be thy will to destroy them which have lived like beasts; but to look upon them that have clearly taught thy law.

**[8:30]** Take thou no indignation at them which are deemed worse than beasts; but love them that always put their trust in thy righteousness and glory.

**[8:31]** For we and our fathers do languish of such diseases: but because of us sinners thou shalt be called merciful.

**[8:32]** For if thou hast a desire to have mercy upon us, thou shalt be called merciful, to us namely, that have no works of righteousness.

**[8:33]** For the just, which have many good works laid up with thee, shall out of their own deeds receive reward.

**[8:34]** For what is man, that thou shouldest take displeasure at him? or what is a corruptible generation, that thou shouldest be so bitter toward it?

**[8:35]** For in truth them is no man among them that be born, but he hath dealt wickedly; and among the faithful there is none which hath not done amiss.

**[8:36]** For in this, O Lord, thy righteousness and thy goodness shall be declared, if thou be merciful unto them which have not the confidence of good works.

**[8:37]** Then answered he me, and said, Some things hast thou spoken aright, and according unto thy words it shall be.

**[8:38]** For indeed I will not think on the disposition of them which have sinned before death, before judgment, before destruction:

**[8:39]** But I will rejoice over the disposition of the righteous, and I will remember also their pilgrimage, and the salvation, and the reward, that they shall have.

**[8:40]** Like as I have spoken now, so shall it come to pass.

**[8:41]** For as the husbandman soweth much seed upon the ground, and planteth many trees, and yet the thing that is sown good in his season cometh not up, neither doth all that is planted take root: even so is it of them that are sown in the world; they shall not all be saved.

**[8:42]** I answered then and said, If I have found grace, let me speak.

**[8:43]** Like as the husbandman’s seed perisheth, if it come not up, and receive not thy rain in due season; or if there come too much rain, and corrupt it:

**[8:44]** Even so perisheth man also, which is formed with thy hands, and is called thine own image, because thou art like unto him, for whose sake thou hast made all things, and likened him unto the husbandman’s seed.

**[8:45]** Be not wroth with us but spare thy people, and have mercy upon thine own inheritance: for thou art merciful unto thy creature.

**[8:46]** Then answered he me, and said, Things present are for the present, and things to cometh for such as be to come.

**[8:47]** For thou comest far short that thou shouldest be able to love my creature more than I: but I have ofttimes drawn nigh unto thee, and unto it, but never to the unrighteous.

**[8:48]** In this also thou art marvellous before the most High:

**[8:49]** In that thou hast humbled thyself, as it becometh thee, and hast not judged thyself worthy to be much glorified among the righteous.

**[8:50]** For many great miseries shall be done to them that in the latter time shall dwell in the world, because they have walked in great pride.

**[8:51]** But understand thou for thyself, and seek out the glory for such as be like thee.

**[8:52]** For unto you is paradise opened, the tree of life is planted, the time to come is prepared, plenteousness is made ready, a city is builded, and rest is allowed, yea, perfect goodness and wisdom.

**[8:53]** The root of evil is sealed up from you, weakness and the moth is hid from you, and corruption is fled into hell to be forgotten:

**[8:54]** Sorrows are passed, and in the end is shewed the treasure of immortality.

**[8:55]** And therefore ask thou no more questions concerning the multitude of them that perish.

**[8:56]** For when they had taken liberty, they despised the most High, thought scorn of his law, and forsook his ways.

**[8:57]** Moreover they have trodden down his righteous,

**[8:58]** And said in their heart, that there is no God; yea, and that knowing they must die.

**[8:59]** For as the things aforesaid shalt receive you, so thirst and pain are prepared for them: for it was not his will that men should come to nought:

**[8:60]** But they which be created have defiled the name of him that made them, and were unthankful unto him which prepared life for them.

**[8:61]** And therefore is my judgment now at hand.

**[8:62]** These things have I not shewed unto all men, but unto thee, and a few like thee. Then answered I and said,

**[8:63]** Behold, O Lord, now hast thou shewed me the multitude of the wonders, which thou wilt begin to do in the last times: but at what time, thou hast not shewed me.

**[9:1]** He answered me then, and said, Measure thou the time diligently in itself: and when thou seest part of the signs past, which I have told thee before,

**[9:2]** Then shalt thou understand, that it is the very same time, wherein the Highest will begin to visit the world which he made.

**[9:3]** Therefore when there shall be seen earthquakes and uproars of the people in the world:

**[9:4]** Then shalt thou well understand, that the most High spake of those things from the days that were before thee, even from the beginning.

**[9:5]** For like as all that is made in the world hath a beginning and an end, and the end is manifest:

**[9:6]** Even so the times also of the Highest have plain beginnings in wonder and powerful works, and endings in effects and signs.

**[9:7]** And every one that shall be saved, and shall be able to escape by his works, and by faith, whereby ye have believed,

**[9:8]** Shall be preserved from the said perils, and shall see my salvation in my land, and within my borders: for I have sanctified them for me from the beginning.

**[9:9]** Then shall they be in pitiful case, which now have abused my ways: and they that have cast them away despitefully shall dwell in torments.

**[9:10]** For such as in their life have received benefits, and have not known me;

**[9:11]** And they that have loathed my law, while they had yet liberty, and, when as yet place of repentance was open unto them, understood not, but despised it;

**[9:12]** The same must know it after death by pain.

**[9:13]** And therefore be thou not curious how the ungodly shall be punished, and when: but enquire how the righteous shall be saved, whose the world is, and for whom the world is created.

**[9:14]** Then answered I and said,

**[9:15]** I have said before, and now do speak, and will speak it also hereafter, that there be many more of them which perish, than of them which shall be saved:

**[9:16]** Like as a wave is greater than a drop.

**[9:17]** And he answered me, saying, Like as the field is, so is also the seed; as the flowers be, such are the colours also; such as the workman is, such also is the work; and as the husbandman ls himself, so is his husbandry also: for it was the time of the world.

**[9:18]** And now when I prepared the world, which was not yet made, even for them to dwell in that now live, no man spake against me.

**[9:19]** For then every one obeyed: but now the manners of them which are created in this world that is made are corrupted by a perpetual seed, and by a law which is unsearchable rid themselves.

**[9:20]** So I considered the world, and, behold, there was peril because of the devices that were come into it.

**[9:21]** And I saw, and spared it greatly, and have kept me a grape of the cluster, and a plant of a great people.

**[9:22]** Let the multitude perish then, which was born in vain; and let my grape be kept, and my plant; for with great labour have I made it perfect.

**[9:23]** Nevertheless, if thou wilt cease yet seven days more, (but thou shalt not fast in them,

**[9:24]** But go into a field of flowers, where no house is builded, and eat only the flowers of the field; taste no flesh, drink no wine, but eat flowers only;)

**[9:25]** And pray unto the Highest continually, then will I come and talk with thee.

**[9:26]** So I went my way into the field which is called Ardath, like as he commanded me; and there I sat among the flowers, and did eat of the herbs of the field, and the meat of the same satisfied me.

**[9:27]** After seven days I sat upon the grass, and my heart was vexed within me, like as before:

**[9:28]** And I opened my mouth, and began to talk before the most High, and said,

**[9:29]** O Lord, thou that shewest thyself unto us, thou wast shewed unto our fathers in the wilderness, in a place where no man treadeth, in a barren place, when they came out of Egypt.

**[9:30]** And thou spakest saying, Hear me, O Israel; and mark my words, thou seed of Jacob.

**[9:31]** For, behold, I sow my law in you, and it shall bring fruit in you, and ye shall be honoured in it for ever.

**[9:32]** But our fathers, which received the law, kept it not, and observed not thy ordinances: and though the fruit of thy law did not perish, neither could it, for it was thine;

**[9:33]** Yet they that received it perished, because they kept not the thing that was sown in them.

**[9:34]** And, lo, it ls a custom, when the ground hath received seed, or the sea a ship, or any vessel meat or drink, that, that being perished wherein it was sown or cast into,

**[9:35]** That thing also which was sown, or cast therein, or received, doth perish, and remaineth not with us: but with us it hath not happened so.

**[9:36]** For we that have received the law perish by sin, and our heart also which received it

**[9:37]** Notwithstanding the law perisheth not, but remaineth in his force.

**[9:38]** And when I spake these things in my heart, I looked back with mine eyes, and upon the right side I saw a woman, and, behold, she mourned and wept with a loud voice, and was much grieved in heart, and her clothes were rent, and she had ashes upon her head.

**[9:39]** Then let I my thoughts go that I was in, and turned me unto her,

**[9:40]** And said unto her, Wherefore weepest thou? why art thou so grieved in thy mind?

**[9:41]** And she said unto me, Sir, let me alone, that I may bewail myself, and add unto my sorrow, for I am sore vexed in my mind, and brought very low.

**[9:42]** And I said unto her, What aileth thee? tell me.

**[9:43]** She said unto me, I thy servant have been barren, and had no child, though I had an husband thirty years,

**[9:44]** And those thirty years I did nothing else day and night, and every hour, but make my, prayer to the Highest.

**[9:45]** After thirty years God heard me thine handmaid, looked upon my misery, considered my trouble, and gave me a son: and I was very glad of him, so was my husband also, and all my neighbours: and we gave great honour unto the Almighty.

**[9:46]** And I nourished him with great travail.

**[9:47]** So when he grew up, and came to the time that he should have a wife, I made a feast.

**[10:1]** And it so came to pass, that when my son was entered into his wedding chamber, he fell down, and died.

**[10:2]** Then we all overthrew the lights, and all my neighbours rose up to comfort me: so I took my rest unto the second day at night.

**[10:3]** And it came to pass, when they had all left off to comfort me, to the end I might be quiet; then rose I up by night and fled, and came hither into this field, as thou seest.

**[10:4]** And I do now purpose not to return into the city, but here to stay, and neither to eat nor drink, but continually to mourn and to fast until I die.

**[10:5]** Then left I the meditations wherein I was, and spake to her in anger, saying,

**[10:6]** Thou foolish woman above all other, seest thou not our mourning, and what happeneth unto us?

**[10:7]** How that Sion our mother is full of all heaviness, and much humbled, mourning very sore?

**[10:8]** And now, seeing we all mourn and are sad, for we are all in heaviness, art thou grieved for one son?

**[10:9]** For ask the earth, and she shall tell thee, that it is she which ought to mourn for the fall of so many that grow upon her.

**[10:10]** For out of her came all at the first, and out of her shall all others come, and, behold, they walk almost all into destruction, and a multitude of them is utterly rooted out.

**[10:11]** Who then should make more mourning than she, that hath lost so great a multitude; and not thou, which art sorry but for one?

**[10:12]** But if thou sayest unto me, My lamentation is not like the earth’s, because I have lost the fruit of my womb, which I brought forth with pains, and bare with sorrows;

**[10:13]** But the earth not so: for the multitude present in it according to the course of the earth is gone, as it came:

**[10:14]** Then say I unto thee, Like as thou hast brought forth with labour; even so the earth also hath given her fruit, namely, man, ever since the beginning unto him that made her.

**[10:15]** Now therefore keep thy sorrow to thyself, and bear with a good courage that which hath befallen thee.

**[10:16]** For if thou shalt acknowledge the determination of God to be just, thou shalt both receive thy son in time, and shalt be commended among women.

**[10:17]** Go thy way then into the city to thine husband.

**[10:18]** And she said unto me, That will I not do: I will not go into the city, but here will I die.

**[10:19]** So I proceeded to speak further unto her, and said,

**[10:20]** Do not so, but be counselled. by me: for how many are the adversities of Sion? be comforted in regard of the sorrow of Jerusalem.

**[10:21]** For thou seest that our sanctuary is laid waste, our altar broken down, our temple destroyed;

**[10:22]** Our psaltery is laid on the ground, our song is put to silence, our rejoicing is at an end, the light of our candlestick is put out, the ark of our covenant is spoiled, our holy things are defiled, and the name that is called upon us is almost profaned: our children are put to shame, our priests are burnt, our Levites are gone into captivity, our virgins are defiled, and our wives ravished; our righteous men carried away, our little ones destroyed, our young men are brought in bondage, and our strong men are become weak;

**[10:23]** And, which is the greatest of all, the seal of Sion hath now lost her honour; for she is delivered into the hands of them that hate us.

**[10:24]** And therefore shake off thy great heaviness, and put away the multitude of sorrows, that the Mighty may be merciful unto thee again, and the Highest shall give thee rest and ease from thy labour.

**[10:25]** And it came to pass while I was talking with her, behold, her face upon a sudden shined exceedingly, and her countenance glistered, so that I was afraid of her, and mused what it might be.

**[10:26]** And, behold, suddenly she made a great cry very fearful: so that the earth shook at the noise of the woman.

**[10:27]** And I looked, and, behold, the woman appeared unto me no more, but there was a city builded, and a large place shewed itself from the foundations: then was I afraid, and cried with a loud voice, and said,

**[10:28]** Where is Uriel the angel, who came unto me at the first? for he hath caused me to fall into many trances, and mine end is turned into corruption, and my prayer to rebuke.

**[10:29]** And as I was speaking these words behold, he came unto me, and looked upon me.

**[10:30]** And, lo, I lay as one that had been dead, and mine understanding was taken from me: and he took me by the right hand, and comforted me, and set me upon my feet, and said unto me,

**[10:31]** What aileth thee? and why art thou so disquieted? and why is thine understanding troubled, and the thoughts of thine heart?

**[10:32]** And I said, Because thou hast forsaken me, and yet I did according to thy words, and I went into the field, and, lo, I have seen, and yet see, that I am not able to express.

**[10:33]** And he said unto me, Stand up manfully, and I will advise thee.

**[10:34]** Then said I, Speak on, my lord, in me; only forsake me not, lest I die frustrate of my hope.

**[10:35]** For I have seen that I knew not, and hear that I do not know.

**[10:36]** Or is my sense deceived, or my soul in a dream?

**[10:37]** Now therefore I beseech thee that thou wilt shew thy servant of this vision.

**[10:38]** He answered me then, and said, Hear me, and I shall inform thee, and tell thee wherefore thou art afraid: for the Highest will reveal many secret things unto thee.

**[10:39]** He hath seen that thy way is right: for that thou sorrowest continually for thy people, and makest great lamentation for Sion.

**[10:40]** This therefore is the meaning of the vision which thou lately sawest:

**[10:41]** Thou sawest a woman mourning, and thou begannest to comfort her:

**[10:42]** But now seest thou the likeness of the woman no more, but there appeared unto thee a city builded.

**[10:43]** And whereas she told thee of the death of her son, this is the solution:

**[10:44]** This woman, whom thou sawest is Sion: and whereas she said unto thee, even she whom thou seest as a city builded,

**[10:45]** Whereas, I say, she said unto thee, that she hath been thirty years barren: those are the thirty years wherein there was no offering made in her.

**[10:46]** But after thirty years Solomon builded the city and offered offerings: and then bare the barren a son.

**[10:47]** And whereas she told thee that she nourished him with labour: that was the dwelling in Jerusalem.

**[10:48]** But whereas she said unto thee, That my son coming into his marriage chamber happened to have a fail, and died: this was the destruction that came to Jerusalem.

**[10:49]** And, behold, thou sawest her likeness, and because she mourned for her son, thou begannest to comfort her: and of these things which have chanced, these are to be opened unto thee.

**[10:50]** For now the most High seeth that thou art grieved unfeignedly, and sufferest from thy whole heart for her, so hath he shewed thee the brightness of her glory, and the comeliness of her beauty:

**[10:51]** And therefore I bade thee remain in the field where no house was builded:

**[10:52]** For I knew that the Highest would shew this unto thee.

**[10:53]** Therefore I commanded thee to go into the field, where no foundation of any building was.

**[10:54]** For in the place wherein the Highest beginneth to shew his city, there can no man’s building be able to stand.

**[10:55]** And therefore fear not, let not thine heart be affrighted, but go thy way in, and see the beauty and greatness of the building, as much as thine eyes be able to see:

**[10:56]** And then shalt thou hear as much as thine ears may comprehend.

**[10:57]** For thou art blessed above many other, and art called with the Highest; and so are but few.

**[10:58]** But to morrow at night thou shalt remain here;

**[10:59]** And so shall the Highest shew thee visions of the high things, which the most High will do unto them that dwell upon the earth in the last days. So I slept that night and another, like as he commanded me.

**[11:1]** Then saw I a dream, and, behold, there came up from the sea an eagle, which had twelve feathered wings, and three heads.

**[11:2]** And I saw, and, behold, she spread her wings over all the earth, and all the winds of the air blew on her, and were gathered together.

**[11:3]** And I beheld, and out of her feathers there grew other contrary feathers; and they became little feathers and small.

**[11:4]** But her heads were at rest: the head in the midst was greater than the other, yet rested it with the residue.

**[11:5]** Moreover I beheld, and, lo, the eagle flew with her feathers, and reigned upon earth, and over them that dwelt therein.

**[11:6]** And I saw that all things under heaven were subject unto her, and no man spake against her, no, not one creature upon earth.

**[11:7]** And I beheld, and, lo, the eagle rose upon her talons, and spake to her feathers, saying,

**[11:8]** Watch not all at once: sleep every one in his own place, and watch by course:

**[11:9]** But let the heads be preserved for the last.

**[11:10]** And I beheld, and, lo, the voice went not out of her heads, but from the midst of her body.

**[11:11]** And I numbered her contrary feathers, and, behold, there were eight of them.

**[11:12]** And I looked, and, behold, on the right side there arose one feather, and reigned over all the earth;

**[11:13]** And so it was, that when it reigned, the end of it came, and the place thereof appeared no more: so the next following stood up. and reigned, and had a great time;

**[11:14]** And it happened, that when it reigned, the end of it came also, like as the first, so that it appeared no more.

**[11:15]** Then came there a voice unto it, and said,

**[11:16]** Hear thou that hast borne rule over the earth so long: this I say unto thee, before thou beginnest to appear no more,

**[11:17]** There shall none after thee attain unto thy time, neither unto the half thereof.

**[11:18]** Then arose the third, and reigned as the other before, and appeared no more also.

**[11:19]** So went it with all the residue one after another, as that every one reigned, and then appeared no more.

**[11:20]** Then I beheld, and, lo, in process of time the feathers that followed stood up upon the right side, that they might rule also; and some of them ruled, but within a while they appeared no more:

**[11:21]** For some of them were set up, but ruled not.

**[11:22]** After this I looked, and, behold, the twelve feathers appeared no more, nor the two little feathers:

**[11:23]** And there was no more upon the eagle’s body, but three heads that rested, and six little wings.

**[11:24]** Then saw I also that two little feathers divided themselves from the six, and remained under the head that was upon the right side: for the four continued in their place.

**[11:25]** And I beheld, and, lo, the feathers that were under the wing thought to set up themselves and to have the rule.

**[11:26]** And I beheld, and, lo, there was one set up, but shortly it appeared no more.

**[11:27]** And the second was sooner away than the first.

**[11:28]** And I beheld, and, lo, the two that remained thought also in themselves to reign:

**[11:29]** And when they so thought, behold, there awaked one of the heads that were at rest, namely, it that was in the midst; for that was greater than the two other heads.

**[11:30]** And then I saw that the two other heads were joined with it.

**[11:31]** And, behold, the head was turned with them that were with it, and did eat up the two feathers under the wing that would have reigned.

**[11:32]** But this head put the whole earth in fear, and bare rule in it over all those that dwelt upon the earth with much oppression; and it had the governance of the world more than all the wings that had been.

**[11:33]** And after this I beheld, and, lo, the head that was in the midst suddenly appeared no more, like as the wings.

**[11:34]** But there remained the two heads, which also in like sort ruled upon the earth, and over those that dwelt therein.

**[11:35]** And I beheld, and, lo, the head upon the right side devoured it that was upon the left side.

**[11:36]** Then I head a voice, which said unto me, Look before thee, and consider the thing that thou seest.

**[11:37]** And I beheld, and lo, as it were a roaring lion chased out of the wood: and I saw that he sent out a man’s voice unto the eagle, and said,

**[11:38]** Hear thou, I will talk with thee, and the Highest shall say unto thee,

**[11:39]** Art not thou it that remainest of the four beasts, whom I made to reign in my world, that the end of their times might come through them?

**[11:40]** And the fourth came, and overcame all the beasts that were past, and had power over the world with great fearfulness, and over the whole compass of the earth with much wicked oppression; and so long time dwelt he upon the earth with deceit.

**[11:41]** For the earth hast thou not judged with truth.

**[11:42]** For thou hast afflicted the meek, thou hast hurt the peaceable, thou hast loved liars, and destroyed the dwellings of them that brought forth fruit, and hast cast down the walls of such as did thee no harm.

**[11:43]** Therefore is thy wrongful dealing come up unto the Highest, and thy pride unto the Mighty.

**[11:44]** The Highest also hath looked upon the proud times, and, behold, they are ended, and his abominations are fulfilled.

**[11:45]** And therefore appear no more, thou eagle, nor thy horrible wings, nor thy wicked feathers nor thy malicious heads, nor thy hurtful claws, nor all thy vain body:

**[11:46]** That all the earth may be refreshed, and may return, being delivered from thy violence, and that she may hope for the judgment and mercy of him that made her.

**[12:1]** And it came to pass, whiles the lion spake these words unto the eagle, I saw,

**[12:2]** And, behold, the head that remained and the four wings appeared no more, and the two went unto it and set themselves up to reign, and their kingdom was small, and fill of uproar.

**[12:3]** And I saw, and, behold, they appeared no more, and the whole body of the eagle was burnt so that the earth was in great fear: then awaked I out of the trouble and trance of my mind, and from great fear, and said unto my spirit,

**[12:4]** Lo, this hast thou done unto me, in that thou searchest out the ways of the Highest.

**[12:5]** Lo, yet am I weary in my mind, and very weak in my spirit; and little strength is there in me, for the great fear wherewith I was afflicted this night.

**[12:6]** Therefore will I now beseech the Highest, that he will comfort me unto the end.

**[12:7]** And I said, Lord that bearest rule, if I have found grace before thy sight, and if I am justified with thee before many others, and if my prayer indeed be come up before thy face;

**[12:8]** Comfort me then, and shew me thy servant the interpretation and plain difference of this fearful vision, that thou mayest perfectly comfort my soul.

**[12:9]** For thou hast judged me worthy to shew me the last times.

**[12:10]** And he said unto me, This is the interpretation of the vision:

**[12:11]** The eagle, whom thou sawest come up from the sea, is the kingdom which was seen in the vision of thy brother Daniel.

**[12:12]** But it was not expounded unto him, therefore now I declare it unto thee.

**[12:13]** Behold, the days will come, that there shall rise up a kingdom upon earth, and it shall be feared above all the kingdoms that were before it.

**[12:14]** In the same shall twelve kings reign, one after another:

**[12:15]** Whereof the second shall begin to reign, and shall have more time than any of the twelve.

**[12:16]** And this do the twelve wings signify, which thou sawest.

**[12:17]** As for the voice which thou heardest speak, and that thou sawest not to go out from the heads but from the midst of the body thereof, this is the interpretation:

**[12:18]** That after the time of that kingdom there shall arise great strivings, and it shall stand in peril of failing: nevertheless it shall not then fall, but shall be restored again to his beginning.

**[12:19]** And whereas thou sawest the eight small under feathers sticking to her wings, this is the interpretation:

**[12:20]** That in him there shall arise eight kings, whose times shall be but small, and their years swift.

**[12:21]** And two of them shall perish, the middle time approaching: four shall be kept until their end begin to approach: but two shall be kept unto the end.

**[12:22]** And whereas thou sawest three heads resting, this is the interpretation:

**[12:23]** In his last days shall the most High raise up three kingdoms, and renew many things therein, and they shall have the dominion of the earth,

**[12:24]** And of those that dwell therein, with much oppression, above all those that were before them: therefore are they called the heads of the eagle.

**[12:25]** For these are they that shall accomplish his wickedness, and that shall finish his last end.

**[12:26]** And whereas thou sawest that the great head appeared no more, it signifieth that one of them shall die upon his bed, and yet with pain.

**[12:27]** For the two that remain shall be slain with the sword.

**[12:28]** For the sword of the one shall devour the other: but at the last shall he fall through the sword himself.

**[12:29]** And whereas thou sawest two feathers under the wings passing over the head that is on the right side;

**[12:30]** It signifieth that these are they, whom the Highest hath kept unto their end: this is the small kingdom and full of trouble, as thou sawest.

**[12:31]** And the lion, whom thou sawest rising up out of the wood, and roaring, and speaking to the eagle, and rebuking her for her unrighteousness with all the words which thou hast heard;

**[12:32]** This is the anointed, which the Highest hath kept for them and for their wickedness unto the end: he shall reprove them, and shall upbraid them with their cruelty.

**[12:33]** For he shall set them before him alive in judgment, and shall rebuke them, and correct them.

**[12:34]** For the rest of my people shall he deliver with mercy, those that have been pressed upon my borders, and he shall make them joyful until the coming of the day of judgment, whereof I have spoken unto thee from the the beginning.

**[12:35]** This is the dream that thou sawest, and these are the interpretations.

**[12:36]** Thou only hast been meet to know this secret of the Highest.

**[12:37]** Therefore write all these things that thou hast seen in a book, and hide them:

**[12:38]** And teach them to the wise of the people, whose hearts thou knowest may comprehend and keep these secrets.

**[12:39]** But wait thou here thyself yet seven days more, that it may be shewed thee, whatsoever it pleaseth the Highest to declare unto thee. And with that he went his way.

**[12:40]** And it came to pass, when all the people saw that the seven days were past, and I not come again into the city, they gathered them all together, from the least unto the greatest, and came unto me, and said,

**[12:41]** What have we offended thee? and what evil have we done against thee, that thou forsakest us, and sittest here in this place?

**[12:42]** For of all the prophets thou only art left us, as a cluster of the vintage, and as a candle in a dark place, and as a haven or ship preserved from the tempest.

**[12:43]** Are not the evils which are come to us sufficient?

**[12:44]** If thou shalt forsake us, how much better had it been for us, if we also had been burned in the midst of Sion?

**[12:45]** For we are not better than they that died there. And they wept with a loud voice. Then answered I them, and said,

**[12:46]** Be of good comfort, O Israel; and be not heavy, thou house of Jacob:

**[12:47]** For the Highest hath you in remembrance, and the Mighty hath not forgotten you in temptation.

**[12:48]** As for me, I have not forsaken you, neither am I departed from you: but am come into this place, to pray for the desolation of Sion, and that I might seek mercy for the low estate of your sanctuary.

**[12:49]** And now go your way home every man, and after these days will I come unto you.

**[12:50]** So the people went their way into the city, like as I commanded them:

**[12:51]** But I remained still in the field seven days, as the angel commanded me; and did eat only in those days of the flowers of the field, and had my meat of the herbs

**[13:1]** And it came to pass after seven days, I dreamed a dream by night:

**[13:2]** And, lo, there arose a wind from the sea, that it moved all the waves thereof.

**[13:3]** And I beheld, and, lo, that man waxed strong with the thousands of heaven: and when he turned his countenance to look, all the things trembled that were seen under him.

**[13:4]** And whensoever the voice went out of his mouth, all they burned that heard his voice, like as the earth faileth when it feeleth the fire.

**[13:5]** And after this I beheld, and, lo, there was gathered together a multitude of men, out of number, from the four winds of the heaven, to subdue the man that came out of the sea

**[13:6]** But I beheld, and, lo, he had graved himself a great mountain, and flew up upon it.

**[13:7]** But I would have seen the region or place whereout the hill was graven, and I could not.

**[13:8]** And after this I beheld, and, lo, all they which were gathered together to subdue him were sore afraid, and yet durst fight.

**[13:9]** And, lo, as he saw the violence of the multitude that came, he neither lifted up his hand, nor held sword, nor any instrument of war:

**[13:10]** But only I saw that he sent out of his mouth as it had been a blast of fire, and out of his lips a flaming breath, and out of his tongue he cast out sparks and tempests.

**[13:11]** And they were all mixed together; the blast of fire, the flaming breath, and the great tempest; and fell with violence upon the multitude which was prepared to fight, and burned them up every one, so that upon a sudden of an innumerable multitude nothing was to be perceived, but only dust and smell of smoke: when I saw this I was afraid.

**[13:12]** Afterward saw I the same man come down from the mountain, and call unto him another peaceable Multitude.

**[13:13]** And there came much people unto him, whereof some were glad, some were sorry, and some of them were bound, and other some brought of them that were offered: then was I sick through great fear, and I awaked, and said,

**[13:14]** Thou hast shewed thy servant these wonders from the beginning, and hast counted me worthy that thou shouldest receive my prayer:

**[13:15]** Shew me now yet the interpretation of this dream.

**[13:16]** For as I conceive in mine understanding, woe unto them that shall be left in those days and much more woe unto them that are not left behind!

**[13:17]** For they that were not left were in heaviness.

**[13:18]** Now understand I the things that are laid up in the latter days, which shall happen unto them, and to those that are left behind.

**[13:19]** Therefore are they come into great perils and many necessities, like as these dreams declare.

**[13:20]** Yet is it easier for him that is in danger to come into these things, than to pass away as a cloud out of the world, and not to see the things that happen in the last days. And he answered unto me, and said,

**[13:21]** The interpretation of the vision shall I shew thee, and I will open unto thee the thing that thou hast required.

**[13:22]** Whereas thou hast spoken of them that are left behind, this is the interpretation:

**[13:23]** He that shall endure the peril in that time hath kept himself: they that be fallen into danger are such as have works, and faith toward the Almighty.

**[13:24]** Know this therefore, that they which be left behind are more blessed than they that be dead.

**[13:25]** This is the meaning of the vision: Whereas thou sawest a man coming up from the midst of the sea:

**[13:26]** The same is he whom God the Highest hath kept a great season, which by his own self shall deliver his creature: and he shall order them that are left behind.

**[13:27]** And whereas thou sawest, that out of his mouth there came as a blast of wind, and fire, and storm;

**[13:28]** And that he held neither sword, nor any instrument of war, but that the rushing in of him destroyed the whole multitude that came to subdue him; this is the interpretation:

**[13:29]** Behold, the days come, when the most High will begin to deliver them that are upon the earth.

**[13:30]** And he shall come to the astonishment of them that dwell on the earth.

**[13:31]** And one shall undertake to fight against another, one city against another, one place against another, one people against another, and one realm against another.

**[13:32]** And the time shall be when these things shall come to pass, and the signs shall happen which I shewed thee before, and then shall my Son be declared, whom thou sawest as a man ascending.

**[13:33]** And when all the people hear his voice, every man shall in their own land leave the battle they have one against another.

**[13:34]** And an innumerable multitude shall be gathered together, as thou sawest them, willing to come, and to overcome him by fighting.

**[13:35]** But he shall stand upon the top of the mount Sion.

**[13:36]** And Sion shall come, and shall be shewed to all men, being prepared and builded, like as thou sawest the hill graven without hands.

**[13:37]** And this my Son shall rebuke the wicked inventions of those nations, which for their wicked life are fallen into the tempest;

**[13:38]** And shall lay before them their evil thoughts, and the torments wherewith they shall begin to be tormented, which are like unto a flame: and he shall destroy them without labour by the law which is like unto me.

**[13:39]** And whereas thou sawest that he gathered another peaceable multitude unto him;

**[13:40]** Those are the ten tribes, which were carried away prisoners out of their own land in the time of Osea the king, whom Salmanasar the king of Assyria led away captive, and he carried them over the waters, and so came they into another land.

**[13:41]** But they took this counsel among themselves, that they would leave the multitude of the heathen, and go forth into a further country, where never mankind dwelt,

**[13:42]** That they might there keep their statutes, which they never kept in their own land.

**[13:43]** And they entered into Euphrates by the narrow places of the river.

**[13:44]** For the most High then shewed signs for them, and held still the flood, till they were passed over.

**[13:45]** For through that country there was a great way to go, namely, of a year and a half: and the same region is called Arsareth.

**[13:46]** Then dwelt they there until the latter time; and now when they shall begin to come,

**[13:47]** The Highest shall stay the springs of the stream again, that they may go through: therefore sawest thou the multitude with peace.

**[13:48]** But those that be left behind of thy people are they that are found within my borders.

**[13:49]** Now when he destroyeth the multitude of the nations that are gathered together, he shall defend his people that remain.

**[13:50]** And then shall he shew them great wonders.

**[13:51]** Then said I, O Lord that bearest rule, shew me this: Wherefore have I seen the man coming up from the midst of the sea?

**[13:52]** And he said unto me, Like as thou canst neither seek out nor know the things that are in the deep of the sea: even so can no man upon earth see my Son, or those that be with him, but in the day time.

**[13:53]** This is the interpretation of the dream which thou sawest, and whereby thou only art here lightened.

**[13:54]** For thou hast forsaken thine own way, and applied thy diligence unto my law, and sought it.

**[13:55]** Thy life hast thou ordered in wisdom, and hast called understanding thy mother.

**[13:56]** And therefore have I shewed thee the treasures of the Highest: after other three days I will speak other things unto thee, and declare unto thee mighty and wondrous things.

**[13:57]** Then went I forth into the field, giving praise and thanks greatly unto the most High because of his wonders which he did in time;

**[13:58]** And because he governeth the same, and such things as fall in their seasons: and there I sat three days.

**[14:1]** And it came to pass upon the third day, I sat under an oak, and, behold, there came a voice out of a bush over against me, and said, Esdras, Esdras.

**[14:2]** And I said, Here am I, Lord And I stood up upon my feet.

**[14:3]** Then said he unto me, In the bush I did manifestly reveal myself unto Moses, and talked with him, when my people served in Egypt:

**[14:4]** And I sent him and led my people out of Egypt, and brought him up to the mount of where I held him by me a long season,

**[14:5]** And told him many wondrous things, and shewed him the secrets of the times, and the end; and commanded him, saying,

**[14:6]** These words shalt thou declare, and these shalt thou hide.

**[14:7]** And now I say unto thee,

**[14:8]** That thou lay up in thy heart the signs that I have shewed, and the dreams that thou hast seen, and the interpretations which thou hast heard:

**[14:9]** For thou shalt be taken away from all, and from henceforth thou shalt remain with my Son, and with such as be like thee, until the times be ended.

**[14:10]** For the world hath lost his youth, and the times begin to wax old.

**[14:11]** For the world is divided into twelve parts, and the ten parts of it are gone already, and half of a tenth part:

**[14:12]** And there remaineth that which is after the half of the tenth part.

**[14:13]** Now therefore set thine house in order, and reprove thy people, comfort such of them as be in trouble, and now renounce corruption,

**[14:14]** Let go from thee mortal thoughts, cast away the burdens of man, put off now the weak nature,

**[14:15]** And set aside the thoughts that are most heavy unto thee, and haste thee to flee from these times.

**[14:16]** For yet greater evils than those which thou hast seen happen shall be done hereafter.

**[14:17]** For look how much the world shall be weaker through age, so much the more shall evils increase upon them that dwell therein.

**[14:18]** For the time is fled far away, and leasing is hard at hand: for now hasteth the vision to come, which thou hast seen.

**[14:19]** Then answered I before thee, and said,

**[14:20]** Behold, Lord, I will go, as thou hast commanded me, and reprove the people which are present: but they that shall be born afterward, who shall admonish them? thus the world is set in darkness, and they that dwell therein are without light.

**[14:21]** For thy law is burnt, therefore no man knoweth the things that are done of thee, or the work that shall begin.

**[14:22]** But if I have found grace before thee, send the Holy Ghost into me, and I shall write all that hath been done in the world since the beginning, which were written in thy law, that men may find thy path, and that they which will live in the latter days may live.

**[14:23]** And he answered me, saying, Go thy way, gather the people together, and say unto them, that they seek thee not for forty days.

**[14:24]** But look thou prepare thee many box trees, and take with thee Sarea, Dabria, Selemia, Ecanus, and Asiel, these five which are ready to write swiftly;

**[14:25]** And come hither, and I shall light a candle of understanding in thine heart, which shall not be put out, till the things be performed which thou shalt begin to write.

**[14:26]** And when thou hast done, some things shalt thou publish, and some things shalt thou shew secretly to the wise: to morrow this hour shalt thou begin to write.

**[14:27]** Then went I forth, as he commanded, and gathered all the people together, and said,

**[14:28]** Hear these words, O Israel.

**[14:29]** Our fathers at the beginning were strangers in Egypt, from whence they were delivered:

**[14:30]** And received the law of life, which they kept not, which ye also have transgressed after them.

**[14:31]** Then was the land, even the land of Sion, parted among you by lot: but your fathers, and ye yourselves, have done unrighteousness, and have not kept the ways which the Highest commanded you.

**[14:32]** And forasmuch as he is a righteous judge, he took from you in time the thing that he had given you.

**[14:33]** And now are ye here, and your brethren among you.

**[14:34]** Therefore if so be that ye will subdue your own understanding, and reform your hearts, ye shall be kept alive and after death ye shall obtain mercy.

**[14:35]** For after death shall the judgment come, when we shall live again: and then shall the names of the righteous be manifest, and the works of the ungodly shall be declared.

**[14:36]** Let no man therefore come unto me now, nor seek after me these forty days.

**[14:37]** So I took the five men, as he commanded me, and we went into the field, and remained there.

**[14:38]** And the next day, behold, a voice called me, saying, Esdras, open thy mouth, and drink that I give thee to drink.

**[14:39]** Then opened I my mouth, and, behold, he reached me a full cup, which was full as it were with water, but the colour of it was like fire.

**[14:40]** And I took it, and drank: and when I had drunk of it, my heart uttered understanding, and wisdom grew in my breast, for my spirit strengthened my memory:

**[14:41]** And my mouth was opened, and shut no more.

**[14:42]** The Highest gave understanding unto the five men, and they wrote the wonderful visions of the night that were told, which they knew not: and they sat forty days, and they wrote in the day, and at night they ate bread.

**[14:43]** As for me. I spake in the day, and I held not my tongue by night.

**[14:44]** In forty days they wrote two hundred and four books.

**[14:45]** And it came to pass, when the forty days were filled, that the Highest spake, saying, The first that thou hast written publish openly, that the worthy and unworthy may read it:

**[14:46]** But keep the seventy last, that thou mayest deliver them only to such as be wise among the people:

**[14:47]** For in them is the spring of understanding, the fountain of wisdom, and the stream of knowledge.

**[14:48]** And I did so.

**[15:1]** Behold, speak thou in the ears of my people the words of prophecy, which I will put in thy mouth, saith the Lord:

**[15:2]** And cause them to be written in paper: for they are faithful and true.

**[15:3]** Fear not the imaginations against thee, let not the incredulity of them trouble thee, that speak against thee.

**[15:4]** For all the unfaithful shall die in their unfaithfulness.

**[15:5]** Behold, saith the Lord, I will bring plagues upon the world; the sword, famine, death, and destruction.

**[15:6]** For wickedness hath exceedingly polluted the whole earth, and their hurtful works are fulfilled.

**[15:7]** Therefore saith the Lord,

**[15:8]** I will hold my tongue no more as touching their wickedness, which they profanely commit, neither will I suffer them in those things, in which they wickedly exercise themselves: behold, the innocent and righteous blood crieth unto me, and the souls of the just complain continually.

**[15:9]** And therefore, saith the Lord, I will surely avenge them, and receive unto me all the innocent blood from among them.

**[15:10]** Behold, my people is led as a flock to the slaughter: I will not suffer them now to dwell in the land of Egypt:

**[15:11]** But I will bring them with a mighty hand and a stretched out arm, and smite Egypt with plagues, as before, and will destroy all the land thereof.

**[15:12]** Egypt shall mourn, and the foundation of it shall be smitten with the plague and punishment that God shall bring upon it.

**[15:13]** They that till the ground shall mourn: for their seeds shall fail through the blasting and hail, and with a fearful constellation.

**[15:14]** Woe to the world and them that dwell therein!

**[15:15]** For the sword and their destruction draweth nigh, and one people shall stand up and fight against another, and swords in their hands.

**[15:16]** For there shall be sedition among men, and invading one another; they shall not regard their kings nor princes, and the course of their actions shall stand in their power.

**[15:17]** A man shall desire to go into a city, and shall not be able.

**[15:18]** For because of their pride the cities shall be troubled, the houses shall be destroyed, and men shall be afraid.

**[15:19]** A man shall have no pity upon his neighbour, but shall destroy their houses with the sword, and spoil their goods, because of the lack of bread, and for great tribulation.

**[15:20]** Behold, saith God, I will call together all the kings of the earth to reverence me, which are from the rising of the sun, from the south, from the east, and Libanus; to turn themselves one against another, and repay the things that they have done to them.

**[15:21]** Like as they do yet this day unto my chosen, so will I do also, and recompense in their bosom. Thus saith the Lord God;

**[15:22]** My right hand shall not spare the sinners, and my sword shall not cease over them that shed innocent blood upon the earth.

**[15:23]** The fire is gone forth from his wrath, and hath consumed the foundations of the earth, and the sinners, like the straw that is kindled.

**[15:24]** Woe to them that sin, and keep not my commandments! saith the Lord.

**[15:25]** I will not spare them: go your way, ye children, from the power, defile not my sanctuary.

**[15:26]** For the Lord knoweth all them that sin against him, and therefore delivereth he them unto death and destruction.

**[15:27]** For now are the plagues come upon the whole earth and ye shall remain in them: for God shall not deliver you, because ye have sinned against him.

**[15:28]** Behold an horrible vision, and the appearance thereof from the east:

**[15:29]** Where the nations of the dragons of Arabia shall come out with many chariots, and the multitude of them shall be carried as the wind upon earth, that all they which hear them may fear and tremble.

**[15:30]** Also the Carmanians raging in wrath shall go forth as the wild boars of the wood, and with great power shall they come, and join battle with them, and shall waste a portion of the land of the Assyrians.

**[15:31]** And then shall the dragons have the upper hand, remembering their nature; and if they shall turn themselves, conspiring together in great power to persecute them,

**[15:32]** Then these shall be troubled bled, and keep silence through their power, and shall flee.

**[15:33]** And from the land of the Assyrians shall the enemy besiege them, and consume some of them, and in their host shall be fear and dread, and strife among their kings.

**[15:34]** Behold clouds from the east and from the north unto the south, and they are very horrible to look upon, full of wrath and storm.

**[15:35]** They shall smite one upon another, and they shall smite down a great multitude of stars upon the earth, even their own star; and blood shall be from the sword unto the belly,

**[15:36]** And dung of men unto the camel’s hough.

**[15:37]** And there shall be great fearfulness and trembling upon earth: and they that see the wrath shall be afraid, and trembling shall come upon them.

**[15:38]** And then shall there come great storms from the south, and from the north, and another part from the west.

**[15:39]** And strong winds shall arise from the east, and shall open it; and the cloud which he raised up in wrath, and the star stirred to cause fear toward the east and west wind, shall be destroyed.

**[15:40]** The great and mighty clouds shall be puffed up full of wrath, and the star, that they may make all the earth afraid, and them that dwell therein; and they shall pour out over every high and eminent place an horrible star,

**[15:41]** Fire, and hail, and flying swords, and many waters, that all fields may be full, and all rivers, with the abundance of great waters.

**[15:42]** And they shall break down the cities and walls, mountains and hills, trees of the wood, and grass of the meadows, and their corn.

**[15:43]** And they shall go stedfastly unto Babylon, and make her afraid.

**[15:44]** They shall come to her, and besiege her, the star and all wrath shall they pour out upon her: then shall the dust and smoke go up unto the heaven, and all they that be about her shall bewail her.

**[15:45]** And they that remain under her shall do service unto them that have put her in fear.

**[15:46]** And thou, Asia, that art partaker of the hope of Babylon, and art the glory of her person:

**[15:47]** Woe be unto thee, thou wretch, because thou hast made thyself like unto her; and hast decked thy daughters in whoredom, that they might please and glory in thy lovers, which have always desired to commit whoredom with thee.

**[15:48]** Thou hast followed her that is hated in all her works and inventions: therefore saith God,

**[15:49]** I will send plagues upon thee; widowhood, poverty, famine, sword, and pestilence, to waste thy houses with destruction and death.

**[15:50]** And the glory of thy Power shall be dried up as a flower, the heat shall arise that is sent over thee.

**[15:51]** Thou shalt be weakened as a poor woman with stripes, and as one chastised with wounds, so that the mighty and lovers shall not be able to receive thee.

**[15:52]** Would I with jealousy have so proceeded against thee, saith the Lord,

**[15:53]** If thou hadst not always slain my chosen, exalting the stroke of thine hands, and saying over their dead, when thou wast drunken,

**[15:54]** Set forth the beauty of thy countenance?

**[15:55]** The reward of thy whoredom shall be in thy bosom, therefore shalt thou receive recompence.

**[15:56]** Like as thou hast done unto my chosen, saith the Lord, even so shall God do unto thee, and shall deliver thee into mischief

**[15:57]** Thy children shall die of hunger, and thou shalt fall through the sword: thy cities shall be broken down, and all thine shall perish with the sword in the field.

**[15:58]** They that be in the mountains shall die of hunger, and eat their own flesh, and drink their own blood, for very hunger of bread, and thirst of water.

**[15:59]** Thou as unhappy shalt come through the sea, and receive plagues again.

**[15:60]** And in the passage they shall rush on the idle city, and shall destroy some portion of thy land, and consume part of thy glory, and shall return to Babylon that was destroyed.

**[15:61]** And thou shalt be cast down by them as stubble, and they shall be unto thee as fire;

**[15:62]** And shall consume thee, and thy cities, thy land, and thy mountains; all thy woods and thy fruitful trees shall they burn up with fire.

**[15:63]** Thy children shall they carry away captive, and, look, what thou hast, they shall spoil it, and mar the beauty of thy face.

**[16:1]** Woe be unto thee, Babylon, and Asia! woe be unto thee, Egypt and Syria!

**[16:2]** Gird up yourselves with cloths of sack and hair, bewail your children, and be sorry; for your destruction is at hand.

**[16:3]** A sword is sent upon you, and who may turn it back?

**[16:4]** A fire is sent among you, and who may quench it?

**[16:5]** Plagues are sent unto you, and what is he that may drive them away?

**[16:6]** May any man drive away an hungry lion in the wood? or may any one quench the fire in stubble, when it hath begun to burn?

**[16:7]** May one turn again the arrow that is shot of a strong archer?

**[16:8]** The mighty Lord sendeth the plagues and who is he that can drive them away?

**[16:9]** A fire shall go forth from his wrath, and who is he that may quench it?

**[16:10]** He shall cast lightnings, and who shall not fear? he shall thunder, and who shall not be afraid?

**[16:11]** The Lord shall threaten, and who shall not be utterly beaten to powder at his presence?

**[16:12]** The earth quaketh, and the foundations thereof; the sea ariseth up with waves from the deep, and the waves of it are troubled, and the fishes thereof also, before the Lord, and before the glory of his power:

**[16:13]** For strong is his right hand that bendeth the bow, his arrows that he shooteth are sharp, and shall not miss, when they begin to be shot into the ends of the world.

**[16:14]** Behold, the plagues are sent, and shall not return again, until they come upon the earth.

**[16:15]** The fire is kindled, and shall not be put out, till it consume the foundation of the earth.

**[16:16]** Like as an arrow which is shot of a mighty archer returneth not backward: even so the plagues that shall be sent upon earth shall not return again.

**[16:17]** Woe is me! woe is me! who will deliver me in those days?

**[16:18]** The beginning of sorrows and great mournings; the beginning of famine and great death; the beginning of wars, and the powers shall stand in fear; the beginning of evils! what shall I do when these evils shall come?

**[16:19]** Behold, famine and plague, tribulation and anguish, are sent as scourges for amendment.

**[16:20]** But for all these things they shall not turn from their wickedness, nor be always mindful of the scourges.

**[16:21]** Behold, victuals shall be so good cheap upon earth, that they shall think themselves to be in good case, and even then shall evils grow upon earth, sword, famine, and great confusion.

**[16:22]** For many of them that dwell upon earth shall perish of famine; and the other, that escape the hunger, shall the sword destroy.

**[16:23]** And the dead shall be cast out as dung, and there shall be no man to comfort them: for the earth shall be wasted, and the cities shall be cast down.

**[16:24]** There shall be no man left to till the earth, and to sow it

**[16:25]** The trees shall give fruit, and who shall gather them?

**[16:26]** The grapes shall ripen, and who shall tread them? for all places shall be desolate of men:

**[16:27]** So that one man shall desire to see another, and to hear his voice.

**[16:28]** For of a city there shall be ten left, and two of the field, which shall hide themselves in the thick groves, and in the clefts of the rocks.

**[16:29]** As in an orchard of Olives upon every tree there are left three or four olives;

**[16:30]** Or as when a vineyard is gathered, there are left some clusters of them that diligently seek through the vineyard:

**[16:31]** Even so in those days there shall be three or four left by them that search their houses with the sword.

**[16:32]** And the earth shall be laid waste, and the fields thereof shall wax old, and her ways and all her paths shall grow full of thorns, because no man shall travel therethrough.

**[16:33]** The virgins shall mourn, having no bridegrooms; the women shall mourn, having no husbands; their daughters shall mourn, having no helpers.

**[16:34]** In the wars shall their bridegrooms be destroyed, and their husbands shall perish of famine.

**[16:35]** Hear now these things and understand them, ye servants of the Lord.

**[16:36]** Behold, the word of the Lord, receive it: believe not the gods of whom the Lord spake.

**[16:37]** Behold, the plagues draw nigh, and are not slack.

**[16:38]** As when a woman with child in the ninth month bringeth forth her son, with two or three hours of her birth great pains compass her womb, which pains, when the child cometh forth, they slack not a moment:

**[16:39]** Even so shall not the plagues be slack to come upon the earth, and the world shall mourn, and sorrows shall come upon it on every side.

**[16:40]** O my people, hear my word: make you ready to thy battle, and in those evils be even as pilgrims upon the earth.

**[16:41]** He that selleth, let him be as he that fleeth away: and he that buyeth, as one that will lose:

**[16:42]** He that occupieth merchandise, as he that hath no profit by it: and he that buildeth, as he that shall not dwell therein:

**[16:43]** He that soweth, as if he should not reap: so also he that planteth the vineyard, as he that shall not gather the grapes:

**[16:44]** They that marry, as they that shall get no children; and they that marry not, as the widowers.

**[16:45]** And therefore they that labour labour in vain:

**[16:46]** For strangers shall reap their fruits, and spoil their goods, overthrow their houses, and take their children captives, for in captivity and famine shall they get children.

**[16:47]** And they that occupy their merchandise with robbery, the more they deck their cities, their houses, their possessions, and their own persons:

**[16:48]** The more will I be angry with them for their sin, saith the Lord.

**[16:49]** Like as a whore envieth a right honest and virtuous woman:

**[16:50]** So shall righteousness hate iniquity, when she decketh herself, and shall accuse her to her face, when he cometh that shall defend him that diligently searcheth out every sin upon earth.

**[16:51]** And therefore be ye not like thereunto, nor to the works thereof.

**[16:52]** For yet a little, and iniquity shall be taken away out of the earth, and righteousness shall reign among you.

**[16:53]** Let not the sinner say that he hath not sinned: for God shall burn coals of fire upon his head, which saith before the Lord God and his glory, I have not sinned.

**[16:54]** Behold, the Lord knoweth all the works of men, their imaginations, their thoughts, and their hearts:

**[16:55]** Which spake but the word, Let the earth be made; and it was made: Let the heaven be made; and it was created.

**[16:56]** In his word were the stars made, and he knoweth the number of them.

**[16:57]** He searcheth the deep, and the treasures thereof; he hath measured the sea, and what it containeth.

**[16:58]** He hath shut the sea in the midst of the waters, and with his word hath he hanged the earth upon the waters.

**[16:59]** He spreadeth out the heavens like a vault; upon the waters hath he founded it.

**[16:60]** In the desert hath he made springs of water, and pools upon the tops of the mountains, that the floods might pour down from the high rocks to water the earth.

**[16:61]** He made man, and put his heart in the midst of the body, and gave him breath, life, and understanding.

**[16:62]** Yea and the Spirit of Almighty God, which made all things, and searcheth out all hidden things in the secrets of the earth,

**[16:63]** Surely he knoweth your inventions, and what ye think in your hearts, even them that sin, and would hide their sin.

**[16:64]** Therefore hath the Lord exactly searched out all your works, and he will put you all to shame.

**[16:65]** And when your sins are brought forth, ye shall be ashamed before men, and your own sins shall be your accusers in that day.

**[16:66]** What will ye do? or how will ye hide your sins before God and his angels?

**[16:67]** Behold, God himself is the judge, fear him: leave off from your sins, and forget your iniquities, to meddle no more with them for ever: so shall God lead you forth, and deliver you from all trouble.

**[16:68]** For, behold, the burning wrath of a great multitude is kindled over you, and they shall take away certain of you, and feed you, being idle, with things offered unto idols.

**[16:69]** And they that consent unto them shall be had in derision and in reproach, and trodden under foot.

**[16:70]** For there shall be in every place, and in the next cities, a great insurrection upon those that fear the Lord.

**[16:71]** They shall be like mad men, sparing none, but still spoiling and destroying those that fear the Lord.

**[16:72]** For they shall waste and take away their goods, and cast them out of their houses.

**[16:73]** Then shall they be known, who are my chosen; and they shall be tried as the gold in the fire.

**[16:74]** Hear, O ye my beloved, saith the Lord: behold, the days of trouble are at hand, but I will deliver you from the same.

**[16:75]** Be ye not afraid neither doubt; for God is your guide,

**[16:76]** And the guide of them who keep my commandments and precepts, saith the Lord God: let not your sins weigh you down, and let not your iniquities lift up themselves.

**[16:77]** Woe be unto them that are bound with their sins, and covered with their iniquities like as a field is covered over with bushes, and the path thereof covered with thorns, that no man may travel through!

**[16:78]** It is left undressed, and is cast into the fire to be consumed therewith.

