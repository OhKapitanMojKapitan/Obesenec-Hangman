# Judith



**[1:1]** In the twelfth year of the reign of Nabuchodonosor, who reigned in Nineve, the great city; in the days of Arphaxad, which reigned over the Medes in Ecbatane,

**[1:2]** And built in Ecbatane walls round about of stones hewn three cubits broad and six cubits long, and made the height of the wall seventy cubits, and the breadth thereof fifty cubits:

**[1:3]** And set the towers thereof upon the gates of it an hundred cubits high, and the breadth thereof in the foundation threescore cubits:

**[1:4]** And he made the gates thereof, even gates that were raised to the height of seventy cubits, and the breadth of them was forty cubits, for the going forth of his mighty armies, and for the setting in array of his footmen:

**[1:5]** Even in those days king Nabuchodonosor made war with king Arphaxad in the great plain, which is the plain in the borders of Ragau.

**[1:6]** And there came unto him all they that dwelt in the hill country, and all that dwelt by Euphrates, and Tigris and Hydaspes, and the plain of Arioch the king of the Elymeans, and very many nations of the sons of Chelod, assembled themselves to the battle.

**[1:7]** Then Nabuchodonosor king of the Assyrians sent unto all that dwelt in Persia, and to all that dwelt westward, and to those that dwelt in Cilicia, and Damascus, and Libanus, and Antilibanus, and to all that dwelt upon the sea coast,

**[1:8]** And to those among the nations that were of Carmel, and Galaad, and the higher Galilee, and the great plain of Esdrelom,

**[1:9]** And to all that were in Samaria and the cities thereof, and beyond Jordan unto Jerusalem, and Betane, and Chelus, and Kades, and the river of Egypt, and Taphnes, and Ramesse, and all the land of Gesem,

**[1:10]** Until ye come beyond Tanis and Memphis, and to all the inhabitants of Egypt, until ye come to the borders of Ethiopia.

**[1:11]** But all the inhabitants of the land made light of the commandment of Nabuchodonosor king of the Assyrians, neither went they with him to the battle; for they were not afraid of him: yea, he was before them as one man, and they sent away his ambassadors from them without effect, and with disgrace.

**[1:12]** Therefore Nabuchodonosor was very angry with all this country, and sware by his throne and kingdom, that he would surely be avenged upon all those coasts of Cilicia, and Damascus, and Syria, and that he would slay with the sword all the inhabitants of the land of Moab, and the children of Ammon, and all Judea, and all that were in Egypt, till ye come to the borders of the two seas.

**[1:13]** Then he marched in battle array with his power against king Arphaxad in the seventeenth year, and he prevailed in his battle: for he overthrew all the power of Arphaxad, and all his horsemen, and all his chariots,

**[1:14]** And became lord of his cities, and came unto Ecbatane, and took the towers, and spoiled the streets thereof, and turned the beauty thereof into shame.

**[1:15]** He took also Arphaxad in the mountains of Ragau, and smote him through with his darts, and destroyed him utterly that day.

**[1:16]** So he returned afterward to Nineve, both he and all his company of sundry nations being a very great multitude of men of war, and there he took his ease, and banqueted, both he and his army, an hundred and twenty days.

**[2:1]** And in the eighteenth year, the two and twentieth day of the first month, there was talk in the house of Nabuchodonosor king of the Assyrians that he should, as he said, avenge himself on all the earth.

**[2:2]** So he called unto him all his officers, and all his nobles, and communicated with them his secret counsel, and concluded the afflicting of the whole earth out of his own mouth.

**[2:3]** Then they decreed to destroy all flesh, that did not obey the commandment of his mouth.

**[2:4]** And when he had ended his counsel, Nabuchodonosor king of the Assyrians called Holofernes the chief captain of his army, which was next unto him, and said unto him.

**[2:5]** Thus saith the great king, the lord of the whole earth, Behold, thou shalt go forth from my presence, and take with thee men that trust in their own strength, of footmen an hundred and twenty thousand; and the number of horses with their riders twelve thousand.

**[2:6]** And thou shalt go against all the west country, because they disobeyed my commandment.

**[2:7]** And thou shalt declare unto that they prepare for me earth and water: for I will go forth in my wrath against them and will cover the whole face of the earth with the feet of mine army, and I will give them for a spoil unto them:

**[2:8]** So that their slain shall fill their valleys and brooks and the river shall be filled with their dead, till it overflow:

**[2:9]** And I will lead them captives to the utmost parts of all the earth.

**[2:10]** Thou therefore shalt go forth. and take beforehand for me all their coasts: and if they will yield themselves unto thee, thou shalt reserve them for me till the day of their punishment.

**[2:11]** But concerning them that rebel, let not thine eye spare them; but put them to the slaughter, and spoil them wheresoever thou goest.

**[2:12]** For as I live, and by the power of my kingdom, whatsoever I have spoken, that will I do by mine hand.

**[2:13]** And take thou heed that thou transgress none of the commandments of thy lord, but accomplish them fully, as I have commanded thee, and defer not to do them.

**[2:14]** Then Holofernes went forth from the presence of his lord, and called all the governors and captains, and the officers of the army of Assur;

**[2:15]** And he mustered the chosen men for the battle, as his lord had commanded him, unto an hundred and twenty thousand, and twelve thousand archers on horseback;

**[2:16]** And he ranged them, as a great army is ordered for the war.

**[2:17]** And he took camels and asses for their carriages, a very great number; and sheep and oxen and goats without number for their provision:

**[2:18]** And plenty of victual for every man of the army, and very much gold and silver out of the king’s house.

**[2:19]** Then he went forth and all his power to go before king Nabuchodonosor in the voyage, and to cover all the face of the earth westward with their chariots, and horsemen, and their chosen footmen.

**[2:20]** A great number also sundry countries came with them like locusts, and like the sand of the earth: for the multitude was without number.

**[2:21]** And they went forth of Nineve three days’ journey toward the plain of Bectileth, and pitched from Bectileth near the mountain which is at the left hand of the upper Cilicia.

**[2:22]** Then he took all his army, his footmen, and horsemen and chariots, and went from thence into the hill country;

**[2:23]** And destroyed Phud and Lud, and spoiled all the children of Rasses, and the children of Israel, which were toward the wilderness at the south of the land of the Chellians.

**[2:24]** Then he went over Euphrates, and went through Mesopotamia, and destroyed all the high cities that were upon the river Arbonai, till ye come to the sea.

**[2:25]** And he took the borders of Cilicia, and killed all that resisted him, and came to the borders of Japheth, which were toward the south, over against Arabia.

**[2:26]** He compassed also all the children of Madian, and burned up their tabernacles, and spoiled their sheepcotes.

**[2:27]** Then he went down into the plain of Damascus in the time of wheat harvest, and burnt up all their fields, and destroyed their flocks and herds, also he spoiled their cities, and utterly wasted their countries, and smote all their young men with the edge of the sword.

**[2:28]** Therefore the fear and dread of him fell upon all the inhabitants of the sea coasts, which were in Sidon and Tyrus, and them that dwelt in Sur and Ocina, and all that dwelt in Jemnaan; and they that dwelt in Azotus and Ascalon feared him greatly.

**[3:1]** So they sent ambassadors unto him to treat of peace, saying,

**[3:2]** Behold, we the servants of Nabuchodonosor the great king lie before thee; use us as shall be good in thy sight.

**[3:3]** Behold, our houses, and all our places, and all our fields of wheat, and flocks, and herds, and all the lodges of our tents lie before thy face; use them as it pleaseth thee.

**[3:4]** Behold, even our cities and the inhabitants thereof are thy servants; come and deal with them as seemeth good unto thee.

**[3:5]** So the men came to Holofernes, and declared unto him after this manner.

**[3:6]** Then came he down toward the sea coast, both he and his army, and set garrisons in the high cities, and took out of them chosen men for aid.

**[3:7]** So they and all the country round about received them with garlands, with dances, and with timbrels.

**[3:8]** Yet he did cast down their frontiers, and cut down their groves: for he had decreed to destroy all the gods of the land, that all nations should worship Nabuchodonosor only, and that all tongues and tribes should call upon him as god.

**[3:9]** Also he came over against Esdraelon near unto Judea, over against the great strait of Judea.

**[3:10]** And he pitched between Geba and Scythopolis, and there he tarried a whole month, that he might gather together all the carriages of his army.

**[4:1]** Now the children of Israel, that dwelt in Judea, heard all that Holofernes the chief captain of Nabuchodonosor king of the Assyrians had done to the nations, and after what manner he had spoiled all their temples, and brought them to nought.

**[4:2]** Therefore they were exceedingly afraid of him, and were troubled for Jerusalem, and for the temple of the Lord their God:

**[4:3]** For they were newly returned from the captivity, and all the people of Judea were lately gathered together: and the vessels, and the altar, and the house, were sanctified after the profanation.

**[4:4]** Therefore they sent into all the coasts of Samaria, and the villages and to Bethoron, and Belmen, and Jericho, and to Choba, and Esora, and to the valley of Salem:

**[4:5]** And possessed themselves beforehand of all the tops of the high mountains, and fortified the villages that were in them, and laid up victuals for the provision of war: for their fields were of late reaped.

**[4:6]** Also Joacim the high priest, which was in those days in Jerusalem, wrote to them that dwelt in Bethulia, and Betomestham, which is over against Esdraelon toward the open country, near to Dothaim,

**[4:7]** Charging them to keep the passages of the hill country: for by them there was an entrance into Judea, and it was easy to stop them that would come up, because the passage was straight, for two men at the most.

**[4:8]** And the children of Israel did as Joacim the high priest had commanded them, with the ancients of all the people of Israel, which dwelt at Jerusalem.

**[4:9]** Then every man of Israel cried to God with great fervency, and with great vehemency did they humble their souls:

**[4:10]** Both they, and their wives and their children, and their cattle, and every stranger and hireling, and their servants bought with money, put sackcloth upon their loins.

**[4:11]** Thus every man and women, and the little children, and the inhabitants of Jerusalem, fell before the temple, and cast ashes upon their heads, and spread out their sackcloth before the face of the Lord: also they put sackcloth about the altar,

**[4:12]** And cried to the God of Israel all with one consent earnestly, that he would not give their children for a prey, and their wives for a spoil, and the cities of their inheritance to destruction, and the sanctuary to profanation and reproach, and for the nations to rejoice at.

**[4:13]** So God heard their prayers, and looked upon their afflictions: for the people fasted many days in all Judea and Jerusalem before the sanctuary of the Lord Almighty.

**[4:14]** And Joacim the high priest, and all the priests that stood before the Lord, and they which ministered unto the Lord, had their loins girt with sackcloth, and offered the daily burnt offerings, with the vows and free gifts of the people,

**[4:15]** And had ashes on their mitres, and cried unto the Lord with all their power, that he would look upon all the house of Israel graciously.

**[5:1]** Then was it declared to Holofernes, the chief captain of the army of Assur, that the children of Israel had prepared for war, and had shut up the passages of the hill country, and had fortified all the tops of the high hills and had laid impediments in the champaign countries:

**[5:2]** Wherewith he was very angry, and called all the princes of Moab, and the captains of Ammon, and all the governors of the sea coast,

**[5:3]** And he said unto them, Tell me now, ye sons of Chanaan, who this people is, that dwelleth in the hill country, and what are the cities that they inhabit, and what is the multitude of their army, and wherein is their power and strength, and what king is set over them, or captain of their army;

**[5:4]** And why have they determined not to come and meet me, more than all the inhabitants of the west.

**[5:5]** Then said Achior, the captain of all the sons of Ammon, Let my lord now hear a word from the mouth of thy servant, and I will declare unto thee the truth concerning this people, which dwelleth near thee, and inhabiteth the hill countries: and there shall no lie come out of the mouth of thy servant.

**[5:6]** This people are descended of the Chaldeans:

**[5:7]** And they sojourned heretofore in Mesopotamia, because they would not follow the gods of their fathers, which were in the land of Chaldea.

**[5:8]** For they left the way of their ancestors, and worshipped the God of heaven, the God whom they knew: so they cast them out from the face of their gods, and they fled into Mesopotamia, and sojourned there many days.

**[5:9]** Then their God commanded them to depart from the place where they sojourned, and to go into the land of Chanaan: where they dwelt, and were increased with gold and silver, and with very much cattle.

**[5:10]** But when a famine covered all the land of Chanaan, they went down into Egypt, and sojourned there, while they were nourished, and became there a great multitude, so that one could not number their nation.

**[5:11]** Therefore the king of Egypt rose up against them, and dealt subtilly with them, and brought them low with labouring in brick, and made them slaves.

**[5:12]** Then they cried unto their God, and he smote all the land of Egypt with incurable plagues: so the Egyptians cast them out of their sight.

**[5:13]** And God dried the Red sea before them,

**[5:14]** And brought them to mount Sina, and Cades-Barne, and cast forth all that dwelt in the wilderness.

**[5:15]** So they dwelt in the land of the Amorites, and they destroyed by their strength all them of Esebon, and passing over Jordan they possessed all the hill country.

**[5:16]** And they cast forth before them the Chanaanite, the Pherezite, the Jebusite, and the Sychemite, and all the Gergesites, and they dwelt in that country many days.

**[5:17]** And whilst they sinned not before their God, they prospered, because the God that hateth iniquity was with them.

**[5:18]** But when they departed from the way which he appointed them, they were destroyed in many battles very sore, and were led captives into a land that was not their’s, and the temple of their God was cast to the ground, and their cities were taken by the enemies.

**[5:19]** But now are they returned to their God, and are come up from the places where they were scattered, and have possessed Jerusalem, where their sanctuary is, and are seated in the hill country; for it was desolate.

**[5:20]** Now therefore, my lord and governor, if there be any error against this people, and they sin against their God, let us consider that this shall be their ruin, and let us go up, and we shall overcome them.

**[5:21]** But if there be no iniquity in their nation, let my lord now pass by, lest their Lord defend them, and their God be for them, and we become a reproach before all the world.

**[5:22]** And when Achior had finished these sayings, all the people standing round about the tent murmured, and the chief men of Holofernes, and all that dwelt by the sea side, and in Moab, spake that he should kill him.

**[5:23]** For, say they, we will not be afraid of the face of the children of Israel: for, lo, it is a people that have no strength nor power for a strong battle

**[5:24]** Now therefore, lord Holofernes, we will go up, and they shall be a prey to be devoured of all thine army.

**[6:1]** And when the tumult of men that were about the council was ceased, Holofernes the chief captain of the army of Assur said unto Achior and all the Moabites before all the company of other nations,

**[6:2]** And who art thou, Achior, and the hirelings of Ephraim, that thou hast prophesied against us as to day, and hast said, that we should not make war with the people of Israel, because their God will defend them? and who is God but Nabuchodonosor?

**[6:3]** He will send his power, and will destroy them from the face of the earth, and their God shall not deliver them: but we his servants will destroy them as one man; for they are not able to sustain the power of our horses.

**[6:4]** For with them we will tread them under foot, and their mountains shall be drunken with their blood, and their fields shall be filled with their dead bodies, and their footsteps shall not be able to stand before us, for they shall utterly perish, saith king Nabuchodonosor, lord of all the earth: for he said, None of my words shall be in vain.

**[6:5]** And thou, Achior, an hireling of Ammon, which hast spoken these words in the day of thine iniquity, shalt see my face no more from this day, until I take vengeance of this nation that came out of Egypt.

**[6:6]** And then shall the sword of mine army, and the multitude of them that serve me, pass through thy sides, and thou shalt fall among their slain, when I return.

**[6:7]** Now therefore my servants shall bring thee back into the hill country, and shall set thee in one of the cities of the passages:

**[6:8]** And thou shalt not perish, till thou be destroyed with them.

**[6:9]** And if thou persuade thyself in thy mind that they shall be taken, let not thy countenance fall: I have spoken it, and none of my words shall be in vain.

**[6:10]** Then Holofernes commanded his servants, that waited in his tent, to take Achior, and bring him to Bethulia, and deliver him into the hands of the children of Israel.

**[6:11]** So his servants took him, and brought him out of the camp into the plain, and they went from the midst of the plain into the hill country, and came unto the fountains that were under Bethulia.

**[6:12]** And when the men of the city saw them, they took up their weapons, and went out of the city to the top of the hill: and every man that used a sling kept them from coming up by casting of stones against them.

**[6:13]** Nevertheless having gotten privily under the hill, they bound Achior, and cast him down, and left him at the foot of the hill, and returned to their lord.

**[6:14]** But the Israelites descended from their city, and came unto him, and loosed him, and brought him to Bethulia, and presented him to the governors of the city:

**[6:15]** Which were in those days Ozias the son of Micha, of the tribe of Simeon, and Chabris the son of Gothoniel, and Charmis the son of Melchiel.

**[6:16]** And they called together all the ancients of the city, and all their youth ran together, and their women, to the assembly, and they set Achior in the midst of all their people. Then Ozias asked him of that which was done.

**[6:17]** And he answered and declared unto them the words of the council of Holofernes, and all the words that he had spoken in the midst of the princes of Assur, and whatsoever Holofernes had spoken proudly against the house of Israel.

**[6:18]** Then the people fell down and worshipped God, and cried unto God. saying,

**[6:19]** O Lord God of heaven, behold their pride, and pity the low estate of our nation, and look upon the face of those that are sanctified unto thee this day.

**[6:20]** Then they comforted Achior, and praised him greatly.

**[6:21]** And Ozias took him out of the assembly unto his house, and made a feast to the elders; and they called on the God of Israel all that night for help.

**[7:1]** The next day Holofernes commanded all his army, and all his people which were come to take his part, that they should remove their camp against Bethulia, to take aforehand the ascents of the hill country, and to make war against the children of Israel.

**[7:2]** Then their strong men removed their camps in that day, and the army of the men of war was an hundred and seventy thousand footmen, and twelve thousand horsemen, beside the baggage, and other men that were afoot among them, a very great multitude.

**[7:3]** And they camped in the valley near unto Bethulia, by the fountain, and they spread themselves in breadth over Dothaim even to Belmaim, and in length from Bethulia unto Cynamon, which is over against Esdraelon.

**[7:4]** Now the children of Israel, when they saw the multitude of them, were greatly troubled, and said every one to his neighbour, Now will these men lick up the face of the earth; for neither the high mountains, nor the valleys, nor the hills, are able to bear their weight.

**[7:5]** Then every man took up his weapons of war, and when they had kindled fires upon their towers, they remained and watched all that night.

**[7:6]** But in the second day Holofernes brought forth all his horsemen in the sight of the children of Israel which were in Bethulia,

**[7:7]** And viewed the passages up to the city, and came to the fountains of their waters, and took them, and set garrisons of men of war over them, and he himself removed toward his people.

**[7:8]** Then came unto him all the chief of the children of Esau, and all the governors of the people of Moab, and the captains of the sea coast, and said,

**[7:9]** Let our lord now hear a word, that there be not an overthrow in thine army.

**[7:10]** For this people of the children of Israel do not trust in their spears, but in the height of the mountains wherein they dwell, because it is not easy to come up to the tops of their mountains.

**[7:11]** Now therefore, my lord, fight not against them in battle array, and there shall not so much as one man of thy people perish.

**[7:12]** Remain in thy camp, and keep all the men of thine army, and let thy servants get into their hands the fountain of water, which issueth forth of the foot of the mountain:

**[7:13]** For all the inhabitants of Bethulia have their water thence; so shall thirst kill them, and they shall give up their city, and we and our people shall go up to the tops of the mountains that are near, and will camp upon them, to watch that none go out of the city.

**[7:14]** So they and their wives and their children shall be consumed with fire, and before the sword come against them, they shall be overthrown in the streets where they dwell.

**[7:15]** Thus shalt thou render them an evil reward; because they rebelled, and met not thy person peaceably.

**[7:16]** And these words pleased Holofernes and all his servants, and he appointed to do as they had spoken.

**[7:17]** So the camp of the children of Ammon departed, and with them five thousand of the Assyrians, and they pitched in the valley, and took the waters, and the fountains of the waters of the children of Israel.

**[7:18]** Then the children of Esau went up with the children of Ammon, and camped in the hill country over against Dothaim: and they sent some of them toward the south, and toward the east over against Ekrebel, which is near unto Chusi, that is upon the brook Mochmur; and the rest of the army of the Assyrians camped in the plain, and covered the face of the whole land; and their tents and carriages were pitched to a very great multitude.

**[7:19]** Then the children of Israel cried unto the Lord their God, because their heart failed, for all their enemies had compassed them round about, and there was no way to escape out from among them.

**[7:20]** Thus all the company of Assur remained about them, both their footmen, chariots, and horsemen, four and thirty days, so that all their vessels of water failed all the inhibitants of Bethulia.

**[7:21]** And the cisterns were emptied, and they had not water to drink their fill for one day; for they gave them drink by measure.

**[7:22]** Therefore their young children were out of heart, and their women and young men fainted for thirst, and fell down in the streets of the city, and by the passages of the gates, and there was no longer any strength in them.

**[7:23]** Then all the people assembled to Ozias, and to the chief of the city, both young men, and women, and children, and cried with a loud voice, and said before all the elders,

**[7:24]** God be judge between us and you: for ye have done us great injury, in that ye have not required peace of the children of Assur.

**[7:25]** For now we have no helper: but God hath sold us into their hands, that we should be thrown down before them with thirst and great destruction.

**[7:26]** Now therefore call them unto you, and deliver the whole city for a spoil to the people of Holofernes, and to all his army.

**[7:27]** For it is better for us to be made a spoil unto them, than to die for thirst: for we will be his servants, that our souls may live, and not see the death of our infants before our eyes, nor our wives nor our children to die.

**[7:28]** We take to witness against you the heaven and the earth, and our God and Lord of our fathers, which punisheth us according to our sins and the sins of our fathers, that he do not according as we have said this day.

**[7:29]** Then there was great weeping with one consent in the midst of the assembly; and they cried unto the Lord God with a loud voice.

**[7:30]** Then said Ozias to them, Brethren, be of good courage, let us yet endure five days, in the which space the Lord our God may turn his mercy toward us; for he will not forsake us utterly.

**[7:31]** And if these days pass, and there come no help unto us, I will do according to your word.

**[7:32]** And he dispersed the people, every one to their own charge; and they went unto the walls and towers of their city, and sent the women and children into their houses: and they were very low brought in the city.

**[8:1]** Now at that time Judith heard thereof, which was the daughter of Merari, the son of Ox, the son of Joseph, the son of Ozel, the son of Elcia, the son of Ananias, the son of Gedeon, the son of Raphaim, the son of Acitho, the son of Eliu, the son of Eliab, the son of Nathanael, the son of Samael, the son of Salasadal, the son of Israel.

**[8:2]** And Manasses was her husband, of her tribe and kindred, who died in the barley harvest.

**[8:3]** For as he stood overseeing them that bound sheaves in the field, the heat came upon his head, and he fell on his bed, and died in the city of Bethulia: and they buried him with his fathers in the field between Dothaim and Balamo.

**[8:4]** So Judith was a widow in her house three years and four months.

**[8:5]** And she made her a tent upon the top of her house, and put on sackcloth upon her loins and ware her widow’s apparel.

**[8:6]** And she fasted all the days of her widowhood, save the eves of the sabbaths, and the sabbaths, and the eves of the new moons, and the new moons and the feasts and solemn days of the house of Israel.

**[8:7]** She was also of a goodly countenance, and very beautiful to behold: and her husband Manasses had left her gold, and silver, and menservants and maidservants, and cattle, and lands; and she remained upon them.

**[8:8]** And there was none that gave her an ill word; as she feared God greatly.

**[8:9]** Now when she heard the evil words of the people against the governor, that they fainted for lack of water; for Judith had heard all the words that Ozias had spoken unto them, and that he had sworn to deliver the city unto the Assyrians after five days;

**[8:10]** Then she sent her waitingwoman, that had the government of all things that she had, to call Ozias and Chabris and Charmis, the ancients of the city.

**[8:11]** And they came unto her, and she said unto them, Hear me now, O ye governors of the inhabitants of Bethulia: for your words that ye have spoken before the people this day are not right, touching this oath which ye made and pronounced between God and you, and have promised to deliver the city to our enemies, unless within these days the Lord turn to help you.

**[8:12]** And now who are ye that have tempted God this day, and stand instead of God among the children of men?

**[8:13]** And now try the Lord Almighty, but ye shall never know any thing.

**[8:14]** For ye cannot find the depth of the heart of man, neither can ye perceive the things that he thinketh: then how can ye search out God, that hath made all these things, and know his mind, or comprehend his purpose? Nay, my brethren, provoke not the Lord our God to anger.

**[8:15]** For if he will not help us within these five days, he hath power to defend us when he will, even every day, or to destroy us before our enemies.

**[8:16]** Do not bind the counsels of the Lord our God: for God is not as man, that he may be threatened; neither is he as the son of man, that he should be wavering.

**[8:17]** Therefore let us wait for salvation of him, and call upon him to help us, and he will hear our voice, if it please him.

**[8:18]** For there arose none in our age, neither is there any now in these days neither tribe, nor family, nor people, nor city among us, which worship gods made with hands, as hath been aforetime.

**[8:19]** For the which cause our fathers were given to the sword, and for a spoil, and had a great fall before our enemies.

**[8:20]** But we know none other god, therefore we trust that he will not despise us, nor any of our nation.

**[8:21]** For if we be taken so, all Judea shall lie waste, and our sanctuary shall be spoiled; and he will require the profanation thereof at our mouth.

**[8:22]** And the slaughter of our brethren, and the captivity of the country, and the desolation of our inheritance, will he turn upon our heads among the Gentiles, wheresoever we shall be in bondage; and we shall be an offence and a reproach to all them that possess us.

**[8:23]** For our servitude shall not be directed to favour: but the Lord our God shall turn it to dishonour.

**[8:24]** Now therefore, O brethren, let us shew an example to our brethren, because their hearts depend upon us, and the sanctuary, and the house, and the altar, rest upon us.

**[8:25]** Moreover let us give thanks to the Lord our God, which trieth us, even as he did our fathers.

**[8:26]** Remember what things he did to Abraham, and how he tried Isaac, and what happened to Jacob in Mesopotamia of Syria, when he kept the sheep of Laban his mother’s brother.

**[8:27]** For he hath not tried us in the fire, as he did them, for the examination of their hearts, neither hath he taken vengeance on us: but the Lord doth scourge them that come near unto him, to admonish them.

**[8:28]** Then said Ozias to her, All that thou hast spoken hast thou spoken with a good heart, and there is none that may gainsay thy words.

**[8:29]** For this is not the first day wherein thy wisdom is manifested; but from the beginning of thy days all the people have known thy understanding, because the disposition of thine heart is good.

**[8:30]** But the people were very thirsty, and compelled us to do unto them as we have spoken, and to bring an oath upon ourselves, which we will not break.

**[8:31]** Therefore now pray thou for us, because thou art a godly woman, and the Lord will send us rain to fill our cisterns, and we shall faint no more.

**[8:32]** Then said Judith unto them, Hear me, and I will do a thing, which shall go throughout all generations to the children of our nation.

**[8:33]** Ye shall stand this night in the gate, and I will go forth with my waitingwoman: and within the days that ye have promised to deliver the city to our enemies the Lord will visit Israel by mine hand.

**[8:34]** But enquire not ye of mine act: for I will not declare it unto you, till the things be finished that I do.

**[8:35]** Then said Ozias and the princes unto her, Go in peace, and the Lord God be before thee, to take vengeance on our enemies.

**[8:36]** So they returned from the tent, and went to their wards.

**[9:1]** Judith fell upon her face, and put ashes upon her head, and uncovered the sackcloth wherewith she was clothed; and about the time that the incense of that evening was offered in Jerusalem in the house of the Lord Judith cried with a loud voice, and said,

**[9:2]** O Lord God of my father Simeon, to whom thou gavest a sword to take vengeance of the strangers, who loosened the girdle of a maid to defile her, and discovered the thigh to her shame, and polluted her virginity to her reproach; for thou saidst, It shall not be so; and yet they did so:

**[9:3]** Wherefore thou gavest their rulers to be slain, so that they dyed their bed in blood, being deceived, and smotest the servants with their lords, and the lords upon their thrones;

**[9:4]** And hast given their wives for a prey, and their daughters to be captives, and all their spoils to be divided among thy dear children; which were moved with thy zeal, and abhorred the pollution of their blood, and called upon thee for aid: O God, O my God, hear me also a widow.

**[9:5]** For thou hast wrought not only those things, but also the things which fell out before, and which ensued after; thou hast thought upon the things which are now, and which are to come.

**[9:6]** Yea, what things thou didst determine were ready at hand, and said, Lo, we are here: for all thy ways are prepared, and thy judgments are in thy foreknowledge.

**[9:7]** For, behold, the Assyrians are multiplied in their power; they are exalted with horse and man; they glory in the strength of their footmen; they trust in shield, and spear, and bow, and sling; and know not that thou art the Lord that breakest the battles: the Lord is thy name.

**[9:8]** Throw down their strength in thy power, and bring down their force in thy wrath: for they have purposed to defile thy sanctuary, and to pollute the tabernacle where thy glorious name resteth and to cast down with sword the horn of thy altar.

**[9:9]** Behold their pride, and send thy wrath upon their heads: give into mine hand, which am a widow, the power that I have conceived.

**[9:10]** Smite by the deceit of my lips the servant with the prince, and the prince with the servant: break down their stateliness by the hand of a woman.

**[9:11]** For thy power standeth not in multitude nor thy might in strong men: for thou art a God of the afflicted, an helper of the oppressed, an upholder of the weak, a protector of the forlorn, a saviour of them that are without hope.

**[9:12]** I pray thee, I pray thee, O God of my father, and God of the inheritance of Israel, Lord of the heavens and earth, Creator of the waters, king of every creature, hear thou my prayer:

**[9:13]** And make my speech and deceit to be their wound and stripe, who have purposed cruel things against thy covenant, and thy hallowed house, and against the top of Sion, and against the house of the possession of thy children.

**[9:14]** And make every nation and tribe to acknowledge that thou art the God of all power and might, and that there is none other that protecteth the people of Israel but thou.

**[10:1]** Now after that she had ceased to cry unto the God of Israel, and bad made an end of all these words.

**[10:2]** She rose where she had fallen down, and called her maid, and went down into the house in the which she abode in the sabbath days, and in her feast days,

**[10:3]** And pulled off the sackcloth which she had on, and put off the garments of her widowhood, and washed her body all over with water, and anointed herself with precious ointment, and braided the hair of her head, and put on a tire upon it, and put on her garments of gladness, wherewith she was clad during the life of Manasses her husband.

**[10:4]** And she took sandals upon her feet, and put about her her bracelets, and her chains, and her rings, and her earrings, and all her ornaments, and decked herself bravely, to allure the eyes of all men that should see her.

**[10:5]** Then she gave her maid a bottle of wine, and a cruse of oil, and filled a bag with parched corn, and lumps of figs, and with fine bread; so she folded all these things together, and laid them upon her.

**[10:6]** Thus they went forth to the gate of the city of Bethulia, and found standing there Ozias and the ancients of the city, Chabris and Charmis.

**[10:7]** And when they saw her, that her countenance was altered, and her apparel was changed, they wondered at her beauty very greatly, and said unto her.

**[10:8]** The God, the God of our fathers give thee favour, and accomplish thine enterprizes to the glory of the children of Israel, and to the exaltation of Jerusalem. Then they worshipped God.

**[10:9]** And she said unto them, Command the gates of the city to be opened unto me, that I may go forth to accomplish the things whereof ye have spoken with me. So they commanded the young men to open unto her, as she had spoken.

**[10:10]** And when they had done so, Judith went out, she, and her maid with her; and the men of the city looked after her, until she was gone down the mountain, and till she had passed the valley, and could see her no more.

**[10:11]** Thus they went straight forth in the valley: and the first watch of the Assyrians met her,

**[10:12]** And took her, and asked her, Of what people art thou? and whence comest thou? and whither goest thou? And she said, I am a woman of the Hebrews, and am fled from them: for they shall be given you to be consumed:

**[10:13]** And I am coming before Holofernes the chief captain of your army, to declare words of truth; and I will shew him a way, whereby he shall go, and win all the hill country, without losing the body or life of any one of his men.

**[10:14]** Now when the men heard her words, and beheld her countenance, they wondered greatly at her beauty, and said unto her,

**[10:15]** Thou hast saved thy life, in that thou hast hasted to come down to the presence of our lord: now therefore come to his tent, and some of us shall conduct thee, until they have delivered thee to his hands.

**[10:16]** And when thou standest before him, be not afraid in thine heart, but shew unto him according to thy word; and he will entreat thee well.

**[10:17]** Then they chose out of them an hundred men to accompany her and her maid; and they brought her to the tent of Holofernes.

**[10:18]** Then was there a concourse throughout all the camp: for her coming was noised among the tents, and they came about her, as she stood without the tent of Holofernes, till they told him of her.

**[10:19]** And they wondered at her beauty, and admired the children of Israel because of her, and every one said to his neighbour, Who would despise this people, that have among them such women? surely it is not good that one man of them be left who being let go might deceive the whole earth.

**[10:20]** And they that lay near Holofernes went out, and all his servants and they brought her into the tent.

**[10:21]** Now Holofernes rested upon his bed under a canopy, which was woven with purple, and gold, and emeralds, and precious stones.

**[10:22]** So they shewed him of her; and he came out before his tent with silver lamps going before him.

**[10:23]** And when Judith was come before him and his servants they all marvelled at the beauty of her countenance; and she fell down upon her face, and did reverence unto him: and his servants took her up.

**[11:1]** Then said Holofernes unto her, Woman, be of good comfort, fear not in thine heart: for I never hurt any that was willing to serve Nabuchodonosor, the king of all the earth.

**[11:2]** Now therefore, if thy people that dwelleth in the mountains had not set light by me, I would not have lifted up my spear against them: but they have done these things to themselves.

**[11:3]** But now tell me wherefore thou art fled from them, and art come unto us: for thou art come for safeguard; be of good comfort, thou shalt live this night, and hereafter:

**[11:4]** For none shall hurt thee, but entreat thee well, as they do the servants of king Nabuchodonosor my lord.

**[11:5]** Then Judith said unto him, Receive the words of thy servant, and suffer thine handmaid to speak in thy presence, and I will declare no lie to my lord this night.

**[11:6]** And if thou wilt follow the words of thine handmaid, God will bring the thing perfectly to pass by thee; and my lord shall not fail of his purposes.

**[11:7]** As Nabuchodonosor king of all the earth liveth, and as his power liveth, who hath sent thee for the upholding of every living thing: for not only men shall serve him by thee, but also the beasts of the field, and the cattle, and the fowls of the air, shall live by thy power under Nabuchodonosor and all his house.

**[11:8]** For we have heard of thy wisdom and thy policies, and it is reported in all the earth, that thou only art excellent in all the kingdom, and mighty in knowledge, and wonderful in feats of war.

**[11:9]** Now as concerning the matter, which Achior did speak in thy council, we have heard his words; for the men of Bethulia saved him, and he declared unto them all that he had spoken unto thee.

**[11:10]** Therefore, O lord and governor, respect not his word; but lay it up in thine heart, for it is true: for our nation shall not be punished, neither can sword prevail against them, except they sin against their God.

**[11:11]** And now, that my lord be not defeated and frustrate of his purpose, even death is now fallen upon them, and their sin hath overtaken them, wherewith they will provoke their God to anger whensoever they shall do that which is not fit to be done:

**[11:12]** For their victuals fail them, and all their water is scant, and they have determined to lay hands upon their cattle, and purposed to consume all those things, that God hath forbidden them to eat by his laws:

**[11:13]** And are resolved to spend the firstfruits of the the tenths of wine and oil, which they had sanctified, and reserved for the priests that serve in Jerusalem before the face of our God; the which things it is not lawful for any of the people so much as to touch with their hands.

**[11:14]** For they have sent some to Jerusalem, because they also that dwell there have done the like, to bring them a licence from the senate.

**[11:15]** Now when they shall bring them word, they will forthwith do it, and they shall be given to thee to be destroyed the same day.

**[11:16]** Wherefore I thine handmaid, knowing all this, am fled from their presence; and God hath sent me to work things with thee, whereat all the earth shall be astonished, and whosoever shall hear it.

**[11:17]** For thy servant is religious, and serveth the God of heaven day and night: now therefore, my lord, I will remain with thee, and thy servant will go out by night into the valley, and I will pray unto God, and he will tell me when they have committed their sins:

**[11:18]** And I will come and shew it unto thee: then thou shalt go forth with all thine army, and there shall be none of them that shall resist thee.

**[11:19]** And I will lead thee through the midst of Judea, until thou come before Jerusalem; and I will set thy throne in the midst thereof; and thou shalt drive them as sheep that have no shepherd, and a dog shall not so much as open his mouth at thee: for these things were told me according to my foreknowledge, and they were declared unto me, and I am sent to tell thee.

**[11:20]** Then her words pleased Holofernes and all his servants; and they marvelled at her wisdom, and said,

**[11:21]** There is not such a woman from one end of the earth to the other, both for beauty of face, and wisdom of words.

**[11:22]** Likewise Holofernes said unto her. God hath done well to send thee before the people, that strength might be in our hands and destruction upon them that lightly regard my lord.

**[11:23]** And now thou art both beautiful in thy countenance, and witty in thy words: surely if thou do as thou hast spoken thy God shall be my God, and thou shalt dwell in the house of king Nabuchodonosor, and shalt be renowned through the whole earth.

**[12:1]** Then he commanded to bring her in where his plate was set; and bade that they should prepare for her of his own meats, and that she should drink of his own wine.

**[12:2]** And Judith said, I will not eat thereof, lest there be an offence: but provision shall be made for me of the things that I have brought.

**[12:3]** Then Holofernes said unto her, If thy provision should fail, how should we give thee the like? for there be none with us of thy nation.

**[12:4]** Then said Judith unto him As thy soul liveth, my lord, thine handmaid shall not spend those things that I have, before the Lord work by mine hand the things that he hath determined.

**[12:5]** Then the servants of Holofernes brought her into the tent, and she slept till midnight, and she arose when it was toward the morning watch,

**[12:6]** And sent to Holofernes, saving, Let my lord now command that thine handmaid may go forth unto prayer.

**[12:7]** Then Holofernes commanded his guard that they should not stay her: thus she abode in the camp three days, and went out in the night into the valley of Bethulia, and washed herself in a fountain of water by the camp.

**[12:8]** And when she came out, she besought the Lord God of Israel to direct her way to the raising up of the children of her people.

**[12:9]** So she came in clean, and remained in the tent, until she did eat her meat at evening.

**[12:10]** And in the fourth day Holofernes made a feast to his own servants only, and called none of the officers to the banquet.

**[12:11]** Then said he to Bagoas the eunuch, who had charge over all that he had, Go now, and persuade this Hebrew woman which is with thee, that she come unto us, and eat and drink with us.

**[12:12]** For, lo, it will be a shame for our person, if we shall let such a woman go, not having had her company; for if we draw her not unto us, she will laugh us to scorn.

**[12:13]** Then went Bagoas from the presence of Holofernes, and came to her, and he said, Let not this fair damsel fear to come to my lord, and to be honoured in his presence, and drink wine, and be merry with us and be made this day as one of the daughters of the Assyrians, which serve in the house of Nabuchodonosor.

**[12:14]** Then said Judith unto him, Who am I now, that I should gainsay my lord? surely whatsoever pleaseth him I will do speedily, and it shall be my joy unto the day of my death.

**[12:15]** So she arose, and decked herself with her apparel and all her woman’s attire, and her maid went and laid soft skins on the ground for her over against Holofernes, which she had received of Bagoas far her daily use, that she might sit and eat upon them.

**[12:16]** Now when Judith came in and sat down, Holofernes his heart was ravished with her, and his mind was moved, and he desired greatly her company; for he waited a time to deceive her, from the day that he had seen her.

**[12:17]** Then said Holofernes unto her, Drink now, and be merry with us.

**[12:18]** So Judith said, I will drink now, my lord, because my life is magnified in me this day more than all the days since I was born.

**[12:19]** Then she took and ate and drank before him what her maid had prepared.

**[12:20]** And Holofernes took great delight in her, and drank more wine than he had drunk at any time in one day since he was born.

**[13:1]** Now when the evening was come, his servants made haste to depart, and Bagoas shut his tent without, and dismissed the waiters from the presence of his lord; and they went to their beds: for they were all weary, because the feast had been long.

**[13:2]** And Judith was left along in the tent, and Holofernes lying along upon his bed: for he was filled with wine.

**[13:3]** Now Judith had commanded her maid to stand without her bedchamber, and to wait for her. coming forth, as she did daily: for she said she would go forth to her prayers, and she spake to Bagoas according to the same purpose.

**[13:4]** So all went forth and none was left in the bedchamber, neither little nor great. Then Judith, standing by his bed, said in her heart, O Lord God of all power, look at this present upon the works of mine hands for the exaltation of Jerusalem.

**[13:5]** For now is the time to help thine inheritance, and to execute thine enterprizes to the destruction of the enemies which are risen against us.

**[13:6]** Then she came to the pillar of the bed, which was at Holofernes’ head, and took down his fauchion from thence,

**[13:7]** And approached to his bed, and took hold of the hair of his head, and said, Strengthen me, O Lord God of Israel, this day.

**[13:8]** And she smote twice upon his neck with all her might, and she took away his head from him.

**[13:9]** And tumbled his body down from the bed, and pulled down the canopy from the pillars; and anon after she went forth, and gave Holofernes his head to her maid;

**[13:10]** And she put it in her bag of meat: so they twain went together according to their custom unto prayer: and when they passed the camp, they compassed the valley, and went up the mountain of Bethulia, and came to the gates thereof.

**[13:11]** Then said Judith afar off, to the watchmen at the gate, Open, open now the gate: God, even our God, is with us, to shew his power yet in Jerusalem, and his forces against the enemy, as he hath even done this day.

**[13:12]** Now when the men of her city heard her voice, they made haste to go down to the gate of their city, and they called the elders of the city.

**[13:13]** And then they ran all together, both small and great, for it was strange unto them that she was come: so they opened the gate, and received them, and made a fire for a light, and stood round about them.

**[13:14]** Then she said to them with a loud voice, Praise, praise God, praise God, I say, for he hath not taken away his mercy from the house of Israel, but hath destroyed our enemies by mine hands this night.

**[13:15]** So she took the head out of the bag, and shewed it, and said unto them, behold the head of Holofernes, the chief captain of the army of Assur, and behold the canopy, wherein he did lie in his drunkenness; and the Lord hath smitten him by the hand of a woman.

**[13:16]** As the Lord liveth, who hath kept me in my way that I went, my countenance hath deceived him to his destruction, and yet hath he not committed sin with me, to defile and shame me.

**[13:17]** Then all the people were wonderfully astonished, and bowed themselves and worshipped God, and said with one accord, Blessed be thou, O our God, which hast this day brought to nought the enemies of thy people.

**[13:18]** Then said Ozias unto her, O daughter, blessed art thou of the most high God above all the women upon the earth; and blessed be the Lord God, which hath created the heavens and the earth, which hath directed thee to the cutting off of the head of the chief of our enemies.

**[13:19]** For this thy confidence shall not depart from the heart of men, which remember the power of God for ever.

**[13:20]** And God turn these things to thee for a perpetual praise, to visit thee in good things because thou hast not spared thy life for the affliction of our nation, but hast revenged our ruin, walking a straight way before our God. And all the people said; So be it, so be it.

**[14:1]** Then said Judith unto them, Hear me now, my brethren, and take this head, and hang it upon the highest place of your walls.

**[14:2]** And so soon as the morning shall appear, and the sun shall come forth upon the earth, take ye every one his weapons, and go forth every valiant man out of the city, and set ye a captain over them, as though ye would go down into the field toward the watch of the Assyrians; but go not down.

**[14:3]** Then they shall take their armour, and shall go into their camp, and raise up the captains of the army of Assur, and shall run to the tent of Holofernes, but shall not find him: then fear shall fall upon them, and they shall flee before your face.

**[14:4]** So ye, and all that inhabit the coast of Israel, shall pursue them, and overthrow them as they go.

**[14:5]** But before ye do these things, call me Achior the Ammonite, that he may see and know him that despised the house of Israel, and that sent him to us as it were to his death.

**[14:6]** Then they called Achior out of the house of Ozias; and when he was come, and saw the head of Holofernes in a man’s hand in the assembly of the people, he fell down on his face, and his spirit failed.

**[14:7]** But when they had recovered him, he fell at Judith’s feet, and reverenced her, and said, Blessed art thou in all the tabernacles of Juda, and in all nations, which hearing thy name shall be astonished.

**[14:8]** Now therefore tell me all the things that thou hast done in these days. Then Judith declared unto him in the midst of the people all that she had done, from the day that she went forth until that hour she spake unto them.

**[14:9]** And when she had left off speaking, the people shouted with a loud voice, and made a joyful noise in their city.

**[14:10]** And when Achior had seen all that the God of Israel had done, he believed in God greatly, and circumcised the flesh of his foreskin, and was joined unto the house of Israel unto this day.

**[14:11]** And as soon as the morning arose, they hanged the head of Holofernes upon the wall, and every man took his weapons, and they went forth by bands unto the straits of the mountain.

**[14:12]** But when the Assyrians saw them, they sent to their leaders, which came to their captains and tribunes, and to every one of their rulers.

**[14:13]** So they came to Holofernes’ tent, and said to him that had the charge of all his things, Waken now our lord: for the slaves have been bold to come down against us to battle, that they may be utterly destroyed.

**[14:14]** Then went in Bagoas, and knocked at the door of the tent; for he thought that he had slept with Judith.

**[14:15]** But because none answered, he opened it, and went into the bedchamber, and found him cast upon the floor dead, and his head was taken from him.

**[14:16]** Therefore he cried with a loud voice, with weeping, and sighing, and a mighty cry, and rent his garments.

**[14:17]** After he went into the tent where Judith lodged: and when he found her not, he leaped out to the people, and cried,

**[14:18]** These slaves have dealt treacherously; one woman of the Hebrews hath brought shame upon the house of king Nabuchodonosor: for, behold, Holofernes lieth upon the ground without a head.

**[14:19]** When the captains of the Assyrians’ army heard these words, they rent their coats and their minds were wonderfully troubled, and there was a cry and a very great noise throughout the camp.

**[15:1]** And when they that were in the tents heard, they were astonished at the thing that was done.

**[15:2]** And fear and trembling fell upon them, so that there was no man that durst abide in the sight of his neighbour, but rushing out all together, they fled into every way of the plain, and of the hill country.

**[15:3]** They also that had camped in the mountains round about Bethulia fled away. Then the children of Israel, every one that was a warrior among them, rushed out upon them.

**[15:4]** Then sent Ozias to Betomasthem, and to Bebai, and Chobai, and Cola and to all the coasts of Israel, such as should tell the things that were done, and that all should rush forth upon their enemies to destroy them.

**[15:5]** Now when the children of Israel heard it, they all fell upon them with one consent, and slew them unto Chobai: likewise also they that came from Jerusalem, and from all the hill country, (for men had told them what things were done in the camp of their enemies) and they that were in Galaad, and in Galilee, chased them with a great slaughter, until they were past Damascus and the borders thereof.

**[15:6]** And the residue that dwelt at Bethulia, fell upon the camp of Assur, and spoiled them, and were greatly enriched.

**[15:7]** And the children of Israel that returned from the slaughter had that which remained; and the villages and the cities, that were in the mountains and in the plain, gat many spoils: for the multitude was very great.

**[15:8]** Then Joacim the high priest, and the ancients of the children of Israel that dwelt in Jerusalem, came to behold the good things that God had shewed to Israel, and to see Judith, and to salute her.

**[15:9]** And when they came unto her, they blessed her with one accord, and said unto her, Thou art the exaltation of Jerusalem, thou art the great glory of Israel, thou art the great rejoicing of our nation:

**[15:10]** Thou hast done all these things by thine hand: thou hast done much good to Israel, and God is pleased therewith: blessed be thou of the Almighty Lord for evermore. And all the people said, So be it.

**[15:11]** And the people spoiled the camp the space of thirty days: and they gave unto Judith Holofernes his tent, and all his plate, and beds, and vessels, and all his stuff: and she took it and laid it on her mule; and made ready her carts, and laid them thereon.

**[15:12]** Then all the women of Israel ran together to see her, and blessed her, and made a dance among them for her: and she took branches in her hand, and gave also to the women that were with her.

**[15:13]** And they put a garland of olive upon her and her maid that was with her, and she went before all the people in the dance, leading all the women: and all the men of Israel followed in their armour with garlands, and with songs in their mouths.

**[16:1]** Then Judith began to sing this thanksgiving in all Israel, and all the people sang after her this song of praise.

**[16:2]** And Judith said, Begin unto my God with timbrels, sing unto my Lord with cymbals: tune unto him a new psalm: exalt him, and call upon his name.

**[16:3]** For God breaketh the battles: for among the camps in the midst of the people he hath delivered me out of the hands of them that persecuted me.

**[16:4]** Assur came out of the mountains from the north, he came with ten thousands of his army, the multitude whereof stopped the torrents, and their horsemen have covered the hills.

**[16:5]** He bragged that he would burn up my borders, and kill my young men with the sword, and dash the sucking children against the ground, and make mine infants as a prey, and my virgins as a spoil.

**[16:6]** But the Almighty Lord hath disappointed them by the hand of a woman.

**[16:7]** For the mighty one did not fall by the young men, neither did the sons of the Titans smite him, nor high giants set upon him: but Judith the daughter of Merari weakened him with the beauty of her countenance.

**[16:8]** For she put off the garment of her widowhood for the exaltation of those that were oppressed in Israel, and anointed her face with ointment, and bound her hair in a tire, and took a linen garment to deceive him.

**[16:9]** Her sandals ravished his eyes, her beauty took his mind prisoner, and the fauchion passed through his neck.

**[16:10]** The Persians quaked at her boldness, and the Medes were daunted at her hardiness.

**[16:11]** Then my afflicted shouted for joy, and my weak ones cried aloud; but they were astonished: these lifted up their voices, but they were overthrown.

**[16:12]** The sons of the damsels have pierced them through, and wounded them as fugatives’ children: they perished by the battle of the Lord.

**[16:13]** I will sing unto the Lord a new song: O Lord, thou art great and glorious, wonderful in strength, and invincible.

**[16:14]** Let all creatures serve thee: for thou spakest, and they were made, thou didst send forth thy spirit, and it created them, and there is none that can resist thy voice.

**[16:15]** For the mountains shall be moved from their foundations with the waters, the rocks shall melt as wax at thy presence: yet thou art merciful to them that fear thee.

**[16:16]** For all sacrifice is too little for a sweet savour unto thee, and all the fat is not sufficient for thy burnt offering: but he that feareth the Lord is great at all times.

**[16:17]** Woe to the nations that rise up against my kindred! the Lord Almighty will take vengeance of them in the day of judgment, in putting fire and worms in their flesh; and they shall feel them, and weep for ever.

**[16:18]** Now as soon as they entered into Jerusalem, they worshipped the Lord; and as soon as the people were purified, they offered their burnt offerings, and their free offerings, and their gifts.

**[16:19]** Judith also dedicated all the stuff of Holofernes, which the people had given her, and gave the canopy, which she had taken out of his bedchamber, for a gift unto the Lord.

**[16:20]** So the people continued feasting in Jerusalem before the sanctuary for the space of three months and Judith remained with them.

**[16:21]** After this time every one returned to his own inheritance, and Judith went to Bethulia, and remained in her own possession, and was in her time honourable in all the country.

**[16:22]** And many desired her, but none knew her all the days of her life, after that Manasses her husband was dead, and was gathered to his people.

**[16:23]** But she increased more and more in honour, and waxed old in her husband’s house, being an hundred and five years old, and made her maid free; so she died in Bethulia: and they buried her in the cave of her husband Manasses.

**[16:24]** And the house of Israel lamented her seven days: and before she died, she did distribute her goods to all them that were nearest of kindred to Manasses her husband, and to them that were the nearest of her kindred.

**[16:25]** And there was none that made the children of Israel any more afraid in the days of Judith, nor a long time after her death.

