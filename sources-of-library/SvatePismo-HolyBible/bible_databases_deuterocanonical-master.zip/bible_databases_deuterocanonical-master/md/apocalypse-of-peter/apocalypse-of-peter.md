# Apocalypse of Peter



**[1:1]** The Second Coming of Christ and Resurrection of the Dead (which Christ revealed unto Peter) who died because of their sins, for that they kept not the commandment of God their creator. 

**[1:2]** And he (Peter) pondered thereon, that he might perceive the mystery of the Son of God, the merciful and lover of mercy. 

**[1:3]** And when the Lord was seated upon the Mount of Olives, his disciples came unto him. 

**[1:4]** And we besought and entreated him severally and prayed him, saying unto him: Declare unto us what are the signs of thy coming and of the end of the world, that we may perceive and mark the time of thy coming and instruct them that come after us, unto whom we preach the word of thy gospel, and whom we set over (in) thy church, that they when they hear it may take heed to themselves and mark the time of thy coming. 

**[1:5]** And our Lord answered us, saying: Take heed that no man deceive you, and that ye be not doubters and serve other gods. Many shall come in my name, saying: I am the Christ. Believe them not, neither draw near unto them. For the coming of the Son of God shall not be plain; but as the lightning that shineth from the east unto the west, so will I come upon the clouds of heaven with a great host in my majesty; with my cross going before my face will I come in my majesty, shining sevenfold more than the sun will I come in my majesty with all my saints, mine angels. And my Father shall set a crown upon mine head, that I may judge the quick and the dead and recompense every man according to his works.

**[2:1]** And ye, take ye the likeness thereof (learn a parable) from the fig-tree: so soon as the shoot thereof is come forth and the twigs grown, the end of the world shall come. 

**[2:2]** And I, Peter, answered and said unto him: Interpret unto me concerning the fig-tree, whereby we shall perceive it; for throughout all its days doth the fig-tree send forth shoots, and every year it bringeth forth its fruit for its master. What then meaneth the parable of the fig-tree? We know it not. 

**[2:3]** And the Master answered and said unto me: Understandest thou not that the fig-tree is the house of Israel? Even as a man that planted a fig-tree in his garden, and it brought forth no fruit. And he sought the fruit thereof many years and when he found it not, he said to the keeper of his garden: Root up this fig-tree that it make not our ground to be unfruitful. And the gardener said unto God: Suffer us to rid it of weeds and dig the ground round about it and water it. If then it bear not fruit, we will straightway remove its roots out of the garden and plant another in place of it. 4. Hast thou not understood that the fig-tree is the house of Israel? Verily I say unto thee, when the twigs thereof have sprouted forth in the last days, then shall feigned Christs come and awake expectation saying: I am the Christ, that am now come into the world. And when they shall perceive the wickedness of their deeds they shall turn away after them and deny him [whom our fathers did praise], even the first Christ whom they crucified and therein sinned a great sin. But this deceiver is not the Christ. And when they reject him he shall slay with the sword, and there shall be many martyrs. 5. Then shall the twigs of the fig-tree, that is, the house of Israel, shoot forth: many shall become martyrs at his hand. Enoch and Elias shall be sent to teach them that this is the deceiver which must come into the world and do signs and wonders to deceive. And therefore shall they that die by his hand be martyrs, and shall be reckoned among the good and righteous martyrs who have pleased God in their life.

**[3:1]** And he showed me in his right hand the souls of all men, And on the palm of his right hand the image of that which shall be accomplished at the last day: and how the righteous and the sinners shall be separated, and how they do that are upright in heart, and how the evil-doers shall be rooted out unto all eternity. We beheld how the sinners wept in great affliction and sorrow, until all that saw it with their eyes wept, whether righteous or angels, and he himself also. 

**[3:2]** And I asked him and said unto him: Lord, suffer me to speak thy word concerning the sinners: It were better for them if they had not been created. And the Saviour answered and said unto me: Peter, wherefore speakest thou thus, that not to have been created were better for them? Thou resistest God. Thou wouldest not have more compassion than he for his image: for he hath created them and brought them forth out of not being. Now because thou hast seen the lamentation which shall come upon the sinners in the last days, therefore is thine heart troubled; but I will show thee their works, whereby they have sinned against the Most High.

**[4:1]** Behold now what shall come upon them in the last days, when the day of God and the day of the decision of the judgement of God cometh. From the east unto the west shall all the children of men be gathered together before my Father that liveth for ever. And he shall command hell to open its bars of adamant and give up all that is therein. 

**[4:2]** And the wild beasts and the fowls shall he command to restore all the flesh that they have devoured, because he willeth that men should appear; for nothing perisheth before God, and nothing is impossible with him, because all things are his. 

**[4:3]** For all things come to pass on the day of decision, on the day of judgement, at the word of God: and as all things were done when he created the world and commanded all that is therein and it was done -even so shall it be in the last days; for all things are possible with God. And therefore saith he in the scripture: Son of man, prophesy upon the several bones and say unto the bones: bone unto bone in joints, sinew. nerves, flesh and skin and hair thereon 

[and soul and spirit]. 

**[4:4]** And soul and spirit shall the great Uriel give them at the commandment of God; for him hath God set over the rising again of the dead at the day of judgement. 

**[4:5]** Behold and consider the corns of wheat that are sown in the earth. As things dry and without soul do men sow them in the earth: and they live again and bear fruit, and the earth restoreth them as a pledge entrusted unto it. 

**[4:6]** And this that dieth, that is sown as seed in the earth, and shall become alive and be restored unto life, is man. 

**[4:7]** How much more shall God raise up on the day of decision them that believe in him and are chosen of him, for whose sake he made the world? And all things shall the earth restore on the day of decision, for it also shall be judged with them, and the heaven with it.

**[5:1]** And this shall come at the day of judgement upon them that have fallen away from faith in God and that have committed sin: Floods of fire shall be let loose; and darkness and obscurity shall come up and clothe and veil the whole world and the waters shall be changed and turned into coals of fire and all that is in them shall burn, and the sea shall become fire. Under the heaven shall be a sharp fire that cannot be quenched and floweth to fulfil the judgement of wrath. And the stars shall fly in pieces by flames of fire, as if they had not been created and the powers (firmaments) of the heaven shall pass away for lack of water and shall be as though they had not been. And the lightnings of heaven shall be no more, and by their enchantment they shall affright the world. The spirits also of the dead bodies shall be like unto them and shall become fire at the commandment of God. 

**[5:2]** And so soon as the whole creation dissolveth, the men that are in the east shall flee unto the west, unto the east; they that are in the south shall flee to the north, and they that are in the south. And in all places shall the wrath of a fearful fire overtake them and an unquenchable flame driving them shall bring them unto the judgement of wrath, unto the stream of unquenchable fire that floweth, flaming with fire, and when the waves thereof part themselves one from another, burning, there shall be a great gnashing of teeth among the children of men.

**[6:1]** Then shall they all behold me coming upon an eternal cloud of brightness: and the angels of God that are with me shall sit upon the throne of my glory at the right hand of my Heavenly Father; and he shall set a crown upon mine head. And when the nations behold it, they shall weep, every nation apart. 

**[6:2]** Then shall he command them to enter into the river of fire while the works of every one of them shall stand before them (something is wanting) to every man according to his deeds. As for the elect that have done good, they shall come unto me and not see death by the devouring fire. But the unrighteous the sinners, and the hypocrites shall stand in the depths of darkness that shall not pass away, and their chastisement is the fire, and angels bring forward their sins and prepare for them a place wherein they shall be punished for ever (every one according to his transgression). 

**[6:3]** Uriel the angel of God shall bring forth the souls of those sinners who perished in the flood, and of all that dwelt in all idols, in every molten image, in every object of love, and in pictures, and of those that dwelt on all hills and in stones and by the wayside, whom men called gods: they shall burn them with them in everlasting fire; and after that all of them with their dwelling places are destroyed, they shall be punished eternally.

**[7:1]** Then shall men and women come unto the place prepared for them. By their tongues wherewith they have blasphemed the way of righteousness shall they be hanged up. There is spread under them unquenchable fire, that they escape it not. 

**[7:2]** Behold, another place: therein is a pit, great and full. In it are they that have denied righteousness: and angels of punishment chastise them and there do they kindle upon them the fire of their torment. 

**[7:3]** And again behold two women: they hang them up by their neck and by their hair; they shall cast them into the pit. These are they which plaited their hair, not for good (or, not to make them beautiful) but to turn them to fornication, that they might ensnare the souls of men unto perdition. And the men that lay with them in fornication shall be hung by their loins in that place of fire; and they shall say one to another: We knew not that we should come unto everlasting punishment. 

**[7:4]** And the murderers and them that have made common cause with them shall they cast into the fire, in a place full of venomous beasts, and they shall be tormented without rest, feeling their pains; and their worms shall be as many in number as a dark cloud. And the angel Ezrael shall bring forth the souls of them that have been slain, and they shall behold the torment of them that slew them, and say one to another: Righteousness and justice is the judgement of God. For we heard, but we believed not, that we should come into this place of eternal judgement.

**[8:1]** And near by this flame shall be a pit, great and very deep, and into it floweth from above all manner of torment, foulness, and issue. And women are swallowed up therein up to their necks and tormented with great pain. These are they that have caused their children to be born untimely, and have corrupted the work of God that created them. Over against them shall be another place where sit their children 

[both] alive, and they cry unto God. And flashes (lightnings) go forth from those children and pierce the eyes of them that for fornication's sake have caused their destruction. 

**[8:2]** Other men and women shall stand above them, naked; and their children stand over against them in a place of delight, and sigh and cry unto God because of their parents, saying: These are they that have despised and cursed and transgressed thy commandments and delivered us unto death: they have cursed the angel that formed us, and have hanged us up, and withheld from us the light which thou hast given unto all creatures. And the milk of their mothers flowing from their breasts shall congeal, and from it shall come beasts devouring flesh, which shall come forth and turn and torment them for ever with their husbands, because they forsook the commandments of God and slew their children. As for their children, they shall be delivered unto the angel Temlakos. And they that slew them shall be tormented eternally, for God willeth it so.

**[9:1]** Ezrael the angel of wrath shall bring men and women, the half of their bodies burning, and cast them into a place of darkness, even the hell of men; and a spirit of wrath shall chastise them with all manner of torment, and a worm that sleepeth not shall devour their entrails: and these are the persecutors and betrayers of my righteous ones. 

**[9:2]** And beside them that are there, shall be other men and women, gnawing their tongues; and they shall torment them with red-hot iron and burn their eyes. These are they that slander and doubt of my righteousness. Other men and women whose works were done in deceitfulness shall have their lips cut off, and fire entereth into their mouth and their entrails. These are the false witnesses. 

**[9:3]** And beside them, in a place near at hand, upon the stone shall be a pillar of fire, and the pillar is sharper than swords. And there shall be men and women clad in rags and filthy garments, and they shall be cast thereon, to suffer the judgement of a torment that ceaseth not: these are they that trusted in their riches and despised the widows and the woman with fatherless children . . . before God.

**[10:1]** And into another place hard by, full of filth, do they cast men and women up to the knees. These are they that lent money and took usury. 

**[10:2]** And other men and women cast themselves down from an high place and return again and run, and devils drive them. These are the worshippers of idols and they put them to the end of their witst drive them up to the top of the height and they cast themselves down. And thus do they continually, and are tormented for ever. These are they which have cut their flesh as 

[apostles] of a man: and the women that were with them . . . and these are the men that defiled themselves together as women. 

**[10:3]** And beside them . . . and beneath them shall the angel Ezrael prepare a place of much fire: and all the idols of gold and silver, all idols, the work of men's hands, and the semblances of images of cats and lions, of creeping things and wild beasts, and the men and women that have prepared the images thereof, shall be in chains of fire and shall be chastised because of their error before the idols, and this is their judgement for ever. 

**[10:4]** And beside them shall be other men and women, burning in the fire of the judgement, and their torment is everlasting. These are they that have forsaken the commandment of God and followed the (persuasions ?) of devils.

**[11:1]** And there shall be another place, very high. There shall be a furnace and a brazier wherein shall burn fire. The fire that shall burn shall come from one end of the brazier. The men and women whose feet slip, shall go rolling down into a place where is fear. And again while the fire that is prepared floweth, they mount up and fall down again and continue to roll down. Thus shall they be tormented for ever. These are they that honoured not their father and mother and of their own accord withheld themselves from them. Therefore shall they be chastised eternally. 

**[11:2]** Furthermore the angel Ezrael shall bring children and maidens to show them those that are tormented. They shall be chastised with pains, with hanging up and with a multitude of wounds which flesh-devouring birds shall inflict upon them. These are they that trust (boast) in their sins, and obey not their parents and follow not the instruction of their fathers, and honour not them that are more aged than they. 

**[11:3]** Beside them shall be girls clad in darkness for a garment and they shall be sore chastised and their flesh shall be torn in pieces. These are they that kept not their virginity until they were given in marriage, and with these torments shall they be punished, and shall feel them. 

**[11:4]** And again, other men and women, gnawing their tongues without ceasing, and being tormented with everlasting fire. These are the servants which were not obedient unto their masters; and this then is their judgement for ever.

**[12:1]** And hard by this place of torment shall be men and women dumb and blind, whose raiment is white. They shall crowd one upon another, and fall upon coals of unquenchable fire. These are they that give alms and say: We are righteous before God: whereas they have not sought after righteousness. 

**[12:2]** Ezrael the angel of God shall bring them forth out of this fire and establish a judgement of decision. This then is their judgement. A river of fire shall flow and all judgement (they that are judged) shall be drawn down into the middle of the river. And Uriel shall set them there. 

**[12:3]** And there are wheels of fire and men and women hung thereon by the strength of the whirling thereof. And they that are in the pit shall burn: now these are the sorcerers and sorceresses. Those wheels shall be in a]l decision (judgement, punishment) by fire without number.

**[13:1]** Thereafter shall the angels bring mine elect and righteous which are perfect in all uprightness, and bear them in their hands, and clothe them with the raiment of the life that is above. They shall see their desire on them that hated them, when he punisheth them, and the torment of every one shall be for ever according to his works. 

**[13:2]** And all they that are in torment shall say with one voice: have mercy upon us, for now know we the judgement of God, which he declared unto us aforetime, and we believed not. And the angel Tatirokos shall come and chastise them with yet greater torment, and say unto them: Now do ye repent, when it is no longer the time for repentance, and nought of life remaineth. And they shall say: Righteous is the judgement of God, for we have heard and perceived that his judgement is good; for we are recompensed according to our deeds.

**[14:1]** Then will I give unto mine elect and righteous the washing (baptism) and the salvation for which they have besought me, in the field of Akrosja which is called Aneslasleja (Elysium). They shall adorn with flowers the portion of the righteous, and I shall go . . . I shall rejoice with them. I will cause the peoples to enter in to mine everlasting kingdom, and show them that eternal thing (life ?) whereon I have made them to set their hope, even I and my Father which is in heaven. 

**[14:2]** I have spoken this unto thee, Peter, and declared it unto thee. Go forth therefore and go unto the land (or city) of the west and enter into the vineyard which I shall tell thee of, in order that by the sickness (sufferings) of the Son who is without sin the deeds of corruption may be sanctified. As for thee, thou art chosen according to the promise which I have given thee. Spread thou therefore my gospel throughout all the world in peace. Verily men shall rejoice: my words shall be the source of hope and of life, and suddenly shall the world be ravished.

**[15:1]** And my Lord Jesus Christ our King said unto me: Let us go unto the holy mountain. And his disciples went with him, praying. And behold there were two men there, and we could not look upon their faces, for a light came from them, shining more than the sun, and their raiment also was shining, and cannot be described, and nothing is sufficient to be compared unto them in this world. And the sweetness of them . . . that no mouth is able to utter the beauty of their appearance, for their aspect was astonishing and wonderful. And the other, great, I say, shineth in his aspect above crystal. Like the flower of roses is the appearance of the colour of his aspect and of his body . . . his head. And upon his shoulders and on their foreheads was a crown of nard woven of fair flowers. As the rainbow in the water, so was their hair. And such was the comeliness of their countenance, adorned with all manner of ornament.

**[16:1]** And when we saw them on a sudden, we marvelled. And I drew near unto the Lord (God) Jesus Christ and said unto him: O my Lord, who are these? And he said unto me: They are Moses and Elias. And I said unto him: Abraham and Isaac and Jacob and the rest of the righteous fathers? And he showed us a great garden, open, full of fair trees and blessed fruits, and of the odour of perfumes. The fragrance thereof was pleasant and came even unto us. And thereof . . . saw I much fruit. And my Lord and God Jesus Christ said unto me: Hast thou seen the companies of the fathers? 

**[16:2]** As is their rest, such also is the honour and the glory of them that are persecuted for my righteousness' sake. And I rejoiced and believed and understood that which is written in the book of my Lord Jesus Christ. And I said unto him: O my Lord, wilt thou that I make here three tabernacles, one for thee, and one for Moses, and one for Elias? And he said unto me in wrath: Satan maketh war against thee, and hath veiled thine understanding; and the good things of this world prevail against thee. Thine eyes therefore must be opened and thine ears unstopped that a tabernacle, not made with men's hands, which my heavenly Father hath made for me and for the elect. And we beheld it and were full of gladness.

**[17:1]** And behold, suddenly there came a voice from heaven, saying: This is my beloved Son in whom I am well pleased: my commandments. And then came a great and exceeding white cloud over our heads and bare away our Lord and Moses and Elias. And I trembled and was afraid: and we looked up and the heaven opened and we beheld men in the flesh, and they came and greeted our Lord and Moses and Elias and went into another heaven. And the word of the scripture was fulfilled: This is the generation that seeketh him and seeketh the face of the God of Jacob. And great fear and commotion was there in heaven and the angels pressed one upon another that the word of the scripture might be fulfilled which saith: Open the gates, ye princes. 

**[17:2]** Thereafter was the heaven shut, that had been open. 

**[17:3]** And we prayed and went down from the mountain, glorifying God, which hath written the names of the righteous in heaven in the book of life.

