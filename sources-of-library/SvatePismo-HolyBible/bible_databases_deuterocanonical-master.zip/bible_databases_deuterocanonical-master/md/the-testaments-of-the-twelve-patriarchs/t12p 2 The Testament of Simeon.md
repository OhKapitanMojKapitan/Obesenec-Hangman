# The Testament of Simeon / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Simeon, the things which he spake to his sons before he died, in the hundred and twentieth year of his life, at which time Joseph, his brother, died.

**[1:2]** For when Simeon was sick, his sons came to visit him. and he strengthened himself and sat up and kissed them, and said:--

**[1:3]** Hearken, my children, to Simeon your father and I will declare unto you what things I have in my heart.

**[1:4]** I was born of Jacob as my father's second son; and my mother Leah called me Simeon, because the Lord had heard her prayer.

**[1:5]** Moreover, I became strong exceedingly; I shrank from no achievement nor was I afraid of ought. For my heart was hard, and my liver was immovable, and my bowels without compassion.

**[1:6]** Because valour also has been given from the Most High to men in soul and body.

**[1:7]** For in the time of my youth I was jealous in many things of Joseph, because my father loved him beyond all.

**[1:8]** And I set my mind against him to destroy him because the prince of deceit sent forth the spirit of jealousy and blinded my mind, so that I regarded him not as a brother, nor did I spare even Jacob my father.

**[1:9]** But his God and the God of his fathers sent forth His angel, and delivered him out of my hands.

**[1:10]** For when I went to Shechem to bring ointment for the flocks, and Reuben to Dothan, where were our necessaries and all our stores, Judah my brother sold him to the Ishmaelites.

**[1:11]** And when Reuben heard these things he was grieved, for he wished to restore him to his father.

**[1:12]** But on hearing this I was exceedingly wroth against Judah in that he let him go away alive, and for five months I continued wrathful against him.

**[1:13]** But the Lord restrained me, and withheld from me the power of my hands; for my right hand was half withered for seven days.

**[1:14]** And I knew, my children, that because of Joseph this had befallen me, and I repented and wept; and I besought the Lord God that my hand might be restored and that I might hold aloof from all pollution and envy and from all folly.

**[1:15]** For I knew that I had devised an evil thing before the Lord and Jacob my father, on account of Joseph my brother, in that I envied him.

**[1:16]** And now, my children, hearken unto me and beware of the spirit of deceit and envy.

**[1:17]** For envy ruleth over the whole mind of a man, and suffereth him neither to eat nor to drink, nor to do any good thing. But it ever suggesteth to him to destroy him that he envieth; and so long as he that is envied flourisheth, he that envieth fadeth away.

**[1:18]** Two years therefore I afflicted my soul with fasting in the fear of the Lord, and I learnt that deliverance from envy cometh by the fear of God.

**[1:19]** For if a man flee to the Lord, the evil spirit runneth away from him and his mind is lightened.

**[1:20]** And henceforward he sympathiseth with him whom he envied and forgiveth those who are hostile to him, and so ceaseth from his envy.



---



**[2:1]** AND my father asked concerning me, because he saw that I was sad; and I said unto him, I am pained in my liver.

**[2:2]** For I mourned more than they all, because I was guilty of the selling of Joseph.

**[2:3]** And when we went down into Egypt, and he bound me as a spy, I knew that I was suffering justly, and I grieved not.

**[2:4]** Now Joseph was a good man, and had the Spirit of God within him: being compassionate and pitiful, he bore no malice against me; but loved me even as the rest of his brethren.

**[2:5]** Beware, therefore, my children, of all jealousy and envy, and walk in singleness of heart, that God may give you also grace and glory, and blessing upon your heads, even as ye saw in Joseph's case.

**[2:6]** All his days he reproached us not concerning this thing, but loved us as his own soul, and beyond his own sons glorified us, and gave us riches, and cattle and fruits.

**[2:7]** Do ye also, my children, love each one his brother with a good heart, and the spirit of envy will withdraw from you.

**[2:8]** For this maketh savage the soul and destroyeth the body; it causeth anger and war in the mind, and stirreth up unto deeds of blood, and leadeth the mind into frenzy, and causeth tumult to the soul and trembling to the body.

**[2:9]** For even in sleep malicious jealousy gnaweth, and with wicked spirits disturbeth the soul, and causeth the body to be troubled, and waketh the mind from sleep in confusion; and as a wicked and poisonous spirit, so appeareth it to men.

**[2:10]** Therefore was Joseph comely in appearance, and goodly to look upon, because no wickedness dwelt in him; for some of the trouble of the spirit the face manifesteth.

**[2:11]** And now, my children, make your hearts good before the Lord, and your ways straight before men, and ye shall find grace before the Lord and men.

**[2:12]** Beware, therefore, of fornication, for fornication is mother of all evils, separating from God, and bringing near to Beliar.

**[2:13]** For I have seen it inscribed in the writing of Enoch that your sons shall be corrupted in fornication, and shall do harm to the sons of Levi with the sword.

**[2:14]** But they shall not be able to withstand Levi; for he shall wage the war of the Lord, and shall conquer all your hosts.

**[2:15]** And they shall be few in number, divided in Levi and Judah, and there shall be none of you for sovereignty, even as also our father prophesied in his blessings.



---



**[3:1]** BEHOLD I have told you all things, that I may be acquitted of your sin.

**[3:2]** Now, if ye remove from you your envy and all stiff-neckedness, is a rose shall my bones flourish in Israel, and as a lily my flesh in Jacob, and my odour shall be as the odour of Libanus; and as cedars shall holy ones be multiplied from me for ever, and their branches shall stretch afar off.

**[3:3]** Then shall perish the seed of Canaan, and a remnant shall not be unto Amalek, and all the Cappadocians shall perish, and all Hittites shall be utterly destroyed.

**[3:4]** Then shall fail the land of Ham, and all the people shall perish.

**[3:5]** Then shall all the earth rest from trouble, and all the world under heaven from war.

**[3:6]** Then the Mighty One of Israel shall glorify Shem.

**[3:7]** For the Lord God shall appear on earth, and Himself save men,

**[3:8]** Then shall all the spirits of deceit be given to be trodden under foot, and men shall, rule over wicked spirits.

**[3:9]** Then shall I arise in Joy and will bless the Most High because of his marvellous works, because God hath taken a body and eaten with men and saved men.

**[3:10]** And now, my children,, and Judah, and obey Levi and Judah, and be not lifted up against these two tribes, for from them shall arise unto you the salvation of God.

**[3:11]** For the Lord shall raise up from Levi as it were a High Priest, and from Judah as it were a King, God and man, He shall save all the Gentiles and the race of Israel.

**[3:12]** Therefore I give you these commands that ye also may command your children, that they may observe them throughout their generations.

**[3:13]** And when Simeon had made an end of commanding his sons, he slept with fathers, an hundred and twenty years old.

**[3:14]** And they laid him in a wooden coffin, to take up his bones to Hebron. And they took them up secretly during a war of the Egyptians. For the bones of Joseph the Egyptians guarded in the tombs of the kings.

**[3:15]** For the sorcerers told them, that on the departure of the bones of Joseph there should be throughout all the land darkness and gloom, and an exceeding great plague to the Egyptians, so that even with a lamp a man should not recognize his brother.

**[3:16]** And the sons of Simeon bewailed their father.

**[3:17]** And they were in Egypt until the day of their departure by the hand of Moses.

