# The Testament of Dan / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Dan, which he spake to his sons in his last days, in the hundred and twenty-fifth year of his life.

**[1:2]** For he called together his I family, and said: Hearken to my words, ye sons of Dan; and give heed to the words of your father.

**[1:3]** I have proved in my heart, and in my whole life, that truth with just dealing is good and well pleasing to God, and that lying and anger are evil, because they teach man all wickedness.

**[1:4]** I confess, therefore, this day to you, my children, that in my heart I resolved on the death of Joseph my brother, the true and good man. .

**[1:5]** And I rejoiced that he was sold, because his father loved him more than us.

**[1:6]** For the spirit of jealousy and vainglory said to me: Thou thyself also art his son.

**[1:7]** And one of the spirits of Beliar stirred me up, saying: Take this sword, and with it slay Joseph: so shall thy father love thee when he is dead.

**[1:8]** Now this is the spirit of anger that persuaded me to crush Joseph as a leopard crusheth a kid.

**[1:9]** But the God of my fathers did not suffer him to fall into my hands, so that I should find him alone and slay him, and cause a second tribe to be destroyed in Israel.

**[1:10]** And now, my children, behold I am dying, and I tell you of a truth, that unless ye keep yourselves from the spirit of lying and of anger, and love truth and longsuffering, ye shall perish.

**[1:11]** For anger is blindness, and does not suffer one to see the face of any man with truth.

**[1:12]** For though it be a father or a mother, he behaveth towards them as enemies; though it be a brother, he knoweth him not; though it be a prophet of the Lord, he disobeyeth him; though a righteous man, he regardeth him not; though a friend, he doth not acknowledge him.

**[1:13]** For the spirit of anger encompasseth him with the net of deceit, and blindeth his eyes, and through lying darkeneth his mind, and giveth him its own peculiar vision.

**[1:14]** And wherewith encompasseth it his eyes? With hatred of heart, so as to be envious of his brother.

**[1:15]** For anger is an evil thing, my children, for it troubleth even the soul itself.

**[1:16]** And the body of the angry man it maketh its own, and over his soul it getteth the mastery, and it bestoweth upon the body power that it may work all iniquity.

**[1:17]** And when the body does all these things, the soul justifieth what is done, since it seeth not aright.

**[1:18]** Therefore he that is wrathful, if he be a mighty man, hath a threefold power in his anger: one by the help of his servants; and a second by his wealth, whereby he persuadeth and overcometh wrongfully; and thirdly, having his own natural power he worketh thereby the evil.

**[1:19]** And though the wrathful man be weak, yet hath he a power twofold of that which is by nature; for wrath ever aideth such in lawlessness.

**[1:20]** This spirit goeth always with lying at the right hand of Satan, that with cruelty and lying his works may be wrought.

**[1:21]** Understand ye, therefore, the power of wrath, that it is vain.

**[1:22]** For it first of all giveth provocation by word; then by deeds it strengtheneth him who is angry, and with sharp losses disturbeth his mind, and so stirreth up with great wrath his soul.

**[1:23]** Therefore, when any one. speaketh against you, be not ye moved to anger, and if any man praiseth you as holy men, be not uplifted: be not moved either to delight or to disgust.

**[1:24]** For first it pleaseth the hearing, and so maketh the mind keen to perceive the grounds for provocation; and then being enraged, he thinketh that he is justly angry.

**[1:25]** If ye fall into any loss or ruin, my children, be not afflicted; for this very spirit maketh a man desire that which is perishable, in order that he may be enraged through the affliction.

**[1:26]** And if ye suffer loss voluntarily, or involuntarily, be not vexed; for from vexation ariseth wrath with lying.

**[1:27]** Moreover, a twofold mischief is wrath with lying; and they assist one another in order to disturb the heart; and when the soul is continually disturbed, the Lord departeth from it, and Beliar ruleth over it.



---



**[2:1]** OBSERVE, therefore, my children, the commandments of the Lord, and keep His law; depart from wrath, and hate lying, that the Lord may dwell among you, and Beliar may flee from you.

**[2:2]** Speak truth each one with his neighbour. So shall ye not fall into wrath and confusion; but ye shall be in peace, having the God of peace, so shall no war prevail over you.

**[2:3]** Love the Lord through all your life, and one another with a true heart.

**[2:4]** I know that in the last days ye shall depart from the Lord, and ye shall provoke Levi unto anger, and fight against Judah; but ye shall not prevail against them, for an angel of the Lord shall guide them both; for by them shall Israel stand.

**[2:5]** And whensoever ye depart from the Lord, ye shall walk in all evil and work the abominations of the Gentiles, going a-whoring after women of the lawless ones, while with all wickedness the spirits of wickedness work in you.

**[2:6]** For I have read in the book of Enoch, the righteous, that your prince is Satan, and that all the spirits of wickedness and pride will conspire to attend constantly on the sons of Levi, to cause them to sin before the Lord.

**[2:7]** And my sons will draw near to Levi, and sin with them in all things; and the sons of Judah will be covetous, plundering other men's goods like lions.

**[2:8]** Therefore shall ye be led away with them into captivity, and there shall ye receive all the plagues of Egypt, and all the evils of the Gentiles.

**[2:9]** And so when ye return to the Lord ye shall obtain mercy, and He shall bring you into His sanctuary, and He shall give you peace.

**[2:10]** And there shall arise unto you from the tribe of Judah and of Levi the salvation of the Lord; and he shall make war against Beliar.

**[2:11]** And execute an everlasting vengeance on our enemies; and the captivity shall he take from Beliar the souls of the saints, and turn disobedient hearts unto the Lord, and give to them that call upon him eternal peace.

**[2:12]** And the saints shall rest in Eden, and in the New Jerusalem shall the righteous rejoice, and it shall be unto the glory of God for ever.

**[2:13]** And no longer shall Jerusalem endure desolation, nor Israel be led captive; for the Lord shall be in the midst of it [living amongst men], and the Holy One of Israel shall reign over it in humility and in poverty; and he who believeth on Him shall reign amongst men in truth.

**[2:14]** And now, fear the Lord, my children, and beware of Satan and his spirits.

**[2:15]** Draw near unto God and unto the angel that intercedeth for you, for he is a mediator between God and man, and for the peace of Israel he shall stand up against the kingdom of the enemy.

**[2:16]** Therefore is the enemy eager to destroy all that call upon the Lord.

**[2:17]** For he knoweth that upon the day on which Israel shall repent, the kingdom of the enemy shall be brought to an end.

**[2:18]** For the very angel of peace shall strengthen Israel, that it fall not into the extremity of evil.

**[2:19]** And it shall be in the time of the lawlessness of Israel, that the Lord will not depart from them, but will transform them into a nation that doeth His will, for none of the angels will be equal unto him.

**[2:20]** And His name shall be in every place in Israel, and among the Gentiles.

**[2:21]** Keep, therefore, yourselves, my children, from every evil work, and cast away wrath and all lying, and love truth and long-suffering.

**[2:22]** And the things which ye have heard from your father, do ye also impart to your children that the Saviour of the Gentiles may receive you; for he is true and long-suffering, meek and lowly, and teacheth by his works the law of God.

**[2:23]** Depart, therefore, from all unrighteousness, and cleave unto the righteousness of God, and your race will be saved for ever.

**[2:24]** And bury me near my fathers.

**[2:25]** And when he had said these things he kissed them, and fell asleep at a good old age.

**[2:26]** And his sons buried him, and after that they carried up his bones, and placed them near Abraham, and Isaac, and Jacob.

**[2:27]** Nevertheless, Dan prophesied unto them that they should forget their God, and should be alienated from the land of their inheritance and from the race of Israel, and from the family of their seed.

