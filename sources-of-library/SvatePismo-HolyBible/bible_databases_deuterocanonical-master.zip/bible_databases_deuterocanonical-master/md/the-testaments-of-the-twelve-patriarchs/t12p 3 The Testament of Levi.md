# The Testament of Levi / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Levi, the things which he ordained unto his sons, according to all that they should do, and what things should befall them until the day of judgement.

**[1:2]** He was sound in health when he called them to him; for it had been revealed to him that he should die.

**[1:3]** And when they were gathered together he said to them:

**[1:4]** I, Levi, was born in Haran, and I came with my father to Shechem.

**[1:5]** And I was young, about twenty years of age, when, with Simeon, I wrought vengeance on Hamor for our sister Dinah.

**[1:6]** And when I was feeding the flocks in Abel-Maul, the spirit of understand of the Lord came upon me, and I saw all men corrupting their way, and that unrighteousness had built for itself walls, and lawlessness sat upon towers.

**[1:7]** And I was grieving for the race of the sons of men, and I prayed to the Lord that I might be saved.

**[1:8]** Then there fell upon me a sleep, and I beheld a high mountain, and I was upon it.

**[1:9]** And behold the heavens were opened, and an angel of God said to me, Levi, enter.

**[1:10]** And I entered from the first heaven, and I saw there a great sea hanging.

**[1:11]** And further I saw a second heaven far brighter and more brilliant, for there was a boundless light also therein,

**[1:12]** And I said to the angel, Why is this so? And the angel said to me, Marvel not at this, for thou shalt see another heaven more brilliant and incomparable.

**[1:13]** And when thou hast ascended thither, Thou shalt stand near the Lord, and shalt be His minister, and shalt, declare His mysteries to men, and shalt proclaim concerning Him that shall redeem Israel.

**[1:14]** And by thee and Judah shall the Lord appear among men, saving every race of men.

**[1:15]** And from the Lord's portion shall be thy life, and He shall be thy field and vineyard, and fruits, gold, and silver.

**[1:16]** Hear, therefore, regarding the heavens which have been shown to thee.

**[1:17]** The lowest is for this cause gloomy unto thee, in that it beholds all the unrighteous deeds of men.

**[1:18]** And it has fire, snow, and ice made ready for the day of judgement, in the righteous judgement of God; for in it are all the spirits of the retributions for vengeance on men.

**[1:19]** And in the second are the hosts Of the armies which are ordained for the day of judgement, to work vengeance on the spirits of deceit and of Beliar.

**[1:20]** And above them are the holy ones.

**[1:21]** And in the highest of all dwelleth the Great Glory, far above all holiness.

**[1:22]** In the heaven next to it are the archangels, who minister and make propitiation to the Lord for all the sins of ignorance of the righteous;

**[1:23]** Offering to the Lord a sweet smelling savour, a reasonable and a bloodless offering.

**[1:24]** And in the heaven below this are the angels who bear answers to the angels of the presence of the Lord.

**[1:25]** And in the heaven next to this are thrones and dominions, in which always they offer praise to God.

**[1:26]** When, therefore, the Lord looketh upon us, all of us are shaken; yea, the heavens, and the earth, and the abysses are shaken at the presence of His majesty.

**[1:27]** But the sons of men, having no perception of these things, sin and provoke the Most High.



---



**[2:1]** NOW, therefore, know that the Lord shall execute judgement upon the sons of men.

**[2:2]** Because when the rocks are being rent, and the sun quenched, and the waters dried up, and the fire cowering, and all creation troubled, and the invisible spirits melting away, and Hades taketh spoils through the visitations of the Most High, men will be unbelieving and persist in their iniquity.

**[2:3]** On this account with punishment shall they be judged.

**[2:4]** Therefore the Most High hath heard thy prayer, to separate thee from iniquity, and that thou shouldst become to Him a son, and a servant, and a minister of His presence.

**[2:5]** The light of knowledge shalt thou light up in Jacob, and as the sun shalt thou be to all the seed of Israel.

**[2:6]** And there shall be given to thee a blessing, and to all thy seed until the Lord shall visit all the Gentiles in His tender mercies for ever.

**[2:7]** And therefore there have been given to thee counsel and understanding, that thou mightest instruct thy sons concerning this;

**[2:8]** Because they that bless Him shall be blessed, and they that curse Him shall perish.

**[2:9]** And thereupon the angel opened to me the gates of heaven, and I saw the holy temple, and upon a throne of glory the Most High.

**[2:10]** And He said to me: Levi, I have given thee the blessing of the priesthood until I come and sojourn in the midst of Israel.

**[2:11]** Then the angel brought me down to the earth, and gave me a shield and a sword, and said to me: Execute vengeance on Shechem because of Dinah, thy sister, and I will be with thee because the Lord hath sent me.

**[2:12]** And I destroyed at that time the sons of Hamor, as it is written in the heavenly tables.

**[2:13]** And I said to him: I pray thee, O Lord, tell me Thy name, that I may call upon Thee in a day of tribulation.

**[2:14]** And he said: I am the angel who intercedeth for the nation of Israel that they may not be smitten utterly, for every evil spirit attacketh it.

**[2:15]** And after these things I awaked, and blessed the Most High, and the angel who intercedeth for the nation of Israel and for all the righteous.



---



**[3:1]** AND when I was going to my father, I found a brazen shield; wherefore also the name of the mountain is Aspis, which is near Gebal, to the south of Abila.

**[3:2]** And I kept these words in my heart. And after this I counselled my father, and Reuben my brother, to bid the sons of Hamor not to be circumcised; for I was zealous because of the abomination which they had wrought on my sister.

**[3:3]** And I slew Shechem first, and Simeon slew Hamor. And after this my brothers came and smote that city with the edge of the sword.

**[3:4]** And my father heard these things and was wroth, and he was grieved in that they had received the circumcision, and after that had been put to death, and in his blessings he looked amiss upon us.

**[3:5]** For we sinned because we had done this thing against his will, and he was sick on that day.

**[3:6]** But I saw that the sentence of God was for evil upon Shechem; for they sought to do to Sarah and Rebecca as they had done to Dinah our sister, but the Lord prevented them.

**[3:7]** And they persecuted Abraham our father when he was a stranger, and they vexed his flocks when they were big with young; and Eblaen, who was born in his house, they most shamefully handled.

**[3:8]** And thus they did to all strangers, taking away their wives by force, and they banished them.

**[3:9]** But the wrath of the Lord came upon them to the uttermost.

**[3:10]** And I said to my father Jacob: By thee will the Lord despoil the Canaanites, and will give their land to thee and to thy seed after thee.

**[3:11]** For from this day forward shall Shechem be called a city of imbeciles; for as a man mocketh a fool, so did we mock them.

**[3:12]** Because also they had wrought folly in Israel by defiling my sister. And we departed and came to Bethel.

**[3:13]** And there again I saw a vision as the former, after we had spent there seventy days.

**[3:14]** And I saw seven men in white raiment saying unto me: Arise, put on the robe of the priesthood, and the crown of righteousness, and the breastplate of understanding, and the garment of truth, and the late of faith, and the turban of the head, and the ephod of prophecy.

**[3:15]** And they severally carried these things and put them on me, and said unto me: From henceforth become a priest of the Lord, thou and thy seed for ever.

**[3:16]** And the first anointed me with holy oil, and gave to me the staff of judgement.

**[3:17]** The second washed me with pure. water, and fed me with bread and wine even the most holy things, and clad me with a holy and glorious robe.

**[3:18]** The third clothed me with a linen vestment like an ephod.

**[3:19]** The fourth put round me a girdle like unto purple.

**[3:20]** The fifth gave me a branch of rich olive.

**[3:21]** The sixth placed a crown on my head.

**[3:22]** The seventh placed on my head a diadem of priesthood, and filled my hands with incense, that I might serve as priest to the Lord God.

**[3:23]** And they said to me: Levi, thy seed shall be divided into three offices, for a sign of the glory of the Lord who is to come.

**[3:24]** And the first portion shall be great; yea, greater than it shall none be.

**[3:25]** The second shall be in the priesthood.

**[3:26]** And the third shall be called by a new name, because a king shall arise in Judah, and shall establish a new priesthood, after the fashion of the Gentiles.

**[3:27]** And His presence is beloved, as a prophet of the Most High, of the seed of Abraham our father.

**[3:28]** Therefore, every desirable thing in Israel shall be for thee and for thy seed, and ye shall eat everything fair to look upon, and the table of the Lord shall thy seed apportion.

**[3:29]** And some of them shall be high priests, and judges, and scribes; for by their mouth shall the holy place be guarded.

**[3:30]** And when I awoke, I understood that this dream was like the first dream. And I hid this also in my heart, and told it not to any man upon the earth.

**[3:31]** And after two days I and Judah went up with our father Jacob to Isaac our father's father.

**[3:32]** And my father's father blessed me according to all the words of the visions which I had seen. And he would not come with us to Bethel.

**[3:33]** And when we came to Bethel, my father saw a vision concerning me, that I should be their priest unto God.

**[3:34]** And he rose up early in the morning, and paid tithes of all to the Lord through me. And so we came to Hebron to dwell there.

**[3:35]** And Isaac called me continually to put me in remembrance of the law of the Lord, even as the angel of the Lord showed unto me.

**[3:36]** And he taught me the law of the priesthood of sacrifices, whole burnt-offerings, first-fruits, freewill-offerings, peace-offerings.

**[3:37]** And each day he was instructing me, and was busied on my behalf before the Lord, and said to me: Beware of the spirit of fornication; for this shall continue and shall by thy seed pollute the holy place.

**[3:38]** Take, therefore, to thyself a wife without blemish or pollution, while yet thou are young, and not of the race of strange nations.

**[3:39]** And before entering into the holy place, bathe; and when thou offerest the sacrifice, wash; and again, when thou finishest the sacrifice, wash.

**[3:40]** Of twelve trees having leaves offer to the Lord, as Abraham taught me also.

**[3:41]** And of every clean beast and bird offer a sacrifice to the Lord.

**[3:42]** And of all thy first-fruits and of wine offer the first, as a sacrifice to the Lord God; and every sacrifice thou shalt salt with salt.

**[3:43]** Now, therefore, observe whatsoever I command you, children; for whatsoever things I have heard from my fathers I have declared unto you.

**[3:44]** And behold I am clear from your ungodliness and transgression, which ye shall commit in the end of the ages against the Saviour of the world, Christ, acting godlessly, deceiving Israel, and stirring up against it great evils from the Lord.

**[3:45]** And ye shall deal lawlessly together with Israel, so He shall not bear with Jerusalem because of your wickedness; but the veil of the temple shall be rent, so as not to cover your shame.

**[3:46]** And ye shall be scattered as captives among the Gentiles, and shall be for a reproach and for a curse there.

**[3:47]** For the house which the Lord shall choose shall be called Jerusalem, as is contained in the book of Enoch the righteous.

**[3:48]** Therefore when I took a wife I was twenty-eight years old, and her name was Melcha.

**[3:49]** And she conceived and bare a son, and I called his name Gersam, for we were sojourners in our land.

**[3:50]** And I saw concerning him, that he would not be in the first rank.

**[3:51]** And Kohath was born in the thirty-fifth year of my life, towards sunrise.

**[3:52]** And I saw in a vision that he was standing on high in the midst of all the congregation.

**[3:53]** Therefore I called his name Kohath which is, beginning of majesty and instruction.

**[3:54]** And she bare me a third son, in the fortieth year of my life; and since his mother bare him with difficulty, I called him Merari, that is, 'my bitterness,' because he also was like to die.

**[3:55]** And Jochebed was born. in Egypt, in my sixty-fourth year, for I was renowned then in the midst of my brethren.

**[3:56]** And Gersam took a wife, and she bare to him Lomni and Semei. And the sons of Kohath, Ambram, Issachar, Hebron, and Ozeel. And the sons of Merari, Mooli, and Mouses.

**[3:57]** And in the ninety-fourth year Ambram took Jochebed my daughter to him to wife, for they were born in one day, he and my daughter.

**[3:58]** Eight years old was I when I went into the land of Canaan, and eighteen years when I slew Shechem, and at nineteen years I became priest, and at twenty-eight years I took a wife, and at forty-eight I went into Egypt.

**[3:59]** And behold, my children, ye are a third generation. In my hundred and eighteenth year Joseph died.



---



**[4:1]** AND now, my children, I command you: Fear the Lord your God with your whole heart, and walk in simplicity according to all His law.

**[4:2]** And do ye also teach your children letters, that they may have understanding all their life, reading unceasingly the law of God.

**[4:3]** For every one that knoweth the law of the Lord shall be honoured, and shall not be a stranger whithersoever he goeth.

**[4:4]** Yea, many friends shall he gain more than his parents, and many men shall desire to serve him, and to hear the law from his mouth.

**[4:5]** Work righteousness, therefore, my children, upon the earth, that ye may have it as a treasure in heaven.

**[4:6]** And sow good things in your souls, that ye may find them in your life.

**[4:7]** But if ye sow evil things, ye shall reap every trouble and affliction.

**[4:8]** Get wisdom in the fear of God with diligence; for though there be a leading into captivity, and cities and lands be destroyed, and gold and silver and every possession perish, the wisdom of the wise nought can take away, save the blindness of ungodliness, and the callousness that comes of sin.

**[4:9]** For if one keep oneself from these evil things, then even among his enemies shall wisdom be a glory to him, and in a strange country a fatherland, and in the midst of foes shall prove a friend.

**[4:10]** Whosoever teaches noble things and does them, shall be enthroned with kings, as was also Joseph my brother.

**[4:11]** Therefore, my children, I have learnt that at the end of the ages ye will transgress against the Lord, stretching out hands to wickedness against Him; and to all the Gentiles shall ye become a scorn.

**[4:12]** For our father Israel is pure from the transgressions of the chief priests [who shall lay their hands upon the Saviour of the world].

**[4:13]** For as the heaven is purer in the Lord's sight than the earth, so also be ye, the lights of Israel, purer than all the Gentiles.

**[4:14]** But if ye be darkened through transgressions, what, therefore, will all the Gentiles do living in blindness?

**[4:15]** Yea, ye shall bring a curse upon our race, because the light of the law which was given for to lighten every man this ye desire to destroy by teaching commandments contrary to the ordinances of God.

**[4:16]** The offerings of the Lord ye shall rob, and from His portion shall ye steal choice portions, eating them contemptuously with harlots.

**[4:17]** And out of covetousness ye shall teach the commandments of the Lord, wedded women shall ye pollute, and the virgins of Jerusalem shall ye defile; and with harlots and adulteresses shall ye be joined, and the daughters of the Gentiles shall ye take to wife, purifying them with an unlawful purification; and your union shall be like unto Sodom and Gomorrah,

**[4:18]** And ye shall be puffed up because of your priesthood, lifting yourselves up against men, and not only so, but also against the commands of God.

**[4:19]** For ye shall contemn the holy things with jests and laughter.

**[4:20]** Therefore the temple, which the Lord shall choose, shall be laid waste through your uncleanness, and ye shall be captives throughout all nations.

**[4:21]** And ye shall be an abomination unto them, and ye shall receive reproach and everlasting shame from the righteous judgement of God.

**[4:22]** And all who hate you shall rejoice at your destruction.

**[4:23]** And if you were not to receive mercy through Abraham, Isaac, and Jacob, our fathers, not one of our seed should be left upon the earth.

**[4:24]** And now I have learnt that for seventy weeks ye shall go astray, and profane the priesthood, and pollute the sacrifices.

**[4:25]** And ye shall make void the law, and set at nought the words of the prophets by evil perverseness.

**[4:26]** And ye shall persecute righteous men, and hate the godly; the words of the faithful shall ye abhor.

**[4:27]** And a man who reneweth the law in the power of the Most High, ye shall call a deceiver; and at last ye shall rush upon him to slay him, not knowing his dignity, taking innocent blood through wickedness upon your heads.

**[4:28]** And your holy places shall be laid waste even to the ground because of him.

**[4:29]** And ye shall have no place that is clean; but ye shall be among the Gentiles a curse and a dispersion until He shall again visit you, and in pity shall receive you through faith and water.



---



**[5:1]** AND whereas ye have heard concerning the seventy weeks, hear also concerning the priesthood. For in each jubilee there shall be a priesthood.

**[5:2]** And in the first jubilee, the first who is anointed to the priesthood shall be great, and shall speak to God as to a father.

**[5:3]** And his priesthood shall be perfect with the Lord, and in the day of his gladness shall he arise for the salvation of the world.

**[5:4]** In the second jubilee, he that is anointed shall be conceived in the sorrow of beloved ones; and his priesthood shall be honoured and shall be glorified by all.

**[5:5]** And the third priest shall he taken hold of by sorrow.

**[5:6]** And the fourth shall be in pain, because unrighteousness shall gather itself against him exceedingly, and all Israel shall hate each one his neighbour.

**[5:7]** The fifth shall be taken hold of by darkness. Likewise also the sixth and the seventh.

**[5:8]** And in the seventh shall, be such pollution as I cannot express before men, for they shall know it who do these things.

**[5:9]** Therefore shall they be taken captive and become a prey, and their land and their substance shall be destroyed.

**[5:10]** And in the fifth week they shall return to their desolate country, and shall renew the house of the Lord.

**[5:11]** And in the seventh week shall become priests, who are idolaters, adulterers, lovers of money, proud, lawless, lascivious, abusers of children and beasts.

**[5:12]** And after their punishment shall have come from the Lord, the priesthood shall fail.

**[5:13]** Then shall the Lord raise up a new priest.

**[5:14]** And to him all the words of the Lord shall be revealed; and he shall execute a righteous judgement upon the earth for a multitude of days.

**[5:15]** And his star shall arise in heaven as of a king.

**[5:16]** Lighting up the light of knowledge as the sun the day, and he shall be magnified in the world.

**[5:17]** He shall shine forth as the sun on the earth, and shall remove all darkness from under heaven, and there shall be peace in all the earth.

**[5:18]** The heavens shall exult in his days, and the earth shall be glad, and the clouds shall rejoice;

**[5:19]** And the knowledge of the Lord shall be poured forth upon the earth, as the water of the seas;

**[5:20]** And the angels of the glory of the presence of the Lord shall be glad in him.

**[5:21]** The heavens shall be opened, and from the temple of glory shall come upon him sanctification, with the Father's voice as from Abraham to Isaac.

**[5:22]** And the glory of the Most High shall be uttered over him, and the spirit of understanding and sanctification shall rest upon him in the water.

**[5:23]** For he shall give the majesty of the Lord to His sons in truth for evermore;

**[5:24]** And there shall none succeed him for all generations for ever.

**[5:25]** And in his priesthood the Gentiles shall be multiplied in knowledge upon the earth, and enlightened through the grace of the Lord. In his priesthood shall sin come to an end, and the lawless shall cease to do evil.

**[5:26]** And he shall open the gates of paradise, and shall remove the threatening sword against Adam, and he shall give to the saints to eat from the tree of life, and the spirit of holiness shall be on them.

**[5:27]** And Beliar shall be bound by him, and he shall give power to His children to tread upon the evil spirits.

**[5:28]** And the Lord shall rejoice in His children, and be well pleased in His beloved ones for ever.

**[5:29]** Then shall Abraham and Isaac and Jacob exult, and I will be glad, and all the saints shall clothe themselves with joy.

**[5:30]** And now, my children, ye have heard all; choose, therefore, for yourselves either the light or the darkness, either the law of the Lord or the works of Beliar.

**[5:31]** And his sons answered him., saying, Before the Lord we will walk according to His law.

**[5:32]** And their father said unto them, The Lord is witness, and His angels are witnesses, and ye are witnesses, and I am witness, concerning the word of your mouth.

**[5:33]** And his sons said unto him: We are witnesses.

**[5:34]** And thus Levi ceased commanding his sons; and he stretched out his feet on the bed, and was gathered to his fathers, after he had lived a hundred and thirty-seven years.

**[5:35]** And they laid him in a coffin, and afterwards they buried him in Hebron, with I Abraham, Isaac, and Jacob.

