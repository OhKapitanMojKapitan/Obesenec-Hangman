# The Testament of Joseph / Testaments of the Twelve Patriarchs 



**[1:1]** THE copy of the Testament of Joseph.

**[1:2]** When he was about to die he called his sons and his brethren together, and said to them:--

**[1:3]** My brethren and my children, hearken to Joseph the beloved of Israel; give ear, my sons, unto your father.

**[1:4]** I have seen in my life envy and death, yet I went not astray, but persevered in the truth--of the Lord.

**[1:5]** These my brethren hated me, but the Lord loved me:

**[1:6]** They wished to slay me, but the God of my fathers guarded me:

**[1:7]** They let me down into a pit, and the Most High brought me up again.

**[1:8]** I was sold into slavery, and the Lord of all made me free:

**[1:9]** I was taken into captivity, and His strong hand succoured me.

**[1:10]** I was beset with hunger, and the Lord Himself nourished me.

**[1:11]** I was alone, and God comforted me:

**[1:12]** I was sick, and the Lord visited me.

**[1:13]** I was in prison, and my God showed favour unto me;

**[1:14]** In bonds, and He released me;

**[1:15]** Slandered, and He pleaded my cause;

**[1:16]** Bitterly spoken against by the Egyptians, and He delivered me;

**[1:17]** Envied by my fellow-slaves, and He exalted me.

**[1:18]** And this chief captain of Pharaoh entrusted to me his house.

**[1:19]** And I struggled against a shameless woman, urging me to transgress with her; but the God of Israel my father delivered me from the burning flame.

**[1:20]** I was cast into prison, I was beaten, I was mocked; but the Lord granted me to find mercy, in the sight of the keeper of the prison.

**[1:21]** For the Lord doth not forsake them that fear Him, neither in darkness, nor in bonds, nor in tribulations, nor in necessities.

**[1:22]** For God is not put to shame as a man, nor as the son of man is he afraid, nor as one that is earth-born is He weak or affrighted.

**[1:23]** But in all those things doth He give protection, and in divers ways doth He comfort, though for a little space He departeth to try the inclination of the soul.

**[1:24]** In ten temptations He showed me approved, and in all of them I endured; for endurance is a mighty charm, and patience giveth many good things.

**[1:25]** How often did the Egyptian woman threaten me with death!

**[1:26]** How often did she give me over to punishment, and then call me back and threaten me, and when I was unwilling to company with her, she said to me:

**[1:27]** Thou shalt be lord of me, and all that is in my house, if thou wilt give thyself unto me, and thou shalt be as our master.

**[1:28]** But I remembered the words of my father, and going into my chamber, I wept and prayed unto the Lord.

**[1:29]** And I fasted in those seven years, and I appeared to the Egyptians as one living delicately, for they that fast for God's sake receive beauty of face.

**[1:30]** And if my lord were away from home, I drank no wine; nor for three days did I take my food, but I gave it to the poor and sick.

**[1:31]** And I sought the Lord early, and I wept for the Egyptian woman of Memphis, for very unceasingly did she trouble me, for also at night she came to me under pretence of visiting me.

**[1:32]** And because she had no male child she pretended to regard me as a son.

**[1:33]** And for a time she embraced me as a son, and I knew it not; but later, she sought to draw me into fornication.

**[1:34]** And when I perceived it I sorrowed unto death; and when she had gone out, I came to myself, and lamented for her many days, because I recognized her guile and her deceit.

**[1:35]** And I declared unto her the words of the Most High, if haply she would turn from her evil lust.

**[1:36]** Often, therefore, did she flatter me with words as a holy man, and guilefully in her talk praise my chastity before her husband, while desiring to ensnare me when we were alone.

**[1:37]** For she lauded me openly as chaste, and in secret she said unto me: Fear not my husband; for he is persuaded concerning thy chastity: for even should one tell him concerning us, he would not believe.

**[1:38]** Owing to all these things I lay upon the ground, and besought God that the Lord would deliver me from her deceit.

**[1:39]** And when she had prevailed nothing thereby, she came again to me under the plea of instruction, that she might learn the word of God.

**[1:40]** And she said unto me: If thou willest that I should leave my idols, lie with me, and I will persuade my husband to depart from his idols, and we will walk in the law by thy Lord.

**[1:41]** And I said unto her: The Lord willeth not. that those who reverence Him should be in uncleanness, nor doth He take pleasure in them that commit adultery, but in those that approach Him with a pure heart and undefiled lips.

**[1:42]** But she heed her peace, longing to accomplish her evil desire.

**[1:43]** And I gave myself yet more to fasting and prayer, that the Lord might deliver me from her.

**[1:44]** And again, at another time she said unto me: If thou wilt not commit adultery, I will kill my husband by poison; and take thee to be my husband.

**[1:45]** I therefore, when I heard this, rent my garments, and said unto her:

**[1:46]** Woman, reverence God, and do not this evil deed, lest thou be destroyed; for know indeed that I will declare this thy device unto all men.

**[1:47]** She therefore, being afraid, besought that I would not declare this device.

**[1:48]** And she departed soothing me with gifts, and sending to me every delight of the sons of men.

**[1:49]** And afterwards she sent me food mingled with enchantments.

**[1:50]** And when the eunuch who brought it came, I looked up and beheld a terrible man giving me with the dish a sword, and I perceived that her scheme was to beguile me.

**[1:51]** And when he had gone out I wept, nor did I taste that or any other of her food.

**[1:52]** So then after one day she came to me and observed the food, and said unto me: Why is it that thou hast not eaten of the food?

**[1:53]** And I said unto her: It is because thou hast filled it with deadly enchantments; and how saidst thou: I come not near to idols but to the Lord alone.

**[1:54]** Now therefore know that the God of my father hath revealed unto me by His angel thy wickedness, and I have kept it to convict thee, if haply thou mayst see and repent.

**[1:55]** But that thou mayst learn that the wickedness of the ungodly hath no power over them that worship God with chastity behold I will take of it and eat before thee.

**[1:56]** And having so said, I prayed thus: The God of my fathers and the angel of Abraham, be with me; and ate.

**[1:57]** And when she saw this she fell upon her face at my feet, weeping; and I raised her up and admonished her.

**[1:58]** And she promised to do this iniquity no more.

**[1:59]** But her heart was still set upon evil, and she looked around how to ensnare me, and sighing deeply she became downcast, though she was not sick.

**[1:60]** And when her husband saw her, he said unto her: Why is thy countenance fallen?

**[1:61]** And she said unto him: I have a pain at my heart, and the groanings of my spirit oppress me; and so he comforted her who was not sick.

**[1:62]** Then, accordingly seizing an opportunity, she rushed unto me while her husband was yet without, and said unto me: I will hang myself, or cast myself over a cliff, if thou wilt not lie with me.

**[1:63]** And when I saw the spirit of Beliar was troubling her, I prayed unto the Lord, and said unto her:

**[1:64]** Why, wretched woman, art thou troubled and disturbed, blinded through sins?

**[1:65]** Remember that if thou kill thyself, Asteho, the concubine of thy husband, thy rival, will beat thy children, and thou wilt destroy thy memorial from off the earth.

**[1:66]** And she said unto me: Lo, then thou lovest me; let this suffice me: only strive for my life and my children, and I expect that I shall enjoy my desire also.

**[1:67]** But she knew not that because of my lord I spake thus, and not because of her.

**[1:68]** For if a man hath fallen before the passion of a wicked desire and become enslaved by it, even as she, whatever good thing he may hear with regard to that passion, he receiveth it with a view to his wicked desire.

**[1:69]** I declare, therefore, unto you, my children, that it was about the sixth hour when she departed from me; and I knelt before the Lord all day, and all the night; and about dawn I rose up, weeping the while and praying for a release from her.

**[1:70]** At last, then, she laid hold of my garments, forcibly dragging me to have connexion with her.

**[1:71]** When, therefore, I saw that in her madness she was holding fast to my garment, I left it behind, and fled away naked.

**[1:72]** And holding fast to the garment she falsely accused me, and when her husband came he cast me into prison in his house; and on the morrow he scourged me and sent me into Pharaoh's prison.

**[1:73]** And when I was in bonds, the Egyptian woman was oppressed with grief, and she came and heard how I gave thanks unto the Lord and sang praises in the abode of darkness, and with glad voice rejoiced, glorifying my God that I was delivered from the lustful desire of the Egyptian woman.

**[1:74]** And often hath she sent unto me saying: Consent to fulfil my desire, and I will release thee from thy bonds, and I will free thee from the darkness.

**[1:75]** And not even in thought did I incline unto her.

**[1:76]** For God loveth him who in a den of wickedness combines fasting with chastity, rather than the man who in kings' chambers combines luxury with license.

**[1:77]** And if a man liveth in chastity, and desireth also glory, and the Most High knoweth that it is expedient for him, He bestoweth this also upon me.

**[1:78]** How often, though she were sick, did she come down to me at unlooked for times, and listened to my voice as I prayed!

**[1:79]** And when I heard her groanings I held my peace.

**[1:80]** For when I was in her house she was wont to bare her arms, and breasts, and legs, that I might lie with her; for she was very beautiful, splendidly adorned in order to beguile me.

**[1:81]** And the Lord guarded me from her devices.



---



**[2:1]** YE see, therefore, my children, how great things patience worketh, and prayer with fasting.

**[2:2]** So ye too, if ye follow after chastity and purity with patience and prayer, with fasting in humility of heart, the Lord will dwell among you because He loveth chastity.

**[2:3]** And wheresoever the Most High dwelleth, even though envy, or slavery, or slander befalleth a man, the Lord who dwelleth in him, for the sake of his chastity not only delivereth him from evil, but also exalteth him even as me.

**[2:4]** For in every way the man is lifted up, whether in deed, or in word, or in thought.

**[2:5]** My brethren knew how my father loved me, and yet I did not exalt myself in my mind: although I was a child, I had the fear of God in my heart; for I knew that all things would pass away.

**[2:6]** And I did not raise myself against them with evil intent, but I honoured my brethren; and out of respect for them, even when I was being sold, I refrained from telling the Ishmaelites that I was a son of Jacob, a great man and a mighty.

**[2:7]** Do ye also, my children, have the fear of God in all your works before your eyes, and honour your brethren.

**[2:8]** For every one who doeth the law of the Lord shall be loved by Him.

**[2:9]** And when I came to the Indocolpitae with the Ishmaelites, they asked me, saying:

**[2:10]** Art thou a slave? And I said that I was a home-born slave, that I might not put my brethren to shame.

**[2:11]** And the eldest of them said unto me: Thou art not a slave, for even thy appearance doth make it manifest.

**[2:12]** But I said that I was their slave.

**[2:13]** Now when we came into Egypt they strove concerning me, which of them should buy me and take me.

**[2:14]** Therefore it seemed good to all that I should remain in Egypt with the merchant of their trade, until they should return bringing merchandise.

**[2:15]** And the Lord gave me favour in the eyes of the merchant, and he entrusted unto me his house.

**[2:16]** And God blessed him by my means, and increased him in gold and silver and in household servants.

**[2:17]** And I was with him three months and five days.

**[2:18]** And about that time the Memphian woman, the wife of Pentephris came down in a chariot, with great pomp, because she had heard from her eunuchs concerning me.

**[2:19]** And she told her husband that the merchant had become rich by means of a young Hebrew, and they say that he had assuredly been stolen out of the land of Canaan.

**[2:20]** Now, therefore, render justice unto him, and take away the youth to thy house; so shall the God of the Hebrews bless thee, for grace from heaven is upon him.

**[2:21]** And Pentephris was persuaded by her words, and commanded the merchant to be brought, and said unto him:

**[2:22]** What is this that I hear concerning thee, that thou stealest persons out of the land of Canaan, and sellest them for slaves?

**[2:23]** But the merchant fell at his feet, and besought him, saying: I beseech thee, my lord, I know not what thou sayest.

**[2:24]** And Pentephris said unto him: Whence, then, is the Hebrew slave?

**[2:25]** And he said: The Ishmaelites entrusted him unto me until they should return.

**[2:26]** But he believed him not, but commanded him to be stripped and beaten.

**[2:27]** And when he persisted in this statement, Pentephris said: Let the youth be brought.

**[2:28]** And when I was brought in, I did obeisance to Pentephris for he was third in rank of the officers of Pharaoh.

**[2:29]** And he took me apart from him, and said unto me: Art thou a slave or free?

**[2:30]** And I said: A slave.

**[2:31]** And he said: Whose?

**[2:32]** And I said: The Ishmaelites'.

**[2:33]** And he said: How didst thou become their slave?

**[2:34]** And I said: They bought me out of the land of Canaan.

**[2:35]** And he said unto me: Truly thou liest; and straightway he commanded me to be stripped and beaten.

**[2:36]** Now, the Memphian woman was looking through a window at me while I was being beaten, for her house was near, and she sent unto him saying:

**[2:37]** Thy judgement is unjust; for thou dost punish a free man who hath been stolen, as though he were a transgressor.

**[2:38]** And when I made no change in my statement, though I was beaten, he ordered me to be imprisoned, until, he said, the owners of the boy should come.

**[2:39]** And the woman said unto her husband: Wherefore dost thou detain the captive and wellborn lad in bonds, who ought rather to be set at liberty, and be waited upon?

**[2:40]** For she wished to see me out of a desire of sin, but I was ignorant concerning all these things.

**[2:41]** And he said to her: It is not the custom of the Egyptians to take that which belongeth to others before proof is given.

**[2:42]** This, therefore, he said concerning the merchant; but as for the lad, he must be imprisoned.

**[2:43]** Now after four and twenty days came the Ishmaelites; for they had heard that Jacob my father was mourning much concerning me.

**[2:44]** And they came and said unto me: How is it that thou saidst that thou wast a slave? and lo, we have learnt that thou art the son of a mighty man in the land of Canaan, and thy father still mourneth for thee in sackcloth and ashes.

**[2:45]** When I heard this my bowels were dissolved and my heart melted, and I desired greatly to weep, but I restrained myself that I should not put my brethren to shame.

**[2:46]** And I said unto them, I know not, I am a slave.

**[2:47]** Then, therefore, they took counsel to sell me, that I should not be found in their hands.

**[2:48]** For they feared my father, lest he should come and execute upon them a grievous vengeance.

**[2:49]** For they had heard that he was mighty with God and with men.

**[2:50]** Then said the merchant unto them: Release me from the judgement of Pentiphri.

**[2:51]** And they came and requested me, saying: Say that thou wast bought by us with money, and he will set us free.

**[2:52]** Now the Memphian woman said to her husband: Buy the youth; for I hear, said she, that they are selling him.

**[2:53]** And straightway she sent a eunuch to the Ishmaelites, and asked them to sell me.

**[2:54]** But since the eunuch would not agree to buy me at their price he returned, having made trial of them, and he made known to his mistress that they asked a large price for their slave.

**[2:55]** And she sent another eunuch, saying: Even though they demand two minas, give them, do not spare the gold; only buy the boy, and bring him to me.

**[2:56]** The eunuch therefore went and gave them eighty pieces of gold, and he received me; but to the Egyptian woman he said I have given a hundred.

**[2:57]** And though I knew this I held my peace, lest the eunuch should be put to shame.

**[2:58]** Ye see, therefore, my children, what great things I endured that I should not put my brethren to shame.

**[2:59]** Do ye also, therefore, love one another, and with long-suffering hide ye one another's faults.

**[2:60]** For God delighteth in the unity of brethren, and in the purpose of a heart that takes pleasure in love.

**[2:61]** And when my brethren came into Egypt they learnt that I had returned their money unto them, and upbraided them not, and comforted them.

**[2:62]** And after the death of Jacob my father I loved them more abundantly, and all things whatsoever he commanded I did very abundantly for them.

**[2:63]** And I suffered them not to be afflicted in the smallest matter; and all that was in my hand I gave unto them.

**[2:64]** And their children were my children, and my children as their servants; and their life was my life, and all their suffering was my suffering, and all their sickness was my infirmity.

**[2:65]** My land was their land, and their counsel my counsel.

**[2:66]** And I exalted not myself among them in arrogance because of my worldly glory, but I was among them as one of the least.

**[2:67]** If ye also, therefore, walk in the commandments of the Lord, my children, He will exalt you there, and will bless you with good things for ever and ever.

**[2:68]** And if any one seeketh to do evil unto you, do well unto him, and pray for him, and ye shall be redeemed of the Lord from all evil.

**[2:69]** For, behold, ye see that out of my humility and longsuffering I took unto wife the daughter of the priest of Heliopolis.

**[2:70]** And a hundred talents of gold were given me with her, and the Lord made them to serve me.

**[2:71]** And He gave me also beauty as a flower beyond the beautiful ones of Israel; and He preserved me unto old age in strength and in beauty, because I was like in all things to Jacob.

**[2:72]** And hear ye, my children, also the vision which I saw.

**[2:73]** There were twelve harts feeding: and the nine were first dispersed over all the earth, and likewise also the three.

**[2:74]** And I saw that from Judah was born a virgin wearing a linen garment, and from her, was born a lamb, without spot; and on his left hand there was as it were a lion; and all the beasts rushed against him, and the lamb overcame them, and destroyed them and trod them under foot.

**[2:75]** And because of him the angels and men rejoiced, and all the land.

**[2:76]** And these things shall come to pass in their season, in the last days.

**[2:77]** Do ye therefore, my children, observe the commandments of the Lord, and honour Levi and Judah; for from them shall arise unto you the Lamb of God, who taketh away the sin of the world, one who saveth all the Gentiles and Israel.

**[2:78]** For His kingdom is an everlasting kingdom, which shall not pass away; but my kingdom among you shall come to an end as a watcher's hammock, which after the summer disappeareth.

**[2:79]** For I know that after my death the Egyptians will afflict you, but God will avenge you, and will bring you into that which He promised to your fathers.

**[2:80]** But ye shall carry up my bones with you; for when my bones are being taken up thither, the Lord shall be with you in light, and Beliar shall be in darkness with the Egyptians.

**[2:81]** And carry ye up Asenath your mother to the Hippodrome, and near Rachel your mother bury her.

**[2:82]** And when he had said these things he stretched out his feet, and died at a good old age.

**[2:83]** And all Israel mourned for him, and all Egypt, with a great mourning.

**[2:84]** And when the children of Israel went out of Egypt, they took with them the bones of Joseph, and they buried him in Hebron with his fathers, and the years of his life were one hundred and ten years.

