# The Testament of Judah / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Judah, what things he spake to his sons before he died.

**[1:2]** They gathered themselves together, therefore, and came to him, and he said to them: Hearken, my children, to Judah your father.

**[1:3]** I was the fourth son born to my father Jacob; and Leah my mother named me Judah, saying, I give thanks to the Lord, because He hath given me a fourth son also.

**[1:4]** I was swift in my youth, and obedient to my father in everything.

**[1:5]** And I honoured my mother and my mother's sister.

**[1:6]** And it came to pass, when I became a man, that my father blessed me, saying, Thou shalt be a king, prospering in all things.

**[1:7]** And the Lord showed me favour in all my works both in the field and in the house.

**[1:8]** I know that I raced a hind, and caught it, and prepared the meat for my father, and he did eat.

**[1:9]** And the roes I used to master in the chase, and overtake all that was in the plains.

**[1:10]** A wild mare I overtook, and caught it and tamed it.

**[1:11]** I slew a lion and plucked a kid out of its mouth.

**[1:12]** I took a bear by its paw and hurled it down the cliff, and it was crushed.

**[1:13]** I outran the wild boar, and seizing it as I ran, I tore it in sunder.

**[1:14]** A leopard in Hebron leaped upon my dog, and I caught it by the tail, and hurled it on the rocks, and it was broken in twain

**[1:15]** I found a wild ox feeding in the fields, and seizing it by the horns, and whirling it round and stunning it, I cast it from me and slew it.

**[1:16]** And when the two kings of the Canaanites came sheathed, in armour against our flocks, and much people with them, single handed I rushed upon the king of Hazor, and smote him on the greives and dragged him down, and so I slew him.

**[1:17]** And the other, the king of Tappuah, as he sat upon his horse, I slew, and so I scattered all his people.

**[1:18]** Achor, the king, a man of giant stature, I found, hurling javelins before and behind as he sat on horseback, and I took up a stone of sixty pounds weight, and hurled it and smote his horse, and killed it.

**[1:19]** And I fought with this other for two hours; and I clave his shield in twain, and I chopped off his feet, and killed him.

**[1:20]** And as I was stripping off his breastplate, behold nine men his companions began to fight with me,

**[1:21]** And I wound my garment on my hand; and I slung stones at them, and killed four of them, and the rest fled.

**[1:22]** And Jacob my father slew Beelesath, king of all the kings, a giant in strength, twelve cubits high.

**[1:23]** And fear fell upon them, and they ceased warring against us.

**[1:24]** Therefore my father was free from anxiety in the wars when I was with my brethren.

**[1:25]** For he saw in a vision concerning me that an angel of might followed me everywhere, that I should not be overcome.

**[1:26]** And in the south there came upon us a greater war than that in Shechem; and I joined in battle array with my brethren, and pursued a thousand men, and slew of them two hundred men and four kings.

**[1:27]** And I went up upon the wall, and I slew four mighty men.

**[1:28]** And so we captured Hazor, and took all the spoil.

**[1:29]** And the next day we departed to Aretan, a city strong and walled and inaccessible, threatening us with death.

**[1:30]** But I and Gad approached on the east side of the city, and Reuben and Levi on the west.

**[1:31]** And they that were upon the wall, thinking that we were alone, were drawn down against us.

**[1:32]** And so my brothers secretly climbed up the wall on both sides by stakes, and entered the city, while the men knew it not.

**[1:33]** And we took it with the edge of the sword.

**[1:34]** And as for those who had taken refuge in the tower, we set fire to the tower and took both it and, them.

**[1:35]** And as we were departing the men of Tappuah seized our spoil, and seeing this we fought with them.

**[1:36]** And we slew them. all and recovered our spoil.

**[1:37]** And when I was at the waters of Kozeba, the men of Jobel came against us to battle.

**[1:38]** And we fought with them and routed them; and their allies from Shiloh we slew, and we did not leave them power to come in against us.

**[1:39]** And the men of Makir came upon us the fifth day, to seize our spoil; and we attacked them and overcame them in fierce battle: for there was a host of mighty men amongst them, and we slew them before they had gone up the ascent.

**[1:40]** And when we came to their city their women rolled upon us stones from the brow of the hill on which the city stood.

**[1:41]** And I and Simeon had ourselves behind the town, and seized upon the heights, and destroyed this city also.

**[1:42]** And the next day it was told us that the king of the city of Gaash with. a mighty host was coming against us.

**[1:43]** I, therefore, and Dan feigned ourselves to be Amorites, and as allies went into their city.

**[1:44]** And in the depth of night our brethren came and we opened to them the gates; and we destroyed all the men and their substance, and we took for a prey all that was theirs, and their three walls we cast down.

**[1:45]** And we drew near to Thamna, where was all the substance of the hostile kings.

**[1:46]** Then being insulted by them, I was therefore wroth, and rushed against them to the summit; and they kept slinging against me stones and darts.

**[1:47]** And had not Dan my brother aided me, they would have slain me.

**[1:48]** We came upon them, therefore, with wrath, and they all fled; and passing by another way, they fought my father, and he made peace with them.

**[1:49]** And we did to them no hurt, and they became tributary to us, and we restored to them their spoil.

**[1:50]** And I built Thamna, and my father built Pabael.

**[1:51]** I was twenty years old when this war befell. And the Canaanites feared me and my brethren.

**[1:52]** And I had much cattle, and I had for chief herdsman Iram the Adullamite.

**[1:53]** And when I went to him I saw Parsaba, king of Adullam; and he spake unto us, and he made us a feast; and when I was heated he gave me his daughter Bathshua to wife.

**[1:54]** She bare me Er, and Onan and Shelah; and two of them the Lord smote: for Shelah lived, and his children are ye.



---



**[2:1]** AND eighteen years my father abode in peace with his brother Esau, and his sons with us, after that we came from Mesopotamia, from Laban.

**[2:2]** And when eighteen years were fulfilled, in the fortieth year of my life, Esau, the brother of my father, came upon us with a mighty and strong people.

**[2:3]** And Jacob smote Esau with an arrow, and he was taken up wounded on Mount Seir, and as he went he died at Anoniram.

**[2:4]** And we pursued after the sons of Esau.

**[2:5]** Now they had a city with walls of iron and gates of brass; and we could not enter into it, and we encamped around, and besieged it.

**[2:6]** And when they opened not to us in twenty days, I set up a ladder in the sight of all and with my shield upon my head I went up, sustaining the assault of stones, upwards of three talents weight; and I slew four of their mighty men.

**[2:7]** And Reuben and Gad slew six others.

**[2:8]** Then they asked from us terms of peace; and having taken counsel with our father, we received them as tributaries.

**[2:9]** And they gave us five hundred cors of wheat, five hundred baths of oil, five hundred measures of wine, until the famine, when we went down into Egypt.

**[2:10]** And after these things my son Er took to wife Tamar, from Mesopotamia, a daughter of Aram.

**[2:11]** Now Er was wicked, and he was in need concerning Tamar, because she was not of the land of Canaan.

**[2:12]** And on the third night an angel of the Lord smote him.

**[2:13]** And he had not known her according to the evil craftiness of his mother, for he did not wish to have children by her.

**[2:14]** In the days of the wedding feast I gave Onan to her in marriage; and he also in wickedness knew her not, though he spent with her a year.

**[2:15]** And when I threatened him he went in unto her, but he spilled the seed on the ground, according to the command of his mother, and he also died through wickedness.

**[2:16]** And I wished to give Shelah also to her, but his mother did not permit it; for she wrought evil against Tamar, because she was not the daughters of Canaan, as she also herself was.

**[2:17]** And I knew that the race of the Canaanites was wicked, but the impulse of youth blinded my mind.

**[2:18]** And when I saw her pouring out wine, owing to the intoxication of wine I was deceived, and took her although my father had not counselled it.

**[2:19]** And while I was away she went and took for Shelah a wife from Canaan.

**[2:20]** And when I knew what she had done, I cursed her in the anguish of my soul.

**[2:21]** And she also died through her wickedness together with her sons.

**[2:22]** And after these things, while Tamar was a widow, she heard after two years that I was going up, to shear my sheep, and adorned herself in bridal array, and sat in the city Enaim by the gate.

**[2:23]** For it was a law of the Amorites, that she who was about to marry should sit in fornication seven days by the gate.

**[2:24]** Therefore being drunk with wine, I did not recognize her; and her beauty deceived me, through the fashion of her adorning.

**[2:25]** And I turned aside to her, and said: Let me go in unto thee.

**[2:26]** And she said: What wilt thou give me? And I gave her my staff, and my girdle, and the diadem of my kingdom in pledge.

**[2:27]** And I went in unto her, and she conceived.

**[2:28]** And not knowing what I had done, I wished to slay her; but she privily sent my pledges, and put me to shame.

**[2:29]** And when I called her, I heard also the secret words which I spoke when lying with her in my drunkenness; and I could not slay her, because it was from the Lord.

**[2:30]** For I said, Lest haply she did it in subtlety, having received the pledge from another woman.

**[2:31]** But I came not again near her while I lived, because I had done this abomination in all Israel.

**[2:32]** Moreover, they who were in the city said there was no harlot in the gate, because she came from another place, and sat for a while in the gate.

**[2:33]** And I thought that no one knew that I had gone in to her.

**[2:34]** And after this we came into Egypt to Joseph, because of the famine.

**[2:35]** And I was forty and six years old, and seventy and three years lived I in Egypt.



---



**[3:1]** AND now I command you, my children, hearken to Judah your father, and keep my sayings to perform all the ordinances of the Lord, and to obey the commands of God.

**[3:2]** And walk not after your lusts, nor in the imaginations of your thoughts in haughtiness of heart; and glory not in the deeds and strength of your youth, for this also is evil in the eyes of the Lord.

**[3:3]** Since I also gloried that in wars no comely woman's face ever enticed me, and reproved Reuben my brother concerning Bilhah, the wife of my father, the spirits of jealousy and of fornication arrayed themselves against me, until I lay with Bathshua the Canaanite, and Tamar, who was espoused to my sons.

**[3:4]** For I said to my father-in-law: I will take counsel with my father, and so will I take thy daughter.

**[3:5]** And he was unwilling but he showed me a boundless store of gold in his daughter's behalf; for be was a king.

**[3:6]** And he adorned her with gold and pearls, and caused her to pour out wine for us at the feast with the beauty of women.

**[3:7]** And the wine turned aside my eyes, and pleasure blinded my heart.

**[3:8]** And I became enamoured of and I lay with her, and transgressed the commandment of the Lord and the commandment of my fathers, and I took her to wife.

**[3:9]** And the Lord rewarded me according to the imagination of my heart, inasmuch as I had no joy in her children.

**[3:10]** And now, my children, I say unto you, be not drunk with wine; for wine turneth the mind away from, the truth, and inspires the passion of lust, and leadeth the eyes into error.

**[3:11]** For the spirit of fornication hath wine as a minister to give pleasure to the mind; for these two also take away the mind of man.

**[3:12]** For if a man drink wine to drunkenness, it disturbeth the mind with filthy thoughts leading to fornication, and heateth the body to carnal union; and if the occasion of the lust be present, he worketh the sin, and is not ashamed.

**[3:13]** Such is the inebriated man, my children; for he who is drunken reverenceth no man.

**[3:14]** For, lo, it made me also to err, so that I was not ashamed of the multitude in the city, in that before the eyes of all I turned aside unto Tamar, and I wrought a great sin, and I uncovered the covering of my sons' shame.

**[3:15]** After I had drunk wine I reverenced not the commandment of God, and I took a woman of Canaan to wife.

**[3:16]** For much discretion needeth the man who drinketh wine, my children; and herein is discretion in drinking wine, a man may drink so long as he preserveth modesty.

**[3:17]** But if he go beyond this limit the spirit of deceit attacketh his mind, and it maketh the drunkard to talk filthily, and to transgress and not to be ashamed, but even to glory in his shame, and to account himself honourable.

**[3:18]** He that committeth fornication is not aware when he suffers loss, and is not ashamed when put to dishonour.

**[3:19]** For even though a man be a king and commit fornication, he is stripped of his kingship by becoming the slave of fornication, as I myself also suffered.

**[3:20]** For I gave my staff, that is, the stay of my tribe; and my girdle, that is, my power; and my diadem, that is, the glory of my kingdom.

**[3:21]** And indeed I repented of these things; wine and flesh I eat not until my old age, nor did I behold any joy.

**[3:22]** And the angel of God showed me that for ever do women bear rule over king and beggar alike.

**[3:23]** And from the king they take away his glory, and from the valiant man his might, and from the beggar even that little which is the stay of his poverty.

**[3:24]** Observe, therefore, my children, the right limit in wine; for there are in it four evil spirits--of lust, of hot desire, of profligacy, of filthy lucre.

**[3:25]** If ye drink wine in gladness, be ye modest in the fear of God.

**[3:26]** For if in your gladness the fear of God departeth, then drunkenness ariseth and shamelessness stealeth in.

**[3:27]** But if ye would live soberly do not touch wine at all, lest ye sin in words of outrage, and in fightings and slanders, and transgressions of the commandments of God, and ye perish before your time.

**[3:28]** Moreover, wine revealeth the mysteries of God and men, even as I also revealed the commandments of God and the mysteries of Jacob my father to the Canaanitish woman Bathshua, which God bade me not to reveal.

**[3:29]** And wine is a cause both of war and confusion.

**[3:30]** And now, I command you, my children, not to love money, nor to gaze upon the beauty of women; because for the sake of money and beauty I was led astray to Bathshua the Canaanite.

**[3:31]** For I know that because of these two things shall my race fall into wickedness.

**[3:32]** For even wise men among my sons shall they mar, and shall cause the kingdom of Judah to be diminished, which the Lord gave me because of my obedience to my father.

**[3:33]** For I never caused grief to Jacob, my father; for all things whatsoever he commanded I did.

**[3:34]** And Isaac, the father of my father, blessed me to be king in Israel, and Jacob further blessed me in like manner.

**[3:35]** And I know that from me shall the kingdom be established.

**[3:36]** And I know what evils ye will do in the last days.

**[3:37]** Beware, therefore, my children, of fornication, and the love of money, and hearken to Judah your father.

**[3:38]** For these things withdraw au from the law of God, and blind the inclination of the soul, and teach arrogance, and suffer not a man to have compassion upon his neighbour.

**[3:39]** They rob his soul of all goodness, and oppress him with toils and troubles, and drive away sleep from him, and devour his flesh.

**[3:40]** And he hindereth the sacrifices of God; and he remembereth not the blessing of God, he hearkeneth not to a prophet when he speaketh, and resenteth the words of godliness.

**[3:41]** For he is a slave to two contrary passions, and cannot obey God, because they have blinded his soul, and he walketh in the day as in the night.

**[3:42]** My children, the love of money leadeth to idolatry; because, when led astray through money, men name as gods those who are not gods, and it causeth him who hath it to fall into madness.

**[3:43]** For the sake of money I lost my children, and had not my repentance, and my humiliation, and the prayers of my father been accepted, I should have died childless.

**[3:44]** But the God of my fathers had mercy on me, because I did it in ignorance.

**[3:45]** And the prince of deceit blinded me, and I sinned as a man and as flesh, being corrupted through sins; and I learnt my own weakness while thinking myself invincible.

**[3:46]** Know, therefore, my children, that two spirits wait upon man-the spirit of truth and the spirit of deceit.

**[3:47]** And in the midst is the spirit of understanding of the mind, to which it belongeth to turn whithersoever it will.

**[3:48]** And the works of truth and the works of deceit are written upon the hearts of men, and each one of them the Lord knoweth.

**[3:49]** And there is no time at which the works of men can be hid; for on the heart itself have they been written down before the Lord.

**[3:50]** And the spirit of truth testifieth all things, and accuseth all; and the sinner is burnt up by his own heart, and cannot raise his face to the judge.



---



**[4:1]** AND now, my children, I command you, love Levi, that ye may abide, and exalt not yourselves against him, lest ye be utterly destroyed.

**[4:2]** For to me the Lord gave the kingdom, and to him the priesthood, and He set the kingdom beneath the priesthood.

**[4:3]** To me He gave the things upon the earth; to him the things in the heavens.

**[4:4]** As the heaven is higher than the earth, so is the priesthood of God higher than the earthly kingdom, unless it falls away through sin from the Lord and is dominated by the earthly kingdom.

**[4:5]** For the angel of the Lord said unto me: The Lord chose him rather than thee, to draw near to Him, and to eat of His table and to offer Him the first-fruits of the choice things of the sons of Israel; but thou shalt be king of Jacob.

**[4:6]** And thou shalt be amongst them as the sea.

**[4:7]** For as, on the sea, just and unjust are tossed about, some taken into captivity while some are enriched, so also shall every race of men be in thee: some shall be impoverished, being taken captive, and others grow rich by plundering the possessions of others.

**[4:8]** For the kings shall be as sea-monsters.

**[4:9]** They shall swallow men like fishes: the sons and daughters of freemen shall they enslave; houses, lands, flocks, money shall they plunder:

**[4:10]** And with the flesh of many shall they wrongfully feed the ravens and the cranes; and they shall advance in evil in covetousness uplifted, and there shall be false prophets like tempest, and they shall persecute all righteous men.

**[4:11]** And the Lord shall bring upon them divisions one against another.

**[4:12]** And there shall be continual wars in Israel; and among men of another race shall my kingdom be brought to an end, until the salvation of Israel shall come.

**[4:13]** Until the appearing of the God of righteousness, that Jacob, and all the Gentiles may rest in peace.

**[4:14]** And He shall guard the might of my kingdom for ever; for the Lord aware to me with an oath that He would not destroy the kingdom from my seed for ever.

**[4:15]** Now I have much grief, my children, because of your lewdness and witchcrafts, and idolatries which ye shall practise against the kingdom, following them that have familiar spirits, diviners, and demons of error.

**[4:16]** Ye shall make your daughters singing girls and harlots, and ye shall mingle in the abominations of the Gentiles.

**[4:17]** For which things' sake the Lord shall bring upon you famine and pestilence, death and the sword, beleaguering by enemies, and revilings of friends, the slaughter of children, the rape of wives, the plundering of possessions, the burning of the temple of God, the laying waste of the land, the enslavement of yourselves among the Gentiles.

**[4:18]** And they shall make some of you eunuchs for their wives.

**[4:19]** Until the Lord visit you, when with perfect heart ye repent and walk in all His commandments, and He bring you up from captivity among the Gentiles.

**[4:20]** And after these things shall a star arise to you from Jacob in peace,

**[4:21]** And a man shall arise from my seed, like the sun of righteousness,

**[4:22]** Walking with the sons of men in meekness and righteousness;

**[4:23]** And no sin shall be found in him.

**[4:24]** And the heavens shall be opened unto him, to pour out the spirit, even the blessing of the Holy Father; and He shall pour out the spirit of grace upon you;

**[4:25]** And ye shall be unto Him sons in truth, and ye shall walk in His commandments first and last.

**[4:26]** Then shall the sceptre of my kingdom shine forth; and from your root shall arise a stem; and from it shall grow a rod of righteousness to the Gentiles, to judge and to save all that call upon the Lord.

**[4:27]** And after these things shall Abraham and Isaac and Jacob arise unto life; and I and my brethren shall be chiefs of the tribes of Israel:

**[4:28]** Levi first, I the second, Joseph third, Benjamin fourth, Simeon fifth, Issachar sixth, and so all in order.

**[4:29]** And the Lord blessed Levi, and the Angel of the Presence, me; the powers of glory, Simeon; the heaven, Reuben; the earth, Issachar; the sea, Zebulun; the mountains, Joseph; the tabernacle, Benjamin; the luminaries, Dan; Eden, Naphtali; the sun, Gad; the moon, Asher.

**[4:30]** And ye shall be the people of the Lord, and have one tongue; and there shall be there no spirit of deceit of Beliar, for he shall be cast into the fire for ever.

**[4:31]** And they who have died in grief shall arise in joy, and they who were poor for the Lord's sake shall be made rich, and they who are put to death for the Lord's sake shall awake to life.

**[4:32]** And the harts of Jacob shall run in joyfulness, and the eagles of Israel shall fly in gladness; and all the people shall glorify the Lord for ever.

**[4:33]** Observe, therefore, my children, all the law of the Lord, for there is hope for all them who hold fast unto, His ways.

**[4:34]** And he said to them: Behold, I die before your eyes this day, a hundred and nineteen years old.

**[4:35]** Let no one bury me in costly apparel, nor tear open my bowels, for this shall they who are kings do; and carry me up to Hebron with you.

**[4:36]** And Judah, when he had said these things, fell asleep; and his sons did according to all whatsoever he commanded them, and they buried him in Hebron, with his fathers.

