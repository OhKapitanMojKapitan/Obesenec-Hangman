# The Testament of Issachar / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Issachar.

**[1:2]** For he called his sons and said to them: Hearken, my children, to Issachar your father; give ear to the words of him who is beloved of the Lord.

**[1:3]** I was born the fifth son to Jacob, by way of hire for the mandrakes.

**[1:4]** For Reuben my brother brought in mandrakes from the field, and Rachel met him and took them.

**[1:5]** And Reuben wept, and at his voice Leah my mother came forth.

**[1:6]** Now these mandrakes were sweet-smelling apples which were produced in the land of Haran below a ravine of water.

**[1:7]** And Rachel said: I will not give them to thee, but they shall be to me instead of children.

**[1:8]** For the Lord hath despised me, and I have not borne children to Jacob.

**[1:9]** Now there were two apples; and Leah said to Rachel: Let it suffice thee that thou hast taken my husband: wilt thou take these also?

**[1:10]** And Rachel said to her: Thou shalt have Jacob this night for the mandrakes of thy son,

**[1:11]** And Leah said to her: Jacob is mine, for I am the wife of his youth.

**[1:12]** But Rachel said: Boast not, and vaunt not thyself; for he espoused me before thee, and for my sake he served our father fourteen years.

**[1:13]** And had not craft increased on the earth and the wickedness of men prospered, thou wouldst not now see the face of Jacob.

**[1:14]** For thou art not his wife, but in craft wert taken to him in my stead.

**[1:15]** And my father deceived me, and removed me on that night, and did not suffer Jacob to see me; for had I been there, this had not happened to him.

**[1:16]** Nevertheless, for the mandrakes I am hiring Jacob to thee for one night.

**[1:17]** And Jacob knew Leah, and she conceived and bare me, and on account of the hire I was called Issachar.

**[1:18]** Then appeared to Jacob an angel of the Lord, saying: Two children shall Rachel bear, inasmuch as she hath refused company with her husband, and hath chosen continency.

**[1:19]** And had not Leah my mother paid the two apples for the sake of his company, she would have borne eight sons; for this reason she bare six, and Rachel bare the two: for on account of the mandrakes the Lord visited her.

**[1:20]** For He knew that for the sake of children she wished to company with Jacob, and not for lust of pleasure.

**[1:21]** For on the morrow also she again gave up Jacob.

**[1:22]** Because of the mandrakes, therefore, the Lord hearkened to Rachel.

**[1:23]** For though she desired them, she cat them not, but offered them in the house of the Lord, presenting them to the priest of the Most High who was at that time.

**[1:24]** When, therefore, I grew up, my children, I walked in uprightness of heart, and I became a husbandman for my father and my brethren, and I brought in fruits from the field according to their season.

**[1:25]** And my father blessed me, for he saw that I walked in rectitude before him.

**[1:26]** And I was not a busybody in my doings, nor envious and malicious against my neighbour.

**[1:27]** I never slandered any one, nor did I censure the life of any man, walking as I did in singleness of eye.

**[1:28]** Therefore, when I was thirty-five years old, I took to myself a wife, for my labour wore away my strength, and I never thought upon pleasure with women; but owing to my toil, sleep overcame me.

**[1:29]** And my father always rejoiced in my rectitude, because I offered through the priest to the Lord all first-fruits; then to my father also.

**[1:30]** And the Lord increased ten thousandfold His benefits in my hands; and also Jacob, my father, knew that God aided my singleness.

**[1:31]** For on all the poor and oppressed I bestowed the good things of the earth in the singleness of my heart.

**[1:32]** And now, hearken to me, my children, and walk in singleness of your heart, for I have seen in it all that is well-pleasing to the Lord. '

**[1:33]** The single-minded man coveteth not gold, he overreacheth not his neighbour, he longeth not after manifold dainties, he delighteth not in varied apparel.

**[1:34]** He doth not desire to live a long life, but only waiteth for the will of God.

**[1:35]** And the spirits of deceit have no power against him, for he looketh not on the beauty of women, lest he should pollute his mind with corruption.

**[1:36]** There is no envy in his thoughts, no malicious person maketh his soul to pine away, nor worry with insatiable desire in his mind.

**[1:37]** For he walketh in singleness of soul, and beholdeth all things in uprightness of heart, shunning eyes made evil through the error of the world, lest he should see the perversion of any of the commandments of the Lord.

**[1:38]** Keep, therefore, my children, the law of God, and get singleness, and walk in guilelessness, not playing the busybody with the business of your neighbour, but love the Lord and your neighbour, have compassion on the poor and weak.

**[1:39]** Bow down your back unto husbandry, and toil in labours in all manner of husbandry, offering gifts to the Lord with thanksgiving.

**[1:40]** For with the first-fruits of the earth will the Lord bless you, even as He blessed all the saints from Abel even until now.

**[1:41]** For no other portion is given to you than of the fatness of the earth, whose fruits are raised by toil.

**[1:42]** For our father Jacob blessed me with blessings of the earth and of first-fruits.

**[1:43]** And Levi and Judah were glorified by the Lord even among the sons of Jacob; for the Lord gave them an inheritance, and to Levi He gave the priesthood, and to Judah the kingdom.

**[1:44]** And do ye therefore obey them, and walk in the singleness of your father; for unto Gad hath it been given to destroy the troops that are coming upon Israel.



---



**[2:1]** KNOW ye therefore, my children, that in the last times your sons will forsake singleness, and will cleave unto insatiable desire.

**[2:2]** And leaving guilelessness, will draw near to malice; and forsaking the commandments of the Lord, they will cleave unto Beliar.

**[2:3]** And leaving husbandry, they will follow after their own wicked devices, and they shall be dispersed among the Gentiles, and shall serve their enemies.

**[2:4]** And do you therefore give these commands to your children, that, if they sin, they may the more quickly return to the Lord; For He is merciful, and will deliver them, even to bring them back into their land.

**[2:5]** Behold, therefore, as ye see, I am a hundred and twenty-six years old and am not conscious of committing any sin.

**[2:6]** Except my wife I have not known any woman. I never committed fornication by the uplifting of my eyes.

**[2:7]** I drank not wine, to be led astray thereby;

**[2:8]** I coveted not any desirable thing that was my neighbour's.

**[2:9]** Guile arose not in my heart;

**[2:10]** A lie passed not through my lips.

**[2:11]** If any man were in distress I joined my sighs with his,

**[2:12]** And I shared my bread with the poor.

**[2:13]** I wrought godliness, all my days I kept truth.

**[2:14]** I loved the Lord; likewise also every man with all my heart.

**[2:15]** So do you also these things, my children, and every spirit of Beliar shall flee from you, and no deed of wicked men shall rule over you;

**[2:16]** And every wild beast shall ye subdue, since you have with you the God of heaven and earth and walk with men in singleness of heart.

**[2:17]** And having said these things, he commanded his sons that they should carry him up to Hebron, and bury him there in the cave with his fathers.

**[2:18]** And he stretched out his feet and died, at a good old age; with every limb sound, and with strength unabated, he slept the eternal sleep.

