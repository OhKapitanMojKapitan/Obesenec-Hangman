# The Testament of Naphtali / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of, the testament of Naphtali, which he ordained at the time of his death in the hundred and thirtieth year of his life.

**[1:2]** When his sons were gathered together in the seventh month, on the first day of the month, while still in good health, he made them a feast of food and wine.

**[1:3]** And after he was awake in the morning, he said to them, I am dying; and they believed him not.

**[1:4]** And as he glorified the Lord, he grew strong and said that after yesterday's feast he should die.

**[1:5]** And he began then to say: Hear, my children, ye sons of Naphtali, hear the words of your father.

**[1:6]** I was born from Bilhah, and because Rachel dealt craftly, and gave Bilhah in place of herself to Jacob, and she conceived and bare me upon Rachel's knees, therefore she called my name Naphtali.

**[1:7]** For Rachel loved me very much because I was born upon her lap; and when I was still young she was wont to kiss me, and say: May I have a brother of thine from mine own womb, like unto thee.

**[1:8]** Whence also Joseph was like unto me in all things, according to the prayers of Rachel.

**[1:9]** Now my mother was Bilhah, daughter of Rotheus the brother of Deborah, Rebecca's nurse, who was born on one and the self-same day with Rachel.

**[1:10]** And Rotheus was of the family of Abraham, a Chaldean, God-fearing, free-born, and noble.

**[1:11]** And he was taken captive and was bought by Laban; and he gave him Euna his handmaid to wife, and she bore a daughter, and called her name Zilpah, after the name of the village in which he had been taken captive.

**[1:12]** And next she bore Bilhah, saying: My daughter hastens after what is new, for immediately that she was born she seized the breast and hastened to suck it.

**[1:13]** And I was swift on my feet like the deer, and my father Jacob appointed me for all messages, and as a deer did he give me his blessing.

**[1:14]** For as the potter knoweth the vessel, how much it is to contain, and bringeth clay accordingly, so also doth the Lord make the body after the likeness of the spirit, and according to the capacity of the body doth He implant the spirit.

**[1:15]** And the one does not fall short of the other by a third part of a hair; for by weight, and measure, and rule was all the creation made.

**[1:16]** And as the potter knoweth the use of each vessel, what it is meet for, so also doth the Lord know the body, how far it will persist in goodness, and when it beginneth in evil.

**[1:17]** For there is no inclination or thought which the Lord knoweth not, for He created every man after His own image.

**[1:18]** For as a man's strength, so also in his work; as his eye, so also in his sleep; as his soul, so also in his word either in the law of the Lord or in the law of Beliar.

**[1:19]** And as there is a division between light and darkness, between seeing and hearing, so also is there a division between man and man, and between woman and woman; and it is not to be said that the one is like the other either in face or in mind.

**[1:20]** For God made all things good in their order, the five senses in the head, and He joined on the neck to the head, adding to it the hair also for comeliness and glory, then the heart for understanding, the belly for excrement, and the stomach for grinding, the windpipe for taking in the breath, the liver for wrath, the gall for bitterness, the spleen for laughter, the reins for prudence, the muscles of the loins for power, the lungs for drawing in, the loins for strength, and so forth.

**[1:21]** So then, my children, let all your works be done in order with good intent in the fear of God, and do nothing disorderly in scorn or out of its due season.

**[1:22]** For if thou bid the eye to hear, it cannot; so neither while ye are in darkness can ye do the works of light.

**[1:23]** Be ye, therefore, not eager to corrupt your doings through covetousness or with vain words to beguile your souls; because if ye keep silence in purity of heart, ye shall understand how to hold fast the will of God, and to cast away the will of Beliar.

**[1:24]** Sun and moon and stars, change not their order; so do ye also change not the law of God in the disorderliness of your doings.

**[1:25]** The Gentiles went astray, and forsook the Lord, and charged their order, and obeyed stocks and stones, spirits of deceit.

**[1:26]** But ye shall not be so, my children, recognizing in the firmament, in the earth, and in the sea, and in all created things, the Lord who made all things, that ye become not as Sodom, which changed the order of nature.

**[1:27]** In like manner the Watchers also changed the order of their nature, whom the Lord cursed at the flood, on whose account He made the earth without inhabitants and fruitless.

**[1:28]** These things I say unto you, my children, for I have read in the writing of Enoch that ye yourselves also shall depart from the Lord, walking according to all the lawlessness of the Gentiles, and ye shall do according to all the wickedness of Sodom.

**[1:29]** And the Lord shall bring captivity upon you, and there shall ye serve your enemies, and ye shall be bowed down with every affliction and tribulation, until the Lord have consumed you all.

**[1:30]** And after ye have become diminished and made few, ye return and acknowledge the Lord your God; and He shall bring you back into your land, according to His abundant mercy.

**[1:31]** And it shall be, that after that they come into the land of their fathers, they shall again forget the Lord and become ungodly.

**[1:32]** And the Lord shall scatter them upon the face of all the earth, until the compassion of the Lord shall come, a man working righteousness and working mercy unto all them that are afar off, and to them that are near.



---



**[2:1]** FOR in the fortieth year of my life, I saw a vision on the Mount of Olives, on the east of Jerusalem, that the sun and the moon were standing still.

**[2:2]** And behold Isaac, the father of my father, said to us; Run and lay hold of them, each one according to his strength; and to him that seizeth them will the sun and moon belong.

**[2:3]** And we all of us ran together, and Levi laid hold of the sun, and Judah outstripped the others and seized the moon, and they were both of them lifted up with them.

**[2:4]** And when Levi became as a sun, lo, a certain young man gave to him twelve branches of palm; and Judah was bright as the moon, and under their feet were twelve rays.

**[2:5]** And the two, Levi and Judah, ran, and laid hold of them.

**[2:6]** And lo, a bull upon the earth, with two great horns, and an eagle's wings upon its back; and we wished to seize him, but could not.

**[2:7]** But Joseph came, and seized him, and ascended up with him on high.

**[2:8]** And I saw, for I was there, and behold a holy writing appeared to us, saying: Assyrians, Medes, Persians, Chaldeans, Syrians, shall possess in captivity the twelve tribes of Israel.

**[2:9]** And again, after seven days, I saw our father Jacob standing by the sea of Jamnia, and we were with him.

**[2:10]** And behold, there came a ship sailing by, without sailors or pilot; and there was written upon the ship, The Ship of Jacob.

**[2:11]** And our father said to us: Come, let us embark on our ship.

**[2:12]** And when he had gone on board, there arose a vehement storm, and a mighty tempest of wind; and our father, who was holding the helm, departed from us.

**[2:13]** And we, being tost with the tempest, were borne along over the sea; and the ship was filled with water, and was pounded by mighty waves, until it was broken up.

**[2:14]** And Joseph fled away upon a little boat, and we were all divided upon nine planks, and Levi and Judah were together.

**[2:15]** And we were all scattered unto the ends of the earth.

**[2:16]** Then Levi, girt about with sackcloth, prayed for us all unto the Lord.

**[2:17]** And when the storm ceased, the ship reached the land as it were in peace.

**[2:18]** And, lo, our father came, and we all rejoiced with one accord.

**[2:19]** These two dreams I told to my father; and he said to me: These things must be fulfilled in their season, after that Israel hath endured many things.

**[2:20]** Then my father saith unto me: I believe God that Joseph liveth, for I see always that the Lord numbereth him with you.

**[2:21]** And he said, weeping: Ah me, my son Joseph, thou livest, though I behold thee not, and thou seest not Jacob that begat thee.

**[2:22]** He caused me also, therefore, to weep by these words, and I burned in my heart to declare that Joseph had been sold, but I feared my brethren.

**[2:23]** And lo! my children, I have shown unto you the last times, how everything shall come to pass in Israel.

**[2:24]** Do ye also, therefore, charge your children that they be united to Levi and to Judah; for through them shall salvation arise unto Israel, and in them shall Jacob be blessed.

**[2:25]** For through their tribes shall God appear dwelling among men on earth, to save the race of Israel, and to gather together the righteous from amongst the Gentiles.

**[2:26]** If ye work that which is good, my children, both men and angels shall bless you; and God shall be glorified among the Gentiles through you, and the devil shall flee from you, and the wild beasts shall fear you, and the Lord shall love you, and the angels shall cleave to you.

**[2:27]** As a man who has trained a child well is kept in kindly remembrance; so also for a good work there is a good remembrance before God.

**[2:28]** But him that doeth not that which is good, both angels and men shall curse, and God shall be dishonoured among the Gentiles through him, and the devil shall make him as his own peculiar instrument, and every wild beast shall master him, and the Lord shall hate him.

**[2:29]** For the commandments of the law are twofold, and through prudence must they be fulfilled.

**[2:30]** For there is a season for a man to embrace his wife, and a season to abstain therefrom for his prayer.

**[2:31]** So, then, there are two commandments; and, unless they be done in due order, they bring very great sin upon men.

**[2:32]** So also is it with the other commandments.

**[2:33]** Be ye therefore wise in God, my children, and prudent, understanding the order of His commandments, and the laws of every word, that the Lord may love you,

**[2:34]** And when he had charged them with many such words, he exhorted them that they should remove his bones to Hebron, and that they should bury him with his fathers.

**[2:35]** And when he had eaten and drunken with a merry heart, he covered his face and died.

**[2:36]** And his sons did according to all that Naphtali their Father had commanded them.

