# The Testament of Benjamin / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Benjamin, which he commanded his sons to observe, after he had lived a hundred and twenty-five years.

**[1:2]** And he kissed them, and said: As Isaac was born to Abraham in his old age, so also was I to Jacob.

**[1:3]** And since Rachel my mother died in giving me birth, I had no milk; therefore I was suckled by Bilhah her handmaid.

**[1:4]** For Rachel remained barren for twelve years after she had borne Joseph; and she prayed the Lord with fasting twelve days, and she conceived and bare Me.

**[1:5]** For my father loved Rachel dearly, and prayed that he might see two sons born from her.

**[1:6]** Therefore was I called Benjamin, that is, a son of days.

**[1:7]** And when I went into Egypt, to Joseph, and my brother recognized me, he said unto me: What did they tell my father when they sold me?

**[1:8]** And I said unto him, They dabbled thy coat with blood and sent it, and said: Know whether this be thy son's coat.

**[1:9]** And he said unto me: Even so, brother, when they had stripped me of my coat they gave me to the Ishmaelites, and they gave me a loin cloth, and scourged me, and bade me run.

**[1:10]** And as for one of them that had beaten me with a rod, a lion met him and slew him.

**[1:11]** And so his associates were affrighted.

**[1:12]** Do ye also, therefore, my children, love the Lord God of heaven and earth, and keep His commandments, following the example of the good and holy man Joseph.

**[1:13]** And let your mind be unto good, even as ye know me; for he that bath his mind right seeth all things rightly.

**[1:14]** Fear ye the Lord, and love your neighbour; and even though the spirits of Beliar claim you to afflict you with every evil, yet shall they not have dominion over you, even as they had not over Joseph my brother.,

**[1:15]** How many men wished to slay him, and God shielded him!

**[1:16]** For he that feareth God and loveth his neighbour cannot be smitten by the spirit of Beliar, being shielded by the fear of God.

**[1:17]** Nor can he be ruled over by the device of men or beasts, for he is helped by the Lord through the love which he hath towards his neighbour.

**[1:18]** For Joseph also besought our father that he would pray for his brethren, that the Lord would not impute to them as sin whatever evil they had done unto him.

**[1:19]** And thus Jacob cried out: My good child, thou hast prevailed over the bowels of thy father Jacob.

**[1:20]** And he embraced him, and kissed him for two hours, saying:

**[1:21]** In thee shall be fulfilled the prophecy of heaven concerning the Lamb of God, and Saviour of the world, and that a blameless one shall be delivered up for lawless men, and a sinless one shall die for ungodly men in the blood of the covenant, for the salvation of the Gentiles and of Israel, and shall destroy Beliar and his servants.

**[1:22]** See ye, therefore, my children, the end of the good man?

**[1:23]** Be followers of his compassion, therefore, with a good mind, that ye also may wear crowns of glory.

**[1:24]** For the good man hath not a dark eye; for he showeth mercy to all men, even though they be sinners.

**[1:25]** And though they devise with evil intent. concerning him, by doing good he overcometh evil, being shielded by God; and he loveth the righteous as his own soul.

**[1:26]** If any one is glorified, he envieth him not; if any one is enriched, he is not jealous; if any one is valiant, he praiseth him; the virtuous man he laudeth; on the poor man he hath mercy; on the weak he hath compassion; unto God he singeth praises.

**[1:27]** And him that hath the grace of a good spirit he loveth as his own soul.

**[1:28]** If therefore, ye also have a good mind, then will both wicked men be at peace with you, and the profligate will reverence you and turn unto good; and the covetous will not only cease from their inordinate desire, but even give the objects of their covetousness to them that are afflicted.

**[1:29]** If ye do well, even the unclean spirits will flee from you; and the beasts will dread you.

**[1:30]** For where there is reverence for good works and light in the mind, even darkness fleeth away from him.

**[1:31]** For if any one does violence to a holy man, he repenteth; for the holy man is merciful to his reviler, and holdeth his peace.

**[1:32]** And if any one betrayeth a righteous man, the righteous man prayeth: though for a little he be humbled, yet not long after he appeareth far more glorious, as was Joseph my brother.

**[1:33]** The inclination of the good man is not in the power of the deceit of the spirit of Beliar, for the angel of peace guideth his soul.

**[1:34]** And he gazeth not passionately upon corruptible things, nor gathereth together riches through a desire of pleasure.

**[1:35]** He delighteth not in pleasure, he grieveth not his neighbour, he sateth not himself with luxuries, he erreth not in the uplifting of the eyes, for the Lord is his portion.

**[1:36]** The good inclination receiveth not glory nor dishonour from men, and it knoweth not any guile, or lie, or fighting or reviling; for the Lord dwelleth in him and lighteth up his soul, and he rejoiceth towards all men always.

**[1:37]** The good mind hath not two tongues, of blessing and of cursing, of contumely and of honour, of sorrow and of joy, of quietness and of confusion, of hypocrisy and of truth, of poverty and of wealth; but it hath one disposition, uncorrupt and pure, concerning all men.

**[1:38]** It hath no double sight, nor double hearing; for in everything which he doeth, or speaketh, or seeth, he knoweth that the Lord looketh on his soul.

**[1:39]** And he cleanseth his mind that he may not be condemned by men as well as by God.

**[1:40]** And in like manner the works of Beliar are twofold, and there is no singleness in them.

**[1:41]** Therefore, my children, I tell you, flee the malice of Beliar; for he giveth a sword to them that obey him.

**[1:42]** And the sword is the mother of seven evils. First the mind conceiveth through Beliar, and first there is bloodshed; secondly ruin; thirdly, tribulation; fourthly, exile; fifthly, dearth; sixthly, panic; seventhly, destruction.

**[1:43]** 'Therefore was Cain also delivered over to seven vengeances by God, for in every hundred years the Lord brought one plague upon him.

**[1:44]** And when he was two hundred years old he began to suffer, and in the nine-hundredth year he was destroyed.

**[1:45]** For on account of Abel, his brother, with -all the evils was he judged, but Lamech with seventy times seven.

**[1:46]** Because for ever those, who are like Cain in envy and hatred of brethren, shall be punished with the same judgement.



---



**[2:1]** AND do ye, my children, flee evil-doing, envy, and hatred of brethren, and cleave to goodness and love.

**[2:2]** He that hath a pure mind in love, looketh not after a woman with a view to fornication; for he hath no defilement in his heart, because the Spirit of God resteth upon him.

**[2:3]** For as the sun is not defiled by shining on dung and mire, but rather drieth up both and driveth away the evil smell; so also the pure mind, though encompassed by the defilements of earth, rather cleanseth them and is not itself defiled.

**[2:4]** And I believe that there will be also evil-doings among you, from the words of Enoch the righteous: that ye shall commit fornication with the fornication of Sodom, and shall perish, all save a few, and shall renew wanton deeds with women; and the kingdom of the Lord shall not be among you, for straightway He shall take it away.

**[2:5]** Nevertheless the temple of God shall be in your portion, and the last temple shall be more glorious than the first.

**[2:6]** And the twelve tribes shall be gathered together there, and all the Gentiles, until the Most High shall send forth His salvation in the visitation of an only-begotten prophet.

**[2:7]** And He shall enter into the first temple, and there shall the Lord be treated with outrage, and He shall be lifted up upon a tree.

**[2:8]** And the veil of the temple shall be rent, and the Spirit of God shall pass on to the Gentiles as fire poured forth.

**[2:9]** And He shall ascend from Hades and shall pass from earth into heaven.

**[2:10]** And I know how lowly He shall be upon earth, and how glorious in heaven.

**[2:11]** Now when Joseph was in Egypt, I longed to see his figure and the form of his countenance; and through the prayers of Jacob my father I saw him, while awake in the daytime, even his entire figure exactly as he was.

**[2:12]** And when he had said these things, he said unto them: Know ye, therefore, my children, that I am dying.

**[2:13]** Do ye, therefore, truth each one to his neighbour, and keep the law of the Lord and His commandments.

**[2:14]** For these things do I leave you instead of inheritance.

**[2:15]** Do ye also, therefore, give them to your children for an everlasting possession; for so did both Abraham, and Isaac, and Jacob.

**[2:16]** For all these things they gave us for an inheritance, saying: Keep the commandments of God, until the Lord shall reveal His salvation to all Gentiles.

**[2:17]** And then shall ye see Enoch, Noah, and Shem, and Abraham, and Isaac, and Jacob, rising on the right hand in gladness,

**[2:18]** Then shall we also rise, each one over our tribe, worshipping the King of heaven, who appeared upon earth in the form of a man in humility.

**[2:19]** And as many as believe on Him on the earth shall rejoice with Him.

**[2:20]** Then also all men shall rise, some unto glory and some unto shame.

**[2:21]** And the Lord shall judge Israel first, for their unrighteousness; for when He appeared as God in the flesh to deliver them they believed Him not.

**[2:22]** And then shall He judge all the Gentiles, as many as believed Him not when He appeared upon earth.

**[2:23]** And He shall convict Israel through the chosen ones of the Gentiles, even as He reproved Esau through the Midianites, who deceived their brethren, so that they fell into fornication, and idolatry; and they were alienated from God, becoming therefore children in the portion of them that fear the Lord.

**[2:24]** If ye therefore, my children, walk in holiness according to the commandments of the Lord, ye shall again dwell securely with me, and all Israel shall be gathered unto the Lord.

**[2:25]** And I shall no longer be called a ravening wolf on account of your ravages, but a worker of the Lord distributing food to them that work what is good.

**[2:26]** And there shall arise in the latter days one beloved of the Lord, of the tribe of Judah and Levi, a doer of His good pleasure in his mouth, with new knowledge enlightening the Gentiles.

**[2:27]** Until the consummation of the age shall he be in the synagogues of the Gentiles, and among their rulers, as a strain of music in the mouth of all.

**[2:28]** And he shall be inscribed in the holy books, both his work and his word, and he shall be a chosen one of God for ever.

**[2:29]** And through them he shall go to and fro as Jacob my father, saying: He shall fill up that which lacketh of thy tribe.

**[2:30]** And when he had said these things he stretched out his feet.

**[2:31]** And died in a beautiful and good sleep.

**[2:32]** And his sons did as he had enjoined them, and they took up his body and buried it in Hebron with his fathers.

**[2:33]** And the number of the days of his life was a hundred and twenty-five years.

