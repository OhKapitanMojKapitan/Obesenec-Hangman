# The Testament of Asher / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the Testament To Asher, what things he spake to his sons in the hundred and twenty-fifth year of his life.

**[1:2]** For while he was still in health, he said to them: Hearken, ye children of Asher, to your father, and I will declare to you all that is upright in the sight of the Lord.

**[1:3]** Two ways hath God given to the sons of men, and two inclinations, and two kinds of action, and two modes of action, and two issues.

**[1:4]** Therefore all things are by twos, one over against the other.

**[1:5]** For there are two ways of good and evil, and with these are the two inclinations in our breasts discriminating them.

**[1:6]** Therefore if the soul take pleasure in the good inclination, all its actions are in righteousness; and if it sin it straightway repenteth.

**[1:7]** For, having its thoughts set upon righteousness, and casting away wickedness, it straightway overthroweth the evil, and uprooteth the sin.

**[1:8]** But if it incline to the evil inclination, all its actions are in wickedness, and it driveth away the good, and cleaveth to the evil, and is ruled by Beliar; even though it work what is good, he perverteth it to evil.

**[1:9]** For whenever it beginneth to do good, he forceth the issue of the action into evil for him, seeing that the treasure of the inclination is filled with an evil spirit.

**[1:10]** A person then may with words help the good for the sake of the evil, yet the issue of the action leadeth to mischief.

**[1:11]** There is a man who showeth no compassion upon him who serveth his turn in evil; and this thing bath two aspects, but the whole is evil.

**[1:12]** And there is a man that loveth him that worketh evil, because he would prefer even to die in evil for his sake; and concerning this it is clear that it bath two aspects, but the whole is an evil work.

**[1:13]** Though indeed he have love, yet is he wicked who concealeth what is evil for the sake of the good name, but the end of the action tendeth unto evil.

**[1:14]** Another stealeth, doeth unjustly, plundereth, defraudeth, and withal pitieth the poor: this too bath a twofold aspect, but the whole is evil.

**[1:15]** He who defraudeth his neighbour provoketh God, and sweareth falsely against the Most High, and yet pitieth the poor: the Lord who commanded the law he setteth at nought and provoketh, and yet he refresheth the poor.

**[1:16]** He defileth the soul, and maketh gay the body; he killeth many, and pitieth a few: this, too, bath a twofold aspect, but the whole is evil.

**[1:17]** Another committeth adultery and fornication, and abstaineth from meats, and when he fasteth he doeth evil, and by the power of his wealth overwhelmeth many; and notwithstanding his excessive wickedness he doeth the commandments: this, too, hath a twofold aspect, but the whole is evil.

**[1:18]** Such men are hares; clean,--like those that divide the hoof, but in very deed are unclean.

**[1:19]** For God in the tables of the commandments hath thus declared.

**[1:20]** But do not ye, my children, wear two faces like unto them, of goodness and of wickedness; but cleave unto goodness only, for God hath his habitation therein, and men desire it.

**[1:21]** But from wickedness flee away, destroying the evil inclination by your good works; for they that are double-faced serve not God, but their own lusts, so that they may please Beliar and men like unto themselves.

**[1:22]** For good men, even they that are of single face, though they be thought by them that are double-faced to sin, are just before God.

**[1:23]** For many in killing the wicked do two works, of good and evil; but the whole is good, because he hath uprooted and destroyed that which is evil.

**[1:24]** One man hateth the merciful and unjust man, and the man who committeth adultery and fasteth: this, too, hath a twofold aspect, but the whole work is good, because he followeth the Lord's example, in that he accepteth not the seeming good as the genuine good.

**[1:25]** Another desireth not to see good day with them that not, lest be defile his body and pollute his soul; this, too, is double-faced, but the whole is good.

**[1:26]** For such men are like to stags and to hinds, because in the manner of wild animals they seem to be unclean, but they are altogether clean; because they walk in zeal for the Lord and abstain from what God also hateth and forbiddeth by His commandments, warding off the evil from the good.

**[1:27]** Ye see, my children, how that there are two in all things, one against the other, and the one is hidden by the other: in wealth is hidden covetousness, in conviviality drunkenness, in laughter grief, in wedlock profligacy.

**[1:28]** Death succeedeth to life, dishonour to glory, night to day, and darkness to light; and all things are under the day, just things under life, unjust things under death; wherefore also eternal life awaiteth death.

**[1:29]** Nor may it be said that truth is a lie, nor right wrong; for all truth is under the light, even as all things are under God.

**[1:30]** All these things, therefore, I proved in my life, and I wandered not from the truth of the Lord, and I searched out the commandments of the Most High, walking according to all my strength with singleness of face unto that which is good.

**[1:31]** Take heed, therefore, ye also, my children, to the commandments of the Lord, following the truth with singleness of face.

**[1:32]** For they that are double-faced are guilty of a twofold sin; for they both do the evil thing and they have pleasure in them that do it, following the example of the spirits of deceit, and striving against mankind.

**[1:33]** Do ye, therefore, my children, keep the law of the Lord, and give not heed unto evil as unto good; but look unto the thing that is really good, and keep it in all commandments of the Lord, having your conversation therein, and resting therein.

**[1:34]** For the latter ends of men do show their righteousness or unrighteousness, when they meet the angels of the Lord and of Satan.

**[1:35]** for when the soul departs troubled, it is tormented by the evil spirit which also it served in lusts and evil works.

**[1:36]** But if he is peaceful with joy he meeteth the angel of peace, and he leadeth him into eternal life.

**[1:37]** Become not, my children, as Sodom, which sinned against the angels of the Lord, and perished for ever.

**[1:38]** For I know that ye shall sin, and be delivered into the hands of your enemies; and your land shall be made desolate, and your holy places destroyed, and ye shall be scattered unto the four corners of the earth.

**[1:39]** And ye shall be set at nought in the dispersion vanishing away as water.

**[1:40]** Until the Most High shall visit the earth, coming Himself as man, with men eating and drinking, and breaking the head of the dragon in the water.

**[1:41]** He shall save Israel and all the Gentiles, God speaking in the person of man.

**[1:42]** Therefore do ye also, my children, tell these things to your children, that they disobey Him not.

**[1:43]** For I have known that ye shall assuredly be disobedient, and assuredly act ungodly, not giving heed to the law of God, but to the commandments of men, being corrupted through wickedness.

**[1:44]** And therefore shall ye be scattered as Gad and Dan my brethren, and ye shall know not your lands, tribe, and tongue.

**[1:45]** But the Lord will gather you together in faith through His tender mercy, and for the sake of Abraham, Isaac, and Jacob.

**[1:46]** And when he had said these things unto them, he commanded them, saying: Bury me in Hebron.

**[1:47]** And he fell asleep and died at a good old age.

**[1:48]** And his sons did as he had commanded them, and they carried him up to Hebron, and buried him with his fathers.

