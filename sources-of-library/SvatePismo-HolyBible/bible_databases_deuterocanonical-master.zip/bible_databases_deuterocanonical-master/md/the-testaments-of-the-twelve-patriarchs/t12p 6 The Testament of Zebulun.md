# The Testament of Zebulun / Testaments of the Twelve Patriarchs



**[1:1]** THE copy of the words of Zebulun, which he enjoined on his sons before he died in the hundred and fourteenth year of his life, two years after the death of Joseph.

**[1:2]** And he said to them: Hearken to me, ye sons of Zebulun attend to the words of your father.

**[1:3]** I, Zebulun, was born a good gift to my parents.

**[1:4]** For when I was born my father was increased very exceedingly, both in flocks and herds, when with the straked rods he had his portion.

**[1:5]** I am not conscious that I have sinned all my days, save in thought.

**[1:6]** Nor yet do I remember that I have done any iniquity, except the sin of ignorance which I committed against Joseph; for I covenanted with my brethren not to tell my father what had been done.

**[1:7]** But I wept in secret many days on account of Joseph, for I feared my brethren, because they had all agreed that if any one should declare the secret, he should be slain.

**[1:8]** But when they wished to kill him, I adjured them much with tears not to be guilty of this sin.

**[1:9]** For Simeon and Gad came against Joseph to kill him, and he said unto them with tears: Pity me, my brethren, have mercy upon the bowels of Jacob our father: lay not upon me your hands to shed innocent blood, for I have not sinned against you.

**[1:10]** And if indeed I have sinned, with chastening chastise me, my brethren, but lay not upon me your hand, for the sake of Jacob our father,

**[1:11]** And as he spoke these words, wailing as he did so, I was unable to bear his lamentations, and began to weep, and my liver was poured out, and all the substance of my bowels was loosened.

**[1:12]** And I wept with Joseph and my heart sounded, and the joints of my body trembled, and I was not able to stand.

**[1:13]** And when Joseph saw me weeping with him, and them coming against him to slay him, he fled behind me, beseeching them.

**[1:14]** But meanwhile Reuben arose and said: Come, my brethren, let us not slay him, but let us cast him into one of these dry pits, which our fathers digged and found no water.

**[1:15]** For for this cause the Lord forbade that water should rise up in them in order that Joseph should be preserved.

**[1:16]** And they did so, until they sold him to the Ishmaelites.

**[1:17]** For in his price I had no share, my children.

**[1:18]** But Simeon and Gad and six other of our brethren took the price of Joseph, and bought sandals for themselves, and their wives, and their children, saying:

**[1:19]** We will not eat of it, for it is the price of our brother's blood, but we will assuredly tread it under foot, because he said that he would be king over us, and so let us see what will become of his dreams.

**[1:20]** Therefore it is written in the writing of the law of Moses, that whosoever will not raise up seed to his brother, his sandal should be unloosed, and they should spit in his face.

**[1:21]** And the brethren of Joseph wished not that their brother should live, and the Lord loosed from them the sandal which they wore against Joseph their brother.

**[1:22]** For when they came into Egypt they were unloosed by the servants of Joseph outside the gate, and so they made obeisance to Joseph after the fashion of King Pharaoh.

**[1:23]** And not only did they make obeisance to him, but were spit upon also, falling down before him forthwith, and so they were put to shame before. the Egyptians.

**[1:24]** For after this the Egyptians heard all the evils that they had done to Joseph.

**[1:25]** And after he was sold my brothers sat down to eat and drink.

**[1:26]** But I, through pity for Joseph, did not eat, but watched the pit, since Judah feared lest Simeon, Dan, and Gad should rush off and slay him.

**[1:27]** But when they saw that I did not eat, they set me to watch him, till he was sold to the Ishmaelites.

**[1:28]** And when Reuben came and heard that while he was away Joseph had been sold, he rent his garments, and mourning, said:

**[1:29]** How shall I look on the face of my father Jacob? And he took the money and ran after the merchants but as he failed to find them he returned grieving.

**[1:30]** But the merchants had left the broad road and marched through the Troglodytes by a short cut.

**[1:31]** But Reuben was grieved, and ate no food that day.

**[1:32]** Dan therefore came to him and said: Weep not, neither grieve; for we have found what we can say to our father Jacob.

**[1:33]** Let us slay a kid of the goats, and dip in it the coat of Joseph; and let us send it to Jacob, saying: Know, is this the coat of thy son?

**[1:34]** And they did so. For they stripped off from Joseph his coat when they were selling him, and put upon him the garment of a slave.

**[1:35]** Now Simeon took the coat, and would not give it up, for he wished to rend it with his sword, as he was angry that Joseph lived and that he had not slain him.

**[1:36]** Then we all rose up and said unto him: If thou givest not up the coat, we will say to our father that thou alone didst this evil thing in Israel.

**[1:37]** And so he gave it unto them, and they did even as Dan had said.



---



**[2:1]** AND now children, I bid you to keep the commands of the Lord, and to show mercy to your neighbours, and to have compassion towards all, not towards men only, but also towards beasts.

**[2:2]** For all this thing's sake the Lord blessed me, and when all my brethren were sick, I escaped without sickness, for the Lord knoweth the purposes of each.

**[2:3]** Have, therefore, compassion in your hearts, my children, because even as a man doeth to his neighbour, even so also will the Lord do to him.

**[2:4]** For the sons of my brethren were sickening and were dying on account of Joseph, because they showed not mercy in their hearts; but my sons were preserved without sickness, as ye know.

**[2:5]** And when I was in the land of Canaan, by the sea-coast, I made a catch of fish for Jacob my father; and when many were choked in the sea, I continued unhurt.

**[2:6]** I was the first to make a boat to sail upon the sea, for the Lord gave me understanding and wisdom therein.

**[2:7]** And I let down a rudder behind it, and I stretched a sail upon another upright piece of wood in the midst.

**[2:8]** And I sailed therein along the shores, catching fish for the house of my father until we came to Egypt.

**[2:9]** And through compassion I shared my catch with every stranger.

**[2:10]** And if a man were a stranger, or sick, or aged, I boiled the fish, and dressed them well, and offered them to all men, as every man had need, grieving with and having compassion upon them.

**[2:11]** Wherefore also the Lord satisfied me with abundance of fish when catching fish; for he that shareth with his neighbour receiveth manifold more from the Lord.

**[2:12]** For five years I caught fish and gave thereof to every man whom I saw, and sufficed for all the house of my father.

**[2:13]** And in the summer I caught fish, and in the winter I kept sheep with my brethren.

**[2:14]** Now I will declare unto you what I did.

**[2:15]** I saw a man in distress through nakedness in wintertime, and had compassion upon him, and stole away a garment secretly from my father's house, and gave it to him who was in distress.

**[2:16]** Do you, therefore, my children, from that which God bestoweth upon you, show compassion and mercy without hesitation to all men, and give to every man with a good heart.

**[2:17]** And if ye have not the wherewithal to give to him that needeth, have compassion for him in bowels of mercy.

**[2:18]** I know that my hand found not the wherewithal to give to him that needed, and I walked with him weeping for seven furlongs, and my bowels yearned towards him in compassion.

**[2:19]** Have, therefore, yourselves also, my children, compassion towards every man with mercy, that the Lord also may have compassion and mercy upon you.

**[2:20]** Because also in, the last days God will send His compassion on the earth, and wheresoever He findeth bowels of mercy He dwelleth in him.

**[2:21]** For in the degree in which a man hath compassion upon his neighbours, in the same degree hath the Lord also upon him.

**[2:22]** And when we went down into Egypt, Joseph bore no malice against us.

**[2:23]** To whom taking heed, do ye also, my children, approve yourselves without malice, and love one another; and do not set down in account, each one of you, evil against his brother.

**[2:24]** For this breaketh unity and divideth all kindred, and troubleth the soul, and weareth away the countenance.

**[2:25]** Observe, therefore, the waters, and know when they flow together, they sweep along stones, trees, earth, and other things.

**[2:26]** But if they are divided into many streams, the earth swalloweth them up, and they vanish away.

**[2:27]** So shall ye also be if ye be divided. Be not Ye, therefore, divided into two heads for everything which the Lord made .hath but one head, and two shoulders, two hands, two feet, and all the remaining members.

**[2:28]** For I have learnt in the writing of my fathers, that ye shall be divided in Israel, and ye shall follow two kings, and shall work every abomination.

**[2:29]** And your enemies shall lead you captive, and ye shall be evil entreated among the Gentiles, with many infirmities and tribulations.

**[2:30]** And after these things ye shall remember the Lord and repent, and He shall have mercy upon you, for He is merciful and compassionate.

**[2:31]** And He setteth not down in account evil against the sons of men, because they are flesh, and are deceived through their own wicked deeds.

**[2:32]** And after these things shall there arise unto you the Lord Himself, the light of righteousness, and ye shall return unto your land.

**[2:33]** And ye shall see Him in Jerusalem, for His name's sake.

**[2:34]** And again through the wickedness of your works shall ye provoke Him to anger,

**[2:35]** And ye shall be cast away by Him unto the time of consummation.

**[2:36]** And now, my children, grieve not that I am dying, nor be cast down in that I am coming to my end.

**[2:37]** For I shall rise again in the midst of you, as a ruler in the midst of his sons; and I shall rejoice in the midst of my tribe, as many as shall keep the law of the Lord, and the commandments of Zebulun their father.

**[2:38]** But upon the ungodly shall the Lord bring eternal fire, and destroy them throughout all generations.

**[2:39]** But I am now hastening away to my rest, as did also my fathers.

**[2:40]** But do ye fear the Lord our God with all your strength all the days of your life.

**[2:41]** And when he had said these things he fell asleep, at a good old age.

**[2:42]** And his sons laid him in a wooden coffin. And afterwards they carried him up and buried him in Hebron, with his fathers.

