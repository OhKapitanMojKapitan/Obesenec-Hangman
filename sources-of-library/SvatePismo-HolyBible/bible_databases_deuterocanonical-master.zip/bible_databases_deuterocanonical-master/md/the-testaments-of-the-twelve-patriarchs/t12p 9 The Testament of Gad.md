# The Testament of Gad / Testaments of the Twelve Patriarchs 



**[1:1]** THE copy of the testament of Gad, what things he spake unto his sons, in the hundred and twenty-fifth year of his life, saying unto them:

**[1:2]** Hearken, my children, I was the ninth son born to Jacob, and I was valiant in keeping the flocks.

**[1:3]** Accordingly I guarded at night the flock; and whenever the lion came, or the wolf, or any wild beast against the fold, I pursued it, and overtaking it I seized its foot with my hand and hurled it about a stone's throw, and so killed it.

**[1:4]** Now Joseph my brother was feeding the flock with us for upwards of thirty days, and being young, he fell sick by reason of the heat.

**[1:5]** And he returned to Hebron to our father, who made him lie down near him, because he loved him greatly.

**[1:6]** And Joseph told our father that the sons of Zilpah and Bilhah were slaying the best of the flock and eating them against the judgement of Reuben and Judah.

**[1:7]** For he saw that I had delivered a lamb out of the mouth of a bear, and put the bear to death; but had slain the lamb, being grieved concerning it that it could not live, and that we had eaten it.

**[1:8]** And regarding this matter I was wroth with Joseph until the day that he was sold.

**[1:9]** And the spirit of hatred was in me, and I wished not either to hear of Joseph with the ears, or see him with the eyes, because he rebuked us to our faces saying that we were eating of the flock without Judah.

**[1:10]** For whatsoever things he told our father, he believed him.

**[1:11]** I confess now my gin, my children, that oftentimes I wished to kill him, because I hated him from my heart.

**[1:12]** Moreover, I hated him yet more for his dreams; and I wished to lick 1 him out of the land of the living, even as an ox licketh up the grass of the field.

**[1:13]** And Judah sold him secretly to the Ishmaelites.

**[1:14]** Thus the God of our fathers delivered him from our hands, that we should not work great lawlessness in Israel.

**[1:15]** And now, my children, hearken to the words of truth to work righteousness, and all the law of the Most High, and go not astray through the spirit of hatred, for it is evil in all the doings of men.

**[1:16]** Whatsoever a man doeth the hater abominateth him: and though a man worketh the law of the Lord, he praiseth him not; though a man feareth the Lord, and taketh pleasure in that which is righteous, he loveth him not.

**[1:17]** He dispraiseth the truth, he envieth him that prospereth, he welcometh evil-speaking, he loveth arrogance, for hatred blindeth his soul; as I also then looked on Joseph.

**[1:18]** Beware, therefore, my children of hatred, for it worketh lawlessness even against the Lord Himself.

**[1:19]** For it will not hear the words of His commandments concerning the loving of one's--neighbour, and it sinneth against God.

**[1:20]** For if a brother stumble, it delighteth immediately to proclaim it to all men, and is urgent that he should be judged for it, and be punished and be put to death.

**[1:21]** And if it be a servant it stirreth him up against his master, and with every affliction it deviseth against him, if possibly he can be put to death.

**[1:22]** For hatred worketh with envy also against them that prosper: so long as it heareth of or seeth their success it always languisheth.

**[1:23]** For as love would quicken even the dead, and would call back them that are condemned to die, so hatred would slay the living, and those that had sinned venially it would not suffer to live.

**[1:24]** For the spirit of hatred worketh together with Satan, through hastiness of spirits, in all things to men's death; but the spirit of love worketh together with the law of God in long-suffering unto the salvation of men.

**[1:25]** Hatred, therefore, is evil, for it constantly mateth with lying, speaking against the truth; and it maketh small things to be great, and causeth the light to be darkness, and calleth the sweet bitter, and teacheth slander, and kindleth wrath, and stirreth up war, and violence and all covetousness; it filleth the heart with evils and devilish poison.

**[1:26]** These things, therefore, I say to you from experience, my children, that ye may drive forth hatred, which is of the devil, and cleave to the love of God.

**[1:27]** Righteousness casteth out hatred, humility destroyeth envy.

**[1:28]** For he that is just and humble is ashamed to do what is unjust, being reproved not of another, but of his own heart, because the Lord looketh on his inclination.

**[1:29]** He speaketh not against a holy man, because the fear of God overcometh hatred.

**[1:30]** For fearing lest he should offend the Lord, he will not do wrong to any man, even in thought.

**[1:31]** These things I learnt at last, after I had repented concerning Joseph.

**[1:32]** For true repentance after a godly sort destroyeth ignorance, and driveth away the darkness, and enlighteneth the eyes, and giveth knowledge to the soul, and leadeth the mind to salvation.

**[1:33]** And those things which it hath not learnt from man, it knoweth through repentance.

**[1:34]** For God brought upon me a disease of the liver; and had not the prayers of Jacob my father succoured me, it had hardly failed but my spirit had departed.

**[1:35]** For by what things a man transgresseth by the same also is he punished .

**[1:36]** Since, therefore, my liver was set mercilessly against Joseph, in my liver too I suffered mercilessly, and was judged for eleven months, for so long a time as I had been angry against Joseph.



---



**[2:1]** AND now, my children, I exhort you, love ye each one his brother, and put away hatred from your hearts, love one another in deed, and in word, and in the inclination of the soul.

**[2:2]** For in the presence of my father I spake peaceably to Joseph; and when I had gone out, the spirit of hatred darkened my mind, and stirred up my soul to slay him.

**[2:3]** Love ye one another from the heart; and if a man sin against thee, speak peaceably to him, and in thy soul hold not guile; and if he repent and confess, forgive him.

**[2:4]** But if he deny it, do not get into a passion with him, lest catching the poison from thee he take to swearing and so thou sin doubly.

**[2:5]** Let not another man hear thy secrets when engaged in legal strife, lest he come to hate thee and become thy enemy, and commit a great sin against thee; for ofttimes he addresseth thee guilefully or busieth himself about thee with wicked intent.

**[2:6]** And though he deny it and yet have a sense of shame when reproved, give over reproving him.

**[2:7]** For be who denieth may repent so as not again to wrong thee; yea, he may also honour thee, and fear and be at peace with thee.

**[2:8]** And if he be shameless and persist in his wrong-doing, even so forgive him from the heart, and leave to God the avenging.

**[2:9]** If a man prospereth more than you, do not be vexed, but pray also for him, that he may have perfect prosperity.

**[2:10]** for so it is expedient for you.

**[2:11]** And if he be further exalted, be not envious of him, remembering that all flesh shall die; and offer praise to God, who giveth things good and profitable to all men.

**[2:12]** Seek out the judgments of the Lord, and thy mind will rest and be at peace.

**[2:13]** And though a man become rich by evil means, even as Esau, the brother of my father, be not jealous; but wait for the end of the Lord.

**[2:14]** For if he taketh away from a man wealth gotten by evil means He forgiveth him if he repent, but the unrepentant is reserved for eternal punishment.

**[2:15]** For the poor man, if free from envy he pleaseth the Lord in all things, is blessed beyond all men, because he hath not the travail of vain men.

**[2:16]** Put away, therefore, jealousy from your souls, and love one another with uprightness of heart.

**[2:17]** Do ye also therefore tell these things to your children, that they honour Judah and Levi, for from them shall the Lord raise up salvation to Israel.

**[2:18]** For I know that at the last your children shall depart from Him, and shall walk in O wickedness, and affliction and corruption before the Lord.

**[2:19]** And when he had rested for a little while, he said again; My children, obey your father, and bury me near to my fathers.

**[2:20]** And he drew up his feet, and fell asleep in peace.

**[2:21]** And after five years they carried him up to Hebron, and laid him with his fathers.

