# Additions to Esther 10



**[10:4]** Then Mardocheus said, God hath done these things.

**[10:5]** For I remember a dream which I saw concerning these matters, and nothing thereof hath failed.

**[10:6]** A little fountain became a river, and there was light, and the sun, and much water: this river is Esther, whom the king married, and made queen:

**[10:7]** And the two dragons are I and Aman.

**[10:8]** And the nations were those that were assembled to destroy the name of the Jews:

**[10:9]** And my nation is this Israel, which cried to God, and were saved: for the Lord hath saved his people, and the Lord hath delivered us from all those evils, and God hath wrought signs and great wonders, which have not been done among the Gentiles.

**[10:10]** Therefore hath he made two lots, one for the people of God, and another for all the Gentiles.

**[10:11]** And these two lots came at the hour, and time, and day of judgment, before God among all nations.

**[10:12]** So God remembered his people, and justified his inheritance.

**[10:13]** Therefore those days shall be unto them in the month Adar, the fourteenth and fifteenth day of the same month, with an assembly, and joy, and with gladness before God, according to the generations for ever among his people.

**[11:1]** In the fourth year of the reign of Ptolemeus and Cleopatra, Dositheus, who said he was a priest and Levite, and Ptolemeus his son, brought this epistle of Phurim, which they said was the same, and that Lysimachus the son of Ptolemeus, that was in Jerusalem, had interpreted it.

**[11:2]** In the second year of the reign of Artexerxes the great, in the first day of the month Nisan, Mardocheus the son of Jairus, the son of Semei, the son of Cisai, of the tribe of Benjamin, had a dream;

**[11:3]** Who was a Jew, and dwelt in the city of Susa, a great man, being a servitor in the king’s court.

**[11:4]** He was also one of the captives, which Nabuchodonosor the king of Babylon carried from Jerusalem with Jechonias king of Judea; and this was his dream:

**[11:5]** Behold a noise of a tumult, with thunder, and earthquakes, and uproar in the land:

**[11:6]** And, behold, two great dragons came forth ready to fight, and their cry was great.

**[11:7]** And at their cry all nations were prepared to battle, that they might fight against the righteous people.

**[11:8]** And lo a day of darkness and obscurity, tribulation and anguish, affliction and great uproar, upon earth.

**[11:9]** And the whole righteous nation was troubled, fearing their own evils, and were ready to perish.

**[11:10]** Then they cried unto God, and upon their cry, as it were from a little fountain, was made a great flood, even much water.

**[11:11]** The light and the sun rose up, and the lowly were exalted, and devoured the glorious.

**[11:12]** Now when Mardocheus, who had seen this dream, and what God had determined to do, was awake, he bare this dream in mind, and until night by all means was desirous to know it.

**[12:1]** And Mardocheus took his rest in the court with Gabatha and Tharra, the two eunuchs of the king, and keepers of the palace.

**[12:2]** And he heard their devices, and searched out their purposes, and learned that they were about to lay hands upon Artexerxes the king; and so he certified the king of them.

**[12:3]** Then the king examined the two eunuchs, and after that they had confessed it, they were strangled.

**[12:4]** And the king made a record of these things, and Mardocheus also wrote thereof.

**[12:5]** So the king commanded, Mardocheus to serve in the court, and for this he rewarded him.

**[12:6]** Howbeit Aman the son of Amadathus the Agagite, who was in great honour with the king, sought to molest Mardocheus and his people because of the two eunuchs of the king.

**[13:1]** The copy of the letters was this: The great king Artexerxes writeth these things to the princes and governours that are under him from India unto Ethiopia in an hundred and seven and twenty provinces.

**[13:2]** After that I became lord over many nations and had dominion over the whole world, not lifted up with presumption of my authority, but carrying myself always with equity and mildness, I purposed to settle my subjects continually in a quiet life, and making my kingdom peaceable, and open for passage to the utmost coasts, to renew peace, which is desired of all men.

**[13:3]** Now when I asked my counsellors how this might be brought to pass, Aman, that excelled in wisdom among us, and was approved for his constant good will and steadfast fidelity, and had the honour of the second place in the kingdom,

**[13:4]** Declared unto us, that in all nations throughout the world there was scattered a certain malicious people, that had laws contrary to all nations, and continually despised the commandments of kings, so as the uniting of our kingdoms, honourably intended by us cannot go forward.

**[13:5]** Seeing then we understand that this people alone is continually in opposition unto all men, differing in the strange manner of their laws, and evil affected to our state, working all the mischief they can that our kingdom may not be firmly established:

**[13:6]** Therefore have we commanded, that all they that are signified in writing unto you by Aman, who is ordained over the affairs, and is next unto us, shall all, with their wives and children, be utterly destroyed by the sword of their enemies, without all mercy and pity, the fourteenth day of the twelfth month Adar of this present year:

**[13:7]** That they, who of old and now also are malicious, may in one day with violence go into the grave, and so ever hereafter cause our affairs to be well settled, and without trouble.

**[13:8]** Then Mardocheus thought upon all the works of the Lord, and made his prayer unto him,

**[13:9]** Saying, O Lord, Lord, the King Almighty: for the whole world is in thy power, and if thou hast appointed to save Israel, there is no man that can gainsay thee:

**[13:10]** For thou hast made heaven and earth, and all the wondrous things under the heaven.

**[13:11]** Thou art Lord of all things, and and there is no man that can resist thee, which art the Lord.

**[13:12]** Thou knowest all things, and thou knowest, Lord, that it was neither in contempt nor pride, nor for any desire of glory, that I did not bow down to proud Aman.

**[13:13]** For I could have been content with good will for the salvation of Israel to kiss the soles of his feet.

**[13:14]** But I did this, that I might not prefer the glory of man above the glory of God: neither will I worship any but thee, O God, neither will I do it in pride.

**[13:15]** And now, O Lord God and King, spare thy people: for their eyes are upon us to bring us to nought; yea, they desire to destroy the inheritance, that hath been thine from the beginning.

**[13:16]** Despise not the portion, which thou hast delivered out of Egypt for thine own self.

**[13:17]** Hear my prayer, and be merciful unto thine inheritance: turn our sorrow into joy, that we may live, O Lord, and praise thy name: and destroy not the mouths of them that praise thee, O Lord.

**[13:18]** All Israel in like manner cried most earnestly unto the Lord, because their death was before their eyes.

**[14:1]** Queen Esther also, being in fear of death, resorted unto the Lord:

**[14:2]** And laid away her glorious apparel, and put on the garments of anguish and mourning: and instead of precious ointments, she covered her head with ashes and dung, and she humbled her body greatly, and all the places of her joy she filled with her torn hair.

**[14:3]** And she prayed unto the Lord God of Israel, saying, O my Lord, thou only art our King: help me, desolate woman, which have no helper but thee:

**[14:4]** For my danger is in mine hand.

**[14:5]** From my youth up I have heard in the tribe of my family that thou, O Lord, tookest Israel from among all people, and our fathers from all their predecessors, for a perpetual inheritance, and thou hast performed whatsoever thou didst promise them.

**[14:6]** And now we have sinned before thee: therefore hast thou given us into the hands of our enemies,

**[14:7]** Because we worshipped their gods: O Lord, thou art righteous.

**[14:8]** Nevertheless it satisfieth them not, that we are in bitter captivity: but they have stricken hands with their idols,

**[14:9]** That they will abolish the thing that thou with thy mouth hast ordained, and destroy thine inheritance, and stop the mouth of them that praise thee, and quench the glory of thy house, and of thine altar,

**[14:10]** And open the mouths of the heathen to set forth the praises of the idols, and to magnify a fleshly king for ever.

**[14:11]** O Lord, give not thy sceptre unto them that be nothing, and let them not laugh at our fall; but turn their device upon themselves, and make him an example, that hath begun this against us.

**[14:12]** Remember, O Lord, make thyself known in time of our affliction, and give me boldness, O King of the nations, and Lord of all power.

**[14:13]** Give me eloquent speech in my mouth before the lion: turn his heart to hate him that fighteth against us, that there may be an end of him, and of all that are likeminded to him:

**[14:14]** But deliver us with thine hand, and help me that am desolate, and which have no other help but thee.

**[14:15]** Thou knowest all things, O Lord; thou knowest that I hate the glory of the unrighteous, and abhor the bed of the uncircumcised, and of all the heathen.

**[14:16]** Thou knowest my necessity: for I abhor the sign of my high estate, which is upon mine head in the days wherein I shew myself, and that I abhor it as a menstruous rag, and that I wear it not when I am private by myself.

**[14:17]** And that thine handmaid hath not eaten at Aman’s table, and that I have not greatly esteemed the king’s feast, nor drunk the wine of the drink offerings.

**[14:18]** Neither had thine handmaid any joy since the day that I was brought hither to this present, but in thee, O Lord God of Abraham.

**[14:19]** O thou mighty God above all, hear the voice of the forlorn and deliver us out of the hands of the mischievous, and deliver me out of my fear.

**[15:1]** And upon the third day, when she had ended her prayers, she laid away her mourning garments, and put on her glorious apparel.

**[15:2]** And being gloriously adorned, after she had called upon God, who is the beholder and saviour of all things, she took two maids with her:

**[15:3]** And upon the one she leaned, as carrying herself daintily;

**[15:4]** And the other followed, bearing up her train.

**[15:5]** And she was ruddy through the perfection of her beauty, and her countenance was cheerful and very amiable: but her heart was in anguish for fear.

**[15:6]** Then having passed through all the doors, she stood before the king, who sat upon his royal throne, and was clothed with all his robes of majesty, all glittering with gold and precious stones; and he was very dreadful.

**[15:7]** Then lifting up his countenance that shone with majesty, he looked very fiercely upon her: and the queen fell down, and was pale, and fainted, and bowed herself upon the head of the maid that went before her.

**[15:8]** Then God changed the spirit of the king into mildness, who in a fear leaped from his throne, and took her in his arms, till she came to herself again, and comforted her with loving words and said unto her,

**[15:9]** Esther, what is the matter? I am thy brother, be of good cheer:

**[15:10]** Thou shalt not die, though our our commandment be general: come near.

**[15:11]** And so be held up his golden sceptre, and laid it upon her neck,

**[15:12]** And embraced her, and said, Speak unto me.

**[15:13]** Then said she unto him, I saw thee, my lord, as an angel of God, and my heart was troubled for fear of thy majesty.

**[15:14]** For wonderful art thou, lord, and thy countenance is full of grace.

**[15:15]** And as she was speaking, she fell down for faintness.

**[15:16]** Then the king was troubled, and all his servants comforted her.

**[16:1]** The great king Artexerxes unto the princes and governors of an hundred and seven and twenty provinces from India unto Ethiopia, and unto all our faithful subjects, greeting.

**[16:2]** Many, the more often they are honoured with the great bounty of their gracious princes, the more proud they are waxen,

**[16:3]** And endeavour to hurt not our subjects only, but not being able to bear abundance, do take in hand to practise also against those that do them good:

**[16:4]** And take not only thankfulness away from among men, but also lifted up with the glorious words of lewd persons, that were never good, they think to escape the justice of God, that seeth all things and hateth evil.

**[16:5]** Oftentimes also fair speech of those, that are put in trust to manage their friends’ affairs, hath caused many that are in authority to be partakers of innocent blood, and hath enwrapped them in remediless calamities:

**[16:6]** Beguiling with the falsehood and deceit of their lewd disposition the innocency and goodness of princes.

**[16:7]** Now ye may see this, as we have declared, not so much by ancient histories, as ye may, if ye search what hath been wickedly done of late through the pestilent behaviour of them that are unworthily placed in authority.

**[16:8]** And we must take care for the time to come, that our kingdom may be quiet and peaceable for all men,

**[16:9]** Both by changing our purposes, and always judging things that are evident with more equal proceeding.

**[16:10]** For Aman, a Macedonian, the son of Amadatha, being indeed a stranger from the Persian blood, and far distant from our goodness, and as a stranger received of us,

**[16:11]** Had so far forth obtained the favour that we shew toward every nation, as that he was called our father, and was continually honoured of all the next person unto the king.

**[16:12]** But he, not bearing his great dignity, went about to deprive us of our kingdom and life:

**[16:13]** Having by manifold and cunning deceits sought of us the destruction, as well of Mardocheus, who saved our life, and continually procured our good, as also of blameless Esther, partaker of our kingdom, with their whole nation.

**[16:14]** For by these means he thought, finding us destitute of friends to have translated the kingdom of the Persians to the Macedonians.

**[16:15]** But we find that the Jews, whom this wicked wretch hath delivered to utter destruction, are no evildoers, but live by most just laws:

**[16:16]** And that they be children of the most high and most mighty, living God, who hath ordered the kingdom both unto us and to our progenitors in the most excellent manner.

**[16:17]** Wherefore ye shall do well not to put in execution the letters sent unto you by Aman the son of Amadatha.

**[16:18]** For he that was the worker of these things, is hanged at the gates of Susa with all his family: God, who ruleth all things, speedily rendering vengeance to him according to his deserts.

**[16:19]** Therefore ye shall publish the copy of this letter in all places, that the Jews may freely live after their own laws.

**[16:20]** And ye shall aid them, that even the same day, being the thirteenth day of the twelfth month Adar, they may be avenged on them, who in the time of their affliction shall set upon them.

**[16:21]** For Almighty God hath turned to joy unto them the day, wherein the chosen people should have perished.

**[16:22]** Ye shall therefore among your solemn feasts keep it an high day with all feasting:

**[16:23]** That both now and hereafter there may be safety to us and the well affected Persians; but to those which do conspire against us a memorial of destruction.

**[16:24]** Therefore every city and country whatsoever, which shall not do according to these things, shall be destroyed without mercy with fire and sword, and shall be made not only unpassable for men, but also most hateful to wild beasts and fowls for ever.

