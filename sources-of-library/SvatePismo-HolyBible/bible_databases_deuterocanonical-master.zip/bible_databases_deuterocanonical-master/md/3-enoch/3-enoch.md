# 3 Enoch



**[1:1]** When I ascended on high to behold the vision of the Merkaba and had entered the six Halls, one within the other: 

**[1:2]** as soon as I reached the door of the seventh Hall I stood still in prayer before the Holy One, blessed be He, and, lifting up my eyes on high (i.e. towards the Divine Majesty), I said: 

**[1:3]** "Lord of the Universe, I pray thee, that the merit of Aaron, the son of Amram, the lover of peace and pursuer of peace, who received the crown of priesthood from Thy Glory on the mount of Sinai, be valid for me in this hour, so that Qafsiel*, the prince, and the angels with him may not get power over me nor throw me down from the heavens ". 

**[1:4]** Forthwith the Holy One, blessed be He, sent to me Metatron, his Servant ('Ebed) the angel, the Prince of the Presence, and he, spreading his wings, with great joy came to meet me so as to save me from their hand. 

**[1:5]** And he took me by his hand in their sight, saying to me: "Enter in peace before the high and exalted King3 and behold the picture of the Merkaba". 

**[1:6]** Then I entered the seventh Hall, and he led me to the camp(s) of Shekina and placed me before the Holy One, blessed be He, to behold the Merkaba. 

**[1:7]** As soon as the princes of the Merkaba and the flaming Seraphim perceived me, they fixed their eyes upon me. Instantly trembling and shuddering seized me and I fell down and was benumbed by the radiant image of their eyes and the splendid appearance of their faces; until the Holy One, blessed be He, rebuked them, saying: 

**[1:8]** "My servants, my Seraphim, my Kerubim and my 'Ophannim! Cover ye your eyes before Ishmael, my son, my friend, my beloved one and my glory, that he tremble not nor shudder!" 

**[1:9]** Forthwith Metatron the Prince of the Presence, came and restored my spirit and put me upon my feet. 

**[1:10]** After that (moment) there was not in me strength enough to say a song before the Throne of Glory of the glorious King, the mightiest of all kings, the most excellent of all princes, until after the hour had passed. 

**[1:11]** After one hour (had passed) the Holy One, blessed be He, opened to me the gates of Shekina, the gates of Peace, the gates of Wisdom, the gates of Strength, the gates of Power, the gates of Speech (Dibbur), the gates of Song, the gates of Qedushsha, the gates of Chant. 

**[1:12]** And he enlightened my eyes and my heart by words of psalm, song, praise, exaltation, thanksgiving, extolment, glorification, hymn and eulogy. And as I opened my mouth, uttering a song before the Holy One, blessed be He, the Holy Chayyoth beneath and above the Throne of Glory answered and said: "HOLY" and "BLESSED BE THE GLORY OF YHWH FROM HIS PLACE!" (i.e. chanted the Qedushsha). 



**[2:1]** In that hour the eagles of the Merkaba, the flaming 'Ophannim and the Seraphim of consuming fire asked Metatron, saying to him: 

**[2:2]** "Youth! Why sufferest thou one born of woman to enter and behold the Merkaba? From which nation, from which tribe is this one? What is his character?" 

**[2:3]** Metatron answered and said to them: "From the nation of Israel whom the Holy One, blessed be He, chose for his people from among seventy tongues (nations), from the tribe of Levi, whom he set aside as a contribution to his name and from the seed of Aaron whom the Holy One, blessed be He, did choose for his servant and put upon him the crown of priesthood on Sinai". 

**[2:4]** Forthwith they spake and said: "Indeed, this one is worthy to behold the Merkaba ". And they said: "Happy is the people that is in such a case!". 



**[3:1]** In that hour I asked Metatron, the angel, the Prince of the Presence: "What is thy name?" 

**[3:2]** He answered me: "I have seventy names, corresponding to the seventy tongues of the world and all of them are based upon the name Metatron, angel of the Presence; but my King calls me 'Youth' (Na’ar)“ 



**[4:1]** I asked Metatron and said to him: “Why art thou called by the name of thy Creator, by seventy names? Thou art greater than all the princes, higher than all the angels, beloved more than all the servants, honoured above all the mighty ones in kingship, greatness and glory: why do they call thee 'Youth' in the high heavens?" 

**[4:2]** He answered and said to me: "Because I am Enoch, the son of Jared. 

**[4:3]** For when the generation of the flood sinned and were confounded in their deeds, saying unto God: 'Depart from us, for we desire not the knowledge of thy ways’ (Job xxi. 14), then the Holy One, blessed be He, removed me from their midst to be a witness against them in the high heavens to all the inhabitants of the world, that they may not say: 'The Merciful One is cruel”. 

**[4:4]** What sinned all those multitudes, their wives, their sons and their, daughters, their horses, their mules and their cattle and their property, and all the birds of the world, all of which the Holy One, blessed be He, destroyed from the world together with them in the waters of the flood? 

**[4:5]** Hence the Holy One, blessed be He, lifted me up in their lifetime before their eyes to be a witness against them to the future world. And the Holy One, blessed be He, assigned me for a prince and a ruler among the ministering angels. 

**[4:6]** In that hour three of the ministering angels, 'UZZA, 'AZZA and 'AZZAEL came forth and brought charges against me in the high heavens, saying before the Holy One, blessed be He: "Said not the Ancient Ones (First Ones) rightly before Thee: Do not create man!'" The Holy One, blessed be He, answered and said unto them: "I have made and I will bear, yea, I will carry and will deliver". (Is. xlvi. 4.) 

**[4:7]** As soon as they saw me, they said before Him: "Lord of the Universe! What is this one that he should ascend to the height of heights? Is not he one from among the sons of [the sons of] those who perished in the days of the Flood? "What doeth he in the Raqia'?" 

**[4:8]** Again, the Holy One, blessed be He, answered and said to them: "What are ye, that ye enter and speak in my presence? I delight in this one more than in all of you, and hence he shall be a prince and a ruler over you in the high heavens." 

**[4:9]** Forthwith all stood up and went out to meet me, prostrated themselves before me and said: "Happy art thou and happy is thy father for thy Creator doth favour thee". 

**[4:10]** And because I am small and a youth among them in days, months and years, therefore they call me "Youth" (Na'ar). 



**[5:1]** From the day when the Holy One, blessed be He, expelled the first Adam from the Garden of Eden (and onwards), Shekina was dwelling upon a Kerub under the Tree of Life. 

**[5:2]** And the ministering angels were gathering together and going down from heaven in parties, from the Raqia in companies and from the heavens in camps to do His will in the whole world. 

**[5:3]** And the first man and his generation were sitting outside the gate of the Garden to behold the radiant appearance of the Shekina. 

**[5:4]** For the splendour of the Shekina traversed the world from one end to the other (with a splendour) 365,000 times (that) of the globe of the sun. And everyone who made use of the splendour of the Shekina, on him no flies and no gnats did rest, neither was he ill nor suffered he any pain. No demons got power over him, neither were they able to injure him. 

**[5:5]** When the Holy One, blessed be He, went out and went in: from the Garden to Eden, from Eden to the Garden, from the Garden to Raqia and from Raqia to the Garden of Eden then all and everyone beheld the splendour of His Shekina and they were not injured; 

**[5:6]** until uthe time of the generation of Enosh who was the head of all idol worshippers of the world. 

**[5:7]** And what did the generation of Enosh do? They went from one end of the world to the other, and each one brought silver, gold, precious stones and pearls in heaps like unto mountains and hills making idols out of them throughout all the world. And they erected the idols in every quarter of the world: the size of each idol was 1000 parasangs. 

**[5:8]** And they brought down the sun, the moon, planets and constellations, and placed them before the idols on their right hand and on their left, to attend them even as they attend the Holy One, blessed be He, as it is written (1 Kings xxii. 19): "And all the host of heaven was standing by him on his right hand and on his left". 

**[5:9]** What power was in them that they were able to bring them down? They would not have been able to bring them down but for 'Uzza, 'Azza and 'Azziel who taught them sorceries whereby they brought them down and made use of them 

**[5:10]** In that time the ministering angels brought charges (against them) before the Holy One, blessed be He, saying before him: "Master of the World! What hast thou to do with the children of men? As it is written (Ps. viii. 4) 'What is man (Enosh) that thou art mindful of him?' 'Mah Adam' is not written here, but 'Mah Enosh', for he (Enosh) is the head of the idol worshippers. 

**[5:11]** Why hast thou left the highest of the high heavens, the abode of thy glorious Name, and the high and exalted Throne in ‘Araboth Raqia’ in the highest and art gone and dwellest with the children of men who worship idols and equal thee to the idols. 

**[5:12]** Now thou art on earth and the idols likewise. What hast thou to do with the inhabitants of the earth who worship idols?" 

**[5:13]** Forthwith the Holy One, blessed be He, lifted up His Shekina from the earth, from their midst. 

**[5:14]** In that moment came the ministering angels, the troops of hosts and the armies of 'Araboth in thousand camps and ten thousand hosts: they fetched trumpets and took the horns in their hands and surrounded the Shekina with all kinds of songs. And He ascended to the high heavens, as it is written (Ps. xlvii. 5): "God is gone up with a shout, the Lord with the sound of a trumpet". 



**[6:1]** When the Holy One, blessed be He, desired to lift me up on high, He first sent 'Anaphiel H (H = Tetragrammaton) the Prince, and he took me from their midst in their sight and carried me in great glory upon a a fiery chariot with fiery horses, servants of glory. And he lifted me up to the high heavens together with the Shekina. 

**[6:2]** As soon as I reached the high heavens, the Holy Chayyoth, the 'Ophannim, the Seraphim, the Kerubim, the Wheels of the Merkaba (the Galgallim), and the ministers of the consuming fire, perceiving my smell from a distance of 365,000 myriads of parasangs, said: "What smell of one born of woman and what taste of a white drop (is this) that ascends on high, and (lo, he is merely) a gnat among those who 'divide flames (of fire)'?" 

**[6:3]** The Holy One, blessed be He, answered and spake unto them: "My servants, my hosts, my Kerubim, my 'Ophannim, my Seraphim! Be ye not displeased on account of this! Since all the children of men have denied me and my great Kingdom and are gone worshipping idols, I have removed my Shekina from among them and have lifted it up on high. But this one whom I have taken from among them is an ELECT ONE among (the inhabitants of) the world and he is equal to all of them in faith, righteousness and perfection of deed and I have taken him for (as) a tribute from my world under all the heavens". 



**[7:1]** When the Holy One, blessed be He, took me away from the generation of the Flood, he lifted me on the wings of the wind of Shekina to the highest heaven and brought me into the great palaces of the 'Araboth Raqia' on high, where are the glorious Throne of Shekina, the Merkaba, the troops of anger, the armies of vehemence, the fiery Shin'anim', the flaming Kerubim, and the burning 'Ophannim, the flaming servants, the flashing Chashmattim and the lightening Seraphim. And he placed me (there) to attend the Throne of Glory day after day. 



**[8:1]** Before He appointed me to attend the Throne of Glory, the Holy One, blessed be He, opened to me: three hundred thousand gates of Understanding; 

 three hundred thousand gates of Subtlety; 

 three hundred thousand gates of Life; 

 three hundred thousand gates of grace and loving-kindness; 

 three hundred thousand gates of love; 

 three hundred thousand gates of Tora; 

 three hundred thousand gates of meekness; 

 three hundred thousand gates of maintenance; 

 three hundred thousand gates' of mercy; 

 three hundred thousand gates of fear of heaven. 

 

**[8:2]** In that hour the Holy One, blessed be He, added in me wisdom unto wisdom, understanding unto understanding, subtlety unto subtlety, knowledge unto knowledge, mercy unto mercy, instruction unto instruction, love unto love, loving-kindness unto loving-kindness, goodness unto goodness, meekness unto meekness, power unto power, strength unto strength, might unto might, brilliance unto brilliance, beauty unto beauty, splendour unto splendour, and I was honoured and adorned with all these good and praiseworthy things more than all the children of heaven. 



**[9:1]** After all these things the Holy One, blessed be He, put His hand upon me and blessed me with 536O blessings. 

**[9:2]** And I was raised and enlarged to the size of the length and width of the world. 

**[9:3]** And He caused 72 wings to grow on me, 36 on each side. And each wing was as the whole world. 

**[9:4]** And He fixed on me 365 eyes: each eye was as the great luminary. 

**[9:5]** And He left no kind of splendour, brilliance, radiance, beauty in (of) all the lights of the universe that He did not fix on me. 



**[10:1]** All these things the Holy One, blessed be He, made for me: He made me a Throne, similar to the Throne of Glory. And He spread over me a curtain of splendour and brilliant appearance, of beauty, grace and mercy, similar to the curtain of the Throne of Glory; and on it were fixed all kinds of lights in the universe. 

**[10:2]** And He placed it at the door of the Seventh Hall and seated me on it. 

**[10:3]** And the herald went forth into every heaven, saying: This is Metatron, my servant. I have made him into a prince and a ruler over all the princes of my kingdoms and over all the children of heaven, except the eight great princes, the honoured and revered ones who are called YHWH, by the name of their King. 

**[10:4]** And every angel and every prince who has a word to speak in my presence (before me) shall go into his presence (before him) and shall speak to him (instead). 

**[10:5]** And every command that he utters to you in my name do ye observe and fulfill. For the Prince of Wisdom and the Prince of Understanding have I committed to him to instruct him in the wisdom of heavenly things and of earthly things, in the wisdom of this world and of the world to come. 

**[10:6]** Moreover, I have set him over all the treasuries of the palaces of Araboth and over all the stores of life that I have in the high heavens. 



**[11:1]** Henceforth the Holy One, blessed be He, revealed to me all the mysteries of Tora and all the secrets of wisdom and all the depths of the Perfect Law; and all living beings' thoughts of heart and all the secrets of the universe and all the secrets of Creation were revealed unto me even as they are revealed unto the Maker of Creation. 

**[11:2]** And I watched intently to behold the secrets of the depth and the wonderful mystery. Before a man did think in secret, I saw (it) and before a man made a thing I beheld it. 

**[11:3]** And there was no thing on high nor in the deep hidden from me. 



**[12:1]** By reason of the love with which the Holy One, blessed be He, loved me more than all the children of heaven, He made me a garment of glory on which were fixed all kinds of lights, and He clad me in it. 

**[12:2]** And He made me a robe of honour on which were fixed all kinds of beauty, splendour, brilliance and majesty. 

**[12:3]** And he made me a royal crown in which were fixed forty-nine costly stones like unto the light of the globe of the sun. 

**[12:4]** For its splendour went forth in the four quarters of the 'Araboth Raqia', and in (through) the seven heavens, and in the four quarters of the world. And he put it on my head. 

**[12:5]** And He called me THE LESSER YHWH in the presence of all His heavenly household; as it is written (Ex. xxiii. 21): "For my name is in him". 



**[13:1]** Because of the great love and mercy with which the Holy One, blessed be He, loved and cherished me more than all the children of heaven, He wrote with his ringer with a flaming style upon the crown on my head the letters by which were created heaven and earth, the seas and rivers, the mountains and hills, the planets and constellations, the lightnings, winds, earthquakes and voices (thunders), the snow and hail, the storm-wind and the tempest; the letters by which were created all the needs of the world and all the orders of Creation. 

**[13:2]** And every single letter sent forth time after time as it were lightnings, time after time as it were torches, time after time as it were flames of fire, time after time (rays) like [as] the rising of the sun and the moon and the planets. 



**[14:1]** When the Holy One, blessed be He, put this crown on my head, (then) trembled before me all the Princes of Kingdoms who are in the height of 'Araboth Raqiaf and all the hosts of every heaven; and even the princes (of) the 'Elim, the princes (of) the 'Er'ellim and the princes (of) the Tafsarim, who are greater than all the ministering angels who minister before the Throne of Glory, shook, feared and trembled before me when they beheld me. 

**[14:2]** Even Sammael, the Prince of the Accusers, who is greater than all the princes of kingdoms on high; feared and trembled before me. 

**[14:3]** And even the angel of fire, and the angel of hail, and the angel of the wind, and the angel of the lightning, and the angel of anger, and the angel of the thunder, and the angel of the snow, and the angel of the rain; and the angel of the day, and the angel of the night, and the angel of the sun and the angel of the moon, and the angel of the planets and the angel of the constellations who rule the world under their hands, feared and trembled and were affrighted before me, when they beheld me. 

**[14:4]** These are the names of the rulers of the world: Gabriel, the angel of the fire, Baradiel, the angel of the hail, Ruchiel who is appointed over the wind, Baraqiel who is appointed over the lightnings, Za'amiel who is appointed over the vehemence, Ziqiel who is appointed over the sparks, Zi'iel who is appointed over the commotion, Zaphiel who is appointed over the storm-wind, Ra'amiel who is appointed over the thunders, Rashiel who is appointed over the earthquake, Shalgiel who is appointed over the snow, Matariel who is appointed over the rain, Shimshiel who is appointed over the day, Lailiel who is appointed over the night, Galgalliel who is appointed over the globe of the sun, 'Ophanniel who is appointed over the globe of the moon, Kokbiel who is appointed over the planets, Rahatiel who is appointed over the constellations. 

**[14:5]** And they all fell prostrate, when they saw me. And they were not able to behold me because of the majestic glory and beauty of the appearance of the shining light of the crown of glory upon my head. 



**[15:1]** As soon as the Holy One, blessed be He, took me in (His) service to attend the Throne of Glory and the Wheels (Galgallim) of the Merkaba and the needs of Shekina, forthwith my flesh was changed into flames, my sinews into flaming fire, my bones into coals of burning juniper, the light of my eye-lids into splendour of lightnings, my eye-balls into fire-brands, the hair of my head into hot flames, all my limbs into wings of burning fire and the whole of my body into glowing fire. 

**[15:2]** And on my right were divisions of fiery flames, on my left fire-brands were burning, round about me stormwind and tempest were blowing and in front of me and behind me was roaring of thunder with earthquake. FRAGMENT OF ‘ASCENSION OF MOSES’ 

**[15:1]** R. Ishmael said: Said to me Metatron, the Prince of the Presence and the prince over all the princes and he stands befote Him who is greater than all the Elohim. And he goes in under the Throne of Glory. And he has a great tabernacle of light on high. And he brings forth the fire of deafness and puts (it) into the ears of the Holy Chayyoth, that they may not hear the voice of the Word (Dibbur) that goes forth from the mouth of the Divine Majesty. 

**[15:2]** And when Moses ascended on high, he fasted 121 fasts, till the habitations of the chashmal were opened to him; and he saw the heart within the heart of the Lion and he saw the innumerable companies of the hosts Around about him. And they desired to burn him. But Moses prayed for mercy, first for Israel and after that for himself: and He who sitteth on the Merkaba opened the windows that are above the heads of the Kerubim. And a host of 1800 advocates and the Prince of the Presence, Metatron, with them went forth to meet Moses. And they took the prayers of Israel and put them as a crown on the head of the Holy One, blessed be He. 

**[15:3]** And they said (Deut. vi. 4): "Hear, O Israel; the Lord our God is one Lord" and their face shone and rejoiced over Shekinaand they said to Metatron: "What are these? And to whom do they give all this honour and glory?" And they answered: "To the Glorious Lord of Israel". And they spake: "Hear, O Israel: the Lord, our God, is one Lord. To whom shall be given abundance of honour and majesty but to Thee YHWH, the Divine Majesty, the King, living and eternal". 

**[15:4]** In that moment spake Akatriel Yah Yehod Sebaoth and said to Metatron, the Prince of the Presence: "Let no prayer that he prayeth before me return (to him) void. Hear thou his prayer and fulfill his desire whether (it be) great or small". 

**[15:5]** Forthwith Metatron, the Prince of the Presence, said to Moses: "Son of Amram! Fear not, for now God delights in thee. And ask thou thy desire of the Glory and Majesty. For thy face shines from one end of the world to the other". But Moses answered him: "(I fear) lest I bring guiltiness upon myself". Metatron said to him: "Receive the letters of the oath, in (by) which there is no breaking the covenant" (which precludes any breach of the covenant). 



**[16:1]** At first I was sitting upon a great Throne at the door of the Seventh Hall; and I was judging the children of heaven, the household on high by authority of the Holy One, blessed be He. And I divided Greatness, Kingship, Dignity, Rulership, Honour and Praise, and Diadem and Crown of Glory unto all the princes of kingdoms, while I was presiding (lit. sitting) in the Celestial Court (Yeshiba), and the princes of kingdoms were standing before me, on my right and on my left by authority of the Holy One, blessed be He. 

**[16:2]** But when Acher came to behold the vision of the Merkaba and fixed his eyes on me, he feared and trembled before me and his soul was affrighted even unto departing from him, because of fear, horror and dread of me, when he beheld me sitting upon a throne like a king with all the ministering angels standing by me as my servants and all the princes of kingdoms adorned with crowns surrounding me: 

**[16:3]** in that moment he opened his mouth and said: "Indeed, there are two Divine Powers in heaven!" 

**[16:4]** Forthwith Bath Qol (the Divine Voice) went forth from heaven from before the Shekina and said: "Return, ye backsliding children (Jer. iii. 22), except Acher!" 

**[16:5]** Then came 'Aniyel, the Prince, the honoured, glorified, beloved, wonderful, revered and fearful one, in commission from the Holy One, blessed be He and gave me sixty strokes with lashes of fire and made me stand on my feet. 



**[17:1]** Seven (are the) princes, the great, beautiful, revered, wonderful and honoured ones who are appointed over the seven heavens. And these are they: MIKAEL, GABRIEL, SHATQIEL, SHACHAQIEL, BAKARIEL, BADARIEL, PACHRIEL. 

**[17:2]** And every one of them is the prince of the host of (one) heaven. And each one of them is accompanied by 496,000 myriads of ministering angels. 

**[17:3]** MIKAEL, the great prince, is appointed over the seventh heaven, the highest one, which is in the 'Araboth. GABRIEL, the prince of the host, is appointed over the sixth heaven which is in Makon. SHATAQIEL, prince of the host, is appointed over the fifth heaven which is in Ma'on. SHAHAQi'EL, prince of the host, is appointed over the fourth heaven which is in Zebul. BADARIEL, prince of the host, is appointed over the third heaven which is in Shehaqim. BARAKIEL, prince of the host, is appointed over the second heaven which is in the height of (Merom) Raqia. PAZRIEL, prince of the host, is appointed over the first heaven which is in Wilon, which is in Shamayim. 

**[17:4]** Under them is GALGALLIEL, the prince who is appointed over the globe (galgal) of the sun, and with him are 96 great and honoured angels who move the sun in Raqia'. 

**[17:5]** Under them is 'OPHANNIEL, the prince who is set over the globe ('ophari) of the moon. And with him are 88 angels who move the globe of the moon 354 thousand parasangs every night at the time when the moon stands in the East at its turning point. And when is the moon sitting in the East at its turning point? Answer: in the fifteenth day of every month. 

**[17:6]** Under them is RAHATIEL, the prince who is appointed over the constellations. And he is accompanied by 72 great and honoured angels. And why is he called RAHATIEL? Because he makes the stars run (marhit) in their orbits and courses 339 thousand parasangs every night from the East to the West, and from the West to the East. For the Holy One, blessed be He, has made a tent for all of them, for the sun, the moon, the planets and the stars in which they travel at night from the West to the East. 

**[17:7]** Under them is KOKBIEL, the prince who is appointed over all the planets. And with him are 365,000 myriads of ministering angels, great and honoured ones who move the planets from city to city and from province to province in the Raqia' of heavens. 

**[17:8]** And over them are SEVENTY-TWO PRINCES OF KINGDOMS on high corresponding to the 72 tongues of the world. And all of them are crowned with royal crowns and clad in royal garments and wrapped in royal cloaks. And all of them are riding on royal horses and they are holding royal sceptres in their hands. And before each one of them when he is travelling in Raqia', royal servants are running with great glory and majesty even as on earth they (princes) are travelling in chariot(s) with horsemen and great armies and in glory and greatness with praise, song and honour. 



**[18:1]** THE ANGELS OF THE FIRST HEAVEN, when(ever) they see their prince, they dismount from their horses and fall on their faces. 

 And THE PRINCE OF THE FIRST HEAVEN, when he sees the prince of the second heaven, he dismounts, removes the crown of glory from his head and falls on his face. 

 And THE PRINCE OF THE SECOND HEAVEN, when he sees the Prince of the third heaven, he removes the crown of glory from his head and falls on his face. 

 And THE PRINCE OF THE THIRD HEAVEN, when he sees the prince of the fourth heaven, he removes the crown of glory from his head and falls on his face. 

 And THE PRINCE OF THE FOURTH HEAVEN, when he sees the prince of the fifth heaven, he removes the crown of glory from his head and falls on his face. 

 And THE PRINCE OF THE FIFTH HEAVEN, when he sees the prince of the sixth heaven, he removes the crown of glory from his head and falls on his face. 

 And THE PRINCE OF THE SIXTH HEAVEN, when he sees the prince of the seventh heaven, he removes the crown of glory from his head and falls on his face. 

 

**[18:2]** And THE PRINCE OF THE SEVENTH HEAVEN, when he sees THE SEVENTY-TWO PRINCES OF KINGDOMS, he removes the crown of glory from his head and falls on his face. 

 

**[18:3]** And the seventy-two princes of kingdoms, when they see THE DOOR KEEPERS OF THE FIRST HALL IN THE ARABOTH RAQIA in the highest, they remove the royal crown from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE FIRST HALL, when they see the door keepers of the second Hall, they remove the crown of glory from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE SECOND HALL, when they see the door keepers of the third Hall, they remove the crown of glory from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE THIRD HALL, when they see the door keepers of the fourth Hall, they remove the crown of glory from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE FOURTH HALL, when they see the door keepers of the fifth Hall, they remove the crown of glory from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE FIFTH HALL, when they see the door keepers of the sixth Hall, they remove the crown of glory from their head and fall on their faces. 

 And THE DOOR KEEPERS OF THE SIXTH HALL, when they see the DOOR KEEPERS OF THE SEVENTH HALL, they remove the crown of glory from their head and fall on their faces. 

**[18:4]** And the door keepers of the seventh Hall, when they see THE FOUR GREAT PRINCES, the honoured ones, WHO ARE APPOINTED OVER THE FOUR CAMPS OF SHEKINA, they remove the crown(s) of glory from their head and fall on their faces. 

**[18:5]** And the four great princes, when they see TAG'AS, the prince, great and honoured with song (and) praise, at the head of all thechildren of heaven, they remove the crown of glory from their head and fall on their faces. 

**[18:6]** And Tag'as, the great and honoured prince, when he sees BARATTIEL, the great prince of three fingers in the height of 'Araboth, the highest heaven, he removes the crown of glory from his head and falls on his face. 

**[18:7]** And Barattiel, the great prince, when he sees HAMON, the great prince, the fearful and honoured, pleasant and terrible one who maketh all the children of heaven to tremble, when the time draweth nigh (that is set) for the saying of the '(Thrice) Holy', as it is written (Isa. xxxiii. 3): "At the noise of the tumult (hamon) the peoples are fled; at the lifting up of thyself the nations are scattered" he removes the crown of glory from his head and falls on his face. 

**[18:8]** And Hamon, the great prince, when he sees TUTRESIEL, the great prince, he removes the crown of glory from his head and falls on his face. 

**[18:9]** And Tutresiel H', the great prince, when he sees ATRUGIEL, the great prince, he removes the crown of glory from his head and falls on his face. 

**[18:10]** And Atrugiel the great prince, when he sees NA'ARIRIEL H', the great prince, he removes the crown of glory from his head and falls on his face. (n) And Na'aririel H', the great prince, when he sees SASNIGIEL H’, the great prince, he removes the crown of glory from his head and falls on his face. 

**[18:12]** And Sasnigiel H', when he sees ZAZRIEL H', the great prince, he removes the crown of glory from his head and falls on his face. 

**[18:13]** And Zazriel H', the prince, when he sees GEBURATIEL H', the prince, he removes the crown of glory from his head and falls on his face. 

**[18:14]** And Geburatiel H', the prince, when he sees 'ARAPHIEL H', the prince, he removes the crown of glory from his head and falls on his face. 

**[18:15]** And 'Araphiel H', the prince, when he sees 'ASHRUYLU, the prince, who presides in all the sessions of the children of heaven, he removes the crown of glory from his head and falls on his face. 

**[18:16]** And Ashruylu H, the prince, when he sees GALLISUR H', THE PRINCE, WHO REVEALS ALL THE SECRETS OF THE LAW (Tora), he removes the crown of glory from his head and falls on his face. 

**[18:17]** And Gallisur H', the prince, when he sees ZAKZAKIEL H', the prince who is appointed to write down the merits of Israel on the Throne of Glory, he removes the crown of glory from his head and falls on his face. 

**[18:18]** And Zakzakiel H', the great prince, when he sees 'ANAPHIEL H', the prince who keeps the keys of the heavenly Halls, he removes the crown of glory from his head and falls on his face. Why is he called by the name of 'Anaphiel? Because the bough of his honour and majesty and his crown and his splendour and his brilliance covers (overshadows) all the chambers of 'Araboth Raqia on high even as the Maker of the World (doth overshadow them). Just as it is written with regard to the Maker of the World (Hab. iii. 3): "His glory covered the heavens, and the earth was full of his praise", even so do the honour and majesty of 'Anaphiel cover all the glories of 'Araboth the highest. 

**[18:19]** And when he sees SOTHER 'ASHIEL H', the prince, the great, fearful and honoured one, he removes the crown of glory from his head and falls on his face. Why is he called Sother Ashiel? Because he is appointed over the four heads of the fiery river over against the Throne of Glory; and every single prince who goes out or enters before the Shekina, goes out or enters only by his permission. For the seals of the fiery river are entrusted to him. And furthermore, his height is 7000 myriads of parasangs. And he stirs up the fire of the river; and he goes out and enters before the Shekina to expound what is written (recorded) concerning the inhabitants of the world. According as it is written (Dan. vii. 10): "the judgement was set, and the books were opened". 

**[18:20]** And Sother 'Ashiel the prince, when he sees SHOQED CHOZI, the great prince, the mighty, terrible and honoured one, he removes the crown of glory from his head and falls upon his face. And why is he called Shoqed Chozi? Because he weighs all the merits (of man) in a balance in the presence of the Holy One, blessed be He. 

**[18:21]** Andwhen he sees ZEHANPURYU H',the great prince, the mighty and terrible one, honoured, glorified and feared in all the heavenly household, he removes the crown of glory from his head and falls on his face. Why is he called Zehanpuryu? Because he rebukes the fiery river and pushes it back to its place. 

**[18:22]** Andwhen he sees 'AZBUGA H', the great prince, glorified, revered, honoured, adorned, wonderful, exalted, beloved and feared among allthe great princes who know the mystery of the Throne of Glory, he removes the crown of glory from his head and falls on his face. Why is he called 'Azbuga? Because in the future he will gird (clothe) the righteous and pious of the world with the garments of life and wrap them in the cloak of life, that they may live in them an eternal life. 

**[18:23]** And when he sees the two great princes, the strong and glorified ones who are standing above him, he removes the crown of glory from his head and falls on his face. And these are the names of the two princes: SOPHERIEL H' (WHO) KILLETH, (Sopheriel H' the Killer), the great prince, the honoured, glorified, blameless, venerable, ancient and mighty one; (and) SOPHERIEL H' (WHO) MAKETH ALIVE (Sopheriel H' the Lifegiver), the great prince, the honoured, glorified, blameless, ancient and mighty one. 

**[18:24]** Why is he called Sopheriel H' who killeth (Sopheriel H' the Killer)? Because he is appointed over the books of the dead: [so that] everyone, when the day of his death draws nigh, he writes him in the books of the dead. Why is he called Sopheriel H' who maketh alive (Sopheriel H' the Lifegiver)? Because he is appointed over the books of the living (of life), so that every one whom the Holy One, blessed be He, will bring into life, he writes him in the book of the living (of life), by authority of MAQOM. Thou might perhaps say: "Since the Holy One, blessed be He, is sitting on a throne, they also are sitting when writing". (Answer): The Scripture teaches us (1 Kings xxii. 19, 2 Chron. xviii. 18): "And all the host of heaven are standing by him". "The host of heaven " (it is said) in order to show us, that even the Great Princes, none like whom there is in the high heavens, do not fulfill the requests of the Shekina otherwise than standing. But how is it (possible that) they (are able to) write, when they are standing? It is like this: 

**[18:25]** One is standing on the wheels of the tempest and the other is standing on the wheels of the storm-wind. The one is clad in kingly garments, the other is clad in kingly garments. 

 The one is wrapped in a mantle of majesty and the other is wrapped in a mantle of majesty. 

 The one is crowned with a royal crown, and the other is crowned with a royal crown. 

 The one's body is full of eyes, and the other's body is full of eyes. 

 The appearance of one is like unto the appearance of lightnings, and the appearance of the other is like unto the appearance of lightnings. 

 The eyes of the one are like the sun in its might, and the eyes of the other are like the sun in its might. The one's height is like the height of the seven heavens, and the other's height is like the height of the seven heavens. The wings of the one are as (many as) the days of the year, and the wings of the other are as (many as) the days of the year. The wings of the one extend over the breadth of Raqia', and the wings of the other extend over the breadth of Raqia. The lips of the one, are as the gates of the East, and the lips of the other are as the gates of the East. The tongue of the one is as high as the waves of the sea, and the tongue of the other is as high as the waves of the sea. From the mouth of the one a flame goes forth, and from the mouth of the other a flame goes forth. From the mouth of the one there go forth lightnings and from the mouth of the other there go forth lightnings. From the sweat of the one fire is kindled, and from the perspiration of the other fire is kindled. From the one's tongue a torch is burning, and from the tongue of the other a torch is burning. On the head of the one there is a sapphire stone, and upon the head of the other there is a sapphire stone. On the shoulders of the one there is a wheel of a swift cherub, and on the shoulders of the other there is a wheel of a swift cherub. One has in his hand a burning scroll, the other has in his hand a burning scroll. The one has in his hand a flaming style, the other has in his hand a flaming style. The length of the scroll is 3000 myriads of parasangs; the size of the style is 3OOO myriads of parasangs; the size of every single letter that they write is 365 parasangs. 



**[19:1]** Above these three angels, these great princes, there is one Prince, distinguished, honoured, noble, glorified, adorned, fearful, valiant, strong, great, magnified, glorious, crowned, wonderful, exalted, blameless, beloved, lordly, high and lofty, ancient and mighty, like unto whom there is none among the princes. His name is RIKBIEL H', the great and revered Prince who is standing by the Merkaba. 

**[19:2]** And why is he called RIKBIEL? Because he is appointed over the wheels of the Merkaba, and they are given in his charge. 

**[19:3]** And how many are the wheels? Eight; two in each direction. And there are four winds compassing them round about. And these are their names: "the Storm-Wind", "the Tempest", "the Strong Wind", and "the Wind of Earthquake". 

**[19:4]** And under them four fieryrivers are continually running, one fiery river on each side. And round about them, between the rivers, four clouds are planted (placed), and these they are: "clouds of fire", "clouds of lamps", "clouds of coal", "clouds of brimstone" and they are standing over against [their] wheels. 

**[19:5]** And the feet of the Chayyoth are resting upon the wheels. And between one wheel and the other earthquake is roaring and thunder is thundering. 

**[19:6]** And when the time draws nigh for the recital of the Song, (then) the multitudes of wheels are moved, the multitude of clouds tremble, all the chieftains (shallishim) are made afraid, all the horsemen (parashim) do rage, all the mighty ones (gibborim) are excited, all the hosts (seba'im) are afrighted, all the troops (gedudim) are in fear, all the appointed ones (memunnim) haste away, all the princes (sarim) and armies (chayyelim) are dismayed, all the servants (mesharetim) do faint and all the angels (mal'akim) and divisions (degalim) travail with pain. 

**[19:7]** And one wheel makes a sound to be heard to the other and one Kerub to another, one Chayya. to another, one Seraph to another (saying) (Ps. Ixviii. 5) "Extol to him that rideth in 'Araboth, by his name Jah and rejoice before him!" 



**[20:1]** Above these there is one great and mighty prince. His name is CHAYYLIEL H', a noble and revered prince, a glorious and mighty prince, a great and revered prince, a prince before whom all the children of heaven do tremble, a prince who is able to swallow up the whole earth in one moment (at a mouthful). 

**[20:2]** And why is he called CHAYYLIEL H'? Because he is appointed over the Holy Chayyoth and smites the Chayyoth with lashes of fire: and glorifies them, when they give praise and glory and rejoicing and he causes them to make haste to say "Holy" and "Blessed be the Glory of H' from his place!" (i.e. the Qedushshd). 



**[21:1]** Four (are) the Chayyoth corresponding to the four winds. Each Chayya is as the space of the whole world. And each one has four faces; and each face is as the face of the East. 

**[21:2]** Each one has four wings and each wing is like the cover (roof) of the universe. 

**[21:3]** And each one has faces in the middle of faces and wings in the middle of wings. The size of the faces is (as the size of) 248 faces, and the size of the wings is (as the size of) 365 wings. 

**[21:4]** And every one is crowned with 2000 crowns on his head. And each crown is like unto the bow in the cloud. And its splendour is like unto the splendour of the globe of the sun. And the sparks that go forth from every one are like the splendour of the morning star (planet Venus) in the East. 



**[22:1]** Above these la there is one prince, noble, wonderful, strong, and praised with all kinds of praise. His name is KERUBIEL H', a mighty prince, full of power and strength a prince of highness, and Highness (is) with him, a righteous prince, and righteousness (is) with him, a holy prince, and holiness (is) with him, a prince glorified in (by) thousand hosts, exalted by ten thousand armies. 

**[22:2]** At his wrath the earth trembles, at his anger the camps are moved, from fear of him the foundations are shaken, at his rebuke the 'Araboth do tremble. 

**[22:3]** His stature is full of (burning) coals. The height of his stature is as the height of the seven heavens the breadth of his stature is as the wideness of the seven heavens and the thickness of his stature is as the seven heavens. 

**[22:4]** The opening of his mouth is like a lamp of fire. His tongue is a consuming fire. His eyebrows are like unto the splendour of the lightning. His eyes are like sparks of brilliance. His countenance is like a burning fire. 

**[22:5]** And there is a crown of holiness upon his head on which (crown) the Explicit Name is graven, and lightnings go forth from it. And the bow of Shekina is between his shoulders. 

**[22:6]** And his sword is like unto a lightning; and upon his loins there are arrows like unto a flame, and upon his armour and shield there is a consuming fire, and upon his neck there are coals of burning juniper and (also) round about him (there are coals of burning juniper). 

**[22:7]** And the splendour of Shekina is on his face; and the horns of majesty on his wheels; and a royal diadem upon his skull. 

**[22:8]** And his body is full of eyes. And wings are covering the whole of his high stature (lit. the height of his stature is all wings). 

**[22:9]** On his right hand a flame is burning, and on his left a fire is glowing; and coals are burning from it. And firebrands go forth from his body. And lightnings are cast forth from his face. With him there is alway thunder upon (in) thunder, by his side there is ever earthquake upon (in) earthquake. 

**[22:10]** And the two princes of the Merkaba are together with him. 

**[22:11]** Why is he called KERUBIEL H', the Prince? Because he is appointed over the chariot of the Kerubim. And the mighty Kerubim are given in his charge. And he adorns the crowns on their heads and polishes the diadem upon their skull. 

**[22:12]** He magnifies the glory of their appearance. And he glorifies the beauty of their majesty. And he increases the greatness of their honour. He causes the song of their praise to be sung. He intensifies their beautiful strength. He causes the brilliance of their glory to shine forth. He beautifies their goodly mercy and lovingkindness. He frames the fairness of their radiance. He makes their merciful beauty even more beautiful. He glorifies their upright majesty. He extols the order of their praise, to stablish the dwellingplace of him "who dwelleth on the Kerubim". 

**[22:13]** And the Kerubim are standing by the Holy Chayyoth, and their wings are raised up to their heads (lit. are as the height of their heads) and Shekina is (resting) upon them 

 and the brillianceof the Glory is upon their faces 

 and song and praise in their mouth 

 and their hands are under their wings 

 and their feet are covered by their wings 

 and horns of glory are upon their heads 

 and the splendour of Shekina on their face 

 and Shekina is (resting) upon them 

 and sapphire stones are round about them 

 and columns of fire on their four sides 

 and columns of firebrands beside them. 

 

**[22:14]** There is one sapphire on one side and another sapphire on another side and under the sapphires there are coals of burning juniper. 

**[22:15]** And one Kerub is standing in each direction but the wings of the Kerubim compass each other above their skulls in glory; and they spread them to sing with them a song to him that inhabiteth the clouds and to praise with them the fearful majesty of the king of kings. 

**[22:16]** And KERUBIEL H', the prince who is appointed over them, he arrays them in comely, beautiful and pleasant orders and he exalts them in all manner of exaltation, dignity and glory. And he hastens them in glory and might to do the will of their Creator every moment. For above their lofty heads abides continually the glory of the high king "who dwelleth on the Kerubim". 



[22b:1] And there is a court before the Throne of Glory, 

[22b:2] which no seraph nor angel can enter, and it is 36,000 myriads of parasangs, as it is written (Is.vi.2): "and the Seraphim are standing above him" (the last word of the scriptural passage being 'Lamech-Vav’ [numerical value: 36]). 

[22b:3] As the numerical value Lamech-Vav 

[22b:36] the number of the bridges there. 

[22b:4] And there are 24 myriads of wheels of fire. And the ministering angels are 12,000 myriads. And there are 12,000 rivers of hail, and 12,000 treasuries of snow. And in the seven Halls are chariots of fire and flames, without reckoning, or end or searching. R. Ishmael said to me: Metatron, the angel, the Prince of the Presence, said to me: 

[22b:1] How are the angels standing on high? He said: Like a bridge that is placed over a river so that every one can pass over it, likewise a bridge is placed from the beginning of the entry to the end. 

[22b:2] And three ministering angels surround it and utter a song before YHWH, the God of Israel. And there are standing before it lords of dread and captains of fear, thousand times thousand and ten thousand times ten thousand in number and they sing praise and hymns before YHWH, the God of Israel. 

[22b:3] Numerous bridges are there: bridges of fire and numerous bridges of hail. Also numerous rivers of hail, numerous treasuries of snow and numerous wheels of fire. 

[22b:4] And how many are the ministering angels? 12,000 myriads: six (thousand myriads) above and six (thousand myriads] below. And 12,000 are the treasuries of snow, six above and six below. And 24 myriads of wheels of fire, 12 (myriads] above and 12 (myriads] below. And they surround the bridges and the rivers of fire and the rivers of hail. And there are numerous ministering angels, forming entries, for all the creatures that are standing in the midst thereof, corresponding to (over against) the paths of Raqia Shamayim. 

[22b:5] What doeth YHWH, the God of Israel, the King of Glory? The Great and Fearful God, mighty in strength, doth cover his face. 

[22b:6] In Araboth are 660,000 myriads of angels of glory standing over against the Throne of Glory and the divisions offlaming fire. And the King of Glory doth cover His face; for else the (Araboth Raqia1 would be rent asunder in its midst because of the majesty, splendour, beauty, radiance, loveliness, brilliancy, brightness and excellency of the appearance of (the Holy One,) blessed be He. 

[22b:7] There are numerous ministering angels performing his will, numerous kings, numerous princes in the 'Araboth of his delight, angels who are revered among the rulers in heaven, distinguished, adorned with song and bringing love to remembrance: (who) are affrighted by the splendour of the Shekina, and their eyes are dazzled by the shining beauty of their King, their faces grow black and their strength doth fail. 

[22b:8] There go forth rivers ofjoy, streams of gladness, rivers of rejoicing, streams of triumph, rivers of love, streams of friendship (another reading:) of commotion and they flow over and go forth before the Throne of Glory and wax great and go through the gates of the paths of 'Araboth Raqia at the voice of the shouting and musick of the CHAYYOTH, at the voice of the rejoicing of the timbrels of his 'OPHANNIM and at the melody of the cymbals of His Kerubim. And they wax great and go forth with commotion with the sound of the hymn: "HOLY, HOLY, HOLY, IS THE LORD OF HOSTS; THE WHOLE EARTH IS FULL OF HIS GLORY!" 



[22c:1] What is the distance between one bridge and another? 12 myriads ofparasangs. Their ascent is 12 myriads of parasangs, and their descent 12 myriads of parasangs. 

[22c:2] (The distance) between the rivers of dread and the rivers of fear is 22 myriads of parasangs; between the rivers of hail and the rivers of darkness 36 myriads of parasangs; between the chambers of lightnings and the clouds of compassion 42 myriads of parasangs; between the clouds of compassion and the Merkaba 84 myriads ofparasangs; between the Merkaba and the Kerubim 148 myriads of parasangs; between the Kerubim and the 'Ophannim 24 myriads of parasangs; between the Ophannim and the chambers of chambers 24 myriads of parasangs; between the chambers of chambers and the Holy Chayyoth 40,000 myriads of parasangs; between one wing (of the Chayyoth) and another12 myriads of parasangs; and the breadth of each one wing is of that same measure; and the distance between the Holy Chayyoth and the Throne of Glory is 30,000 myriads of parasangs. 

[22c:3] And from the foot of the Throne to the seat there are 40,000 myriads of parasangs. And the name of Him that sitteth on it: let the name be sanctified! 

[22c:4] And the arches of the Bow are set above the 'Araboth, and they are 1000 thousands and 10,000 times ten thousands (of parasangs) high. Their measure is after the measure of the 'Irin and Qaddishin (Watchers and Holy Ones). As it is written (Gen. ix. 13) "My bow I have set in the cloud". It is not written here "I will set" but "I have set", (i.e.) already; clouds that surround the Throne of Glory. As His clouds pass by, the angels of hail (turn into) burning coal. 

[22c:5] And a fire of the voice goes down from by the Holy Chayyoth. And because of the breath of that voice they "run" (Ezek. i. 14) to another place, fearing lest it command them to go; and they "return" lest it injure them from the other side. Therefore "they run and return" (Ezek. i. 14). 

[22c:6] And these arches of the Bow are more beautiful and radiant than the radiance of the sun during the summer solstice. And they are whiter than a flaming fire and they are great and beautiful. 

[22c:7] Above the arches of the Bow are the wheels of the 'Ophannim. Their height is 1000 thousand and 10,000 times 10,000 units of measure after the measure of the Seraphim and the Troops (Gedudim). 



**[23:1]** There are numerous winds blowing under the wings of the Kerubim. There blows "the Brooding Wind", as it is written (Gen. i. 2): " and the wind of God was brooding upon the face of the waters". 

**[23:2]** There blows "the Strong Wind", as it is said (Ex. xiv. 21): "and the Lord caused the sea to go back by a strong east wind all that night". 

**[23:3]** There blows "the East Wind" as it is written (Ex. x. 13): "the east wind brought the locusts". 

**[23:4]** There blows "the Wind of Quails" as it is written (Num. xi. 31): "And there went forth a wind from the Lord and brought quails". 

**[23:5]** There blows "the Wind of Jealousy" as it is written (Num.v.14): "And the wind of jealousy came upon him". 

**[23:6]** There blows the "Wind of Earthquake" as it is written (i Kings .xix. 1 1): "and after that the wind of the earthquake; but the Lord was not in the earthquake". 

**[23:7]** There blows the "Wind of H' " as it is written (Ex. xxxvii. i): "and he carried me out by the wind of H' and set me down". 

**[23:8]** There blows the "Evil Wind" as it is written (i Sam. xvi. 23): "and the evil wind departed from him". 

**[23:9]** There blows the "Wind of Wisdom" and the "Wind of Understanding" and the "Wind of Knowledge" and the "Wind of the Fear of H'" as it is written (Is. xi. 2): "And the wind of H' shall rest upon him; the wind of wisdom and understanding, the wind of counsel and might, the wind of knowledge and of the fear. 

**[23:10]** There blows the "Wind of Rain", as it is written (Prov. xxv. 23): "the north wind bringeth forth rain". 

**[23:11]** There blows the "Wind of Lightnings", as it is written (Jer.x.13, li. 16): "he maketh lightnings for the rain and bringeth forth the wind out of his treasuries". 

**[23:12]** There blows the "Wind, Breaking the Rocks", as it is written (i Kings xix. n): "the Lord passed by and a great and strong wind (rent the mountains and brake in pieces the rocks before the Lord)". 

**[23:13]** There blows the "Wind of Assuagement of the Sea", as it is written (Gen. viii. i): "and God made a wind to pass over the earth, and the waters assuaged". 

**[23:14]** There blows the "Wind of Wrath", as it is written (Job i. 19): "and behold there came a great wind from the wilderness and smote the four corners of the house and it fell". 

**[23:15]** There blows the "Storm-Wind", as it is written (Ps. cxlviii. 8): "Storm-wind, fulfilling his word". 

**[23:16]** And Satan is standing among these winds, for "storm-wind" is nothing else but "Satan", and all these winds do not blow but under the wings of the Kerubim, as it is written (Ps. xviii. n): "and he rode upon a cherub and did fly, yea, and he flew swiftly upon the wings of the wind". 

**[23:17]** And whither go all these winds? The Scripture teaches us, that they go out from under the wings of the Kerubim and descend on the globe of the sun, as it is written (Eccl. i. 6): "The wind goeth toward the south and turneth about unto the north; it turneth about continually in its course and the wind returneth again to its circuits". And from the globe of the sun they return and descend upon the rivers and the seas, upon] the mountains and upon the hills, as it is written (Am.iv.13): "For lo, he that formeth the mountains and createth the wind". 

**[23:18]** And from the mountains and the hills they return and descend to the seas and the rivers; and from the seas and the rivers they return and descend upon (the) cities and provinces; and from the cities and provinces they return and descend into the Garden, and from the Garden they return and descend to Eden, as it is written (Gen.iii. 8): "walking in the Garden in the wind of day". And in the midst of the Garden they join together and blow from one side to the other and are perfumed with the spices of the Garden even from its remotest parts, until they separate from each other, and, filled with the scent of the pure spices, they bring the odour from the remotest parts of Eden and the spices of the Garden to the righteous and godly who in the time to come shall inherit the Garden of Eden and the Tree of Life, as it is written (Cant. iv. 16): "Awake, O north wind; and come thou south; blow upon my garden, that the spices thereof may flow out. Let my beloved come into his garden and eat his precious fruits". 

 

**[24:1]** Numerous chariots has the Holy One, blessed be He: He has the "Chariots of (the) Kerubim", as it is written (Ps.xviii.11, 2 Sam.xxii.11): "And he rode upon a cherub and did fly". 

**[24:2]** He has the "Chariots of Wind", as it is written (ib.): "and he flew swiftly upon the wings of the wind ". 

**[24:3]** He has the "Chariots of (the) Swift Cloud", as it is written (Is. xix. i): "Behold, the Lord rideth upon a swift cloud". 

**[24:4]** He has "the Chariots of Clouds", as it is written (Ex. xix. 9): "Lo, I come unto thee in a cloud". 

**[24:5]** He has the "Chariots of the Altar", as it is written (Am. ix. i):"I saw the Lord standing upon the Altar". 

**[24:6]** He has the "Chariots of Ribbotaim", as it is written (Ps.Ixviii. 18): "The chariots of God are Ribbotaim; thousands of angels". 

**[24:7]** He has the "Chariots of the Tent", as it is written (Deut.xxxi. 15): "And the Lord appeared in the Tent in a pillar of cloud". 

**[24:8]** He has the "Chariots of the Tabernacle", as it is written (Lev. i. 1): "And the Lord spake unto him out of the tabernacle". 

**[24:9]** He has the "Chariots of the Mercy-Seat", as it is written (Num. vii. 89): "then he heard the Voice speaking unto him from upon the mercy-seat". 

**[24:10]** He has the "Chariots of Sapphire Stone", as it is written (Ex. xxiv. 10): "and there was under his feet as it were a paved work of sapphire stone". 

**[24:11]** He has the "Chariots of Eagles ", as it is written (Ex. xix. 4):"I bare you on eagles' wings". Eagles literally are not meant here but "they that fly swiftly as eagles". 

**[24:12]** He has the "chariots of Shout", as it is written (Ps. xlvii. 6):"God is gone up with a shout". 

**[24:13]** He has the "Chariots of 'Araboth", as it is written (Ps.Ixviii. 5): "Extol Him that rideth upon the 'Araboth". 

**[24:14]** He has the "Chariots of Thick Clouds", as it is written (Ps. civ. 3): "who maketh the thick clouds His chariot". 

**[24:15]** He has the "Chariots of the Chayyoth", as it is written (Ezek. i. 14): "and the Chayyoth ran and returned". They run by permission and return by permission, for Shekina is above their heads. 

**[24:16]** He has the "Chariots of Wheels (Galgallim)", as it is written (Ezek. x. 2): "And he said: Go in between the whirling wheels". 

**[24:17]** He has the "Chariots of a Swift Kerub", as it is written (Ps.xviii.10 & Is.xix.1): "riding on a swift cherub". And at the time when He rides on a swift kerub, as he sets one of His feet upon him, before he sets the other foot upon his back, he looks through eighteen thousand worlds at one glance. And he discerns and sees into them all and knows what is in all of them and then he sets down the other foot upon him, according as it is written (Ezek. xlviii. 35): "Round about eighteen thousand". Whence do we know that He looks through every one of them every day? It is written (Ps. xiv. 2): “He looked down from heaven upon the children of men to see if there were any that did understand, that did seek after God". (i8) He has the "Chariots of the 'Ophannim", as it is written (Ezek. x. 12): "and the 'Ophannim were full of eyes round about". 

**[24:19]** He has the "Chariots of His Holy Throne", as it is written (Ps. xlvii. 8):" God sitteth upon his holy throne ". 

**[24:20]** He has the "chariots of the Throne of Yah", as it is written (Ex. xvii. 16): "Because a hand is lifted up upon the Throne of Jah". 

**[24:21]** He has the "Chariots of the Throne of Judgement", as it is written (Is. v. 16): "but the Lord of hosts shall be exalted in judgment". 

**[24:22]** He has the "Chariots of the Throne of Glory", as it is written (Jer. xvii. 12): "The Throne of Glory, set on high from the beginning, is the place of our sanctuary". 

**[24:23]** He has the "Chariots of the High and Exalted Throne", as it is written (Is. vi. i): "I saw the Lord sitting upon the high and exalted throne". 



**[25:1]** Above these there is one great prince, revered, high, lordly, fearful, ancient and strong. 'OPHAPHANNIEL H is his name. 

**[25:2]** He has sixteen faces, four faces on each side,(also) hundred wings on each side. And he has 8466 eyes, corresponding to the days of the year. [2190 –and some say 2116- on each side.] [2191 /2196 and sixteen on each side.] 

**[25:3]** And those two eyes of his face, in each one of them lightnings are flashing, and from each one of them firebrands are burning; and no creature is able to behold them: for anyone who looks at them is burnt instantly. 

**[25:4]** His height is (as) the distance of 2500 years' journey. No eye can behold and no mouth can tell the mighty power of his strength save the King of kings, the Holy One, blessed be He, alone. 

**[25:5]** Why is he called 'OPHAPHANNIEL ? Because he is appointed over the 'Ophannim and the 'Ophannimare given in his charge. He stands every day and attends and beautifies them. And he exalts and orders their apartment and polishes their standing-place and makes bright their dwellings, makes their corners even and cleanses their seats. And he waits upon them early and late, by day and by night, to increase their beauty, to make great their dignity and to make them "diligent in praise of their Creator. 

**[25:6]** And all the 'Ophannim are full of eyes, and they are all full of brightness; seventy two sapphire stones are fixed on their garments on their right side and seventy two sapphire stones are fixed on their garments on their left side. 

**[25:7]** And four carbuncle stones are fixed on the crown of every single one, the splendour of which proceeds in the four directions of 'Araboth even as the splendour of the globe of the sun proceeds in all the directions of the universe. And why is it called Carbuncle (Bareqet)? Because its splendour is like the appearance of a lightning (Baraq). And tents of splendour, tents of brilliance, tents of brightness as of sapphire and carbuncle inclose them because of the shining appearance of their eyes. 



**[26:1]** Above these there is one prince, wonderful, noble, great, honourable, mighty, terrible, a chief and leader 1 and a swift scribe, glorified, honoured and beloved. 

**[26:2]** He is altogether filled with splendour, full of praise and shining; and he is wholly full of brilliance, of light and of beauty; and the whole of him is filled with goodliness and greatness. 

**[26:3]** His countenance is altogether like (that of) angels, but his body is like an eagle's body. 

**[26:4]** His splendour is like unto lightnings, his appearance like fire brands, his beauty like unto sparks, his honour like fiery coals, his majesty like chashmals, his radiance like the light of the planet Venus. The image of him is like unto the Greater Light. His height is as the seven heavens. The light from his eyebrows is like the sevenfold light. 

**[26:5]** The sapphire stone upon his head is as great as the whole universe and like unto the splendour of the very heavens in radiance. 

**[26:6]** His body is full of eyes like the stars of the sky, innumerable and unsearchable. Every eye is like the planet Venus. Yet, there are some of them like the Lesser Light and some of them like unto the Greater Light. From his ankles to his knees (they are) like unto stars of lightning, from his knees to his thighs like unto the planet Venus, from his thighs to his loins like unto the moon, from his loins to his neck like the sun, from his neck to his skull like unto the Light Imperishable. (Cf. Zeph. iii. 5.) 

**[26:7]** The crown on his head is like unto the splendour of the Throne of Glory. The measure of the crown is the distance of 502 years' journey. There is no kind of splendour, no kind of brilliance, no kind of radiance, no kind of light in the universe but is fixed on that crown. 

**[26:8]** The name of that prince is SERAPHIEL H'. And the crown on his head, its name is "the Prince of Peace". And why is he called by the name of SERAPHIEL'? Because he is appointed over the Seraphim. And the flaming Seraphim are given in his charge. And he presides over them by day and by night and teaches them song, praise, proclamation of beauty, might and majesty; that they may proclaim the beauty of their King in all manner of Praise and Sanctification (Qedushsha). 

**[26:9]** How many are the Seraphim? Four, corresponding to the four winds of the world. And how many wings have they each one of them? Six, corresponding to the six days of Creation. And how many faces have they? Each one of them four faces. 

**[26:10]** The measure of the Seraphim and the height of each one of them correspond to the height of the seven heavens. The size of each wing is like the measure of all Raqia' . The size of each face is like that of the face of the East. 

**[26:11]** And each one of them gives forth light like unto the splendour of the Throne of Glory: so that not even the Holy Chayyoth, the honoured 'Ophannim, nor the majestic Kerubim are able to behold it. For everyone who beholds it, his eyes are darkened because of its great splendour. 

**[26:12]** Why are they called Seraphim? Because they burn (saraph) the writing tables of Satan: Every day Satan is sitting, together with SAMMAEL, the Prince of Rome, and with DUBBIEL, the Prince of Persia, and they write the iniquities of Israel on writing tables which they hand over to the Seraphim, in order that they may present them before the Holy One, blessed be He, so that He may destroy Israel from the world. But the Seraphim know from the secrets of the Holy One, blessed be He, that he desires not, that this people Israel should perish. What do the Seraphim? Every day do they receive (accept) them from the hand of Satan and burn them in the burning fire over against the high and exalted Throne in order that they may not come before the Holy One, blessed be He, at the time when he is sitting upon the Throne of Judgement, judging the whole world in truth. 



**[27:1]** Above the Seraphim there is one prince, exalted above all the princes, wondrous more than all the servants. His name is RADWERIEL H' who is appointed over the treasuries of the books. 

**[27:2]** He fetches forth the Case of Writings (with) the Book of Records in it, and brings it before the Holy One, blessed be He. And he breaks the seals of the case, opens it, takes out the books and delivers them before the Holy One, blessed be He. And the Holy One, blessed be He, receives them of his hand and gives them in his sight to the Scribes, that they may read them in the Great Beth Din (The court of justice) in the height of 'Araboth Raqia', before the heavenly household. 

**[27:3]** And why is he called RADWERIEL? Because out of every word that goes forth from his mouth an angel is created: and he stands in the songs (in the singing company) of the ministering angels and utters a song before the Holy One, blessed be He when the time draws nigh for the recitation of the (Thrice) Holy. 



**[28:1]** Above all these there are four great princes, Irin and Qaddishin by name: high, honoured, revered, beloved, wonderful and glorious ones, greater than all the children of heaven. There is none like unto them among all the celestial princes and none their equal among all the Servants. For each one of them is equal to all the rest together. 

**[28:2]** And their dwelling is over against the Throne of Glory, and their standing place over against the Holy One, blessed be He, so that the brilliance of their dwelling is a reflection of the brilliance of the Throne of Glory. And the splendour of their countenance is a reflection of the splendour of Shekina. 

**[28:3]** And they are glorified by the glory of the Divine Majesty (Gebura) and praised by (through) the praise of Shekina. 

**[28:4]** And not only that, but the Holy One, blessed be He, does nothing in his world without first consulting them, but after that he doeth it. As it is written (Dan. iv. 17): "The sentence is by the decree of the 'Irin and the demand by the word of the Qaddishin." 

**[28:5]** The Irin are two and the Qaddishin are two. And how are they standing before the Holy One, blessed be He? It is to be understood, that one ‘Ir is standing on one side and the other ‘Ir on the other side, and one Qaddish is standing on one side and the other on the other side. 

**[28:6]** And ever do they exalt the humble, and they abase to the ground those that are proud, and they exalt to the height those that are humble. 

**[28:7]** And every day, as the Holy One, blessed be He, is sitting upon the Throne of Judgement and judges the whole world, and the Books of the Living and the Books of the Dead are opened before Him, then all the children of heaven are standing before him in fear, dread, awe and trembling. At that time, (when) the Holy One, blessed be He, is sitting upon the Throne of Judgement to execute judgement, his garment is white as snow, the hair on his head as pure wool and the whole of his cloak is like the shining light. And he is covered with righteousness all over as with a coat of mail. 

**[28:8]** And those 'Irin and Qaddishin are standing before him like court officers before the judge. And they raise and argue every case and close the case that comes before the Holy One, blessed be He, in judgement, according as it is written (Dan. iv. 17): "The sentence is by the decree of the 'Irin and the demand by the word of the Qaddishin" 

**[28:9]** Some of them argue and others pass the sentence in the Great Beth Din in 'Araboth. Some of them make the requests from before the Divine Majesty and some close the cases before the Most High. Others finish by going down and (confirming ) executing the sentences on earth below. According as it is written (Dan. iv. 13 , 14): " Behold an 'Ir and a Qaddishcame down from heaven and cried aloud and said thus, Hew down the tree, and cut off his branches, shake off his leaves, and scatter his fruit: let the beasts get away from under it, and the fowls from his branches". 

**[28:10]** Why are they called 'Irin and Qaddishint (Watchers and Holy Ones)? By reason that they sanctify the body and the spirit with lashes of fire on the third day of the judgement, as it is written (Hos. vi. 2): "After two days will he revive us: on the third he will raise us up, and we shall live before him." 



**[29:1]** Each one of them has seventy names corresponding to the seventy tongues of the world. And all of them are (based) upon the name of the Holy One, blessed be He. And every several name is written with a flaming style upon the Fearful Crown (Keiher Nora) which is on the head of the high and exalted King. 

**[29:2]** And from each one of them there go forth sparks and lightnings. And each one of them is beset with horns of splendour round about. From each one lights are shining forth, and each one is surrounded by tents of brilliance so that not even the Seraphim and the Chayyoth who are greater than all the children of heaven are able to behold them. 



**[30:1]** Whenever the Great Beth Din is seated in the 'Araboth Raqia' on high there is no opening of the mouth for anyone in the world save those great princes who are called H' by the name of the Holy One, blessed be He. 

**[30:2]** How many are those princes? Seventy-two princes of the kingdoms of the world besides the Prince of the World who speaks (pleads) in favour of the world before the Holy One, blessed be He, every day, at the hour when the book is opened in which are recorded all the doings of the world, according as it is written (Dan.vii.10): "The judgement was set and the books were opened." 



**[31:1]** At the time when the Holy One, blessed be He, is sitting on the Throne, of Judgement, (then) Justice is standing on His right and Mercy on His left and Truth before His face. 

**[31:2]** And when man enters before Him to judgement, (then) there comes forth from the splendour of the Mercy towards him as (it were) a staff and stands in front of him. Forthwith man falls upon his face, (and) all the angels of destruction fear and tremble before him, according as it is written (Is.xvi. 5): "And with mercy shall the throne be established, and he shall sit upon it in truth." 



**[32:1]** When the Holy One, blessed be He, opens the Book half of which is fire and half flame, (then) they go out from before Him in every moment to execute the judgement on the wicked by His sword (that is) drawn forth out of its sheath and the splendour of which shines like a lightning and pervades the world from one end to the other, as it is written (Is. Ixvi. 16): "For by fire will the Lord plead (and by his sword with all flesh)." 

**[32:2]** And all the inhabitants of the world (lit. those who come into the world) fear and tremble before Him, when they behold His sharpened sword like unto a lightning from one end of the world to the other, and sparks and flashes of the size of the stars of Raqia' going out from it; according as it is written (Deut. xxxii. 41): "If I whet the lightning of my sword". 



**[33:1]** At the time that the Holy One, blessed be He, is sitting on the Throne of Judgement, (then) the angels of Mercy are standing on His right, the angels of Peace are standing on His left and the angels of Destruction are standing in front of Him. 

**[33:2]** And one scribe is standing beneath Him, and another scribe above Him. 

**[33:3]** And the glorious Seraphim surround the Throne on its four sides with walls of lightnings, and the 'Ophannim surround them with fire-brands round about the Throne of Glory. And clouds of fire and clouds of flames compass them to the right and to the left; and the Holy Chayyoth carry the Throne of Glory from below: each one with three fingers. The measure of the fingers of each one is 800,000 and 700 times hundred, (and) 66,000 parasangs. 

**[33:4]** And underneath the feet of the Chayyoth seven fiery rivers are running and flowing. And the breadth of each river is 365 thousand parasangs and its depth is 248 thousand myriads of parasangs. Its length is unsearchable and immeasureable. 

**[33:5]** And each river turns round in a bow in the four directions of 'Araboth Raqict , and (from there) it falls down to Ma'on and is stayed, and from Ma1 on to Zebul, from Zebul to Shechaqim, from Shechaqim to Raqia' , from Raqia' to Shamayim and from Shamayim upon the heads of the wicked who are in Gehenna, as it is written (Jer. xxiii. 19): "Behold a whirlwind of the Lord, even his fury, is gone, yea, a whirling tempest; it shall burst upon the head of the wicked". 



**[34:1]** The hoofs of the Chayyoth are surrounded by seven clouds of burning coals. The clouds of burning coals are surrounded on the outside by seven walls of flame(s). The seven walls of flame(s) are surrounded on the outside by seven walls of hailstones (stones of 'Et-gabish, Ezek. xiii. 11,13, xxviii. 22). The hailstones are surrounded on the outside by stones of hail (stone of Barad). The stones of hail are surrounded on the outside by stones of "the wings of the tempest ". The stones of "the wings of the tempest" are surrounded on the outside by flames of fire. The flames of fire are surrounded by the chambers of the whirlwind. The chambers of the whirlwind are surrounded on the outside by the fire and the water. 

**[34:2]** Round about the fire and the water are those who utter the "Holy". Round about those who utter the "Holy" are those who utter the "Blessed"'. Round about those who utter the "Blessed" are the bright clouds. The bright clouds are surrounded on the outside by coals of burning jumper; and on the outside surrounding the coals of burning juniper there are thousand camps of fire and ten thousand hosts of flame(s). And between every several camp and every several host there is a cloud, so that they may not be burnt by the fire. 



**[35:1]** 506 thousand myriads of camps has the Holy One, blessed be He, in the height of 'Araboth Raqia. And each camp is (composed of) 496 thousand angels. 

**[35:2]** And every single angel, the height of his stature is as the great sea; and the appearance of their countenance as the appearance of the lightning, and their eyes as lamps of fire, and their arms and their feet like in colour to polished brass and the roaring voice of their words like the voice of a multitude. 

**[35:3]** And they are all standing before the Throne of Glory in four rows. And the princes of the army are standing at the head of each row. 

**[35:4]** And some of them utter the "Holy" and others utter the "Blessed", some of them run as messengers, others are standing in attendance, according as it is written (Dan. vii. 10): "Thousand thousands ministered unto him, and ten thousand times ten thousand stood before him: the judgment was set and the books were opened". 

**[35:5]** And in the hour, when the time draws nigh for to say the "Holy", (then) first there goes forth a whirlwind from before the Holy One, blessed be He, and bursts upon the camp of Shekina and there arises a great commotion among them, as it is written (Jer.xxx. 23): "Behold, the whirlwind of the Lord goeth forth with fury, a continuing commotion". 

**[35:6]** At that moment thousand thousands of them are changed into sparks, thousand thousands of them into firebrands, thousand thousands into flashes, thousand thousands into flames, thousand thousands into males, thousand thousands into females, thousand thousands into winds, thousand thousands into burning fires, thousand thousands into flames, thousand thousands into sparks, thousand thousands into chashmals of light; until they take upon themselves the yoke of the kingdom of heaven, the high and lifted up, of the Creator of them all with fear, dread, awe and trembling, with commotion, anguish, terror and trepidation. Then they are changed again into their former shape to have the fear of their King before them alway, as they have set their hearts on saying the Song continually, as it is written (Is. vi. 3): "And one cried unto another and said (Holy, Holy, Holy, etc.)". 



**[36:1]** At the time when the ministering angels desire to say (the) Song, (then) Nehar di-Nur (the fiery stream) rises with many thousand thousands and myriads of myriads" (of angels) of power and strength of fire and it runs and passes under the Throne of Glory, between the camps of the ministering angels and the troops of 'Araboth. 

**[36:2]** And all the ministering angels first go down into Nehar di-Nur, and they dip themselves in the fire and dip their tongue and their mouth seven times; and after that they go up and put on the garment of 'Machaqe Samal’ and cover themselves with cloaks of chashmal and stand in four rows over against the Throne of Glory, in all the heavens. 



**[37:1]** In the seven Halls there are standing four chariots of Shekina, and before each one are standing the four camps of Shekina. Between each camp a river of fire is continually flowing. 

**[37:2]** Between each river there are bright clouds [surrounding them], and between each cloud there are put up pillars of brimstone. Between one pillar and another there are standing flaming wheels, surrounding them. And between one wheel and another there are flames of fire round about. Between one flame and another there are treasuries of lightnings; behind the treasuries of lightnings are the wings of the stormwind. Behind the wings of the storm-wind are the chambers of the tempest; behind the chambers of the tempest there are winds, voices, thunders, sparks [upon] sparks and earthquakes [upon] earthquakes. 



**[38:1]** At the time, when the ministering angels utter (the Thrice) Holy, then all the pillars of the heavens and their sockets do tremble, and the gates of the Halls of Araboth Raqia' are shaken and the foundations of Shechaqim and the Universe (Tebel) are moved, and the orders of Ma'on and the chambers of Makon quiver, and all the orders of Raqia and the constellations and the planets are dismayed, and the globes of the sun and the moon haste away and flee out of their courses and run 12,000 parasangs and seek to throw themselves down from heaven, 

**[38:2]** by reason of the roaring voice of their chant, and the noise of their praise and the sparks and lightnings that go forth from their faces; as it is written (Ps. Ixxvii. 18): "The voice of thy thunder was in the heaven (the lightnings lightened the world, the earth trembled and shook)". 

**[38:3]** Until the prince of the world calls them, saying: "Be ye quiet in your place! Fear not because of the ministering angels who sing the Song before the Holy One, blessed be He". As it is written (Job.xxxviii. 7): "When the morning stars sang together and all the children of heaven shouted for joy". 



**[39:1]** When the ministering angels utter the "Holy" then all the explicit names that are graven with a flaming style on the Throne of Glory fly off like eagles, with sixteen wings. And they surround and compass the Holy One, blessed be He, on the four sides of the place of His Shekina1. 

**[39:2]** And the angels of the host, and the flaming Servants, and the mighty 'Ophannim, and the Kerubim of the Shekina, and the Holy Chayyoth, and the Seraphim, and the 'Er'ellim, and the Taphsarim and the troops of consuming fire, and the fiery armies, and the flaming hosts, and the holy princes, adorned with crowns, clad in kingly majesty, wrapped in glory, girt with loftiness, fall upon their faces three times, saying: "Blessed be the name of His glorious kingdom for ever and ever". 



**[40:1]** When the ministering angels say "Holy" before the Holy One, blessed be He, in the proper way, then the servants of His Throne, the attendants of His Glory, go forth with great mirth from under the Throne of Glory. 

**[40:2]** And they all carry in their hands, each one of them thousand thousand and ten thousand times ten thousand crowns of stars, similar in appearance to the planet Venus, and put them on the ministering angels and the great princes who utter the "Holy". Three crowns they put on each one of them: one crown because they say "Holy", another crown, because they say "Holy, Holy", and a third crown because they say "Holy, Holy, Holy, is the Lord of Hosts" . 

**[40:3]** And in the moment that they do not utter the "Holy" in the right order, a consuming fire goes forth from the little finger of the Holy One, blessed be He, and falls down in the midst of their ranks and is divided into 496 thousand parts corresponding to the four camps of the ministering angels, and consumes them in one moment, as it is written (Ps. xcvii. 3): "A fire goeth before him and burneth up his adversaries round about". 

**[40:4]** After that the Holy One, blessed be He, opens His mouth and speaks one word and creates others in their stead, new ones like them. And each one stands before His Throne of Glory, uttering the "Holy", as it is written (Lam. iii. 23): "They are new every morning; great is thy faithfulness”. 



**[41:1]** Come and behold the letters by which the heaven and theearth were created, the letters by which were created the mountains and hills, the letters by which were created the seas and rivers, the letters by which were created the trees and herbs, the letters by which were created the planets and the constellations, the letters by which were created the globe of the moon and the globe of the sun, Orion, the Pleiades and all the different luminaries of Raqia' . 

**[41:2]** the letters by which were created the Throne of Glory and the Wheels of the Merkaba, the letters by which were created the necessities of the worlds, 

**[41:3]** the letters by which were created wisdom, understanding, knowledge, prudence, meekness and righteousness by which the whole world is sustained. 

**[41:4]** And I walked by his side and he took me by his hand and raised me upon his wings and showed me those letters, all of them, that are graven with a flaming style on the Throne of Glory: and sparks go forth from them and cover all the chambers of 'Araboth. 



**[42:1]** Come and I will show thee, where the waters are suspended in the highest, where fire is burning in the midst of hail, where lightnings lighten out of the midst of snowy mountains, where thunders are roaring in the celestial heights, where a flame is burning in the midst of the burning fire and where voices make themselves heard in the midst of thunder and earthquake. 

**[42:2]** Then I went by his side and he took me by his hand and lifted me up on his wings and showed me all those things. I beheld the waters suspended on high in 'Araboth Raqia' by (force of) the name YAH 'EHYE 'ASHER 'EHYE (Jah, I am that I am), And their fruits going down from heaven and watering the face of the world, as it is written (Ps.civ.13): "(He watereth the mountains from his chambers:) the earth is satisfied with the fruit of thy work". 

**[42:3]** And I saw fire and snow and hailstone that were mingled together within each other and yet were undamaged, by (force of) the name 'ESH 'OKELA (consuming fire), as it is written (Deut. iv. 24): "For the Lord, thy God, is a consuming fire". 

**[42:4]** And I saw lightnings that were lightening out of mountains of snow and yet were not damaged (quenched), by (force of) the name YAH SUR 'OLAMIM (Jah, the everlasting rock), as it is written (Is. xxvi. 4): "For in Jah, YHWH, the everlasting rock". 

**[42:5]** And I saw thunders and voices that were roaring in the midst of fiery flames and were not damaged (silenced), by (force of) the name 'EL-SHADDAI RABBA (the Great God Almighty) as it is written (Gen. xvii. i): "I am God Almighty". 

**[42:6]** And I beheld a flame (and) a glow (glowing flames) that were flaming and glowing in the midst of burning fire, and yet were not damaged (devoured), by (force of) the name YAD 'AL KES YAH (the hand upon the Throne of the Lord) as it is written (Ex. xvii. 16): "And he said: for the hand is upon the Throne of the Lord". 

**[42:7]** And I beheld rivers of fire in the midst of rivers of water and they were not damaged (quenched) by (force of) the name 'OSE SHALOM (Maker of Peace) as it is written (Job xxv. 2): "He maketh peace in his high places". For he makes peace between the fire and the water, between the hail and the fire, between the wind and the cloud, between the earthquake and the sparks. 



**[43:1]** Come and I will show thee where are the spirits of the righteous that have been created and have returned, and the spirits of the righteous that have not yet been created. 

**[43:2]** And he lifted me up to his side, took me by his hand and lifted me up near the Throne of Glory by the place of the Shekina; and he revealed the Throne of Glory to me, and he showed me the spirits that have been created and had returned: and they were flying above the Throne of Glory before the Holy One, blessed be He. 

**[43:3]** After that I went to interpret the following verse of Scripture and I found in what is written (Isa.Ivii. 16): "for the spirit clothed itself before me, and the souls I have made" that ("for the spirit was clothed before me") means the spirits that have been created in the chamber of creation of the righteous and that have returned before the Holy One, blessed be He; (and the words:) "and the souls I have made" refer to the spirits of the righteous that have not yet been created in the chamber (GUPH). 



**[44:1]** Come and I will show thee the spirits of the wicked and the spirits of the intermediate where they are standing, and the spirits of the intermediate, whither they go down, and the spirits of the wicked, where they go down. 

**[44:2]** And he said to me: The spirits of the wicked go down to She'ol by the hands of two angels of destruction: ZA'APHIEL and SIMKIEL are their names. 

**[44:3]** SIMKIEL is appointed over the intermediate to support them and purify them because of the great mercy of the Prince of the Place (Maqom). ZA'APHIEL is appointed over the spirits of the wicked in order to cast them down from the presence of the Holy One, blessed be He, and from the splendour of the Shekina to She'ol, to be punished in the fire of Gehenna with staves of burning coal. 

**[44:4]** And I went by his side, and he took me by his hand and showed me all of them with his fingers. 

**[44:5]** And I beheld the appearance of their faces (and, lo, it was) as the appearance of children of men, and their bodies like eagles. And not only that but (furthermore) the colour of the countenance of the intermediate was like pale grey on account of their deeds, for there are stains upon them until they have become cleaned from their iniquity in the fire. 

**[44:6]** And the colour of the wicked was like the bottom of a pot on account of the wickedness of their doings. 

**[44:7]** And I saw the spirits of the Patriarchs Abraham Isaac and Jacob and the rest of the righteous whom they have brought up out of their graves and who have ascended to the Heaven (Raqirf). And they were praying before the Holy One, blessed be He, saying in their prayer: "Lord of the Universe! How long wilt thou sit upon (thy) Throne like a mourner in the days of his mourning with thy right hand behind thee 7and not7 deliver thy children and reveal thy Kingdom in the world? And for how long wilt thou have no pity upon thy children who are made slaves among the nations of the world? Nor upon thy right hand that is behind thee wherewith thou didst stretch out the heavens and the earth and the heavens of heavens? When wilt thou have compassion?" 

**[44:8]** Then the Holy One, blessed be He, answered every one of them, saying: "Since these wicked do sin so and so, and transgress with such and such transgressions against me, how could I deliver my great Right Hand in the downfall by their hands (caused by them). 

**[44:9]** In that moment Metatron called me and spake to me: "My servant! Take the books, and read their evil doings!" Forthwith I took the books and read their doings and there were to be found 36 transgressions (written down) with regard to each wicked one and besides, that they have transgressed all the letters in the Tora, as it is written (Dan. ix. u): "Yea, all Israel have transgressed thy Law". It is not written 'al torateka but 'et (JIN) torateka, for they have transgressed from 'Aleph to Taw, 4O statutes have they transgressed for each letter. 

**[44:10]** Forthwith Abraham, Isaac and Jacob wept. Then said to them the Holy One, blessed be He: "Abraham, my beloved, Isaac, my Elect one, Jacob, my firstborn! How can I now deliver them from among the nations of the world?" And forthwith MIKAEL, the Prince of Israel, cried and wept with a loud voice and said (Ps. x. i): "Why standest thou afar off, O Lord?". 



**[45:1]** Come, and I will show thee the Curtain of MAQOM (the Divine Majesty) which is spread before the Holy One, blessed be He, (and) whereon are graven all the generations of the world and all their doings, both what they have done and what they will do until the end of all generations. 

**[45:2]** And I went, and he showed it to me pointing it out with his fingers Mike a father who teaches his children the letters of Tora. And I saw each generation, the rulers of each generation, 

 and the heads of each generation, 

 the shepherds of each generation, 

 the oppressors (drivers) of each generation, 

 the keepers of each generation, 

 the scourgers of each generation, 

 the overseers of each generation, 

 the judges of each generation, 

 the court officers of each generation, 

 the teachers of each generation, 

 the supporters of each generation, 

 the chiefs of each generation, 

 the presidents of academies of each generation, 

 the magistrates of each generation, 

 the princes of each generation, 

 the counsellors of each generation, 

 the nobles of each generation, 

 and the men of might of each generation, 

 the elders of each generation, 

 and the guides of each generation. 

 

**[45:3]** And I saw Adam, his generation, their doings and their thoughts, Noah and his generation, their doings and their thoughts, and the generation of the flood, their doings and their thoughts, Shem and his generation, their doings and their thoughts, Nimrod and the generation of the confusion of tongues, and his generation, their doings and their thoughts, Abraham and his generation, their doings and their thoughts, Isaac and his generation, their doings and their thoughts, Ishmael and his generation, their doings and their thoughts, Jacob and his generation, their doings and their thoughts, Joseph and his generation, their doings and their thoughts, the tribes and their generation, their doings and their thoughts, Amram and his generation, their doings and their thoughts, Moses and his generation, their doings and their thoughts, 

**[45:4]** Aaron and Mirjam their works and their doings, the princes and the elders, their works and doings, Joshua and his generation, their works and doings, the judges and their generation, their works and doings, Eli and his generation, their works and doings, "Phinehas, their works and doings, Elkanah and his generation, their works and their doings, Samuel and his generation, their works and doings, the kings of Judah with their generations, their works and their doings, the kings of Israel and their generations, their works and their doings, the princes of Israel, their works and their doings; the princes of the nations of the world, their works and their doings, the heads of the councils of Israel, their works and their doings; the heads of (the councils in) the nations of the world, their generations, their works and their doings; the rulers of Israel and their generation, their works and their doings; the nobles of Israel and their generation, their works and their doings; the nobles of the nations of the world and their generation(s), their works and their doings; the men of reputation in Israel, their generation, their works and their doings; the judges of Israel, their generation, their works and their doings; the judges of the nations of the world and their generation, their works and their doings; the teachers of children in Israel, their generations, their works and their doings; the teachers of children in the nations of the world, their generations, their works and their doings; the counsellors (interpreters) of Israel, their generation, their works and their doings; the counsellors (interpreters) of the nations of the world, their generation, their works and their doings; all the prophets of Israel, their generation, their works and their doings; all the prophets of the nations of the world, their generation, their works and their doings; 

**[45:5]** and all the fights and wars that the nations of the world wrought against the people of Israel in the time of their kingdom. And I saw Messiah, son of Joseph, and his generation "and their" works and their doings that they will do against the nations of the world. And I saw Messiah, son of David, and his generation, and all the fights and wars, and their works and their doings that they will do with Israel both for good and evil. And I saw all the fights and wars that Gog and Magog will fight in the days of Messiah, and all that the Holy One, blessed be He, will do with them in the time to come. 

**[45:6]** And all the rest of all the leaders of the generations and all the works of the generations both in Israel and in the nations of the world, both what is done and what will be done hereafter to all generations until the end of time, (all) were graven on the Curtain of MAQOM. And I saw all these things with my eyes; and after I had seen it, I opened my mouth in praise of MAQOM (the Divine Majesty) (saying thus, Eccl. viii. 4, 5): "For the King's word hath power (and who may say unto him: What doest thou?) Whoso keepeth the commandments shall know no evil thing". And I said: (Ps. civ. 24) "O Lord, how manifold are thy works!". 



**[46:1]** (Come and I will show thee) the space of the stars a that are standing in Raqia' night by night in fear of the Almighty (MAQOM) and (I will show thee) where they go and where they stand. 

**[46:2]** I walked by his side, and he took me by his hand and pointed out all to me with his fingers. And they were standing on sparks of flames round the Merkaba of the Almighty (MAQOM). What did Metatron do? At that moment he clapped his hands and chased them off from their place. Forthwith they flew off on flaming wings, rose and fled from the four sides of the Throne of the Merkaba, and (as they flew) he told me the names of every single one. As it is written (Ps. cxlvii. 4):" He telleth the number of the stars; he giveth them all their names", teaching, that the Holy One, blessed be He, has given a name to each one of them. 

**[46:3]** And they all enter in counted order under the guidance of (lit. through, by the hands of) RAHATIEL to Raqia' ha-shamayim to serve the world. And they go out in counted order to praise the Holy One, blessed be He, with songs and hymns, according as it is written (Ps. xix. i): "The heavens declare the glory of God". 

**[46:4]** But in the time to come the Holy One, blessed be He, will create them anew, as it is written (Lam. iii. 23): "They are new every morning". And they open their mouth and utter a song. Which is the song that they utter? (Ps. viii. 3): "When I consider thy heavens". 



**[47:1]** Come and I will show thee the souls of the angels and the spirits of the ministering servants whose bodies have been burnt in the fire of MAQOM (the Almighty) that goes forth from his little finger. And they have been made into fiery coals in the midst of the fiery river (Nehar di-Nur). But their spirits and their souls are standing behind the Shekina. 

**[47:2]** Whenever the ministering angels utter a song at a wrong time or as not appointed to be sung they are burnt and consumed by the fire of their Creator and by a flame from their Maker, in the places (chambers) of the whirlwind, for it blows upon them and drives them into the Nehar di-Nur; and there they are made into numerous mountains of burning coal. But their spirit and their soul return to their Creator, and all are standing behind their Master. 

**[47:3]** And I went by his side and he took me by his hand; and he showed me all the souls of the angels and the spirits of the ministering servants who were standing behind the Shekina upon wings of the whirlwind and walls of fire surrounding them. 

**[47:4]** At that moment Metatron opened to me the gates of the walls within which they were standing behind the Shekina, And I lifted up my eyes and saw them, and behold, the likeness of every one was as (that of) angels and their wings like birds' (wings), made out of flames, the work of burning fire. In that moment I opened my mouth in praise of MAQOM and said (Ps. xcii. 5): "How great are thy works, O Lord ". 



**[48:1]** Come, and I will show thee the Right Hand of MAQOM, laid behind (Him) because of the destruction of the Holy Temple; from which all kinds of splendour and light shine forth and by which the 955 heavens were created; and whom not even the Seraphim and the 'Ophannim are permitted (to behold), until the day of salvation shall arrive. 

**[48:2]** And I went by his side and he took me by his hand and showed me (the Right Hand of MAQOM), with all manner of praise, rejoicing and song: and no mouth can tell its praise, and no eye can behold it, because of its greatness, dignity, majesty, glory and beauty. 

**[48:3]** And not only that, but all the souls of the righteous who are counted worthy to behold the joy of Jerusalem, they are standing by it, praising and praying before it three times every day, saying (Is.li.9): "Awake, awake, put on strength, O arm of the Lord" according as it is written (Is. Ixiii. 12): "He caused his glorious arm to go at the right hand of Moses". 

**[48:4]** In that moment the Right Hand of MAQOM was weeping. And there went forth from its five fingers five rivers of tears and fell down into the great sea and shook the whole world, according as it is written (Is. xxiv. 19, 20): "The earth is utterly broken 

**[48:1]** , the earth is clean dissolved 

**[48:2]** , the earth is moved exceedingly 

**[48:3]** , the earth shall stagger like a drunken man 

**[48:4]** and shall be moved to and fro like a hut 

**[48:5]** ", five times corresponding to the fingers of his Great Right Hand. 

**[48:5]** But when the Holy One, blessed be He, sees, that there is no righteous man in the generation, and no pious man (Chasid] on earth, and no justice in the hands of men; and (that there is) no man like unto Moses, and no intercessor as Samuel who could pray before MAQOM for the salvation and for the deliverance, and for His Kingdom, that it be revealed in the whole world; and for His great Right Hand that He put it before Himself again to work great salvation by it for Israel, 

**[48:6]** then forthwith will the Holy One, blessed be He, remember His own justice, favour, mercy and grace: and He will deliver His great Arm by himself, and His righteousness will support Him. According as it is written (Is. lix. 16): "And he saw, that there was no man" (that is:) like unto Moses who prayed countless times for Israel in the desert and averted the (Divine) decrees from them" and he wondered, that there was no intercessor" like unto Samuel who intreated the Holy One, blessed be He, and called unto Him and he answered him and fulfilled his desire, even if it was not fit (in accordance with the Divine plan), according as it is written (i Sam. xii. 17): "Is it not wheat-harvest to-day? I will call unto the Lord". 

**[48:7]** And not only that, but He joined fellowship with Moses in every place, as it is written (Ps.xcix.6): "Moses and Aaron among His priests." And again it is written (Jer. xv. i): "Though Moses and Samuel stood before me" (Is. Ixiii. 5): "Mine own arm brought salvation unto me". 

**[48:8]** Said the Holy One, blessed be He in that hour: " How long shall I wait for the children of men to work salvation according to their righteousness for my arm? For my own sake and for the sake of my merit and righteousness will I deliver my arm and by it redeem my children from among the nations of the world. As it is written (Is. xlviii. n): "For my own sake will I do it. For how should my name be profaned". 

**[48:9]** In that moment will the Holy One, blessed be He, reveal His Great Arm and show it to the nations of the world: for its length is as the length of the world and its breadth is as the width of the world. And the appearance of its splendour is like unto the splendour of the sunshine in its might, in the summer solstice. 

**[48:10]** Forthwith Israel will be saved from among the nations of the world. And Messiah will appear unto them and He will bring them up to Jerusalem with great joy. And not only that but Israel will come from the four quarters of the World and eat with Messiah. But the nations of the world shall not eat with them, as it is written (Is. Hi. 10): "The Lord hath made bare his holy arm in the eyes of all the nations; and all the ends of the earth shall see the salvation of our God". And again (Deut. xxxii. 12): "The Lord alone did lead him, and there was no strange god with him". (Zech. xiv. 9): "And the Lord shall be king over all the earth". 



[48b:1] These are the seventy-two names written on the heart of the Holy One, blessed be He: SS, SeDeQ {righteousness), SaHPeL SUR {Is. xxvi. 4}, SBI, SaDdlQ{righteous}, S'Ph, SHN, SeBa'oTh {Lord of Hosts},ShaDdaY {God Almighty}, 'eLoHIM {God}, YHWH, SH, DGUL, W'DOM, SSS", 'YW, 'F, 'HW, HB, YaH, HW, WWW, SSS, PPP, NN, HH, HaY {living}, HaY, ROKeB 'aRaBOTh {riding upon the ‘Araboth’, Ps. Ixviii. 5}, YH, HH, WH, MMM, NNN, HWW, YH, YHH, HPhS, H'S, 'I, W, S", Z', "', QQQ {Holy, Holy, Holy}, QShR, BW, ZK, GINUR, GINURYa’, Y’, YOD, 'aLePh, H'N, P'P, R'W, YYWy YYW, BBS, DDD, TTT, KKK, KLL, SYS, 'XT', BShKMLW {= blessed be the Name of His glorious kingdom for ever and ever}, completed for MeLeK HalOLaM {the King of the Universe], JBRH LB' {the beginning of Wisdom for the children of men}, BNLK W" Y {blessed be He who gives strength to the weary and increaseth strength to them that have no might, Is. xl. 29}that go forth (adorned) with numerous crowns of fire with numerous crowns of flame, with numerous crowns of chashmal, with numerous crowns of lightning from before the Throne of Glory. And with them (there are) thousand hundreds of power (i.e. powerful angels) who escort them like a king with trembling and dread, with awe and shivering, with honour and majesty andfear, with terror, with greatness and dignity, with glory and strength, with understanding and knowledge and with a pillar of fire and a pillar of flame and lightning and their light is as lightnings of light and with the likeness of the chashmal. 

[48b:2] And they give glory unto them and they answer and cry before them: Holy, Holy, Holy. And they roll (convoy) them through every heaven as mighty and honoured princes. And when they bring them all back to the place of the Throne of Glory, then all the Chayyoth by the Merkaba open their mouth in praise of His glorious name, saying: "Blessed be the name of His glorious kingdom for ever and ever". 





[48c:1] "I seized him, and I took him and I appointed him" that is Enoch, the son of Jared, whose name is Metatron 

[48c:2] and I took him from among the children of men 

[48c:5] and made him a Throne over against my Throne. Which is the size of that Throne? Seventy thousand parasangs (all) of fire. 

[48c:9] I committed unto him 70 angels corresponding to the nations (of the world) and I gave into his charge all the household above and below. 

[48c:7] And I committed to him Wisdom and Intelligence more than (to) all the angels. And I called his name "the LESSER YAH", whose name is by Gematria 71. And I arranged for him all the works of Creation. And I made his power to transcend (lit. I made for him power more than) all the ministering angels. ALT 2 

[48c:3] He committed unto Metatron that is Enoch, the son of Jared all treasuries. And I appointed him over all the stores that I have in every heaven. And I committed into his hands the keys of each heavenly store. 

[48c:4] I made (of) him the prince over all the princes, and I made (of) him a minister of my Throne of Glory, to provide for and arrange the Holy Chayyoth, to wreathe crowns for them (to crown them with crowns), to clothe them with honour and majesty to prepare for them a seat when he is sitting on his throne to magnify his glory in the height. 

[48c:5] The height of his stature among all those (that are) of high stature (is) seventy thousand parasangs. And I made his glory great as the majesty of my glory. 

[48c:6] and the brilliance of his eyes as the splendour of the Throne of Glory. 

[48c:7] his garment honour and majesty, his royal crown 500 by 500 parasangs. ALT 3 

[48c:1] Aleph1 I made him strong, I took him, I appointed him: (namely) Metatron, my servant who is one (unique) among all the children of heaven. I made him strong in the generation of the first Adam. But when I beheld the men of the generation of the flood, that they were corrupt, then I went and removed my Shekina from among them. And 1 lifted it up on high with the sound of a trumpet and with a shout, as it is written (Ps.xlvii. 6): "God is gone up with a shout, the Lord with the sound of a trumpet". 

[48c:2] "And I took him": (that is) Enoch, the son of Jared, from among them. And I lifted him up with the sound of a trumpet and with a tera'a (shout) to the high heavens, to be my witness together with the Chayyoth by the Merkaba in the world to come. 

[48c:3] I appointed him over all the treasuries and stores that I have in every heaven. And I committed into his hand the keys of every several one. 

[48c:4] I made (of) him the prince over all the princes and a minister of the Throne of Glory (and) the Halls of 'Araboth: to open their doors to me, and (of) the Throne of Glory, to exalt an arrange it; (and I appointed him over) the Holy Chayyot to wreathe crowns upon their heads; the majestic 'Ophannim, to crown them with strength and glory; the; honoured Kerubim, to clothe: them in majesty; over the radiant sparks, to make them to shine with splendour and brilliance; over the flaming Seraphim, to cover them with highness; the Chashmallim of light, to make them radiant with Light and to prepare the seat for me every morning as I sit upon the Throne of Glory. And to extol and magnify my glory inthe height of my power; (and I have committed unto him) the secrets of above and the secrets of below (heavenly secrets and earthly secrets). 

[48c:5] I made him higher than all. The height of his stature, in the midst of all (who are) high of stature (I made) seventy thousand parasangs. I made his Throne great by the majesty of my Throne. And I increased its glory by the honour of my glory. 

[48c:6] I transformed his flesh into torches of fire, and all the bones of his body into fiery coals; and I made the appearance of his eyes as the lightning, and the light of his eyebrows as the imperishable light. I made his face bright as the splendour of the sun, and his eyes as the splendour of the Throne of Glory. 

[48c:7] I made honour and majesty his clothing, beauty and highness his covering cloak and a royal crown of 500 by (times) 500 parasangs (his) diadem. And I put upon him of my honour, my majesty and the splendour. of my glory that is upon my Throne of Glory. I called him the LESSER YHWH, the Prince of the Presence, the Knower of Secrets: for every secret did I reveal to him as a father and all mysteries declared I unto him in uprightness. 

[48c:8] I set up his throne at the door of my Hall that he may sit and judge the heavenly household on high. And I placed every prince before him, to receive authority from him, to perform his will. 

[48c:9] Seventy names did I take from (my) names and called him by them to enhance his glory. Seventy princes gave I into his hand, to command unto them my precepts and my words in every language: to abase by his word the proud to the ground, and to exalt by the utterance of his lips the humble to the height; to smite kings by his speech, to turn kings away from their paths, to set up(the) rulers over their dominion as it is written (Dan.ii. 21): "and he changeth the times and the seasons, and to give wisdom unto all the setwise of the world and understanding (and) knowledge to all who understand knowledge, as it is griten (Dan. ii. 21): " and knowledge to them that know understanding", to reveal to them the secrets of my words and to teach the decree of my righteous judgement, 

[48c:10] as it is written (Is.Iv. n): “so shall my word be that goeth forth out of my mouth; it shall not return unto me void but shall accomplish (that which I please)". ‘E'eseh’ (I shall accomplish) is not written here, but "asdh' (he shall accomplish), meaning, that whatever word and whatever utterance goes forth from before the Holy One, blessed be He, Metatron stands and carries it out. And he establishes the decrees of the Holy One, blessed be He. 



[48d:1] Seventy names has Metatron which the Holy One, blessed be He, took from his own name and put upon him. And these they are: YeHOEL, YaH, YeHOEL, YOPHIEL and Yophphiel, and 'APHPHIEL and MaRGeZIEL, GIPpUYEL, Pa'aZIEL, 'A'aH, PeRIEL, TaTRIEL, TaBKIEL,'W, YHWH, DH, WHYH, 'eBeD, DiBbURIEL, 'aPh'aPIEL, SPPIEL, PaSPaSIEL, SeNeGRON, MeTaTRON, SOGDIN, 'ADRIGON, ASUM, SaQPaM, SaQTaM, MIGON MITTON, MOTTRON, ROSPHIM, QINOTh, ChaTaTYaH, DeGaZYaH, PSPYaH, BSKNYH, MZRG, BaRaD.., MKRKK, MSPRD, ChShG, ChShB, MNRTTT, BSYRYM, MITMON, TITMON, PiSQON, SaPhSaPhYaH, ZRCh, ZRChYaH, B’, BeYaH, HBH BeYaH, PeLeT, PLTYaH, RaBRaBYaH, ChaS, ChaSYaH, TaPhTaPhYaH, TaMTaMYaH, SeHaSYaH, IRURYaH, 'aL'aLYaH, BaZRIDYaH, SaTSaTKYaH, SaSDYaH, RaZRaZYAH, BaZRaZYaH, 'aRIMYaH, SBHYaH, SBIBKHYH, SiMKaM, YaHSeYaH, SSBIBYaH, SaBKaSBeYaH, QeLILQaLYaH, fKIHHH, HHYH, WH, WHYH, ZaKklKYaH, TUTRISYaH, SURYaH, ZeH, PeNIRHYaH, Z1Z’H, GaL RaZaYYa, MaMLIKYaH, TTYaH, eMeQ, QaMYaH, MeKaPpeRYaH, PeRISHYaH, SePhaM, GBIR, GiBbORYaH, GOR, GORYaH, ZIW, 'OKBaR, the LESSER YHWH, after the name of his Master, (Ex. xxiii. 21) "for my name is in him", RaBIBIEL, TUMIEL, Segansakkiel ('Sagnezagiel' / 'Neganzegael), the Prince of Wisdom. 

[48d:2] And why is he called by the name Sagnesakiel? Because all the treasuries of wisdom are committed in his hand. 

[48d:3] And all of them were opened to Moses on Sinai, so that he learnt them during the forty days, while he was standing (remaining}: the Torah in the seventy aspects of the seventy tongues, the Prophets in the seventy aspects of the seventy tongues, the Writings in the seventy aspects of the seventy tongues, 'the Halakas in the seventy aspects of the seventy tongues, the Traditions in the seventy aspects of the seventy tongues, the Haggadas in the seventy aspects of the seventy tongues and the Toseftas in the seventy aspects of the seventy tongues'. 

[48d:4] But as soon as the forty days were ended, he forgot all of them in one moment. Then the Holy One, blessed be He, called Yephiphyah, the Prince of the Law, and (through him) they were given to Moses as a gift. As it is written (Deut. x. 4): "and the Lord gave them unto me". And after that it remained with him. And whence do we know, that it remained (in his memory) ? Because it is written (Mai. iv. 4): " Remember ye the Law of Moses my servant which I commanded unto him in Horeb for all Israel, even my statutes and judgements". The Law of Moses': that is the Tora, the Prophets and the Writings, 'statutes': that is the Halakas and Traditions, 'judgements'; that is the Haggadas and the Toseftas. And all of them were given to Moses on high on Sinai. 

[48d:5] These seventy names (are) a reflection of the Explicit Name(s) on the Merkaba which are graven upon the Throne of Glory. For the Holy One, blessed be He, took from His Explicit Name(s) and put upon the name of Metatron: Seventy Names of His by which the ministering angels call the King of the kings of kings, blessed be He, in the high heavens, and twenty-two letters that are on the ring upon his finger with which are sealed the destinies of the princes of kingdoms on high in greatness and power and with which are sealed the lots of the Angel of Death, and the destinies of every nation and tongue. 

[48d:6] Said Metatron, the Angel, the Prince of the Presence; the Angel, the Prince of the Wisdom; the Angel, the Prince of the Understanding; the Angel, the Prince of the Kings; the Angel, the Prince of the Rulers; the angel, the Prince of the Glory; the angel, the Prince of the high ones, and of the princes, the exalted, great and honoured ones, in heaven and on earth: 

[48d:7] "H, the God of Israel, is my witness in this thing, (that] when I revealed this secret to Moses, then all the hosts in every heaven on high raged against me and said to me: 

[48d:8] Why dost thou reveal this secret to son of man, born of woman, tainted and unclean, a man of a putrefying drop, the secret by which were created heaven and earth, the sea and the dry land, the mountains and hills, the rivers and springs, Gehenna of fire and hail, the Garden of Eden and the Tree of Life; and by which were formed Adam and Eve, and the cattle, and the wild beasts, and the fowl of the air, and the fish of the sea, and Behemoth and Leviathan, and the creeping things, the worms, the dragons of the sea, and the creeping things of the deserts; and the Tora and Wisdom and Knowledge and Thought and the Gnosis of things above and the fear of heaven. Why dost thou reveal this to flesh and blood? I answered them: Because the Holy One, blessed be He, has given me authority, And furthermore, I have obtained permission from the high and exalted Throne, from which all the Explicit Names go forth with lightnings of fire and flaming chashmallim. 

[48d:9] But they were not appeased, until the Holy One, blessed be He, rebuked them and drove them away with rebuke from before him, saying to them: "I delight in, and have set my love on, and have entrusted and committed unto Metatron, my Servant, alone, for he is One (unique) among all the children of heaven. 

[48d:10] And Metatron brought them out from his house of treasuries and committed them to Moses, and Moses to Joshua, and Joshua to the elders, and the elders to the prophets and the prophets to the men of the Great Synagogue, and the men of the Great Synagogue to Ezra and Ezra the Scribe to Hillel the elder, and Hillel the elder to R. Abbahu and R. Abbahu to R. Zera, and R. Zera to the men of faith, and the men of faith (committed them) to give warning and to heal by them all diseases that rage in the world, as it is written (Ex. xv. 26): "If thou wilt diligently hearken to the voice of the Lord, thy God, and wilt do that which is right in his eyes, and wilt give ear to his commandments, and keep all his statutes, I will put none of the diseases upon thee, which I have put upon the Egyptians: for I am the Lord, that healeth thee". (Ended and finished. Praise be unto the Creator of the World.)

