# 2 Adam and Eve



**[1:1]** When Luluwa heard Cain's words, she wept and went to call her father and mother, and told them how that Cain had killed his brother Abel.



**[1:2]** Then they all cried aloud and lifted up their voices, and slapped their faces, and threw dust upon their heads, and rent asunder their garments, and went out and came to the place where Abel was killed.



**[1:3]** And they found him lying on the earth, killed, and beasts around him; while they wept and cried because of this just one. From his body, by reason of its purity, went forth a smell of sweet spices.



**[1:4]** And Adam carried him, his tears streaming down his face; and went to the Cave of Treasures, where he laid him, and wound him up with sweet spices and myrrh.



**[1:5]** And Adam and Eve continued by the burial of him in great grief a hundred and forty days. Abel was fifteen and a half years old, and Cain seventeen years and a half.



**[1:6]** As for Cain, when the mourning for his brother was ended, he took his sister Luluwa and married her, without leave from his father and mother; for they could not keep him from her, by reason of their heavy heart.



**[1:7]** He then went down to the bottom of the mountain, away from the garden, near to the place where he had killed his brother.



**[1:8]** And in that place were many fruit trees and forest trees. His sister bare him children, who in their turn began to multiply by degrees until they filled that place.



**[1:9]** But as for Adam and Eve, they came not together after Abel's funeral, for seven years. After this, however, Eve conceived; and while she was with child, Adam said to her, "Come, let us take an offering and offer it up unto God, and ask Him to give us a fair child, in whom we may find comfort, and whom we may join in marriage to Abel's sister."



**[1:10]** Then they prepared an offering and brought it up to the altar, and offered it before the Lord, and began to entreat Him to accept their offering, and to give them a good offspring.



**[1:11]** And God heard Adam and accepted his offering. Then, they worshipped, Adam, Eve, and their daughter, and came down to the Cave of Treasures and placed a lamp in it, to burn by night and by day, before the body of Abel.



**[1:12]** Then Adam and Eve continued fasting and praying until Eve's time came that she should be delivered, when she said to Adam, "I wish to go to the cave in the rock, to bring forth in it."



**[1:13]** And he said, "Go, and take with thee thy daughter to wait on thee; but I will remain in this Cave of Treasures before the body of my son Abel."



**[1:14]** Then Eve hearkened to Adam, and went, she and her daughter. But Adam remained by himself in the Cave of Treasures.



**[2:1]** And Eve brought forth a son perfectly beautiful in figure and in countenance. His beauty was like that of his father Adam, yet more beautiful.



**[2:2]** Then Eve was comforted when she saw him, and remained eight days in the cave; then she sent her daughter unto Adam to tell him to come and see the child and name him. But the daughter stayed in his place by the body of her brother, until Adam returned. So did she.



**[2:3]** But when Adam came and saw the child's good looks, his beauty, and his perfect figure, he rejoiced over him, and was comforted for Abel. Then he named the child Seth, that means, "that God has heard my prayer, and has delivered me out of my affliction." But it means also "power and strength."



**[2:4]** Then after Adam had named the child, he returned to the Cave of Treasures; and his daughter went back to her mother.



**[2:5]** But Eve continued in her cave, until forty days were fulfilled, when she came to Adam, and brought with her the child and her daughter.



**[2:6]** And they came to a river of water, where Adam and his daughter washed themselves, b~ cause of their sorrow for Abel; but Eve and the babe washed for purification.



**[2:7]** Then they returned, and took an offering, and went to the mountain and offered it up, for the babe; and God accepted their offering, and sent His blessing upon them, and upon their son Seth; and they came back to the Cave of Treasures.



**[2:8]** As for Adam, he knew not again his wife Eve, all the days of his life; neither was any more offspring born of them; but only those five, Cain, Luluwa, Abel, Aklia, and Seth alone.



**[2:9]** But Seth waxed in stature and in strength; and began to fast and pray, fervently.



**[3:1]** As for our father Adam, at the end of seven years from the day he had been severed from his wife Eve, Satan envied him, when he saw him thus separated from her; and strove to make him live with her again.



**[3:2]** Then Adam arose and went up above the Cave of Treasures; and continued to sleep there night by night. But as soon as it was light every day he came down to the cave, to pray there and to receive a blessing from it.



**[3:3]** But when it was evening he went up on the roof of the cave, where he slept by himself, fearing lest Satan should overcome him. And he continued thus apart thirty-nine days.



**[3:4]** Then Satan, the hater of all good, when he saw Adam thus alone, fasting and praying, appeared unto him in the form of a beautiful woman, who came and stood before him in the night of the fortieth day, and said unto him:-



**[3:5]** "0 Adam, from the time ye have dwelt in this cave, we have experienced great peace from you, and your prayers have reached us, and we have been comforted about you.



**[3:6]** "But now, 0 Adam, that thou hast gone up over the roof of the cave to sleep, we have had doubts about thee, and a great sorrow has come upon us because of thy separation from Eve. Then again, when thou art on the roof of this cave, thy prayer is poured out, and thy heart wanders from side to side.



**[3:7]** "But when thou wast in the cave thy prayer was like fire gathered together; it came down to us, and thou didst find rest.



**[3:8]** "Then I also grieved over thy children who are severed from thee; and my sorrow is great about the murder of thy son Abel; for he was righteous; and over a righteous man every one will grieve.



**[3:9]** "But I rejoiced over the birth of thy son Seth; yet after a little while I sorrowed greatly over Eve, because she is my sister. For when God sent a deep sleep over thee, and drew her out of thy side, He brought me out also with her. But HE raised her by placing her with thee, while He lowered me.



**[3:10]** "I rejoiced over my sister for her being with thee. But God had made me a promise before, and said, 'Grieve not; when Adam has gone up on the roof of the Cave of Treasures, and is separated from Eve his wife, I will send thee to him, thou shalt join thyself to him in marriage, and bear him five children, as Eve did bear him five.'



**[3:11]** "And now, lo! God's promise to me is fulfilled; for it is He who has sent me to thee for the wedding; because if thou wed me, I shall bear thee finer and better children than those of Eve.



**[3:12]** "Then again, thou art as yet but a youth; end not thy youth in this world in sorrow; but spend the days of thy youth in mirth and pleasure. For thy days are few and thy trial is great. Be strong; end thy days in this world in rejoicing. I shall take pleasure in thee, and thou shall rejoice with me in this wise, and without fear.



**[3:13]** "Up, then, and fulfil the command of thy God," she then drew near to Adam, and embraced him.



**[3:14]** But when Adam saw that he should be overcome by her, he prayed to God with a fervent heart to deliver him from her.



**[3:15]** Then God sent His Word unto Adam, saying, "0 Adam, that figure is the one that promised thee the Godhead, and majesty; he is not favourably disposed towards thee; but shows himself to thee at one time in the form of a woman; another moment, in the likeness if an angel; on another occasions, in the similitude of a serpent; and at another time, in the semblance of a god; but he does all that only to destroy thy soul.



**[3:16]** "Now, therefore, 0 Adam, understanding thy heart, I have delivered thee many a time from his hands; in order to show thee that I am a merciful God; and that I wish thy good, and that I do not wish thy ruin."



**[4:1]** Then God ordered Satan to show himself to Adam plainly, in his own hideous form.



**[4:2]** But when Adam saw him, he feared, and trembled at the sight of him.



**[4:3]** And God said to Adam, 'Look at this devil, and at his hideous look, and know that he it is who made thee fall from brightness into darkness, from peace and rest to toil and misery.



**[4:4]** And look, 0 Adam, at him, who said of himself that he is God! Can God be black? Would God take the form of a woman? Is there any one stronger than God? And can He be overpowered?



**[4:5]** "See, then, 0 Adam, and behold him bound in thy presence, in the air, unable to flee away! Therefore, I say unto thee, be not afraid of him; henceforth take care, and beware of him, in whatever he may do to thee."



**[4:6]** Then God drove Satan away from before Adam, whom He strengthened, and whose heart He comforted, saying to him, "Go down to the Cave of Treasures, and separate not thyself from Eve; I will quell in you all animal lust."



**[4:7]** From that hour it left Adam and Eve, and they enjoyed rest by the commandment of God. But God did not the like to any one of Adam's seed; but only to Adam and Eve.



**[4:8]** Then Adam worshipped before the Lord, for having delivered him, and for having layed his passions. And he came down from above the cave, and dwelt with Eve as aforetime.



**[4:9]** This ended the forty days of his separation from Eve.



**[5:1]** As for Seth, when he was seven years old, he knew good and evil, and was consistent in fasting and praying, and spent all his nights in entreating God for mercy and forgiveness.



**[5:2]** He also fasted when bringing up his offering every day, more than his father did; for he was of a fair countenance, like unto an angel of God. He also had a good heart, preserved the finest qualities of his soul; and for this reason he brought up his offering every day.



**[5:3]** And God was pleased with his offering; but He was also pleased with his purity. And he continued thus in doing the will of God, and of his father and mother, until he was seven years old.



**[5:4]** After that, as he was corning down from the altar, having ended his offering, Satan appeared unto him in the form of a beautiful angel, brilliant with light; with a staff of light in his hand, himself girt about with a girdle of light.



**[5:5]** He greeted Seth with a beautiful smile, and began to beguile him with fair words, saying to him, "0 Seth, why abidest thou in this mountain? For it is rough, full of stones and of sand, and of trees with no good fruit on them; a wilderness without habitations and without towns; no good place to dwell in. But all is heat, weariness, and trouble."



**[5:6]** He said further, 'But we dwell in beautiful places, in another world than this earth. Our world is one of light and our condition is of the best; our women are handsomer than any others; and I wish thee, 0 Seth, to wed one of them; because I see that thou art fair to look upon, and in this land there is not one woman good enough for thee. Besides, all those who live in this world, are only five souls.



**[5:7]** "But in our world there are very many men and many maidens, all more beautiful one than another. I wish, therefore, to remove thee hence, that thou mayest see my relations and be wedded to which ever thou likest.



**[5:8]** "Thou shalt then abide by me and be at peace; thou shalt be filled with splendour and light, as we are.



**[5:9]** "Thou shalt remain in our world. and rest from this world and the misery of it; thou shalt never again feel faint and weary; thou shalt never bring up an offering, nor sue for mercy; for thou shalt commit no more sin nor be swayed by passions.



**[5:10]** "And if thou wilt hearken to what I say, thou shalt wed one of my daughters; for with us it is no sin so to do; neither is it reckoned animal lust.



**[5:11]** "For in our world we have no God; but we all are gods; we all are of the light, heavenly, powerful, strong and glorious."



**[6:1]** When Seth heard these words he was amazed, and inclined his heart to Satan's treacherous speech, and said to him, "Saidst thou there is an-other world created than this; and other creatures more beautiful than the creatures that are in this world?"



**[6:2]** And Satan said "Yes; behold thou hast heard me; but I will yet praise them and their ways, in thy hearing."



**[6:3]** But Seth said to him, "Thy speech has amazed me; and thy beautiful description of it all."



**[6:4]** "Yet I cannot go with thee to-day; not until I have gone to my father Adam and to my mother Eve, and told them all thou hast said to me. Then if they give me leave to go with thee, I will come."



**[6:5]** Again Seth said, "I am afraid of doing any thing without my father's and mother's leave, lest I perish like my brother Cain, and like my father Adam, who transgressed the commandment of God. But, behold, thou knowest this place; come, and meet me here to-morrow."



**[6:6]** When Satan heard this, he said to Seth, "If thou tellest thy father Adam what I have told thee, he will not let thee come with me.



**[6:7]** But hearken to me; do not tell thy father and mother what I have said to thee; but come with me to-day, to our world; where thou shalt see beautiful things and enjoy thyself there, and revel this day among my children, beholding them and taking thy fill of mirth; and rejoice ever more. Then I shall bring thee back to this place to-morrow; but if thou wouldest rather abide with me, so be it."



**[6:8]** Then Seth answered, "The spirit of my father and of my mother, hangs on me; and if I hide from them one day, they will die, and God will hold me guilty of sinning against them.



**[6:9]** "And except that they know I am come to this place to bring up to it my offering, they would not be separated from me one hour; neither should I go to any other place, unless they let me. But they treat me most kindly, because I come back to them quickly."



**[6:10]** Then Satan said to him, "What will happen to thee if thou hide thyself from them one night, and return to them at break of day?"



**[6:11]** But Seth, when he saw how he kept on talking, and that he would not leave him-ran, and went up to the altar, and spread his hands unto God, and sought deliverance from Him.



**[6:12]** Then God sent His Word, and cursed Satan, who fled from Him.



**[6:13]** But as for Seth, he had gone up to the altar, saying thus in his heart. "The altar is the place of offering, and God is there; a divine fire shall consume it; so shall Satan be unable to hurt me, and shall not take me away thence."



**[6:14]** Then Seth came down from the altar and went to his father and mother, whom he found in the way, longing to hear his voice; for he had tarried a while.



**[6:15]** He then began to tell them what had befallen him from Satan, under the form of an angel.



**[6:16]** But when Adam heard his account, he kissed his face, and warned him against that angel, telling him it was Satan who thus appeared to him. Then Adam took Seth, and they went to the Cave of Treasures, and rejoiced therein.



**[6:17]** But from that day forth Adam and Eve never parted from him, to whatever place he might go, whether for his offering or for any thing else.



**[6:18]** This sign happened to Seth, when he was nine years old.



**[7:1]** When our father Adam saw that Seth was of a perfect heart, he wished him to marry; lest the enemy should appear to him another time, and overcome him.



**[7:2]** So Adam said to his son Seth, "I wish, 0 my son, that thou wed thy sister Aklia, Abel's sister, that she may bear thee children, who shall replenish the earth, according to God's promise to us.



**[7:3]** "Be not afraid, 0 my son; there is no disgrace in it. I wish thee to marry, from fear lest the enemy overcome thee.'



**[7:4]** Seth, however, did not wish to marry; but in obedience to his father and mother, he said not a word.



**[7:5]** So Adam married him to Aklia. And he was fifteen years old.



**[7:6]** But when he was twenty years of age, he begat a son, whom he called Enos; and then begat other children than him,



**[7:7]** Then Enos grew up, married, and begat Cainan.



**[7:8]** Cainan also grew up, married, and begat Mahalaleel.



**[7:9]** Those fathers were born during Adam's lifetime, and dwelt by the Cave of Treasures.



**[7:10]** Then were the days of Adam nine hundred and thirty years, and those of Mahalaleel one hundred. But Mahalaleel, when he was grown up, loved fasting, praying, and with hard labours, until the end of our father Adam's days drew near.



**[8:1]** When our father Adam saw that his end was near, he called his son Seth, who came to him in the Cave of Treasures,



**[8:1]** And he said unto him: -



**[8:2]** "0 Seth, my son bring me thy children and thy children's children, that I may shed my blessing on them ere I die."



**[8:3]** When Seth heard these words from his father Adam, he went from him, shed a flood of tears over his face, and gathered together his children and his children's children, and brought them to his father Adam.



**[8:4]** But when our father Adam saw them around him, he wept at having to be separated from them.



**[8:5]** And when they saw him weeping, they all wept together, and fell upon his face saying, "How shalt thou be severed from us, 0 our father? And how shall the earth receive thee and hide thee from our eyes?" Thus did they lament much, and in like words.



**[8:6]** Then our father Adam blessed them all, and said to Seth, after he had blessed them:-



**[8:7]** "0 Seth, my son, thou knowest this world - that it is full of sorrow, and of weariness; and thou knowest all that has come upon us, from our trials in it I therefore flow command thee in these words: to keep innocency, to be pure and just, and trusting in God; and lean not to the discourses of Satan, nor to the apparitions in which he will show himself to thee.



**[8:8]** But keep the commandments that I give thee this day; then give the same to thy son Enos; and let Enos give it to his son Cainan; and Cainan to his son Mahalaleel; so that this commandment abide firm among all your children.



**[8:9]** "0 Seth, my son, the moment I am dead take ye my body and wind it up with myrrh, aloes, and cassia, and leave me here in this Cave of Treasures in which are all these tokens which God gave us from the garden.



**[8:10]** "0 my son, hereafter shall a flood come and overwhelm all creatures, and leave out only eight souls.



**[8:11]** "But, 0 my son, let those whom it will leave out from among your children at that time, take my body with them out of this cave; and when they have taken it with them, let the oldest among them command his children to lay my body in a ship until the flood has been assuaged, and they come out of the ship.



**[8:12]** Then they shall take my body and lay it in the middle of the earth, shortly after they have been saved from the waters of the flood.



**[8:13]** "For the place where my body shall be laid, is the middle of the earth; God shall come from thence and shall save all our kindred.



**[8:14]** "But now, 0 Seth, my son, place thyself at the head of thy people; tend them and watch over them in the fear of God; and lead them in the good way. Command them to fast unto God; and make them understand they ought not to hearken to Satan, lest he destroy them.



**[8:15]** "Then, again, sever thy children and thy children's children from Cain's children; do not let them ever mix with those, nor come near them either in their words or in their deeds."



**[8:16]** Then Adam let his blessing descend upon Seth, and upon his children, and upon all his children's children.



**[8:17]** He then turned to his son Seth, and to Eve his wife, and ,said to them, "Preserve this gold, this incense, and this myrrh, that God has given us for a sign; for in days that are coming, a flood will overwhelm the whole creation. But those who shall go into the ark shall take with them the gold, the incense, and the myrrh, together with my body; and will lay the gold, the incense, and the myrrh, with my body in the midst of the earth.



**[8:18]** "Then, after a long time, the city in which the gold, the incense, and the myrrh are found with my body, shall be plundered. But when it is spoiled, the gold the incense, and the myrrh shall be taken care of with the spoil that is kept; and naught of them shall perish, until the Word of God, made man shall come; when kings shall take them, and shall offer to Him, gold in token of His being King; incense, in token of His being God of heaven and earth; and myrrh, in token of His passion.



**[8:19]** "Gold also, as a token of His overcoming Satan, and all our foes; incense as a token that He will rise from the dead, and be exalted above things in heaven and things in the earth; and myrrh, in token that He will drink bitter gall; and feel the pains of hell from Satan.



**[8:20]** "And now, 0 Seth, my son, behold I have revealed unto thee hidden mysteries, which God had revealed unto me. Keep my commandment, for thyself, and for thy people."



**[9:1]** When Adam had ended his commandment to Seth, his limbs were loosened, his hands and feet lost all power, his mouth became dumb, and his tongue ceased altogether to speak. He closed his eyes and gave up the ghost.



**[9:2]** But when his children saw that he was dead, they threw themselves over him, men and women, old and young, weeping.



**[9:3]** The death of Adam took place at the end of nine hundred and thirty years that he lived upon the earth; on the fifteenth day of Barmudeh, after the reckoning of an epact of the sun, at the ninth hour.



**[9:4]** It was on a Friday, the very day on which he was created, and on which he rested; and the hour at which he died, was the same as that at which he came out of the garden.



**[9:5]** Then Seth wound him up well, and embalmed him with plenty of sweet spices, from sacred trees and from the Holy Mountain; and he laid his body on the eastern side of the inside of the cave, the side of the incense; and placed in front of him a lamp - stand kept burning.



**[9:6]** Then his children stood before him weeping and wailing over him the whole night until break of day.



**[9:7]** Then Seth and his son Enos, and Cainan, the son of Enos, went out and took good offerings to present unto the Lord, and they came to the altar upon which Adam offered gifts to God, when he did offer.



**[9:8]** But Eve said to them, "Wait until we have first asked God to accept our offering, and to keep by Him the soul of Adam His servant, and to take it up to rest."



**[9:9]** And they all stood up and prayed.



**[10:1]** And when they had ended their prayer, the Word of God came and comforted them concerning their father Adam.



**[10:2]** After this, they offered their gifts for themselves and for their father.



**[10:3]** And when they had ended their offering, the Word of God came to Seth, the eldest among them, saying unto him, "0 Seth, Seth, Seth, three times. As I was with thy father, so also shall I be with thee, until the fulfilment of the promise I made him - thy father saying, I will send My Word and save thee and thy seed.



**[10:4]** "But as to thy father Adam, keep thou the commandment he gave thee; and sever thy seed from that of Cain thy brother."



**[10:5]** And God withdrew His Word from Seth.



**[10:6]** Then Seth, Eve, and their children, came down from the mountain to the Cave of Treasures.



**[10:7]** But Adam was the first whose soul died in the land of Eden, in the Cave of Treasures; for no one died before him, but his son Abel, who died murdered.



**[10:8]** Then all the children of Adam rose up, and wept over their father Adam, and made offerings to him, one hundred and forty days.



**[11:1]** After the death of Adam and of Eve, Seth severed his children, and his children's children, from Cain's children. Cain and his seed went down and dwelt westward, below the place where he had killed his brother Abel.



**[11:2]** But Seth and his children, dwelt northwards upon the mountain of the Cave of Treasures, in order to be near to their father Adam.



**[11:3]** And Seth the elder, tall and good, with a fine soul, and of a strong mind, stood at the head of his people; and tended them in innocence, penitence, and meekness, and did not allow one of them to go down to Cain's children.



**[11:4]** But because of their own purity, they were named "Children of God," and they were with God, instead of the hosts of angels who fell; for they continued in praises to God, and in singing psalms unto Him, in their cave - the Cave of Treasures.



**[11:5]** Then Seth stood before the body of his father Adam, and of his mother Eve, and prayed night and day, and asked for mercy towards himself and his children; and that when he had some difficult dealing with a child, He would give him counsel.



**[11:6]** But Seth and his children did not like earthly work, but gave themselves to heavenly things; for they had no other thought than praises, doxologies, and psalms unto God.



**[11:7]** Therefore did they at all times hear the voices of angels, praising and glorifying God; from within the garden, or when they were sent by God on an errand, or when they were going up to heaven.



**[11:8]** For Seth and his children, by reason of their own purity, heard and saw those angels. Then, again, the garden was not far above them, but only some fifteen spiritual cubits.



**[11:9]** Now one spiritual cubit answers to three cubits of man, altogether forty-five cubits.



**[11:10]** Seth and his children dwelt on the mountain below the garden; they sowed not, neither did they reap; they wrought no food for the body. not even wheat; but only offerings. They ate of the fruit and of trees well flavoured that grew on the mountain where they dwelt.



**[11:11]** Then Seth often fasted every forty days, as did also his eldest children. For the family of Seth smelled the smell of the trees in the garden, when the wind blew that way.



**[11:12]** They were happy, innocent, without sudden fear, there was no jealousy, no evil action, no hatred among them. There was no animal passion; from no mouth among them went forth either foul words or curse; neither evil counsel nor fraud. For the men of that time never swore, but under hard circumstances, when men must swear, they swore by the blood of Abel the just.



**[11:13]** But they constrained their children and their women every day in the cave to fast and pray, and to worship the most High God. They blessed themselves in the body of their father Adam, and anointed themselves with it.



**[11:14]** And they did so until the end of Seth drew near.



**[12:1]** Then Seth, the just, called his son Enos, and Cainan, son of Enos, and Mahalaleel, son of Cainan, and said unto them:-



**[12:2]** "As my end is near, I wish to build a roof over the altar on which gifts are offered."



**[12:3]** They hearkened to his commandment and went out, all of them, both old and young, and worked hard at it, and built a beautiful roof over the altar.



**[12:4]** And Seth's thought, in so doing, was that a blessing should come upon his children on the mountain; and that he should present an offering for them before his death.



**[12:5]** Then when the building of the roof was completed, he commanded them to make offerings. They worked diligently at these, and brought them to Seth their father who took them and offered them upon the altar; and prayed God to accept their offerings, to have mercy on the souls of his children, and to keep them from the hand of Satan.



**[12:6]** And God accepted his offering, and sent His blessing upon him and upon his children. And then God made a promise to Seth, saying, "At the end of the great five days and a half, concerning which I have made a promise to thee and to thy father, I will send My Word and save thee and thy seed."



**[12:7]** Then Seth and his children, and his children's children, met together, and came down from the altar, and went to the Cave of Treasures - where they prayed, and blessed themselves in the body of our father Adam, and anointed themselves with it.



**[12:8]** But Seth abode in the Cave of Treasures, a few days, and then suffered - sufferings unto death.



**[12:9]** Then Enos, his first - born son, came to him, with Cainan, his son, and Mahalaleel, Cainan's son, and Jared, the son of Mahalaleel, and Enoch, Jared's son, with their wives and children to receive a blessing from Seth.



**[12:10]** Then Seth prayed over them, and blessed them, and adjured them by the blood of Abel the just, saying, "I beg of you my children, not to let one of you go down from this Holy and pure Mountain.



**[12:11]** Make no fellowship with the children of Cain the murderer and the sinner, who killed his brother; for ye know, 0 my children, that we flee from him, and from all his sin with all our might because he killed his brother Abel."



**[12:12]** After having said this, Seth blessed Enos, his first - born son, and commanded him habitually to minister in purity before the body of our father Adam, all the days of his life; then, also, to go at times to the altar which he Seth had built. And he commanded him to feed his people in righteousness, in judgment and purity all the days of his life.



**[12:13]** Then the limbs of Seth were loosened; his hands and feet lost all power; his mouth became dumb and unable to speak; and he gave up the ghost and died the day after his nine hundred and twelfth year; on the twenty - seventh day of the month Abib; Enoch being then twenty years old.



**[12:14]** Then they wound up carefull the body of Seth, and embalmed him with sweet spices, and laid him in the Cave Treasures, on the right side of our father Adam's body, and they mourned for him forty days. They offered gifts for him, as they had done for our father Adam.



**[12:15]** After the death of Seth, Enos rose at the head of his people, whom he fed in righteousness, and judgment, as his father had commanded him.



**[12:16]** But by the time Enos was eight hundred and twenty years old, Cain had a large progeny; for they married frequently, being given to animal lusts; until the land below the mountain, was filled with them.



**[13:1]** In those days lived Lamech the blind, who was of the sons of Cain. He had a son whose name was Atun, and they two had much cattle.



**[13:2]** But Lamech was in the habit of sending them to feed with a young shepherd, who tended them; and who, when coming home in the evening wept before his grandfather, and before his father Atun and his mother Hazina, and said to them, "As for me, I cannot feed those cattle alone, lest one rob me of some of them, or kill me for the sake of them." For among the children of Cain, there was much robbery, murder and sin.



**[13:3]** Then Lamech pitied him, and he said, "Truly, he when alone, might be overpowered by the men of this place."



**[13:4]** So Lamech arose, took a bow he had kept ever since he was a youth, ere he became blind, and he took large arrows, and smooth stones, and a sling which he had, and went to the field with the young shepherd, and placed himself behind the cattle; while the young shepherd watched the cattle. Thus did Lamech many days.



**[13:5]** Meanwhile Cain, ever since God had cast him off, and had cursed him with trembling and terror, could neither settle nor find rest in any one place; but wandered from place to place.



**[13:6]** In his wanderings he came to Lamech's wives, and asked them about him. They said to him, "He is in the field with the cattle."



**[13:7]** Then Cain went to look for him; and as he came into the field, the young shepherd heard the noise he made, and the cattle herding together from before him,



**[13:8]** Then said he to Lamech, "0 my lord, is that a wild beast or a robber?"



**[13:9]** And Lamech said to him, "Make me understand which way he looks, when he comes up.



**[13:10]** Then Lamech bent his bow, placed an arrow on it, and fitted a stone in the sling, and when Cain came out from the open country, the shepherd said to Lamech, "Shoot, behold, he is coming."



**[13:11]** Then Lamech shot at Cain with his arrow and hit him in his side. And Lamech struck him with a stone from his sling, that fell upon his face, and knocked out both his eyes; then Cain fell at once and died.



**[13:12]** Then Lamech and the young shepherd came up to him, and found him lying on the ground. And the young shepherd said to him, "It is Cain our grandfather, whom thou hast killed, 0 my lord!"



**[13:18]** Then was Lamech sorry for it, and from the bitterness of his regret, he clapped his hands together, and struck with his flat palm the head of the youth, who fell as if dead; but Lamech thought it was a feint; so he took up a stone and smote him, and smashed his head until he died.



**[14:1]** When Enos was nine hundred years old, all the children of Seth, and of Cainan, and his first-born, with their wives and children, gathered around him, asking for a blessing from him.



**[14:2]** He then prayed over them and blessed them, and adjured them by the blood of Abel the just saying to them, "Let not one of your children go down from this Holy Mountain, and let them make no fellowship with the children of Cain the murderer."



**[14:3]** Then Enos called his son Cainan and said to him, "See, 0 my son, and set thy heart on thy people, and establish them in righteousness, and in innocence; and stand ministering before the body of our father Adam, all the days of thy life."



**[14:4]** After this Enos entered into rest, aged nine hundred and eighty - five years; and Cainan wound him up, and laid him in the Cave of Treasures on the left of his father Adam; and made offerings for him, after the custom of his fathers.



**[15:1]** After the death of Enos, Cainan stood at the head of his people in righteousness and innocence, as his father had commanded him; he also continued to minister before the body of Adam, inside the Cave of Treasures.



**[15:2]** Then when he had lived nine hundred and ten years, suffering and affliction came upon him. And when he was about to enter into rest, all the fathers with their wives and children came to him, and he blessed them, and adjured them by the blood of Abel, the just, saying to them, "Let not one among you go down from this Holy Mountain; and make no fellowship with the children of Cain the murderer."



**[15:3]** Mahalaleel, his first - born son, received this commandment from his father, who blessed him and died.



**[15:4]** Then Mahalaleel embalmed him with sweet spices, and laid him in the Cave of Treasures, with his fathers; and they made offerings for him, after the custom of their fathers.



**[16:1]** Then Mahalaleel stood over his people, and fed them in righteousness and innocence, and watched them to see they held no intercourse with the children of Cain.



**[16:2]** He also continued in the Cave of Treasures praying and ministering before the body of our father Adam, asking God for mercy on himself and on his people; until he was eight hundred and seventy years old, when he fell sick.



**[16:3]** Then all his children gathered unto him, to see him, and to ask for his blessing on them all, ere he left this world.



**[16:4]** Then Mahalaleel arose and sat on his bed, his tears streaming down his face, and he called his eldest son Jared, who came to him.



**[16:5]** He then kissed his face, and said to him, "0 Jared, my son, I adjure thee by Him who made heaven and earth, to watch over thy people, and to feed them in righteousness and in innocence; and not to let one of them go down from this Holy Mountain to the children of Cain, lest he perish with them.



**[16:6]** "Hear, 0 my son, hereafter there shall come a great destruction upon this earth on account of them; God will be angry with the world, and will destroy them with waters.



**[16:7]** "But I also know that thy children will not hearken to thee, and that they will go down from this mountain and hold intercourse with the children of Cain, and that they shall perish with them.



**[16:8]** "0 my son! teach them, and watch over them, that no guilt attach to thee on their account."



**[16:9]** Mahalaleel said, moreover, to his son Jared, "When I die, embalm my body and lay it in the Cave of Treasures, by the bodies of my fathers; then stand thou by my body and pray to God; and take care of them, and fulfil thy ministry before them, until thou enterest into rest thyself."



**[16:10]** Mahalaleel then blessed all his children; and then lay down on his bed, and entered into rest like his fathers.



**[16:11]** But when Jared saw that his father Mahalaleel was dead, he wept, and sorrowed, and embraced and kissed his hands and his feet; and so did all his children.



**[16:12]** And his children embalmed him carefully, and laid him by the bodies of his fathers. Then they arose, and mourned for him forty days.



**[17:1]** Then Jared kept his father's commandment, and arose like a lion over his people. He fed them in righteousness and innocence, and commanded them to do nothing without his counsel. For he was afraid concerning them, lest they should go to the children of Cain.



**[17:2]** Wherefore did he give them orders repeatedly; and continued to do so until the end of the four hundred and eighty-fifth year of his life.



**[17:3]** At the end of these said years, there came unto him this sign. As Jared was standing like a lion before the bodies of his fathers, praying and warning his people, Satan envied him, and wrought a beautiful apparition, because Jared would not let his children do aught without his counsel.



**[17:4]** Satan then appeared to him with thirty men of his hosts, in the form of handsome men; Satan himself being the elder and tallest among them, with a fine beard.



**[17:5]** They stood at the mouth of the cave, and called out Jared, from within it.



**[17:6]** He came out to them, and found them looking like fine men, full of light, and of great beauty. He wondered at their beauty and at their looks; and thought within himself whether they might not be of the children of Cain.



**[17:7]** He said also in his heart, "As the children of Cain cannot come up to the height of this mountain, and none of them is so handsome as these appear to be; and among these men there is not one of my kindred - they must be strangers."



**[17:8]** Then Jared and they exchanged a greeting and he said to the elder among them, "0 my father, explain to me the wonder that is in thee, and tell me who these are, with thee; for they look to me like strange men."



**[17:9]** Then the elder began to weep, and the rest wept with him; and he said to Jared, "I am Adam whom God made first; and this is Abel my son, who was killed by his brother Cain, into whose heart Satan put to murder him.



**[17:10]** "Then this is my son Seth, whom I asked of the Lord, who gave him to me, to comfort me instead of Abel.



**[17:11]** "Then this one is my son Enos, son of Seth, and that other one is Cainan, son of Enos, and that other one is Mahalaleel, son of Cainan, thy father."



**[17:12]** But Jared remained wondering at their appearance, and at the speech of the elder to him.



**[17:13]** Then the elder said to him, "Marvel not, 0 my son; we live in the land north of the garden, which God created before the world. He would not let us live there, but placed us inside the garden, below which ye are now dwelling.



**[17:14]** "But after that I transgressed, He made me come out of it, and I was left to dwell in this cave; great and sore troubles came upon me; and when my death drew near, I commanded my son Seth to tend his people well; and this my commandment is to be handed from one to another, unto the end of the generations to come.



**[17:15]** "But, 0 Jared, my son, we live in beautiful regions, while you live here in misery, as this thy father Mahalaleel informed me; telling me that a great flood will come and overwhelm the whole earth.



**[17:16]** "Therefore, 0 my son, fearing for your sakes, I rose and took my children with me, and came hither for us to visit thee and thy children; but I found thee standing in this cave weeping, and thy children scattered about this mountain, in the heat and in misery.



**[17:17]** "But, 0 my son, as we missed our way, and came as far as this, we found other men below this mountain; who inhabit a beautiful country, full of trees and of fruits, and of all manner of verdure; it is like a garden; so that when we found them we thought they were you; until thy father Mahalaleel told me they were no such thing.



**[17:18]** "Now, therefore, 0 my son, hearken to my counsel, and go down to them, thou and thy children. Ye will rest from all this suffering in which ye are. But if thou wilt not go down to them, then, arise, take thy children, and come with us to our garden; ye shall live in our beautiful land, and ye shall rest from all this trouble, which thou and thy children are now bearing."



**[17:19]** But Jared when he heard this discourse from the elder, wondered; and went hither and thither, but at that moment he found not one of his children.



**[17:20]** Then he answered and said to the elder, "Why have you hidden yourselves until this day?"



**[17:21]** And the elder replied, "If thy father had not told us, we should not have known it."



**[17:22]** Then Jared believed his words were true.



**[17:23]** So that elder said to Jared, "Wherefore didst thou turn about, so and so?" And he said, "I was seeking one of my children, to tell him about my going with you, and about their coming down to those about whom thou hast spoken to me."



**[17:24]** When the elder heard Jared's intention, he said to him, "Let alone that purpose at present, and come with us; thou shalt see our country; if the land in which we dwell pleases thee, we and thou shall return hither and take thy family with us. But if our country does not please thee, thou shalt come back to thine own place."



**[17:25]** And the elder urged Jared, to go before one of his children came to counsel him otherwise.



**[17:26]** Jared, then, came out of the cave and went with them, and among them. And they comforted him, until they came to the top of the mountain of the sons of Cain.



**[17:27]** Then said the elder to one of his companions, "We have forgotten something by the mouth of the cave, and that is the chosen garment we had brought to clothe Jared withal."



**[17:28]** He then said to one of them, "Go back, thou, some one; and we will wait for thee here, until thou come back. Then will we clothe Jared and he shall be like us, good, handsome, and fit to come with us into our country."



**[17:29]** Then that one went back.



**[17:30]** But when he was a short distance off, the elder called to him and said to him, "Tarry thou, until I come up and speak to thee."



**[17:31]** Then he stood still, and the elder went up to him and said to him, "One thing we forgot at the cave, it is this - to put out the lamp that burns inside it, above the bodies that are therein. Then come back to us, quick."



**[17:32]** That one went, and the elder came back to his fellows and to Jared. And they came down from the mountain, and Jared with them; and they stayed by a fountain of water, near the houses of the children of Cain and waited for their companion until he brought the garment for Jared.



**[17:33]** He, then, who went back to the cave, put out the lamp, and came to them and brought a phantom with him and showed it them. And when Jared saw it he wondered at the beauty and grace thereof, and rejoiced in his heart believing it was all true.



**[17:34]** But while they were staying there, three of them went into houses of the sons of Cain and said to them, "Bring us to - day some food by the fountain of water, for us and our companions to eat."



**[17:35]** But when the sons of Cain saw them, they wondered at them and thought: "These are beautiful to look at, and such as we never saw before." So they rose and came with them to the fountain of water, to see their companions.



**[17:36]** They found them so very handsome, that they cried aloud about their places for others to gather together and come and look at these beautiful beings. Then they gathered around them both men and women.



**[17:37]** Then the elder said to them, "We are strangers in your land, bring us some good food and drink, you and your women, to refresh ourselves with you."



**[17:38]** When those men heard these words of the elder, every one of Cain's sons brought his wife, and another brought his daughter, and so, many women came to them; every one addressing Jared either for himself or for his wife; all alike.



**[17:39]** But when Jared saw what they did, his very soul wrenched itself from them; neither would he taste of their food or of their drink.



**[17:40]** The elder saw him as he wrenched himself from them, and said to him, "Be not sad; I am the great elder, as thou shalt see me do, do thyself in like manner."



**[17:41]** Then he spread his hands and took one of the women, and five of his companions did the same before Jared, that he should do as they did.



**[17:42]** But when Jared saw them working infamy he wept, and said in his mind, - My fathers never did the like.



**[17:43]** He then spread his hands and prayed with a fervent heart, and with much weeping, and entreated God to deliver him from their hands.



**[17:44]** No sooner did Jared begin to pray than the elder fled with his companions; for they could not abide in a place of prayer.



**[17:45]** Then Jared turned round but could not see them, but found himself standing in the midst of the children of Cain.



**[17:46]** He then wept and said, "0 God, destroy me not with this race, concerning which my fathers have warned me; for now, 0 my Lord God, I was thinking that those who appeared unto me were my fathers; but I have found them out to be devils, who allured me by this beautiful apparition, until I believed them.



**[17:47]** "But now I ask Thee, 0 God, to deliver me from this race, among whom I am now staying, as Thou didst deliver me from those devils. Send Thy angel to draw me out of the midst of them; for I have not myself power to escape from among them."



**[17:48]** When Jared had ended his prayer, God sent His angel in the midst of them, who took Jared and set him upon the mountain, and showed him the way, gave him counsel, and then departed from him.



**[18:1]** The children of Jared were in the habit of visiting him hour after hour, to receive his blessing and to ask his advice for every thing they did; and when he had a work to do, they did it for him.



**[18:2]** But this time when they went into the cave they found not Jared, but they found the lamp put out, and the bodies of the fathers thrown about, and voices came from them by the power of God, that said, "Satan in an apparition has deceived our son, wishing to destroy him, as he destroyed our son Cain."



**[18:3]** They said also, "Lord God of heaven and earth, deliver our son from the hand of Satan, who wrought a great and false apparition before him." They also spake of other matters, by the power of God.



**[18:4]** But when the children of Jared heard these voices they feared, and stood weeping for their father; for they knew not what had befallen him.



**[18:5]** And they wept for him that day until the setting of the sun.



**[18:6]** Then came Jared with a woeful countenance, wretched in mind and body, and sorrowful at having been separated from the bodies of his fathers.



**[18:7]** But as he was drawing near to the cave, his children saw him, and hastened to the cave, and hung upon his neck, crying, and saying to him, "0 father, where hast thou been, and why hast thou left us, as thou wast not wont to do?" And again, "0 father, when thou didst disappear, the lamp over the bodies of our fathers went out, the bodies were thrown about, and voices came from them"



**[18:8]** When Jared heard this he was sorry, and went into the cave; and there found the bodies thrown about, the lamp put out, and the fathers themselves praying for his deliverance from the hand of Satan.



**[18:9]** Then Jared fell upon the bodies and embraced them, and said, "0 my fathers, through your intercession, let God deliver me from the hand of Satan! And I beg you will ask God to keep me and to hide me from him unto the day of my death."



**[18:10]** Then all the voices ceased save the voice of our father Adam, who spake to Jared by the power of God, just as one would speak to his fellow, saying, "0 Jared, my son, offer gifts to God for having delivered thee from the hand of Satan; and when thou bringest those offerings, so be it that thou offerest them on the altar on which I did offer. Then also, beware of Satan; for he deluded me many a time with his apparitions, wishing to destroy me, but God delivered me out of his hand.



**[18:11]** "Command thy people that they be on their guard against him; and never cease to offer up gifts to God."



**[18:12]** Then the voice of Adam also became silent; and Jared and his children wondered at this. Then they laid the bodies as they were at first; and Jared and his children stood praying the whole of that night, until break of day.



**[18:13]** Then Jared made an offering and offered it up on the altar, as Adam had commanded him. And as he went up to the altar, he prayed to God for mercy and for forgiveness of his sin, concerning the lamp going out.



**[18:14]** Then God appeared unto Jared on the altar and blessed him and his children, and accepted their offerings; and commanded Jared to take of the sacred fire from the altar, and with it to light the lamp that shed light on the body of Adam.



**[19:1]** Then God revealed to him again the promise He had made to Adam; He explained to him the 5500 years, and revealed unto him the mystery of His coming upon the earth.



**[19:2]** And God said to Jared, "As to that fire which thou hast taken from the altar to light the lamp withal, let it abide with you to give light to the bodies; and let it not come out of the cave, until the body of Adam comes out of it.



**[19:3]** But, 0 Jared, take care of the fire, that it burn bright in the lamp; neither go thou again out of the cave until thou receivest an order through a vision, and not in an apparition, when seen by thee.



**[19:4]** "Then command again thy people not to hold intercourse with the children of Cain, and not to learn their ways; for I am God who loves not hatred and works of iniquity."



**[19:5]** God gave also many other commandments to Jared, and blessed him. And then withdrew His Word from him.



**[19:6]** Then Jared drew near with his children, took some fire, and came down to the cave, and lighted the lamp before the body of Adam; and he gave his people commandments as God had told him to do.



**[19:7]** This sign happened to Jared at the end of his four hundred and fiftieth year; as did also many other wonders, we do not record. But we record only this one for shortness sake, and in order not to lengthen our narrative.



**[19:8]** And Jared continued to teach his children eighty years; but after that they began to transgress the commandments he had given them, and to do many things without his counsel. They began to go down from the Holy Mountain one after another, and to mix with the children of Cain, in foul fellowships.



**[19:9]** Now the reason for which the children of Jared went down the Holy Mountain, is this, that we will now reveal unto you.



**[20:1]** After Cain had gone down to the land of dark soil, and his children had multiplied therein, there was one of them, whose name was Genun, son of Lamech the blind who slew Cain.



**[20:2]** But as to this Genun, Satan came into him in his childhood; and he made sundry trumpets and horns, and string instruments, cymbals and psalteries, and lyres and harps, and flutes; and he played on them at all times and at every hour.



**[20:3]** And when he played on them, Satan came into them, so that from among them were heard beautiful and sweet sounds, that ravished the heart.



**[20:4]** Then he gathered companies upon companies to play on them; and when they played, it pleased well the children of Cain, who inflamed themselves with sin among themselves, and burnt as with fire; while Satan inflamed their hearts, one with another, and increased lust among them.



**[20:5]** Satan also taught Genun to bring strong drink out of corn; and this Genun used to bring together companies upon companies in drink-houses; and brought into their hands all manner of fruits and flowers; and they drank together.



**[20:6]** Thus did this Genun multiply sin exceedingly; he also acted with pride, and taught the children of Cain to commit all manner of the grossest wickedness, which they knew not; and put them up to manifold doings which they knew not before.



**[20:7]** Then Satan, when he saw that they yielded to Genun and hearkened to him in every thing he told them, rejoiced greatly, increased Genun's understanding until he took iron and with it made weapons of war.



**[20:8]** Then when they were drunk, hatred and murder increased among them; one man used violence against another to teach him evil taking his children and defiling them before him.



**[20:9]** And when men saw they were overcome, and saw others that were not overpowered, those who were beaten came to Genun, took refuge with him, and he made them his confederates.



**[20:10]** Then sin increased among them greatly; until a man married his own sister, or daughter, or mother, and others; or the daughter of his father's sister, so that there was no more distinction of relationship, and they no longer knew what is iniquity; but did wickedly, and the earth was defiled with sin; and they angered God the Judge, who had created them.



**[20:11]** But Genun gathered together companies upon companies, that played on horns and on all the other instruments we have already mentioned, at the foot of the Holy Mountain; and they did so in order that the children of Seth who were on the Holy Mountain should hear it.



**[20:12]** But when the children of Seth heard the noise, they wondered, and came by companies, and stood on the top of the mountain to look at those below; and they did thus a whole year.



**[20:13]** When, at the end of that year, Genun saw that they were being won over to him little by little, Satan entered into him, and taught him to make dyeing - stuffs for garments of divers patterns, and made him understand how to dye crimson and purple and what not.



**[20:14]** And the sons of Cain who wrought all this, and shone in beauty and gorgeous apparel, gathered together at the foot of the mountain in splendour, with horns and gorgeous dresses, and horse races, committing all manner of abominations.



**[20:15]** Meanwhile the children of Seth, who were on the Holy Mountain, prayed and praised God, in the place of the hosts of angels who had fallen; wherefore God had called them 'angels," because He rejoiced over them greatly.



**[20:16]** But after this, they no longer kept His commandment, nor held by the promise He had made to their fathers; but they relaxed from their fasting and praying, and from the counsel of Jared their father. And they kept on gathering together on the top of the mountain, to look upon the children of Cain, from morning until evening, and upon what they did, upon their beautiful dresses and ornaments.



**[20:17]** Then the children of Cain looked up from below, and saw the children of Seth, standing in troops on the top of the mountain; and they called to them to come down to them.



**[20:18]** But the children of Seth said to them from above, "We don't know the way." Then Genun, the son of Lamech, heard them say they did not know the way, and he bethought himself how he might bring them down.



**[20:19]** Then Satan appeared to him by night, saying, "There is no way for them to come down from the mountain on which they dwell; but when they come to-morrow, say to them, 'Come ye to the western side of the mountain; there you will find the way of a stream of water, that comes down to the foot of the mountain, between two hills; come down that way to us."



**[20:20]** Then when it was day, Genun blew the horns and beat the drums below the mountain, as he was wont. The children of Seth heard it, and came as they used to do.



**[20:21]** Then Genun said to them from down below, "Go to the western side of the mountain, there you will find the way to come down."



**[20:22]** But when the children of Seth heard these words from him, they went back into the cave to Jared, to tell him all they had heard.



**[20:23]** Then when Jared heard it, he was grieved; for he knew that they would transgress his counsel.



**[20:24]** After this a hundred men of the children of Seth gathered together, and said among themselves, "Come, let us go down to the children of Cain, and see what they do, and enjoy ourselves with them."



**[20:25]** But when Jared heard this of the hundred men, his very soul was moved, and his heart was grieved. He then arose with great fervour, and stood in the midst of them, and adjured them by the blood of Abel the just, "Let not one of you go down from this holy and pure mountain, in which our fathers have ordered us to dwell."



**[20:26]** But when Jared saw that they did not receive his words, he said unto them, "0 my good and innocent and holy children, know that when once you go down from this holy mountain, God will not allow you to return again to it."



**[20:27]** He again adjured them, saying, "I adjure by the death of our father Adam, and by the blood of Abel, of Seth, of Enos, of Cainan, and of Mahalaleel, to hearken to me, and not to go down from this holy mountain; for the moment you leave it, you will be reft of life and of mercy; and you shall no longer be called 'children of God,' but 'children of the devil.'



**[20:28]** But they would not hearken to his words.



**[20:29]** Enoch at that time was already grown up, and in his zeal for God, he arose and said, "Hear me, 0 ye sons of Seth, small and great-when ye transgress the commandment of our fathers, and go down from this holy mountain-ye shall not come up hither again for ever."



**[20:30]** But they rose up against Enoch, and would not hearken to his words, but went down from the Holy Mountain.



**[20:31]** And when they looked at the daughters of Cain, at their beautiful figures, and at their hands and feet dyed with colour, and tattooed in ornaments on their faces, the fire of sin was kindled in them.



**[20:32]** Then Satan made them look most beautiful before the sons of Seth, as he also made the sons of Seth appear of the fairest in the eyes of the daughters of Cain, so that the daughters of Cain lusted after the sons of Seth like ravenous beasts, and the sons of Seth after the daughters of Cain, until they committed abomination with them.



**[20:33]** But after they had thus fallen into this defilement, they returned by the way they had come, and tried to ascend the Holy Mountain. But they could not, because the stones of that holy mountain were of fire flashing before them, by reason of which they could not go up again.



**[20:34]** And God was angry with them, and repented of them because they had come down from glory, and had thereby lost or forsaken their own purity or innocence, and were fallen into the defilement of sin.



**[20:35]** Then God sent His Word to Jared, saying, "These thy children, whom thou didst call 'My children,' - behold they have transgressed My commandment, and have gone down to the abode of perdition, and of sin. Send a messenger to those that are left, that they may not go down, and be lost."



**[20:36]** Then Jared wept before the Lord, and asked of Him mercy and forgiveness. But he wished that his soul might depart from his body, rather than hear these words from God about the going down of his children from the Holy Mountain.



**[20:37]** But he followed God's order, and preached unto them not to go down from that holy mountain, and not to hold intercourse with the children of Cain.



**[20:38]** But they heeded not his message, and would not obey his counsel.



**[21:1]** After this another company gathered together, and they went to look after their brethren; but they perished as well as they. And so it was, company after company, until only a few of them were left.



**[21:2]** Then Jared sickened from grief, and his sickness was such that the day of his death drew near.



**[21:3]** Then he called Enoch his eldest son, and Methuselah Enoch's son, and Lamech the son of Methuselah, and Noah the son of Lamech.



**[21:4]** And when they were come to him he prayed over them and blessed them, and said to them, "Ye are righteous, innocent sons; go ye not down from this holy mountain; for behold, your children and your children's children have gone down from this holy mountain, and have estranged themselves from this holy mountain, through their abominable lust and transgression of God's commandment.



**[21:5]** "But I know, through the power of God, that He will not leave you on this holy mountain, because your children have transgressed His commandment and that of our fathers, which we had received from them.



**[21:6]** "But, 0 my sons, God will take you to a strange land, and ye never shall again return to behold with your eyes this garden and this holy mountain.



**[21:7]** "Therefore, 0 my sons, set your hearts on your own selves, and keep the commandment of God which is with you. And when you go from this holy mountain, into a strange land which ye know not, take with you the body of our father Adam, and with it these three precious gifts and offerings, namely, the gold, the incense, and the myrrh; and let them be in the place where the body of our father Adam shall lay.



**[21:8]** "And unto him of you who shall be left, 0 my sons, shall the Word of God come, and when he goes out of this land he shall take with him the body of our father Adam, and shall lay it in the middle of the earth, the place in which salvation shall be wrought."



**[21:9]** Then Noah said unto him, "Who is he of us that shall be left?"



**[21:10]** And Jared answered, "Thou art he that shall be left. And thou shalt take the body of our father Adam from the cave, and place it with thee in the ark when the flood comes.



**[21:11]** "And thy son Shem, who shall come out of thy loins, he it is who shall lay the body of our father Adam in the middle of the earth, in the place whence salvation shall come."



**[21:12]** Then Jared turned to his son Enoch, and said unto him "Thou, my son, abide in this cave, and minister diligently before the body of our father Adam all the days of thy life; and feed thy people in righteousness and innocence."



**[21:13]** And Jared said no more. His hands were loosened, his eyes closed, and he entered into rest like his fathers. His death took place in the three hundred and sixtieth year of Noah, and in the nine hundred and eighty-ninth year of his own life; on the twelfth of Takhsas on a Friday.



**[21:14]** But as Jared died, tears streamed down his face by reason of his great sorrow, for the children of Seth, who had fallen in his days.



**[21:15]** Then Enoch, Methuselah, Lamech and Noah, these four, wept over him; embalmed him carefully, and then laid him in the Cave of Treasures. Then they rose and mourned for him forty days.



**[21:16]** And when these days of mourning were ended, Enoch, Methuselah, Lamech and Noah remained in sorrow of heart, because their father had departed from them, and they saw him no more.



**[22:1]** But Enoch kept the commandment of Jared his father, and continued to minister in the cave.



**[22:2]** It is this Enoch to whom many wonders happened, and who also wrote a celebrated book; but those wonders may not be told in this place.



**[22:3]** Then after this, the children of Seth went astray and fell, they, their children and their wives. And when Enoch, Methuselah, Lamech and Noah saw them, their hearts suffered by reason of their fall into doubt full of unbelief; and they wept and sought of God mercy, to preserve them, and to bring them out of that wicked generation.



**[22:4]** Enoch continued in his ministry before the Lord three hundred and eighty-five years, and at the end of that time he became aware through the grace of God, that God intended to remove him from the earth.



**[22:5]** He then said to his son, "0 my son, I know that God intends to bring the waters of the Flood upon the earth, and to destroy our creation.



**[22:6]** "And ye are the last rulers over this people on this mountain; for I know that not one will be left you to beget children on this holy mountain; neither shall any one of you rule over the children of his people; neither shall any great company be left of you, on this mountain."



**[22:7]** Enoch said also to them, "Watch over your souls, and hold fast by your fear of God and by your service of Him, and worship Him in upright faith, and serve Him in righteousness, innocence and judgment, in repentance and also in purity."



**[22:8]** When Enoch had ended his commandments to them, God transported him from that mountain to the land of life, to the mansions of the righteous and of the chosen, the abode of Paradise of joy, in light that reaches up to heaven; light that is outside the light of this world; for it is the light of God, that fills the whole world, but which no place can contain.



**[22:9]** Thus, because Enoch was in the light of God, he found himself out of the reach of death; until God would have him die.



**[22:10]** Altogether, not one of our fathers or of their children, remained on that holy mountain, except those three, Methuselah, Lamech, and Noah. For all the rest went down from the mountain and fell into sin with the children of Cain. Therefore were they forbidden that mountain, and none remained on it but those three men.



