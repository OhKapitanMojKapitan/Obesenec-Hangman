# Fourth Baruch



**[1:1]** It came to pass, when the children of Israel were taken captive by the king of the Chaldeans, that God spoke to Jeremiah saying: Jeremiah, my chosen one, arise and depart from this city, you and Baruch, since I am going to destroy it because of the multitude of the sins of those who dwell in it.

**[1:2]** For your prayers are like a solid pillar in its midst, and like an indestructible wall surrounding it.

**[1:3]** Now, then, arise and depart before the host of the Chaldeans surrounds it.

**[1:4]** And Jeremiah answered, saying: I beseech you, Lord, permit me, your servant, to speak in your presence.

**[1:5]** And the Lord said to him: Speak, my chosen one Jeremiah.

**[1:6]** And Jeremiah spoke, saying: Lord Almighty, would you deliver the chosen city into the hands of the Chaldeans, so that the king with the multitude of his people might boast and say: "I have prevailed over the holy city of God"?

**[1:7]** No, my Lord, but if it is your will, let it be destroyed by your hands.

**[1:8]** And the Lord said to Jeremiah: Since you are my chosen one, arise and depart form this city, you and Baruch, for I am going to destroy it because of the multitude of the sins of those who dwell in it.

**[1:9]** For neither the king nor his host will be able to enter it unless I first open its gates.

**[1:10]** Arise, then, and go to Baruch, and tell him these words.

**[1:11]** And when you have arisen at the sixth hour of the night, go out on the city walls and I will show you that unless I first destroy the city, they cannot enter it.

**[1:12]** When the Lord had said this, he departed from Jeremiah.

**[2:1]** And Jeremiah ran and told these things to Baruch; and as they went into the temple of God, Jeremiah tore his garments and put dust on his head and entered the holy place of God.

**[2:2]** And when Baruch saw him with dust sprinkled on his head and his garments torn, he cried out in a loud voice, saying: Father Jeremiah, what are you doing? What sin has the people committed?

**[2:3]** (For whenever the people sinned, Jeremiah would sprinkle dust on his head and would pray for the people until their sin was forgiven.)

**[2:4]** So Baruch asked him, saying: Father, what is this?

**[2:5]** And Jeremiah said to him: Refrain from rending your garments -- rather, let us rend our hearts! And let us not draw water for the trough, but let us weep and fill them with tears! For the Lord will not have mercy on this people.

**[2:6]** And Baruch said: Father Jeremiah, what has happened?

**[2:7]** And Jeremiah said: God is delivering the city into the hands of the king of the Chaldeans, to take the people captive into Babylon.

**[2:8]** And when Baruch heard these things, he also tore his garments and said: Father Jeremiah, who has made this known to you?

**[2:9]** And Jeremiah said to him: Stay with me awhile, until the sixth hour of the night, so that you may know that this word is true.

**[2:10]** Therefore they both remained in the altar-area weeping, and their garments were torn.

**[3:1]** And when the hour of the night arrived, as the Lord had told Jeremiah they came up together on the walls of the city, Jeremiah and Baruch.

**[3:2]** And behold, there came a sound of trumpets; and angels emerged from heaven holding torches in their hands, and they set them on the walls of the city.

**[3:3]** And when Jeremiah and Baruch saw them, they wept, saying: Now we know that the word is true!

**[3:4]** And Jeremiah besought the angels, saying: I beseech you, do not destroy the city yet, until I say something to the Lord.

**[3:5]** And the Lord spoke to the angels, saying: Do not destroy the city until I speak to my chosen one, Jeremiah.

**[3:6]** Then Jeremiah spoke, saying: I beg you, Lord, bid me to speak in your presence.

**[3:7]** And the Lord said: Speak, my chosen one Jeremiah.

**[3:8]** And Jeremiah said: Behold, Lord, now we know that you are delivering the city into the hands of its enemies, and they will take the people away to Babylon. What do you want me to do with the holy vessels of the temple service?

**[3:10]** And the Lord said to him: Take them and consign them to the earth, saying: Hear, Earth, the voice of your creator who formed you in the abundance of waters, who sealed you with seven seals for seven epochs, and after this you will receive your ornaments (?) --

**[3:11]** Guard the vessels of the temple service until the gathering of the beloved.

**[3:12]** And Jeremiah spoke, saying: I beseech you, Lord, show me what I should do for Abimelech the Ethiopian, for he has done many kindnesses to your servant Jeremiah.

**[3:13]** For he pulled me out of the miry pit; and I do not wish that he should see the destruction and desolation of this city, but that you should be merciful to him and that he should not be grieved.

**[3:14]** And the Lord said to Jeremiah: Send him to the vineyard of Agrippa, and I will hide him in the shadow of the mountain until I cause the people to return to the city.

**[3:15]** And you, Jeremiah, go with your people into Babylon and stay with them, preaching to them, until I cause them to return to the city.

**[3:16]** But leave Baruch here until I speak with him.

**[3:17]** When he had said these things, the Lord ascended from Jeremiah into heaven.

**[3:18]** But Jeremiah and Baruch entered the holy place, and taking the vessels of the temple service, they consigned them to the earth as the Lord had told them.

**[3:19]** And immediately the earth swallowed them.

**[3:20]** And they both sat down and wept.

**[3:21]** And when morning came, Jeremiah sent Abimelech, saying: Take a basket and go to the estate of Agrippa by the mountain road, and bring back some figs to give to the sick among the people; for the favor of the Lord is on you and his glory is on your head.

**[3:22]** And when he had said this, Jeremiah sent him away; and Abimelech went as he told him.

**[4:1]** And when morning came, behold the host of the Chaldeans surrounded the city.

**[4:2]** And the great angel trumpeted, saying: Enter the city, host of the Chaldeans; for behold, the gate is opened for you.

**[4:3]** Therefore let the king enter, with his multitudes, and let him take all the people captive.

**[4:4]** But taking the keys of the temple, Jeremiah went outside the city and threw them away in the presence of the sun, saying: I say to you, Sun, take the keys of the temple of God and guard them until the day in which the Lord asks you for them.

**[4:5]** For we have not been found worthy to keep them, for we have become unfaithful guardians.

**[4:6]** While Jeremiah was still weeping for the people, they brought him out with the people and dragged them into Babylon.

**[4:7]** But Baruch put dust on his head and sat and wailed this lamentation, saying: Why has Jerusalem been devastated? Because of the sins of the beloved people she was delivered into the hands of enemies -- because of our sins and those of the people.

**[4:8]** But let not the lawless ones boast and say: "We were strong enough to take the city of God by our might;" but it was delivered to you because of our sins.

**[4:9]** And God will pity us and cause us to return to our city, but you will not survive!

**[4:10]** Blessed are our fathers, Abraham, Isaac and Jacob, for they departed from this world and did not see the destruction of this city.

**[4:11]** When he had said this, Baruch departed from the city, weeping and saying: Grieving because of you, Jerusalem, I went out from you.

**[4:12]** And he remained sitting in a tomb, while the angels came to him and explained to him everything that the Lord revealed to him through them.

**[5:1]** But Abimelech took the figs in the burning heat; and coming upon a tree, he sat under its shade to rest a bit.

**[5:2]** And leaning his head on the basket of figs, he fell asleep and slept for 66 years; and he was not awakened from his slumber.

**[5:3]** And afterward, when he awoke from his sleep, he said: I slept sweetly for a little while, but my head is heavy because I did not get enough sleep.

**[5:4]** Then he uncovered the basket of figs and found them dripping milk.

**[5:5]** And he said: I would like to sleep a little longer, because my head is heavy. But I am afraid that I might fall asleep and be late in awakening and my father Jeremiah would think badly of me; for if he were not in a hurry, he would not have sent me today at daybreak.

**[5:6]** So I will get up, and proceed in the burning heat; for isn't there heat, isn't there toil every day?

**[5:7]** So he got up and took the basket of figs and placed it on his shoulders, and he entered into Jerusalem and did not recognize it -- neither his own house, nor the place -- nor did he find his own family or any of his acquaintances.

**[5:8]** And he said: The Lord be blessed, for a great trance has come over me today!

**[5:9]** This is not the city Jerusalem -- and I have lost my way because I came by the mountain road when I arose from my sleep; and since my head was heavy because I did not get enough sleep, I lost my way.

**[5:10]** It will seem incredible to Jeremiah that I lost my way!

**[5:11]** And he departed from the city; and as he searched he saw the landmarks of the city, and he said: Indeed, this is the city; I lost my way.

**[5:12]** And again he returned to the city and searched, and found no one of his own people; and he said: The Lord be blessed, for a great trance has come over me!

**[5:13]** And again he departed from the city, and he stayed there grieving, not knowing where he should go.

**[5:14]** And he put down the basket, saying: I will sit here until the Lord takes this trance from me.

**[5:15]** And as he sat, he saw an old man coming from the field; and Abimelech said to him: I say to you, old man, what city is this?

**[5:16]** And he said to him: It is Jerusalem.

**[5:17]** And Abimelech said to him: Where is Jeremiah the priest, and Baruch the secretary, and all the people of this city, for I could not find them?

**[5:18]** And the old man said to him: Are you not from this city, seeing that you remember Jeremiah today, because you are asking about him after such a long time?

**[5:19]** For Jeremiah is in Babylon with the people; for they were taken captive by king Nebuchadnezzar, and Jeremiah is with them to preach the good news to them and to teach them the word.

**[5:20]** As soon as Abimelech heard this from the old man, he said: If you were not an old man, and if it were not for the fact that it is not lawful for a man to upbraid one older than himself, I would laugh at you and say that you are out of your mind -- since you say that the people have been taken captive into Babylon.

**[5:21]** Even if the heavenly torrents had descended on them, there has not yet been time for them to go into Babylon!

**[5:22]** For how much time has passed since my father Jeremiah sent me to the estate of Agrippa to bring a few figs, so that I might give them to the sick among the people?

**[5:23]** And I went and got them, and when I came to a certain tree in the burning heat, I sat to rest a little; and I leaned my head on the basket and fell asleep.

**[5:24]** And when I awoke I uncovered the basket of figs, supposing that I was late; and I found the figs dripping milk, just as I had collected them.

**[5:25]** But you claim that the people have been taken captive into Babylon.

**[5:26]** But that you might know, take the figs and see!

**[5:27]** And he uncovered the basket of figs for the old man, and he saw them dripping milk.

**[5:28]** And when the old man saw them, he said: O my son, you are a righteous man, and God did not want you to see the desolation of the city, so he brought this trance upon you.

**[5:29]** For behold it is 66 years today since the people were taken captive into Babylon.

**[5:30]** But that you might learn, my son, that what I tell you is true -- look into the field and see that the ripening of the crops has not appeared.

**[5:31]** And notice that the figs are not in season, and be enlightened.

**[5:32]** Then Abimelech cried out in a loud voice, saying: I bless you, God of heaven and earth, the Rest of the souls of the righteous in every place!

**[5:33]** Then he said to the old man: What month is this?

**[5:34]** And he said: Nisan (which is Abib).

**[5:35]** And taking some of figs, he gave them to the old man and said to him: May God illumine your way to the city above, Jerusalem. 6

**[6:1]** After this, Abimelech went out of the city and prayed to the Lord.

**[6:2]** And behold, an angel of the Lord came and took him by the right hand and brought him back to where Baruch was sitting, and he found him in a tomb.

**[6:3]** And when they saw each other, they both wept and kissed each other.

**[6:4]** But when Baruch looked up he saw with his own eyes the figs that were covered in Abimelech's basket.

**[6:5]** And lifting his eyes to heaven, he prayed, saying:

**[6:6]** You are the God who gives a reward to those who love you. Prepare yourself, my heart, and rejoice and be glad while you are in your tabernacle, saying to your fleshly house, "your grief has been changed to joy;" for the Sufficient One is coming and will deliver you in your tabernacle -- for there is no sin in you.

**[6:7]** Revive in your tabernacle, in your virginal faith, and believe that you will live!

**[6:8]** Look at this basket of figs -- for behold, they are 66 years old and have not become shrivelled or rotten, but they are dripping milk.

**[6:9]** So it will be with you, my flesh, if you do what is commanded you by the angel of righteousness.

**[6:10]** He who preserved the basket of figs, the same will again preserve you by his power.

**[6:11]** When Baruch had said this, he said to Abimelech: Stand up and let us pray that the Lord may make known to us how we shall be able to send to Jeremiah in Babylon the report about the shelter provided for you on the way.

**[6:12]** And Baruch prayed, saying: Lord God, our strength is the elect light which comes forth from your mouth.

**[6:13]** We beseech and beg of your goodness -- you whose great name no one is able to know -- hear the voice of your servants and let knowledge come into our hearts.

**[6:14]** What shall we do, and how shall we send this report to Jeremiah in Babylon?

**[6:15]** And while Baruch was still praying, behold an angel of the Lord came and said all these words to Baruch: Agent of the light, do not be anxious about how you will send to Jeremiah; for an eagle is coming to you at the hour of light tomorrow, and you will direct him to Jeremiah.

**[6:16]** Therefore, write in a letter: Say to the children of Israel: Let the stranger who comes among you be set apart and let 15 days go by; and after this I will lead you into your city, says the Lord.

**[6:17]** He who is not separated from Babylon will not enter into the city; and I will punish them by keeping them from being received back by the Babylonians, says the Lord.

**[6:18]** And when the angel had said this, he departed from Baruch.

**[6:19]** And Baruch sent to the market of the gentiles and got papyrus and ink and wrote a letter as follows: Baruch, the servant of God, writes to Jeremiah in the captivity of Babylon:

**[6:20]** Greetings! Rejoice, for God has not allowed us to depart from this body grieving for the city which was laid waste and outraged.

**[6:21]** Wherefore the Lord has had compassion on our tears, and has remembered the covenant which he established with our fathers Abraham, Isaac and Jacob.

**[6:22]** And he sent his angel to me, and he told me these words which I send to you.

**[6:13]** These, then, are the words which the Lord, the God of Israel, spoke, who led us out of Egypt, out of the great furnace: Because you did not keep my ordinances, but your heart was lifted up, and you were haughty before me, in anger and wrath I delivered you to the furnace in Babylon.

**[6:24]** If, therefore, says the Lord, you listen to my voice, from the mouth of Jeremiah my servant, I will bring the one who listens up from Babylon; but the one who does not listen will become a stranger to Jerusalem and to Babylon.

**[6:25]** And you will test them by means of the water of the Jordan; whoever does not listen will be exposed -- this is the sign of the great seal.

**[7:1]** And Baruch got up and departed from the tomb and found the eagle sitting outside the tomb.

**[7:2]** And the eagle said to him in a human voice: Hail, Baruch, steward of the faith.

**[7:3]** And Baruch said to him: You who speak are chosen from among all the birds of heaven, for this is clear from the gleam of your eyes; tell me, then, what are you doing here?

**[7:4]** And the eagle said to him: I was sent here so that you might through me send whatever message you want.

**[7:5]** And Baruch said to him: Can you carry this message to Jeremiah in Babylon?

**[7:6]** And the eagle said to him: Indeed, it was for this reason I was sent.

**[7:7]** And Baruch took the letter, and 15 figs from Abimelech's basket, and tied them to the eagle's neck and said to him: I say to you, king of the birds, go in peace with good health and carry the message for me.

**[7:8]** Do not be like the raven which Noah sent out and which never came back to him in the ark; but be like the dove which, the third time, brought a report to the righteous one.

**[7:9]** So you also, take this good message to Jeremiah and to those in bondage with him, that it may be well with you-take this papyrus to the people and to the chosen one of God.

**[7:10]** Even if all the birds of heaven surround you and want to fight with you, struggle -- the Lord will give you strength.

**[7:11]** And do not turn aside to the right or to the left, but straight as a speeding arrow, go in the power of God, and the glory of the Lord will be with you the entire way.

**[7:12]** Then the eagle took flight and went away to Babylon, having the letter tied to his neck; and when he arrived he rested on a post outside the city in a desert place.

**[7:13]** And he kept silent until Jeremiah came along, for he and some of the people were coming out to bury a corpse outside the city.

**[7:14]** (For Jeremiah had petitioned king Nebuchadnezzar, saying: "Give me a place where I may bury those of my people who have died;" and the king gave it to him.)

**[7:15]** And as they were coming out with the body, and weeping, they came to where the eagle was.

**[7:16]** And the eagle cried out in a loud voice, saying: I say to you, Jeremiah the chosen one of God, go and gather together the people and come here so that they may hear a letter which I have brought to you from Baruch and Abimelech.

**[7:17]** And when Jeremiah heard this, he glorified God; and he went and gathered together the people along with their wives and children, and he came to where the eagle was.

**[7:18]** And the eagle came down on the corpse, and it revived.

**[7:19]** (Now this took place so that they might believe.)

**[7:20]** And all the people were astounded at what had happened, and said: This is the God who appeared to our fathers in the wilderness through Moses, and now he has appeared to us through the eagle.

**[7:21]** And the eagle said: I say to you, Jeremiah, come, untie this letter and read it to the people -- So he untied the letter and read it to the people.

**[7:22]** And when the people heard it, they wept and put dust on their heads, and they said to Jeremiah: Deliver us and tell us what to do that we may once again enter our city.

**[7:23]** And Jeremiah answered and said to them: Do whatever you heard from the letter, and the Lord will lead us into our city.

**[7:24]** And Jeremiah wrote a letter to Baruch, saying thus: My beloved son, do not be negligent in your prayers, beseeching God on our behalf, that he might direct our way until we come out of the jurisdiction of this lawless king.

**[7:25]** For you have been found righteous before God, and he did not let you come here, lest you see the affliction which has come upon the people at the hands of the Babylonians.

**[7:26]** For it is like a father with an only son, who is given over for punishment; and those who see his father and console him cover his face, lest he see how his son is being punished, and be even more ravaged by grief.

**[7:27]** For thus God took pity on you and did not let you enter Babylon lest you see the affliction of the people.

**[7:28]** For since we came here, grief has not left us, for 66 years today.

**[7:29]** For many times when I went out I found some of the people hung up by king Nebuchadnezzar, crying and saying: "Have mercy on us, God-ZAR!"

**[7:30]** When I heard this, I grieved and cried with two-fold mourning, not only because they were hung up, but because they were calling on a foreign God, saying "Have mercy on us."

**[7:31]** But I remembered days of festivity which we celebrated in Jerusalem before our captivity; and when I remembered, I groaned, and returned to my house wailing and weeping.

**[7:32]** Now, then, pray in the place where you are -- you and Abimelech -- for this people, that they may listen to my voice and to the decrees of my mouth, so that we may depart from here.

**[7:33]** For I tell you that the entire time that we have spent here they have kept us in subjection, saying: Recite for us a song from the songs of Zion -- the song of your God.

**[7:34]** And we reply to them: How shall we sing for you since we are in a foreign land?

**[7:35]** And after this, Jeremiah tied the letter to the eagle's neck, saying: Go in peace, and may the Lord watch over both of us.

**[7:36]** And the eagle took flight and came to Jerusalem and gave the letter to Baruch; and when he had untied it he read it and kissed it and wept when he heard about the distresses and afflictions of the people.

**[7:37]** But Jeremiah took the figs and distributed them to the sick among the people, and he kept teaching them to abstain from the pollutions of the gentiles of Babylon. 6

**[8:1]** And the day came in which the Lord brought the people out of Babylon.

**[8:2]** And the Lord said to Jeremiah: Rise up -- you and the people -- and come to the Jordan and say to the people: Let anyone who desires the Lord forsake the works of Babylon.

**[8:3]** As for the men who took wives from them and the women who took husbands from them -- those who listen to you shall cross over, and you take them into Jerusalem; but those who do not listen to you, do not lead them there.

**[8:4]** And Jeremiah spoke these words to the people, and they arose and came to the Jordan to cross over.

**[8:5]** As he told them the words that the Lord had spoken to him, half of those who had taken spouses from them did not wish to listen to Jeremiah, but said to him: We will never forsake our wives, but we will bring them back with us into our city.

**[8:6]** So they crossed the Jordan and came to Jerusalem.

**[8:7]** And Jeremiah and Baruch and Abimelech stood up and said: No man joined with Babylonians shall enter this city!

**[8:8]** And they said to one another: Let us arise and return to Babylon to our place -- And they departed.

**[8:9]** But while they were coming to Babylon, the Babylonians came out to meet them, saying: You shall not enter our city, for you hated us and you left us secretly; therefore you cannot come in with us.

**[8:10]** For we have taken a solemn oath together in the name of our god to receive neither you nor your children, since you left us secretly.

**[8:11]** And when they heard this, they returned and came to a desert place some distance from Jerusalem and built a city for themselves and named it 'SAMARIA.'

**[8:12]** And Jeremiah sent to them, saying: Repent, for the angel of righteousness is coming and will lead you to your exalted place.

**[9:1]** Now those who were with Jeremiah were rejoicing and offering sacrifices on behalf of the people for nine days.

**[9:2]** But on the tenth, Jeremiah alone offered sacrifice.

**[9:3]** And he prayed a prayer, saying: Holy, holy, holy, fragrant aroma of the living trees, true light that enlightens me until I ascend to you;

**[9:4]** For your mercy, I beg you -- for the sweet voice of the two seraphim, I beg -- for another fragrant aroma.

**[9:5]** And may Michael, archangel of righteousness, who opens the gates to the righteous, be my guardian (?) until he causes the righteous to enter.

**[9:6]** I beg you, almighty Lord of all creation, unbegotten and incomprehensible, in whom all judgment was hidden before these things came into existence.

**[9:7]** When Jeremiah had said this, and while he was standing in the altar-area with Baruch and Abimelech, he became as one whose soul had departed.

**[9:8]** And Baruch and Abimelech were weeping and crying out in a loud voice: Woe to us! For our father Jeremiah has left us -- the priest of God has departed!

**[9:9]** And all the people heard their weeping and they all ran to them and saw Jeremiah lying on the ground as if dead.

**[9:10]** And they tore their garments and put dust on their heads and wept bitterly.

**[9:11]** And after this they prepared to bury him.

**[9:12]** And behold, there came a voice saying: Do not bury the one who yet lives, for his soul is returning to his body!

**[9:13]** And when they heard the voice they did not bury him, but stayed around his tabernacle for three days saying, "when will he arise?"

**[9:14]** And after three days his soul came back into his body and he raised his voice in the midst of them all and said: Glorify God with one voice! All of you glorify God and the son of God who awakens us -- messiah Jesus -- the light of all the ages, the inextinguishable lamp, the life of faith.

**[9:15]** But after these times there shall be 477 years more and he comes to earth.

**[9:16]** And the tree of life planted in the midst of paradise will cause all the unfruitful trees to bear fruit, and will grow and sprout forth.

**[9:17]** And the trees that had sprouted and became haughty and said: "We have supplied our power (?) to the air," he will cause them to wither, with the grandeur of their branches, and he will cause them to be judged -- that firmly rooted tree!

**[9:18]** And what is crimson will become white as wool -- the snow will be blackened -- the sweet waters will become salty, and the salty sweet, in the intense light of the joy of God.

**[9:19]** And he will bless the isles so that they become fruitful by the word of the mouth of his messiah.

**[9:20]** For he shall come, and he will go out and choose for himself twelve apostles to proclaim the news among the nations-- he whom I have seen adorned by his father and coming into the world on the Mount of Olives -- and he shall fill the hungry souls.

**[9:21]** When Jeremiah was saying this concerning the son of God -- that he is coming into the world -- the people became very angry and said: This is a repetition of the words spoken by Isaiah son of Amos, when he said: I saw God and the son of God.

**[9:22]** Come, then, and let us not kill him by the same sort of death with which we killed Isaiah, but let us stone him with stones.

**[9:23]** And Baruch and Abimelech were greatly grieved because they wanted to hear in full the mysteries that he had seen.

**[9:24]** But Jeremiah said to them: Be silent and weep not, for they cannot kill me until I describe for you everything I saw.

**[9:25]** And he said to them: Bring a stone here to me.

**[9:26]** And he set it up and said: Light of the ages, make this stone to become like me in appearance, until I have described to Baruch and Abimelech everything I saw.

**[9:27]** Then the stone, by God's command, took on the appearance of Jeremiah.

**[9:28]** And they were stoning the stone, supposing that it was Jeremiah!

**[9:29]** But Jeremiah delivered to Baruch and to Abimelech all the mysteries he had seen, and forthwith he stood in the midst of the people desiring to complete his ministry.

**[9:30]** Then the stone cried out, saying: O foolish children of Israel, why do you stone me, supposing that I am Jeremiah? Behold, Jeremiah is standing in your midst!

**[9:31]** And when they saw him, immediately they rushed upon him with many stones, and his ministry was fulfilled.

**[9:32]** And when Baruch and Abimelech came, they buried him, and taking the stone they placed it on his tomb and inscribed it thus: This is the stone that was the ally of Jeremiah.

