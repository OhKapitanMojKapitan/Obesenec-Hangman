# Scripts Folder

Generally this is a python / linux environment made for managing and updating the documents.